#!/usr/bin/env Rscript
# 07_annotation_sensitivity.R -- Annotation-definition and minimum-cell sensitivity of the pseudobulk
# contrasts (Additional file 11, Additional file 13).
#
# Statistical calls are unchanged from the submitted analysis; only input and
# output locations are resolved through scripts/00_setup.R.

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
source(file.path(nihl_paths$scripts, 'utils.R'))
nihl_require_versions('3.62.2', '4.4.2')

suppressPackageStartupMessages(library(Matrix))
set.seed(20260713)

root <- Sys.getenv('NIHL_ANALYSIS_ROOT', 'outputs/NIHL_submission')
src_dir <- file.path(root, 'source_data', 'cell_annotation_sensitivity')
out_dir <- file.path(root, 'results', 'cell_annotation_sensitivity')
dir.create(src_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

meta <- read.csv(nihl_inputs$GSE168041_metadata, stringsAsFactors = FALSE)
master <- read.csv(nihl_inputs$GSE168041_gene_map, stringsAsFactors = FALSE)
markers <- read.csv(nihl_inputs$cell_type_markers, stringsAsFactors = FALSE)
cm <- read.csv(gzfile(file.path(root, 'source_data', 'GSE168041_celltype',
  'cell_metadata_marker_guided.csv.gz')), stringsAsFactors = FALSE)

hallmark_lines <- strsplit(readLines(
  Sys.getenv('NIHL_HUMAN_GMT',
    nihl_inputs$human_gmt)), '\t')
hallmark_lines <- hallmark_lines[lengths(hallmark_lines) >= 3]
hallmark <- lapply(hallmark_lines, function(x) unique(toupper(x[-c(1, 2)])))
names(hallmark) <- vapply(hallmark_lines, `[[`, character(1), 1)
core_pathways <- c('HALLMARK_TNFA_SIGNALING_VIA_NFKB',
  'HALLMARK_INFLAMMATORY_RESPONSE', 'HALLMARK_OXIDATIVE_PHOSPHORYLATION',
  'HALLMARK_INTERFERON_GAMMA_RESPONSE', 'HALLMARK_E2F_TARGETS',
  'HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION')

camera_pr_exact <- function(statistic, pathways, inter_gene_cor = 0.01) {
  statistic <- statistic[is.finite(statistic)]
  names(statistic) <- toupper(names(statistic))
  statistic <- statistic[!duplicated(names(statistic))]
  G <- length(statistic)
  index <- lapply(pathways, function(set) which(names(statistic) %in% set))
  valid <- lengths(index) >= 5L & lengths(index) < G - 2L
  tab <- limma::cameraPR(statistic, index = index[valid],
    inter.gene.cor = inter_gene_cor, sort = FALSE)
  score <- ifelse(tab$Direction == 'Up',
    qt(tab$PValue / 2, df = G - 2, lower.tail = FALSE),
    qt(tab$PValue / 2, df = G - 2))
  data.frame(pathway = rownames(tab), NGenes = tab$NGenes,
    Direction = tab$Direction, score = score, PValue = tab$PValue,
    within_class_FDR = tab$FDR, row.names = NULL,
    stringsAsFactors = FALSE)
}

strict_keep <- cm$cell_type != 'unassigned' & cm$top_marker_score >= 0.10 &
  cm$marker_score_margin >= 0.05
cm$strict_cell_type <- ifelse(strict_keep, cm$cell_type, 'unassigned')

confidence <- do.call(rbind, lapply(split(cm, cm$cell_type), function(z) {
  data.frame(cell_type = z$cell_type[1], n_cells = nrow(z),
    top_score_median = median(z$top_marker_score),
    top_score_q10 = quantile(z$top_marker_score, 0.10),
    margin_median = median(z$marker_score_margin),
    margin_q10 = quantile(z$marker_score_margin, 0.10),
    retained_strict_n = sum(z$strict_cell_type == z$cell_type[1]),
    retained_strict_fraction = mean(z$strict_cell_type == z$cell_type[1]),
    stringsAsFactors = FALSE)
}))
write.csv(confidence, file.path(src_dir, 'annotation_confidence_by_class.csv'),
  row.names = FALSE)

assignment <- data.frame(
  definition = c('primary_assigned', 'primary_unassigned', 'strict_assigned',
    'strict_unassigned'),
  n_cells = c(sum(cm$cell_type != 'unassigned'), sum(cm$cell_type == 'unassigned'),
    sum(cm$strict_cell_type != 'unassigned'),
    sum(cm$strict_cell_type == 'unassigned')),
  stringsAsFactors = FALSE)
assignment$fraction <- assignment$n_cells / nrow(cm)
write.csv(assignment, file.path(src_dir, 'assigned_unassigned_sensitivity.csv'),
  row.names = FALSE)

base_dir <- nihl_inputs$GSE168041_matrix_dir
all_strict_pb <- list()
strict_counts <- list()
marker_accum <- list()

for (i in seq_len(nrow(meta))) {
  sm <- meta[i, ]
  message('Marker/strict aggregation ', i, '/16: ', sm$sample_id)
  prefix <- file.path(base_dir, sm$sample_label)
  m <- as(readMM(gzfile(paste0(prefix, '_matrix.mtx.gz'))), 'CsparseMatrix')
  feat <- read.delim(gzfile(paste0(prefix, '_genes.tsv.gz')), header = FALSE,
    stringsAsFactors = FALSE)
  colnames(feat)[1:2] <- c('gene_id', 'gene_symbol')
  bc <- readLines(gzfile(paste0(prefix, '_barcodes.tsv.gz')))
  z <- cm[cm$sample_id == sm$sample_id, ]
  idx <- match(z$barcode, bc)
  stopifnot(all(!is.na(idx)))

  # Marker dot-plot quantities under the primary assigned labels.
  cohort_markers <- markers[markers$cohort_scope %in% c('both', sm$tissue_cohort), ]
  marker_idx <- match(toupper(cohort_markers$marker_gene), toupper(feat$gene_symbol))
  valid <- !is.na(marker_idx)
  mg <- cohort_markers$marker_gene[valid]
  mi <- marker_idx[valid]
  mm <- m[mi, idx, drop = FALSE]
  lib <- z$n_count
  mm_norm <- mm %*% Diagonal(x = 1e4 / pmax(lib, 1))
  mm_norm@x <- log1p(mm_norm@x)
  for (ct in setdiff(unique(z$cell_type), 'unassigned')) {
    cells <- which(z$cell_type == ct)
    if (!length(cells)) next
    key <- paste(sm$tissue_cohort, ct, sep = '__')
    marker_accum[[length(marker_accum) + 1]] <- data.frame(
      sample_id = sm$sample_id, tissue_cohort = sm$tissue_cohort,
      assigned_cell_type = ct, marker_gene = mg,
      mean_log_normalized = Matrix::rowMeans(mm_norm[, cells, drop = FALSE]),
      percent_expressing = Matrix::rowMeans(mm[, cells, drop = FALSE] > 0) * 100,
      n_cells = length(cells), stringsAsFactors = FALSE)
  }

  # Strict-annotation pseudobulks.
  for (ct in setdiff(unique(z$strict_cell_type), 'unassigned')) {
    cells_local <- which(z$strict_cell_type == ct)
    cells <- idx[cells_local]
    agg <- Matrix::rowSums(m[, cells, drop = FALSE])
    mapped <- numeric(nrow(master))
    map_idx <- match(sub('[.][0-9]+$', '', feat$gene_id),
      sub('[.][0-9]+$', '', master$gene_id))
    ok <- !is.na(map_idx)
    for (k in which(ok)) mapped[map_idx[k]] <- mapped[map_idx[k]] + agg[k]
    key <- paste(sm$sample_id, ct, sep = '__')
    all_strict_pb[[key]] <- mapped
    strict_counts[[key]] <- data.frame(sample_id = sm$sample_id,
      tissue_cohort = sm$tissue_cohort, condition = sm$condition,
      cell_type = ct, n_cells = length(cells), library_size = sum(mapped),
      stringsAsFactors = FALSE)
  }
  rm(m, mm, mm_norm)
  invisible(gc())
}

marker_source <- do.call(rbind, marker_accum)
write.csv(marker_source, file.path(src_dir, 'marker_dotplot_sample_level.csv'),
  row.names = FALSE)
strict_counts <- do.call(rbind, strict_counts)
write.csv(strict_counts, file.path(src_dir, 'strict_annotation_cell_counts.csv'),
  row.names = FALSE)
strict_pb <- do.call(cbind, all_strict_pb)
rownames(strict_pb) <- master$gene_id
saveRDS(strict_pb, file.path(src_dir, 'strict_annotation_pseudobulk_counts.rds'),
  compress = TRUE)

# Primary pseudobulk counts and metadata.
pb_file <- file.path(root, 'source_data', 'GSE168041_celltype',
  'mouse_celltype_pseudobulk_counts.csv.gz')
pb_df <- read.csv(gzfile(pb_file), stringsAsFactors = FALSE, check.names = FALSE)
pb <- as.matrix(pb_df[, -(1:2), drop = FALSE])
storage.mode(pb) <- 'numeric'
rownames(pb) <- pb_df$gene_id
cell_counts <- read.csv(file.path(root, 'source_data', 'GSE168041_celltype',
  'cell_counts_and_library_sizes.csv'), stringsAsFactors = FALSE)

fit_one <- function(counts, sample_info, tag) {
  condition <- factor(sample_info$condition, levels = c('naive', 'noise'))
  design <- model.matrix(~0 + condition)
  colnames(design) <- c('naive', 'noise')
  C <- matrix(c(-1, 1), ncol = 1,
    dimnames = list(colnames(design), 'noise_vs_naive'))
  keep <- filterByExpr(counts, design = design, min.count = 10,
    min.total.count = 15)
  cf <- counts[keep, , drop = FALSE]
  nf <- calcNormFactors(cf, method = 'TMM')
  v <- voom(cf, design = design, lib.size = colSums(cf) * nf,
    normalize.method = 'none', plot = FALSE)
  fit <- contrasts.fit(lmFit(v, design), C)
  fit <- eBayes(fit, robust = TRUE, trend = FALSE)
  stat <- fit$t[, 1]
  names(stat) <- toupper(master$gene_symbol[match(rownames(cf), master$gene_id)])
  ans <- camera_pr_exact(stat, hallmark)
  ans$analysis <- tag
  ans$n_naive <- sum(condition == 'naive')
  ans$n_noise <- sum(condition == 'noise')
  ans
}

all_camera <- list()
for (th in c(10, 20, 30)) {
  for (cohort in unique(meta$tissue_cohort)) {
    types <- setdiff(unique(cell_counts$cell_type[cell_counts$tissue_cohort == cohort]),
      'unassigned')
    for (ct in types) {
      z <- merge(meta[meta$tissue_cohort == cohort,
        c('sample_id', 'condition')],
        cell_counts[cell_counts$tissue_cohort == cohort &
          cell_counts$cell_type == ct, ],
        by = c('sample_id', 'condition'), all.x = TRUE)
      z$n_cells[is.na(z$n_cells)] <- 0
      z$library_size[is.na(z$library_size)] <- 0
      z <- z[z$n_cells >= th & z$library_size >= 5000, ]
      if (sum(z$condition == 'naive') < 3 || sum(z$condition == 'noise') < 3) next
      keys <- paste(z$sample_id, ct, sep = '__')
      if (!all(keys %in% colnames(pb))) next
      all_camera[[length(all_camera) + 1]] <- fit_one(pb[, keys, drop = FALSE], z,
        paste('primary', th, cohort, ct, sep = '__'))
    }
  }
}

for (cohort in unique(meta$tissue_cohort)) {
  types <- setdiff(unique(strict_counts$cell_type[strict_counts$tissue_cohort == cohort]),
    'unassigned')
  for (ct in types) {
    z <- merge(meta[meta$tissue_cohort == cohort, c('sample_id', 'condition')],
      strict_counts[strict_counts$tissue_cohort == cohort &
        strict_counts$cell_type == ct, ],
      by = c('sample_id', 'condition'), all.x = TRUE)
    z$n_cells[is.na(z$n_cells)] <- 0
    z$library_size[is.na(z$library_size)] <- 0
    z <- z[z$n_cells >= 20 & z$library_size >= 5000, ]
    if (sum(z$condition == 'naive') < 3 || sum(z$condition == 'noise') < 3) next
    keys <- paste(z$sample_id, ct, sep = '__')
    if (!all(keys %in% colnames(strict_pb))) next
    all_camera[[length(all_camera) + 1]] <- fit_one(
      strict_pb[, keys, drop = FALSE], z,
      paste('strict', 20, cohort, ct, sep = '__'))
  }
}

camera_sens <- do.call(rbind, all_camera)
camera_sens$global_FDR <- p.adjust(camera_sens$PValue, method = 'BH')
write.csv(camera_sens, file.path(out_dir,
  'CAMERA_PR_annotation_and_cell_threshold_sensitivity.csv'), row.names = FALSE)

core <- camera_sens[camera_sens$pathway %in% core_pathways, ]
parts <- strsplit(core$analysis, '__', fixed = TRUE)
core$annotation_definition <- vapply(parts, `[[`, character(1), 1)
core$min_cells <- as.integer(vapply(parts, `[[`, character(1), 2))
core$tissue_cohort <- vapply(parts, `[[`, character(1), 3)
core$cell_type <- vapply(parts, function(x) paste(x[4:length(x)], collapse = '__'),
  character(1))
stability <- aggregate(Direction ~ pathway + tissue_cohort + cell_type,
  data = core, FUN = function(x) paste(sort(unique(x)), collapse = ';'))
names(stability)[4] <- 'directions_across_definitions'
stability$n_definitions <- as.integer(table(interaction(core$pathway,
  core$tissue_cohort, core$cell_type))[interaction(stability$pathway,
  stability$tissue_cohort, stability$cell_type)])
stability$direction_stable <- !grepl(';', stability$directions_across_definitions)
write.csv(stability, file.path(out_dir,
  'core_pathway_direction_stability_summary.csv'), row.names = FALSE)

cat('Cell annotation and threshold sensitivity complete.\n')
print(assignment)
print(table(stability$direction_stable, useNA = 'ifany'))
