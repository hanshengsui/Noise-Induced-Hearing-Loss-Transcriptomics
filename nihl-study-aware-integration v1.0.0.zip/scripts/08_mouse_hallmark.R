#!/usr/bin/env Rscript
# 08_mouse_hallmark.R -- Human-symbol versus official mouse-Hallmark sensitivity of the focal
# programmes (Additional file 5).
#
# Statistical calls are unchanged from the submitted analysis; only input and
# output locations are resolved through scripts/00_setup.R.

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
source(file.path(nihl_paths$scripts, 'utils.R'))
nihl_require_versions('3.62.2', '4.4.2')

suppressPackageStartupMessages(library(dplyr))

set.seed(20260713)

source_root <- Sys.getenv('NIHL_ANALYSIS_ROOT', 'outputs/NIHL_submission')
out_root <- Sys.getenv('NIHL_REVISION_ROOT', 'outputs/NIHL_submission_revision4')
out_analysis <- file.path(out_root, 'analysis_results', 'mouse_hallmark_sensitivity')
out_results <- file.path(out_root, 'Results', 'Programmes')
dir.create(out_analysis, recursive = TRUE, showWarnings = FALSE)
dir.create(out_results, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out_root, 'Code', 'gene_sets'), recursive = TRUE, showWarnings = FALSE)

human_gmt_file <- Sys.getenv('NIHL_HUMAN_GMT',
  nihl_inputs$human_gmt)
mouse_gmt_file <- Sys.getenv('NIHL_MOUSE_GMT',
  nihl_inputs$mouse_core4_gmt)

read_gmt <- function(path) {
  z <- strsplit(readLines(path, warn = FALSE, encoding = 'UTF-8'), '\t', fixed = TRUE)
  z <- z[lengths(z) >= 3]
  ans <- lapply(z, function(x) unique(toupper(x[-c(1, 2)])))
  names(ans) <- vapply(z, `[[`, character(1), 1)
  ans
}

core <- c(
  'HALLMARK_TNFA_SIGNALING_VIA_NFKB',
  'HALLMARK_INFLAMMATORY_RESPONSE',
  'HALLMARK_OXIDATIVE_PHOSPHORYLATION',
  'HALLMARK_E2F_TARGETS'
)
human <- read_gmt(human_gmt_file)[core]
mouse <- read_gmt(mouse_gmt_file)[core]
stopifnot(identical(names(human), core), identical(names(mouse), core))

camera_pr_exact <- function(statistic, pathways, inter_gene_cor = 0.01) {
  statistic <- statistic[is.finite(statistic)]
  names(statistic) <- toupper(names(statistic))
  statistic <- statistic[!duplicated(names(statistic))]
  G <- length(statistic)
  index <- lapply(pathways, function(set) which(names(statistic) %in% set))
  valid <- lengths(index) >= 5L & lengths(index) < G - 2L
  tab <- limma::cameraPR(statistic, index = index[valid],
    inter.gene.cor = inter_gene_cor, sort = FALSE)
  camera_t <- ifelse(tab$Direction == 'Up',
    qt(tab$PValue / 2, df = G - 2, lower.tail = FALSE),
    qt(tab$PValue / 2, df = G - 2))
  data.frame(programme = rownames(tab), ranked_universe = G,
    mapped_size = tab$NGenes, Direction = tab$Direction,
    camera_t = camera_t, PValue = tab$PValue, core4_FDR = tab$FDR,
    row.names = NULL, stringsAsFactors = FALSE)
}

ranks0 <- readRDS(file.path(source_root, 'source_data', 'program_integration',
                            'ranked_gene_statistics.rds'))
pers <- readRDS(file.path(source_root, 'source_data', 'standard_pathway_reanalysis',
                          'four_persistence_rankings.rds'))

ranks <- list(
  GSE8342_resilience = ranks0$GSE8342_resilience_interaction,
  EMTAB_24h = ranks0$EMTAB_h24,
  EMTAB_72h = ranks0$EMTAB_h72,
  EMTAB_1week = ranks0$EMTAB_week1,
  persistence_consistency_weighted_mean_t = pers$consistency_weighted_mean_t,
  persistence_weakest_timepoint_t = pers$weakest_timepoint_t,
  persistence_stouffer_signed_z = pers$stouffer_signed_z,
  persistence_signed_rank_product = pers$signed_rank_product,
  GSE107086_acute_noise_average_shamADX = ranks0$GSE107086_noise_average_shamADX
)

cell_dir <- file.path(source_root, 'results', 'GSE168041_celltype')
cell_files <- list.files(cell_dir, pattern = '__noise_vs_naive[.]csv[.]gz$', full.names = TRUE)
stopifnot(length(cell_files) == 13)
for (f in cell_files) {
  z <- read.csv(gzfile(f), stringsAsFactors = FALSE, check.names = FALSE)
  stat_col <- if ('moderated_t' %in% names(z)) 'moderated_t' else 't'
  stat <- z[[stat_col]]
  names(stat) <- z$gene_symbol
  nm <- paste0('cellclass_', sub('__noise_vs_naive[.]csv[.]gz$', '', basename(f)))
  ranks[[nm]] <- stat
}

run_collection <- function(pathways, collection_name) {
  bind_rows(lapply(names(ranks), function(nm) {
    x <- camera_pr_exact(ranks[[nm]], pathways)
    x$analysis <- nm
    x$collection <- collection_name
    x
  }))
}

all_results <- bind_rows(
  run_collection(human, 'Human_Hallmark_v2024.1_symbol_match'),
  run_collection(mouse, 'Mouse_MSigDB_MH_orthology_mapped_current')
) %>%
  select(collection, analysis, programme, ranked_universe, mapped_size,
         Direction, camera_t, PValue, core4_FDR)

human_res <- filter(all_results, collection == 'Human_Hallmark_v2024.1_symbol_match') %>%
  rename_with(~paste0('human_', .x), c(mapped_size, Direction, camera_t, PValue, core4_FDR)) %>%
  select(-collection, -ranked_universe)
mouse_res <- filter(all_results, collection == 'Mouse_MSigDB_MH_orthology_mapped_current') %>%
  rename_with(~paste0('mouse_', .x), c(mapped_size, Direction, camera_t, PValue, core4_FDR)) %>%
  select(-collection)

comparison <- inner_join(human_res, mouse_res, by = c('analysis', 'programme')) %>%
  mutate(
    direction_preserved = human_Direction == mouse_Direction,
    human_evidence_category = if_else(human_core4_FDR < 0.10, 'S', 'N'),
    mouse_evidence_category = if_else(mouse_core4_FDR < 0.10, 'S', 'N'),
    evidence_category_preserved = human_evidence_category == mouse_evidence_category,
    analysis_group = case_when(
      analysis == 'GSE8342_resilience' ~ 'resilience',
      grepl('^EMTAB_', analysis) ~ 'direct_time',
      grepl('^persistence_', analysis) ~ 'persistence_rank',
      grepl('^cellclass_', analysis) ~ 'cell_class',
      grepl('^GSE107086_', analysis) ~ 'acute_context',
      TRUE ~ 'other'
    )
  )

set_comparison <- bind_rows(lapply(core, function(nm) {
  h <- human[[nm]]; m <- mouse[[nm]]
  data.frame(
    programme = nm,
    human_set_size = length(h),
    mouse_set_size = length(m),
    overlap = length(intersect(h, m)),
    union = length(union(h, m)),
    jaccard = length(intersect(h, m)) / length(union(h, m)),
    human_only = length(setdiff(h, m)),
    mouse_only = length(setdiff(m, h))
  )
}))

summary <- comparison %>%
  group_by(analysis_group) %>%
  summarise(
    comparisons = n(),
    direction_preserved = sum(direction_preserved),
    evidence_category_preserved = sum(evidence_category_preserved),
    .groups = 'drop'
  ) %>%
  mutate(
    direction_changed = comparisons - direction_preserved,
    direction_preservation_percent = 100 * direction_preserved / comparisons,
    evidence_category_changed = comparisons - evidence_category_preserved,
    evidence_category_preservation_percent = 100 * evidence_category_preserved / comparisons
  ) %>%
  bind_rows(comparison %>% summarise(
    analysis_group = 'all', comparisons = n(),
    direction_preserved = sum(direction_preserved),
    evidence_category_preserved = sum(evidence_category_preserved)
  ) %>% mutate(
    direction_changed = comparisons - direction_preserved,
    direction_preservation_percent = 100 * direction_preserved / comparisons,
    evidence_category_changed = comparisons - evidence_category_preserved,
    evidence_category_preservation_percent = 100 * evidence_category_preserved / comparisons
  )) %>%
  select(analysis_group, comparisons, direction_preserved, direction_changed,
         direction_preservation_percent, evidence_category_preserved,
         evidence_category_changed, evidence_category_preservation_percent)

write.csv(all_results, file.path(out_analysis, 'core4_collection_specific_CAMERA_PR.csv'), row.names = FALSE)
write.csv(comparison, file.path(out_analysis, 'core4_human_vs_mouse_direction_comparison.csv'), row.names = FALSE)
write.csv(set_comparison, file.path(out_analysis, 'core4_gene_set_overlap.csv'), row.names = FALSE)
write.csv(summary, file.path(out_analysis, 'core4_direction_preservation_summary.csv'), row.names = FALSE)
write.csv(comparison, file.path(out_results, 'core4_human_vs_mouse_hallmark_sensitivity.csv'), row.names = FALSE)
write.csv(summary, file.path(out_results, 'core4_mouse_hallmark_sensitivity_summary.csv'), row.names = FALSE)

table_s8a <- summary %>%
  mutate(
    `Analysis scope` = recode(analysis_group,
      resilience = 'GSE8342 resilience contrast',
      direct_time = 'E-MTAB direct time contrasts',
      persistence_rank = 'E-MTAB persistence-rank definitions',
      acute_context = 'GSE107086 acute-context rank',
      cell_class = 'GSE168041 broad cell-class ranks',
      all = 'All tested analysis-programme pairs'),
    `Direction preserved` = paste0(direction_preserved, '/', comparisons),
    `Core-4 FDR category preserved` = paste0(evidence_category_preserved, '/', comparisons),
    analysis_group = factor(analysis_group,
      levels = c('resilience', 'direct_time', 'persistence_rank',
                 'acute_context', 'cell_class', 'all'))
  ) %>%
  arrange(analysis_group) %>%
  select(`Analysis scope`, Comparisons = comparisons, `Direction preserved`,
         `Core-4 FDR category preserved`)

programme_label <- c(
  HALLMARK_TNFA_SIGNALING_VIA_NFKB = 'TNF–NF-κB signalling',
  HALLMARK_INFLAMMATORY_RESPONSE = 'Inflammatory response',
  HALLMARK_OXIDATIVE_PHOSPHORYLATION = 'Oxidative phosphorylation',
  HALLMARK_E2F_TARGETS = 'E2F targets'
)

format_q <- function(x) {
  ifelse(x < 0.001,
         sub('e-0', 'e-', sprintf('%.2e', x), fixed = TRUE),
         sprintf('%.3f', x))
}

format_result <- function(direction, statistic, fdr) {
  paste0(direction, ' ', sprintf('%.3f', statistic), ' / ', format_q(fdr))
}

make_detail_row <- function(label, programme, analyses) {
  z <- comparison %>%
    filter(.data$programme == .env$programme, .data$analysis %in% .env$analyses) %>%
    slice(match(analyses, .data$analysis))
  stopifnot(nrow(z) == length(analyses), identical(z$analysis, analyses))
  human_direction <- paste(z$human_Direction, collapse = '/')
  mouse_direction <- paste(z$mouse_Direction, collapse = '/')
  human_category <- paste(z$human_evidence_category, collapse = '/')
  mouse_category <- paste(z$mouse_evidence_category, collapse = '/')
  direction_text <- if (length(analyses) == 1L) {
    paste0(ifelse(z$direction_preserved, 'Yes', 'No'), ' (',
           z$human_Direction, '→', z$mouse_Direction, ')')
  } else if (all(z$direction_preserved)) {
    paste0('Yes (', human_direction, ')')
  } else {
    paste0('No (human ', human_direction, '; mouse ', mouse_direction, ')')
  }
  category_text <- if (length(analyses) == 1L) {
    paste0(ifelse(z$evidence_category_preserved, 'Yes', 'No'), ' (',
           z$human_evidence_category, '→', z$mouse_evidence_category, ')')
  } else if (all(z$evidence_category_preserved)) {
    paste0('Yes (', human_category, ')')
  } else {
    paste0('No (human ', human_category, '; mouse ', mouse_category, ')')
  }
  data.frame(
    Analysis = label,
    Programme = unname(programme_label[programme]),
    `Human-symbol CAMERA-PR t / core-4 FDR` = paste(
      format_result(z$human_Direction, z$human_camera_t, z$human_core4_FDR),
      collapse = '; '),
    `Mouse MH CAMERA-PR t / core-4 FDR` = paste(
      format_result(z$mouse_Direction, z$mouse_camera_t, z$mouse_core4_FDR),
      collapse = '; '),
    `Direction preserved` = direction_text,
    `Evidence category preserved` = category_text,
    check.names = FALSE,
    stringsAsFactors = FALSE
  )
}

direct_analyses <- c('EMTAB_24h', 'EMTAB_72h', 'EMTAB_1week')
persistence_analyses <- c(
  'persistence_consistency_weighted_mean_t',
  'persistence_weakest_timepoint_t',
  'persistence_stouffer_signed_z',
  'persistence_signed_rank_product'
)
table_s8b <- bind_rows(
  lapply(core, function(p) make_detail_row('GSE8342 resilience', p, 'GSE8342_resilience')),
  lapply(core, function(p) make_detail_row('E-MTAB direct time', p, direct_analyses)),
  lapply(core, function(p) make_detail_row('E-MTAB persistence ranks', p, persistence_analyses)),
  make_detail_row('Boundary: neuronal-cohort endothelial',
                  'HALLMARK_INFLAMMATORY_RESPONSE',
                  'cellclass_neuronal_focused_endothelial'),
  make_detail_row('Boundary: neuronal-cohort endothelial',
                  'HALLMARK_E2F_TARGETS',
                   'cellclass_neuronal_focused_endothelial')
)

analysis_label <- c(
  GSE8342_resilience = 'GSE8342 resilience',
  EMTAB_24h = 'E-MTAB direct time: 24 h',
  EMTAB_72h = 'E-MTAB direct time: 72 h',
  EMTAB_1week = 'E-MTAB direct time: 1 week',
  persistence_consistency_weighted_mean_t = 'E-MTAB persistence: consistency-weighted mean t',
  persistence_weakest_timepoint_t = 'E-MTAB persistence: weakest-time-point t',
  persistence_stouffer_signed_z = 'E-MTAB persistence: signed Stouffer z',
  persistence_signed_rank_product = 'E-MTAB persistence: signed rank product',
  GSE107086_acute_noise_average_shamADX = 'GSE107086 acute noise average, sham surgery',
  cellclass_lateral_wall_focused_basal_cell = 'GSE168041 lateral-wall cohort: basal cell',
  cellclass_lateral_wall_focused_endothelial = 'GSE168041 lateral-wall cohort: endothelial',
  cellclass_lateral_wall_focused_fibrocyte = 'GSE168041 lateral-wall cohort: fibrocyte',
  cellclass_lateral_wall_focused_immune = 'GSE168041 lateral-wall cohort: immune',
  cellclass_lateral_wall_focused_intermediate_melanocyte = 'GSE168041 lateral-wall cohort: intermediate/melanocyte',
  cellclass_lateral_wall_focused_marginal_cell = 'GSE168041 lateral-wall cohort: marginal cell',
  cellclass_lateral_wall_focused_pericyte_smooth_muscle = 'GSE168041 lateral-wall cohort: pericyte/smooth muscle',
  cellclass_neuronal_focused_endothelial = 'GSE168041 neuronal cohort: endothelial',
  cellclass_neuronal_focused_fibrocyte = 'GSE168041 neuronal cohort: fibrocyte',
  cellclass_neuronal_focused_immune = 'GSE168041 neuronal cohort: immune',
  cellclass_neuronal_focused_pericyte_smooth_muscle = 'GSE168041 neuronal cohort: pericyte/smooth muscle',
  cellclass_neuronal_focused_schwann_glial = 'GSE168041 neuronal cohort: Schwann/glial',
  cellclass_neuronal_focused_spiral_ganglion_neuron = 'GSE168041 neuronal cohort: spiral-ganglion neuron'
)
stopifnot(setequal(names(analysis_label), unique(comparison$analysis)))

table_s8c <- comparison %>%
  mutate(
    analysis_order = match(analysis, names(analysis_label)),
    programme_order = match(programme, core)
  ) %>%
  arrange(analysis_order, programme_order) %>%
  transmute(
    Analysis = unname(analysis_label[analysis]),
    Programme = unname(programme_label[programme]),
    `Human-symbol CAMERA-PR t / core-4 FDR` =
      format_result(human_Direction, human_camera_t, human_core4_FDR),
    `Mouse MH CAMERA-PR t / core-4 FDR` =
      format_result(mouse_Direction, mouse_camera_t, mouse_core4_FDR),
    `Direction preserved` = paste0(ifelse(direction_preserved, 'Yes', 'No'),
                                   ' (', human_Direction, '→', mouse_Direction, ')'),
    `Evidence category preserved` = paste0(
      ifelse(evidence_category_preserved, 'Yes', 'No'),
      ' (', human_evidence_category, '→', mouse_evidence_category, ')')
  )

write.csv(table_s8a, file.path(out_root, 'tables', 'Table_S8A_mouse_hallmark_preservation_summary.csv'), row.names = FALSE)
write.csv(table_s8b, file.path(out_root, 'tables', 'Table_S8B_mouse_hallmark_detailed_comparison.csv'), row.names = FALSE)
write.csv(table_s8c, file.path(out_root, 'tables', 'Table_S8C_mouse_hallmark_complete_88_pair_comparison.csv'), row.names = FALSE)
# Compatibility alias now points to the complete publication-facing 88-pair panel.
write.csv(table_s8c, file.path(out_root, 'tables', 'Table_S8_mouse_hallmark_sensitivity.csv'), row.names = FALSE)

file.copy(human_gmt_file, file.path(out_root, 'Code', 'gene_sets', basename(human_gmt_file)), overwrite = TRUE)
file.copy(mouse_gmt_file, file.path(out_root, 'Code', 'gene_sets', basename(mouse_gmt_file)), overwrite = TRUE)
file.copy(nihl_inputs$mouse_gmt_provenance,
          file.path(out_root, 'Code', 'gene_sets',
                    'mh.core4.MouseMSigDB.current.provenance.txt'),
          overwrite = TRUE)

capture.output(sessionInfo(), file = file.path(out_root, 'Code', 'sessionInfo_mouse_hallmark_sensitivity.txt'))

cat('Mouse Hallmark sensitivity complete.\n')
print(summary)
