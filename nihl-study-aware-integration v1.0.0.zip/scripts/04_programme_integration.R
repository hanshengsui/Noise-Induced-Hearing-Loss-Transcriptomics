#!/usr/bin/env Rscript
# 04_programme_integration.R -- Cross-study programme integration from the stage-1 per-gene statistics
# (Table 3 inputs, Figure 3, Figure 4B).
#
# Statistical calls are unchanged from the submitted analysis; only input and
# output locations are resolved through scripts/00_setup.R.

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
source(file.path(nihl_paths$scripts, 'utils.R'))
nihl_require_versions('3.62.2', '4.4.2')

set.seed(20260712)

root <- Sys.getenv('NIHL_ANALYSIS_ROOT', 'outputs/NIHL_submission')
out_dir <- file.path(root, 'results', 'program_integration')
src_dir <- file.path(root, 'source_data', 'program_integration')
tab_dir <- file.path(root, 'tables')
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(src_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tab_dir, recursive = TRUE, showWarnings = FALSE)

read_gz_csv <- function(path) read.csv(gzfile(path), stringsAsFactors = FALSE,
                                       check.names = FALSE)

collapse_rank <- function(z, gene = 'gene_symbol', score = 'moderated_t') {
  z <- z[is.finite(z[[score]]) & !is.na(z[[gene]]) & nzchar(z[[gene]]), ]
  z$symbol_key <- toupper(z[[gene]])
  z <- z[order(z$symbol_key, -abs(z[[score]])), ]
  z <- z[!duplicated(z$symbol_key), ]
  s <- z[[score]]
  names(s) <- z$symbol_key
  sort(s, decreasing = TRUE)
}

read_gmt <- function(path) {
  x <- strsplit(readLines(path, warn = FALSE), '\t', fixed = TRUE)
  out <- lapply(x, function(z) unique(toupper(z[-c(1,2)])))
  names(out) <- vapply(x, `[`, character(1), 1)
  out
}

# Competitive pre-ranked enrichment.  The Mann-Whitney statistic is reported
# as an AUC and converted to a signed normal score (NES). This avoids arbitrary
# DEG cut-offs and is deterministic for complete ranked lists.
rank_enrich <- function(stats, pathways, analysis_id, collection = 'Hallmark') {
  stats <- stats[is.finite(stats)]
  N <- length(stats)
  ranks_asc <- rank(stats, ties.method = 'average')
  names(ranks_asc) <- names(stats)
  ans <- lapply(names(pathways), function(pw) {
    hit <- intersect(names(stats), pathways[[pw]])
    m <- length(hit)
    n <- N - m
    if (m < 10 || m > 500 || n < 10) return(NULL)
    R1 <- sum(ranks_asc[hit])
    U <- R1 - m * (m + 1) / 2
    auc <- U / (m * n)
    mu <- m * n / 2
    sigma <- sqrt(m * n * (m + n + 1) / 12)
    z <- (U - mu) / sigma
    p <- 2 * pnorm(-abs(z))
    ord <- names(stats)
    if (z >= 0) {
      lead <- intersect(ord[seq_len(max(1, floor(0.20*N)))], hit)
    } else {
      lead <- intersect(rev(ord)[seq_len(max(1, floor(0.20*N)))], hit)
    }
    data.frame(analysis_id = analysis_id, collection = collection,
               pathway = pw, tested_genes = N, overlap_size = m,
               AUC = auc, NES = z, PValue = p,
               leading_edge = paste(head(lead, 25), collapse = ';'),
               stringsAsFactors = FALSE)
  })
  ans <- do.call(rbind, ans)
  ans$FDR <- p.adjust(ans$PValue, method = 'BH')
  ans[order(ans$FDR, -abs(ans$NES)), ]
}

gmt <- read_gmt(nihl_inputs$human_gmt)

# GSE8342: strain-by-noise interaction is (resistant response - susceptible
# response), so positive ranks denote relatively stronger induction in the
# resistant strain and negative ranks relatively stronger repression.
g_int <- read_gz_csv(file.path(root, 'results', 'GSE8342',
                              'representative_probe__strain_by_noise_interaction.csv.gz'))
g_res <- read_gz_csv(file.path(root, 'results', 'GSE8342',
                              'representative_probe__resistant_noise_vs_control.csv.gz'))
g_sus <- read_gz_csv(file.path(root, 'results', 'GSE8342',
                              'representative_probe__susceptible_noise_vs_control.csv.gz'))
ranks <- list(
  GSE8342_resilience_interaction = collapse_rank(g_int),
  GSE8342_resistant_noise = collapse_rank(g_res),
  GSE8342_susceptible_noise = collapse_rank(g_sus)
)

# E-MTAB-16125: construct a continuous persistence score from all three
# moderated statistics.  A sign-consistency multiplier (1 or 1/3) downweights
# trajectories that change direction without converting them to a binary list.
e24 <- read_gz_csv(file.path(root, 'results', 'E-MTAB-16125',
                            'E-MTAB-16125__h24_vs_control.csv.gz'))
e72 <- read_gz_csv(file.path(root, 'results', 'E-MTAB-16125',
                            'E-MTAB-16125__h72_vs_control.csv.gz'))
e1w <- read_gz_csv(file.path(root, 'results', 'E-MTAB-16125',
                            'E-MTAB-16125__week1_vs_control.csv.gz'))
dedup_effect <- function(z) {
  z <- z[!is.na(z$gene_symbol) & nzchar(z$gene_symbol) & is.finite(z$moderated_t), ]
  z$symbol_key <- toupper(z$gene_symbol)
  z <- z[order(z$symbol_key, -abs(z$moderated_t)), ]
  z[!duplicated(z$symbol_key), ]
}
e24d <- dedup_effect(e24)
e72d <- dedup_effect(e72)
e1wd <- dedup_effect(e1w)
e <- merge(e24d[,c('symbol_key','gene_symbol','moderated_t','logFC','AveExpr')],
           e72d[,c('symbol_key','moderated_t','logFC')], by = 'symbol_key',
           suffixes = c('_h24','_h72'))
e <- merge(e, e1wd[,c('symbol_key','moderated_t','logFC')], by = 'symbol_key')
names(e)[names(e) == 'moderated_t'] <- 'moderated_t_week1'
names(e)[names(e) == 'logFC'] <- 'logFC_week1'
sgn <- cbind(sign(e$logFC_h24), sign(e$logFC_h72), sign(e$logFC_week1))
consistency <- abs(rowSums(sgn))/3
e$persistence_score <- rowMeans(cbind(e$moderated_t_h24,
                                      e$moderated_t_h72,
                                      e$moderated_t_week1)) * consistency
e <- e[order(e$symbol_key, -abs(e$persistence_score)), ]
e <- e[!duplicated(e$symbol_key), ]
persist_rank <- e$persistence_score
names(persist_rank) <- e$symbol_key
ranks$EMTAB_persistence <- sort(persist_rank, decreasing = TRUE)
ranks$EMTAB_h24 <- collapse_rank(e24)
ranks$EMTAB_h72 <- collapse_rank(e72)
ranks$EMTAB_week1 <- collapse_rank(e1w)

# Independent acute bulk context from GSE107086 (whole cochlea); receptor
# interaction contrasts are retained for the exploratory supplement only.
g107 <- read_gz_csv(file.path(root, 'results', 'GSE107086',
                             'GSE107086__noise_average_shamADX.csv.gz'))
ranks$GSE107086_noise_average_shamADX <- collapse_rank(g107)

enrich <- do.call(rbind, lapply(names(ranks), function(nm)
  rank_enrich(ranks[[nm]], gmt, nm)))
rownames(enrich) <- NULL
write.csv(enrich, file.path(tab_dir, 'Table_S6_ranked_Hallmark_enrichment.csv'),
          row.names = FALSE)

# Resilience-persistence two-dimensional programme framework.
ri <- enrich[enrich$analysis_id == 'GSE8342_resilience_interaction',
             c('pathway','NES','FDR','overlap_size')]
names(ri)[-1] <- paste0('resilience_', names(ri)[-1])
pe <- enrich[enrich$analysis_id == 'EMTAB_persistence',
             c('pathway','NES','FDR','overlap_size')]
names(pe)[-1] <- paste0('persistence_', names(pe)[-1])
two_d <- merge(ri, pe, by = 'pathway')
two_d$quadrant <- ifelse(two_d$resilience_NES >= 0 & two_d$persistence_NES >= 0,
                         'resilience_up__persistence_up',
                  ifelse(two_d$resilience_NES >= 0 & two_d$persistence_NES < 0,
                         'resilience_up__persistence_down',
                  ifelse(two_d$resilience_NES < 0 & two_d$persistence_NES >= 0,
                         'resilience_down__persistence_up',
                         'resilience_down__persistence_down')))
two_d$joint_evidence <- -log10(pmax(two_d$resilience_FDR, 1e-300)) +
                        -log10(pmax(two_d$persistence_FDR, 1e-300))
two_d <- two_d[order(-two_d$joint_evidence), ]
write.csv(two_d, file.path(tab_dir, 'Table_2_resilience_persistence_programs.csv'),
          row.names = FALSE)

# Leave-one-analysis-out stability for the three comparable acute-noise bulk
# ranks.  This is a programme-level influence analysis, not a pooled effect.
acute_ids <- c('GSE8342_resistant_noise','GSE8342_susceptible_noise',
               'EMTAB_h24','GSE107086_noise_average_shamADX')
az <- enrich[enrich$analysis_id %in% acute_ids, c('analysis_id','pathway','NES')]
loso <- do.call(rbind, lapply(acute_ids, function(drop) {
  z <- az[az$analysis_id != drop, ]
  ag <- aggregate(NES ~ pathway, z, function(x)
    c(mean_NES = mean(x), min_abs_NES = min(abs(x)),
      sign_agreement = abs(sum(sign(x)))/length(x)))
  vv <- as.matrix(ag$NES)
  data.frame(dropped_analysis = drop, pathway = ag$pathway,
             mean_NES = vv[,1], min_abs_NES = vv[,2],
             sign_agreement = vv[,3], stringsAsFactors = FALSE)
}))
write.csv(loso, file.path(src_dir, 'pathway_leave_one_analysis_out.csv'),
          row.names = FALSE)

# Rank-rank hypergeometric overlap grid.  Separate upper and lower tails avoid
# mixing concordant up- and down-ranked signals.
rrho_grid <- function(a, b, id_a, id_b, cuts = c(100,250,500,1000)) {
  common <- intersect(names(a), names(b))
  a <- a[intersect(names(a), common)]
  b <- b[intersect(names(b), common)]
  N <- length(common)
  out <- list()
  k <- 0
  for (tail in c('upper','lower')) for (ca in cuts) for (cb in cuts) {
    aa <- if (tail == 'upper') head(names(a), min(ca,N)) else head(names(sort(a)), min(ca,N))
    bb <- if (tail == 'upper') head(names(b), min(cb,N)) else head(names(sort(b)), min(cb,N))
    x <- length(intersect(aa, bb))
    p <- phyper(x - 1, length(aa), N - length(aa), length(bb), lower.tail = FALSE)
    k <- k + 1
    out[[k]] <- data.frame(analysis_a=id_a, analysis_b=id_b, tail=tail,
                           cut_a=ca, cut_b=cb, universe=N, overlap=x,
                           PValue=p, stringsAsFactors=FALSE)
  }
  z <- do.call(rbind, out)
  z$FDR <- p.adjust(z$PValue, 'BH')
  z
}
rr <- rbind(
  rrho_grid(ranks$GSE8342_resilience_interaction, ranks$EMTAB_persistence,
            'GSE8342_resilience_interaction','EMTAB_persistence'),
  rrho_grid(ranks$GSE8342_susceptible_noise, ranks$EMTAB_h24,
            'GSE8342_susceptible_noise','EMTAB_h24'),
  rrho_grid(ranks$GSE8342_resistant_noise, ranks$EMTAB_h24,
            'GSE8342_resistant_noise','EMTAB_h24'))
write.csv(rr, file.path(src_dir, 'rank_rank_hypergeometric_grid.csv'), row.names=FALSE)

# Expression- and variance-matched permutation for the pre-specified GSE8342
# Tier-2 effect screen.  External support is defined before permutation as an
# effect-consistent E-MTAB trajectory with the same direction as the interaction.
s4 <- read.csv(file.path(tab_dir, 'Table_S4_GSE8342_resilience_gene_evidence.csv'),
               stringsAsFactors = FALSE)
qmap <- read.csv(file.path(root, 'source_data', 'GSE8342',
                          'representative_probe_map.csv'), stringsAsFactors = FALSE)
s4 <- merge(s4, qmap[,c('gene_symbol','mean_expression','variance')],
            by = 'gene_symbol', all.x = TRUE)
em <- read.csv(file.path(tab_dir, 'Table_S5_E-MTAB_temporal_gene_classes.csv'),
               stringsAsFactors = FALSE)
keep_cols <- intersect(c('gene_symbol','effect_consistent_persistent','temporal_class',
                         'h24_logFC','h72_logFC','week1_logFC'), names(em))
em <- em[, keep_cols]
s4 <- merge(s4, em, by = 'gene_symbol', all.x = TRUE)
if (!'effect_consistent_persistent' %in% names(s4))
  s4$effect_consistent_persistent <- s4$temporal_class %in%
    c('persistent_increase','persistent_decrease')
external_sign <- sign(rowMeans(cbind(s4$h24_logFC,s4$h72_logFC,s4$week1_logFC),
                               na.rm = TRUE))
s4$externally_supported <- !is.na(s4$effect_consistent_persistent) &
  s4$effect_consistent_persistent & external_sign == sign(s4$interaction_logFC)

bin_safe <- function(x, n) {
  q <- unique(quantile(x, probs=seq(0,1,length.out=n+1), na.rm=TRUE))
  cut(x, breaks=q, include.lowest=TRUE, labels=FALSE)
}
s4$expr_bin <- bin_safe(s4$mean_expression, 10)
s4$var_bin <- bin_safe(log1p(s4$variance), 5)
s4$stratum <- interaction(s4$expr_bin, s4$var_bin, drop=TRUE)
candidate <- which(s4$tier2_effect_screen_pre_external_support & !is.na(s4$stratum))
obs <- sum(s4$externally_supported[candidate], na.rm=TRUE)
candidate_strata <- table(s4$stratum[candidate])
B <- 10000
# The matched null is a sum of stratum-specific hypergeometric draws.  This is
# mathematically equivalent to repeatedly sampling without replacement but is
# much faster and keeps the requested 10,000 permutations practical.
null_mat <- sapply(names(candidate_strata), function(st) {
  pool <- which(s4$stratum == st & !s4$tier2_effect_screen_pre_external_support)
  k <- unname(candidate_strata[st])
  if (length(pool) < k) pool <- which(s4$stratum == st)
  success <- sum(s4$externally_supported[pool], na.rm=TRUE)
  rhyper(B, success, length(pool) - success, min(k, length(pool)))
})
null <- if (is.null(dim(null_mat))) null_mat else rowSums(null_mat)
perm_summary <- data.frame(
  candidate_n = length(candidate), observed_external_support = obs,
  null_mean = mean(null), null_sd = sd(null),
  empirical_P_greater = (1 + sum(null >= obs))/(B+1), permutations=B,
  matching_variables='mean expression decile; log1p variance quintile',
  stringsAsFactors=FALSE)
write.csv(perm_summary, file.path(tab_dir,
  'Table_S7_expression_matched_permutation.csv'), row.names=FALSE)
write.csv(data.frame(external_support_count=null),
          file.path(src_dir,'expression_matched_permutation_null.csv'),row.names=FALSE)

saveRDS(ranks, file.path(src_dir, 'ranked_gene_statistics.rds'))
cat('Ranked programme integration complete.\n')
print(head(two_d, 10))
print(perm_summary)
