#!/usr/bin/env Rscript
# 02_emtab_and_glucocorticoid.R -- replicated time course and glucocorticoid context
# (Table 2 activation-to-resolution IUT, Figure 3, Additional file 6).
#
# E-MTAB-16125: five individual mice per time point, sex-adjusted TMM-voom.
# GSE107086: factorial glucocorticoid-context series (noise x day/night x ADX).

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
source(file.path(nihl_paths$scripts, 'utils.R'))
nihl_require_versions('3.62.2', '4.4.2')
nihl_require_inputs(nihl_inputs[c('E_MTAB_sdrf', 'E_MTAB_featurecounts',
                                  'GSE107086_counts', 'GSE168041_gene_map')])

set.seed(20260712)

root <- Sys.getenv('NIHL_ANALYSIS_ROOT', 'outputs/NIHL_submission')
tab_dir <- file.path(root, 'tables')
dir.create(tab_dir, recursive = TRUE, showWarnings = FALSE)

fit_count_voom <- function(counts, design, contrasts, feature, out_dir, prefix,
                           min_count = 10, min_total_count = 15) {
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  counts <- as.matrix(counts)
  storage.mode(counts) <- 'numeric'
  keep <- filterByExpr(counts, design = design, min.count = min_count,
                       min.total.count = min_total_count)
  counts <- counts[keep, , drop = FALSE]
  feature <- feature[match(rownames(counts), feature$feature_id), , drop = FALSE]
  norm_factor <- calcNormFactors(counts, method = 'TMM')
  lib_raw <- colSums(counts)
  lib_effective <- lib_raw * norm_factor
  v <- voom(counts, design = design, lib.size = lib_effective,
            normalize.method = 'none', plot = FALSE)
  fit <- lmFit(v, design)
  fit <- contrasts.fit(fit, contrasts)
  fit <- eBayes(fit, robust = TRUE, trend = FALSE)

  results <- list()
  for (nm in colnames(contrasts)) {
    tt <- topTable(fit, coef = nm, number = Inf, sort.by = 'none')
    se <- fit$stdev.unscaled[, nm] * sqrt(fit$s2.post)
    crit <- qt(0.975, df = fit$df.total)
    results[[nm]] <- data.frame(
      feature,
      contrast = nm,
      logFC = tt$logFC,
      SE = se,
      CI_low = tt$logFC - crit * se,
      CI_high = tt$logFC + crit * se,
      AveExpr = tt$AveExpr,
      moderated_t = tt$t,
      PValue = tt$P.Value,
      FDR = tt$adj.P.Val,
      B = tt$B,
      df_total = fit$df.total,
      stringsAsFactors = FALSE
    )
    con <- gzfile(file.path(out_dir, paste0(prefix, '__', nm, '.csv.gz')), 'wt')
    write.csv(results[[nm]], con, row.names = FALSE, na = '')
    close(con)
  }

  qc <- data.frame(sample_id = colnames(counts), raw_library_size = lib_raw,
                   TMM_norm_factor = norm_factor,
                   effective_library_size = lib_effective,
                   stringsAsFactors = FALSE)
  write.csv(qc, file.path(out_dir, paste0(prefix, '__library_qc.csv')), row.names = FALSE)
  pca <- prcomp(t(v$E), center = TRUE, scale. = FALSE)
  write.csv(data.frame(sample_id = rownames(pca$x), PC1 = pca$x[,1], PC2 = pca$x[,2]),
            file.path(out_dir, paste0(prefix, '__pca.csv')), row.names = FALSE)
  list(results = results, fit = fit, voom = v, counts = counts, feature = feature,
       qc = qc, keep = keep)
}

## ----------------------------------------------------------------------
## E-MTAB-16125: sex-adjusted replicated time course
## ----------------------------------------------------------------------
sdrf <- read.delim(nihl_inputs$E_MTAB_sdrf, check.names = TRUE,
                   stringsAsFactors = FALSE)
meta <- unique(sdrf[, c('Source.Name','Characteristics.sex.','Derived.Array.Data.File',
                        'Factor.Value.time.','Factor.Value.injury.')])
names(meta) <- c('sample_id','sex','count_file','time_label','injury')
meta$group <- ifelse(meta$time_label == 'control', 'control',
              ifelse(grepl('^24h', meta$time_label), 'h24',
              ifelse(grepl('^72h', meta$time_label), 'h72', 'week1')))
meta <- meta[order(match(meta$group, c('control','h24','h72','week1')), meta$sample_id), ]

count_dir <- nihl_inputs$E_MTAB_featurecounts
lst <- list(); genes <- NULL
for (i in seq_len(nrow(meta))) {
  x <- read.delim(file.path(count_dir, meta$count_file[i]), header = FALSE,
                  col.names = c('gene_id','count'), stringsAsFactors = FALSE)
  if (is.null(genes)) genes <- x$gene_id
  if (!identical(genes, x$gene_id)) stop('E-MTAB-16125 gene order mismatch')
  lst[[meta$sample_id[i]]] <- x$count
}
counts <- do.call(cbind, lst)
rownames(counts) <- genes

gene_map <- read.csv(nihl_inputs$GSE168041_gene_map, stringsAsFactors = FALSE)
gene_map$ensembl_stable <- sub('\\..*$', '', gene_map$gene_id)
feature <- data.frame(
  feature_id = rownames(counts), gene_id = rownames(counts),
  gene_symbol = gene_map$gene_symbol[match(sub('\\..*$', '', rownames(counts)), gene_map$ensembl_stable)],
  stringsAsFactors = FALSE
)
group <- factor(meta$group, levels = c('control','h24','h72','week1'))
sex <- factor(meta$sex)
design <- model.matrix(~0 + group + sex)
colnames(design) <- sub('group', '', colnames(design), fixed = TRUE)
colnames(design) <- sub('sex', 'sex_', colnames(design), fixed = TRUE)
C <- cbind(
  h24_vs_control = c(-1,1,0,0,0),
  h72_vs_control = c(-1,0,1,0,0),
  week1_vs_control = c(-1,0,0,1,0)
)
rownames(C) <- colnames(design)

out16125 <- file.path(root, 'results', 'E-MTAB-16125')
fit16125 <- fit_count_voom(counts, design, C, feature, out16125, 'E-MTAB-16125')
write.csv(meta, file.path(out16125, 'sample_metadata.csv'), row.names = FALSE)

r24 <- fit16125$results$h24_vs_control
r72 <- fit16125$results$h72_vs_control
r1w <- fit16125$results$week1_vs_control
i72 <- match(r24$feature_id, r72$feature_id)
i1w <- match(r24$feature_id, r1w$feature_id)

tt_global <- topTable(fit16125$fit, coef = 1:3, number = Inf, sort.by = 'none')
global_P <- tt_global$P.Value
global_FDR <- tt_global$adj.P.Val

temporal <- data.frame(
  feature_id = r24$feature_id,
  gene_id = r24$gene_id,
  gene_symbol = r24$gene_symbol,
  h24_logFC = r24$logFC, h24_SE = r24$SE, h24_PValue = r24$PValue, h24_FDR = r24$FDR,
  h72_logFC = r72$logFC[i72], h72_SE = r72$SE[i72], h72_PValue = r72$PValue[i72], h72_FDR = r72$FDR[i72],
  week1_logFC = r1w$logFC[i1w], week1_SE = r1w$SE[i1w], week1_PValue = r1w$PValue[i1w], week1_FDR = r1w$FDR[i1w],
  global_time_F = tt_global$F,
  global_time_PValue = global_P,
  global_time_FDR = global_FDR,
  stringsAsFactors = FALSE
)

same_dir <- with(temporal,
  sign(h24_logFC) == sign(h72_logFC) & sign(h24_logFC) == sign(week1_logFC) & sign(h24_logFC) != 0)
effect3 <- with(temporal,
  abs(h24_logFC) >= 0.3 & abs(h72_logFC) >= 0.3 & abs(week1_logFC) >= 0.3)
n_nominal <- rowSums(cbind(temporal$h24_PValue < 0.05,
                           temporal$h72_PValue < 0.05,
                           temporal$week1_PValue < 0.05), na.rm = TRUE)
temporal$strict_persistent <- same_dir & effect3 & temporal$global_time_FDR < 0.10 &
                              abs(temporal$week1_logFC) >= 0.3 & n_nominal >= 2
temporal$effect_consistent_persistent <- same_dir & effect3

direction <- sign(temporal$h24_logFC)
one24 <- ifelse(direction > 0,
                pt(r24$moderated_t, df = r24$df_total, lower.tail = FALSE),
                pt(r24$moderated_t, df = r24$df_total, lower.tail = TRUE))
one72 <- ifelse(direction > 0,
                pt(r72$moderated_t[i72], df = r72$df_total[i72], lower.tail = FALSE),
                pt(r72$moderated_t[i72], df = r72$df_total[i72], lower.tail = TRUE))
one1w <- ifelse(direction > 0,
                pt(r1w$moderated_t[i1w], df = r1w$df_total[i1w], lower.tail = FALSE),
                pt(r1w$moderated_t[i1w], df = r1w$df_total[i1w], lower.tail = TRUE))
temporal$IUT_max_one_sided_P <- pmax(one24, one72, one1w, na.rm = TRUE)
temporal$IUT_FDR <- p.adjust(temporal$IUT_max_one_sided_P, method = 'BH')
temporal$high_confidence_IUT <- same_dir & effect3 & temporal$IUT_FDR < 0.10

temporal$temporal_class <- 'other'
reversal <- with(temporal, sign(h24_logFC) != sign(week1_logFC) &
                              abs(h24_logFC) >= 0.3 & abs(week1_logFC) >= 0.3)
p_up <- same_dir & direction > 0 & effect3
p_down <- same_dir & direction < 0 & effect3
transient <- with(temporal, abs(h24_logFC) >= 0.5 & abs(h72_logFC) < 0.3 & abs(week1_logFC) < 0.3)
delayed <- with(temporal, abs(h24_logFC) < 0.3 & (abs(h72_logFC) >= 0.5 | abs(week1_logFC) >= 0.5))
temporal$temporal_class[delayed] <- 'delayed'
temporal$temporal_class[transient] <- 'transient_early'
temporal$temporal_class[p_up] <- 'persistent_increase'
temporal$temporal_class[p_down] <- 'persistent_decrease'
temporal$temporal_class[reversal] <- 'reversal'
temporal$n_nominal_P_lt_0.05 <- n_nominal
temporal <- temporal[order(temporal$global_time_PValue), ]
write.csv(temporal, file.path(tab_dir, 'Table_S5_E-MTAB_temporal_gene_classes.csv'), row.names = FALSE)

class_summary <- as.data.frame(table(temporal$temporal_class), stringsAsFactors = FALSE)
names(class_summary) <- c('temporal_class','n_genes')
class_summary <- rbind(class_summary,
  data.frame(temporal_class = c('strict_persistent','effect_consistent_persistent','high_confidence_IUT'),
             n_genes = c(sum(temporal$strict_persistent),
                         sum(temporal$effect_consistent_persistent),
                         sum(temporal$high_confidence_IUT))))
write.csv(class_summary, file.path(out16125, 'formal_temporal_summary.csv'), row.names = FALSE)

# Persistence threshold sensitivity.
grid <- expand.grid(abs_logFC = c(0.2,0.3,0.5), n_nominal = 1:3,
                    require_week1 = c(FALSE,TRUE), global_FDR = c(0.05,0.10),
                    stringsAsFactors = FALSE)
grid$n_genes <- apply(grid, 1, function(z) {
  fc <- as.numeric(z[['abs_logFC']]); np <- as.integer(z[['n_nominal']])
  reqw <- as.logical(z[['require_week1']]); gf <- as.numeric(z[['global_FDR']])
  eff <- abs(temporal$h24_logFC) >= fc & abs(temporal$h72_logFC) >= fc
  if (reqw) eff <- eff & abs(temporal$week1_logFC) >= fc
  sum(same_dir & eff & n_nominal >= np & temporal$global_time_FDR < gf, na.rm = TRUE)
})
write.csv(grid, file.path(out16125, 'persistence_threshold_sensitivity.csv'), row.names = FALSE)

## ----------------------------------------------------------------------
## GSE107086: replicated factorial exploratory glucocorticoid analysis
## ----------------------------------------------------------------------
x107 <- read.csv(gzfile(nihl_inputs$GSE107086_counts), check.names = FALSE)
genes107 <- as.character(x107$geneName)
counts107 <- as.matrix(x107[, -1, drop = FALSE])
storage.mode(counts107) <- 'numeric'; rownames(counts107) <- genes107
sample107 <- colnames(counts107)
group107 <- sub('[abc]$', '', sample107)
meta107 <- data.frame(
  sample_id = sample107, group = group107,
  noise = ifelse(grepl('^Sh', group107), 'sham', 'noise'),
  phase = ifelse(grepl('^(Sh)?D', group107), 'day', 'night'),
  adrenal_status = ifelse(grepl('ShADX$', group107), 'sham_ADX', 'ADX'),
  biological_unit = 'individual_mouse', stringsAsFactors = FALSE
)
groups107 <- c('DNADX','DNShADX','NNADX','NNShADX','ShDNADX','ShDNShADX','ShNNADX','ShNNShADX')
gf107 <- factor(group107, levels = groups107)
d107 <- model.matrix(~0 + gf107); colnames(d107) <- groups107
C107 <- cbind(
  noise_day_ADX = c(1,0,0,0,-1,0,0,0),
  noise_day_shamADX = c(0,1,0,0,0,-1,0,0),
  noise_night_ADX = c(0,0,1,0,0,0,-1,0),
  noise_night_shamADX = c(0,0,0,1,0,0,0,-1),
  GC_dependency_day = c(-1,1,0,0,1,-1,0,0),
  GC_dependency_night = c(0,0,-1,1,0,0,1,-1),
  noise_average_shamADX = c(0,0.5,0,0.5,0,-0.5,0,-0.5),
  noise_average_ADX = c(0.5,0,0.5,0,-0.5,0,-0.5,0),
  GC_dependency_average = c(-0.5,0.5,-0.5,0.5,0.5,-0.5,0.5,-0.5)
)
rownames(C107) <- groups107
f107 <- data.frame(feature_id = genes107, gene_symbol = genes107, stringsAsFactors = FALSE)
out107 <- file.path(root, 'results', 'GSE107086')
fit107 <- fit_count_voom(counts107, d107, C107, f107, out107, 'GSE107086',
                         min_count = 10, min_total_count = 15)
write.csv(meta107, file.path(out107, 'sample_metadata.csv'), row.names = FALSE)

sum107 <- do.call(rbind, lapply(names(fit107$results), function(nm) {
  z <- fit107$results[[nm]]
  data.frame(contrast = nm, n_genes = nrow(z),
             n_FDR_0.05 = sum(z$FDR < 0.05),
             n_FDR_0.10 = sum(z$FDR < 0.10),
             n_FDR_0.10_abs_logFC_0.5 = sum(z$FDR < 0.10 & abs(z$logFC) >= 0.5),
             stringsAsFactors = FALSE)
}))
write.csv(sum107, file.path(out107, 'formal_summary.csv'), row.names = FALSE)

cat('Formal TMM-normalized limma-voom analyses complete.\n')
print(class_summary)
print(sum107)
