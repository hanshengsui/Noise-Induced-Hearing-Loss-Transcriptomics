#!/usr/bin/env Rscript
# 10_expanded_validation.R -- independent validation across four external bulk series
# (Additional file 3, Figure 2D-E, Figure 3D, Figure 4, Additional file 5).
#
# GSE160639  raw counts, TMM-voom, 70/94/105 dB SPL
# GSE196870  deposited FPKM matrix as deposited (limma-trend)
# GSE312476  deposited normalised abundance, log2(x + 0.5) (limma-trend)
# GSE100365  Affymetrix series matrix, sex-adjusted, auditory nerve
#
# Camera-PR settings: inter.gene.cor = 0.01, use.ranks = FALSE, sets with fewer
# than five mapped genes or more than G - 2 genes dropped. BH within each
# contrast over the 50 Hallmark sets.
#
# Runtime: about 1 minute on a 2020-class laptop CPU.

options(stringsAsFactors = FALSE)

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
source(file.path(nihl_paths$scripts, 'utils.R'))
nihl_require_versions('3.62.2', '4.4.2')

# NIHL_DATASETS restricts the run to a subset of the four external series. It
# exists so that a single dataset can be taken through the pipeline end to end
# as a smoke test; a full run leaves it unset and processes all four.
requested <- Sys.getenv('NIHL_DATASETS', '')
requested <- if (nzchar(requested)) {
  strsplit(requested, ',', fixed = TRUE)[[1]]
} else c('GSE160639', 'GSE196870', 'GSE312476', 'GSE100365')
wanted_dataset <- function(x) x %in% requested

# Only the inputs of the datasets actually being run are required, so that a
# single-series smoke test does not demand the other three archives.
input_keys <- c(
  GSE160639 = 'GSE160639_counts', GSE196870 = 'GSE196870_fpkm',
  GSE312476 = 'GSE312476_table_s1', GSE100365 = 'GSE100365_series'
)
needed <- unname(input_keys[requested])
needed <- needed[!is.na(needed)]
extra_needed <- if ('GSE100365' %in% requested) 'GPL1261_annotation' else character()
if ('GSE160639' %in% requested) extra_needed <- c(extra_needed, 'gene_map_mouse')
nihl_require_inputs(nihl_inputs[c(needed, extra_needed)])

# readxl reads the deposited GSE312476 workbook.
suppressPackageStartupMessages(library(readxl))

result_root <- file.path(nihl_paths$work, 'revision', 'expanded_validation')
dir.create(result_root, recursive = TRUE, showWarnings = FALSE)

wanted_dataset <- function(x) x %in% requested

read_gmt <- function(path) {
  lines <- readLines(path, warn = FALSE)
  parts <- strsplit(lines, "\t", fixed = TRUE)
  parts <- parts[lengths(parts) >= 3L]
  ans <- lapply(parts, function(x) unique(toupper(x[-c(1L, 2L)])))
  names(ans) <- vapply(parts, `[[`, character(1), 1L)
  ans
}

human_hallmark <- read_gmt(nihl_inputs$human_gmt)
mouse_hallmark <- read_gmt(nihl_inputs$mouse_gmt)

target_programmes <- c(
  "HALLMARK_TNFA_SIGNALING_VIA_NFKB",
  "HALLMARK_INFLAMMATORY_RESPONSE",
  "HALLMARK_OXIDATIVE_PHOSPHORYLATION",
  "HALLMARK_E2F_TARGETS",
  "HALLMARK_INTERFERON_GAMMA_RESPONSE",
  "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION",
  "HALLMARK_UNFOLDED_PROTEIN_RESPONSE"
)

camera_pr <- function(statistic, pathways, collection, dataset, contrast) {
  statistic <- statistic[is.finite(statistic)]
  names(statistic) <- toupper(names(statistic))
  statistic <- statistic[!duplicated(names(statistic))]
  index <- lapply(pathways, function(set) which(names(statistic) %in% set))
  valid <- lengths(index) >= 5L & lengths(index) < length(statistic) - 2L
  tab <- limma::cameraPR(
    statistic,
    index = index[valid],
    inter.gene.cor = 0.01,
    use.ranks = FALSE,
    sort = FALSE
  )
  signed_t <- ifelse(
    tab$Direction == "Up",
    qt(tab$PValue / 2, df = length(statistic) - 2, lower.tail = FALSE),
    qt(tab$PValue / 2, df = length(statistic) - 2)
  )
  data.frame(
    dataset = dataset,
    contrast = contrast,
    collection = collection,
    programme = rownames(tab),
    n_genes = tab$NGenes,
    direction = tab$Direction,
    camera_t = signed_t,
    PValue = tab$PValue,
    FDR = tab$FDR,
    ranked_universe = length(statistic),
    stringsAsFactors = FALSE,
    row.names = NULL
  )
}

write_gene_result <- function(tab, dataset, contrast) {
  out <- file.path(result_root, dataset)
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  con <- gzfile(file.path(out, paste0(dataset, "__", contrast, "__complete_results.csv.gz")), "wt")
  on.exit(close(con), add = TRUE)
  write.csv(tab, con, row.names = FALSE, na = "")
}

extract_contrasts <- function(fit, feature, dataset) {
  gene_results <- list()
  programme_results <- list()
  for (contrast in colnames(fit$coefficients)) {
    tt <- topTable(fit, coef = contrast, number = Inf, sort.by = "none")
    gene_tab <- data.frame(
      dataset = dataset,
      contrast = contrast,
      feature,
      logFC = tt$logFC,
      AveExpr = tt$AveExpr,
      moderated_t = tt$t,
      PValue = tt$P.Value,
      FDR = tt$adj.P.Val,
      B = tt$B,
      stringsAsFactors = FALSE
    )
    write_gene_result(gene_tab, dataset, contrast)
    gene_results[[contrast]] <- gene_tab
    statistic <- gene_tab$moderated_t
    names(statistic) <- gene_tab$gene_symbol
    programme_results[[paste0(contrast, "_human")]] <- camera_pr(
      statistic, human_hallmark, "Human Hallmark v2024.1 direct-symbol match",
      dataset, contrast
    )
    programme_results[[paste0(contrast, "_mouse")]] <- camera_pr(
      statistic, mouse_hallmark, "Mouse Hallmark v2024.1 orthologized",
      dataset, contrast
    )
  }
  list(
    genes = do.call(rbind, gene_results),
    programmes = do.call(rbind, programme_results)
  )
}

save_model_qc <- function(dataset, metadata, expression, extra = NULL) {
  out <- file.path(result_root, dataset)
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  nihl_write_csv(metadata, file.path(out, "sample_metadata.csv"), na = "")
  pca <- prcomp(t(expression), center = TRUE, scale. = FALSE)
  pca_tab <- data.frame(
    sample_id = rownames(pca$x),
    PC1 = pca$x[, 1],
    PC2 = pca$x[, 2],
    metadata[match(rownames(pca$x), metadata$sample_id), setdiff(names(metadata), "sample_id"),
             drop = FALSE],
    stringsAsFactors = FALSE
  )
  nihl_write_csv(pca_tab, file.path(out, "pca_source.csv"), na = "")
  if (!is.null(extra)) {
    nihl_write_csv(extra, file.path(out, "model_qc.csv"), na = "")
  }
}

aggregate_counts_by_symbol <- function(counts, symbols) {
  ok <- !is.na(symbols) & nzchar(symbols) & symbols != "N/A"
  counts <- counts[ok, , drop = FALSE]
  symbols <- toupper(symbols[ok])
  rowsum(counts, group = symbols, reorder = FALSE)
}

representative_by_mean <- function(expr, symbols, feature_ids = rownames(expr)) {
  symbols <- toupper(symbols)
  ok <- !is.na(symbols) & nzchar(symbols) & symbols != "N/A" &
    !grepl("///", symbols, fixed = TRUE)
  expr <- expr[ok, , drop = FALSE]
  symbols <- symbols[ok]
  feature_ids <- feature_ids[ok]
  avg <- rowMeans(expr, na.rm = TRUE)
  ord <- order(symbols, -avg, feature_ids)
  expr <- expr[ord, , drop = FALSE]
  symbols <- symbols[ord]
  feature_ids <- feature_ids[ord]
  keep <- !duplicated(symbols)
  list(
    expression = expr[keep, , drop = FALSE],
    symbols = symbols[keep],
    feature_ids = feature_ids[keep]
  )
}

all_programmes <- list()

## ---------------------------------------------------------------------
## GSE160639: independent sound-level response with raw read counts
## ---------------------------------------------------------------------
if (wanted_dataset('GSE160639')) {
g160 <- read.delim(
  gzfile(nihl_inputs$GSE160639_counts),
  check.names = FALSE
)
gene_map <- read.csv(nihl_inputs$gene_map_mouse)
gene_map$stable_id <- sub("\\..*$", "", gene_map$gene_id)
g160_symbol <- gene_map$gene_symbol[
  match(sub("\\..*$", "", g160$gene_id), gene_map$stable_id)
]
g160_counts <- as.matrix(g160[, -1, drop = FALSE])
storage.mode(g160_counts) <- "numeric"
rownames(g160_counts) <- g160$gene_id
g160_counts <- aggregate_counts_by_symbol(g160_counts, g160_symbol)

g160_group <- factor(
  sub(".*_", "", colnames(g160_counts)),
  levels = c("70dB", "94dB", "105dB")
)
g160_meta <- data.frame(
  sample_id = colnames(g160_counts),
  group = as.character(g160_group),
  dB_SPL = c(rep(70, 4), rep(94, 4), rep(105, 4)),
  biological_unit = "individual deposited library",
  interpretation = ifelse(g160_group == "70dB", "non-injurious sound reference", "noise exposure"),
  stringsAsFactors = FALSE
)
g160_design <- model.matrix(~0 + g160_group)
colnames(g160_design) <- paste0("g", levels(g160_group))
g160_keep <- filterByExpr(g160_counts, design = g160_design, min.count = 10)
g160_counts_f <- g160_counts[g160_keep, , drop = FALSE]
g160_dge <- DGEList(g160_counts_f)
g160_dge <- calcNormFactors(g160_dge, method = "TMM")
g160_voom <- voom(g160_dge, g160_design, plot = FALSE)
g160_contrasts <- makeContrasts(
  dB94_vs_70 = g94dB - g70dB,
  dB105_vs_70 = g105dB - g70dB,
  dB105_vs_94 = g105dB - g94dB,
  levels = g160_design
)
g160_fit <- eBayes(
  contrasts.fit(lmFit(g160_voom, g160_design), g160_contrasts),
  robust = TRUE,
  trend = FALSE
)
g160_feature <- data.frame(
  feature_id = rownames(g160_fit$coefficients),
  gene_symbol = rownames(g160_fit$coefficients),
  stringsAsFactors = FALSE
)
g160_res <- extract_contrasts(g160_fit, g160_feature, "GSE160639")
all_programmes[["GSE160639"]] <- g160_res$programmes
save_model_qc(
  "GSE160639", g160_meta, g160_voom$E,
  data.frame(
    sample_id = colnames(g160_counts_f),
    raw_library_size = colSums(g160_counts_f),
    TMM_norm_factor = g160_dge$samples$norm.factors,
    effective_library_size = g160_dge$samples$lib.size * g160_dge$samples$norm.factors
  )
)

}

## ---------------------------------------------------------------------
## GSE196870: independent 1 h/24 h whole-cochlea FPKM validation
## ---------------------------------------------------------------------
if (wanted_dataset('GSE196870')) {
g196 <- read.csv(
  gzfile(nihl_inputs$GSE196870_fpkm),
  check.names = FALSE
)
g196_cols <- c(
  paste0("MUS_", 1:4),
  paste0("PN_1h_", 1:4),
  paste0("PN_24h_", 1:4)
)
g196_expr0 <- as.matrix(g196[, g196_cols, drop = FALSE])
storage.mode(g196_expr0) <- "numeric"
rownames(g196_expr0) <- g196$id
g196_rep <- representative_by_mean(g196_expr0, g196$gene, g196$id)
g196_expr <- g196_rep$expression
g196_feature <- data.frame(
  feature_id = g196_rep$feature_ids,
  gene_symbol = g196_rep$symbols,
  stringsAsFactors = FALSE
)
g196_keep <- rowMeans(g196_expr, na.rm = TRUE) > 0.5 &
  apply(g196_expr, 1, sd, na.rm = TRUE) > 0
g196_expr <- g196_expr[g196_keep, , drop = FALSE]
g196_feature <- g196_feature[g196_keep, , drop = FALSE]
g196_group <- factor(
  c(rep("control", 4), rep("noise_1h", 4), rep("noise_24h", 4)),
  levels = c("control", "noise_1h", "noise_24h")
)
g196_meta <- data.frame(
  sample_id = colnames(g196_expr),
  group = as.character(g196_group),
  biological_unit = "one mouse; bilateral cochleae combined",
  repository_scale = "FPKM matrix as deposited; no additional log transformation",
  stringsAsFactors = FALSE
)
g196_design <- model.matrix(~0 + g196_group)
colnames(g196_design) <- levels(g196_group)
g196_contrasts <- makeContrasts(
  noise_1h_vs_control = noise_1h - control,
  noise_24h_vs_control = noise_24h - control,
  noise_24h_vs_1h = noise_24h - noise_1h,
  levels = g196_design
)
g196_fit <- eBayes(
  contrasts.fit(lmFit(g196_expr, g196_design), g196_contrasts),
  robust = TRUE,
  trend = TRUE
)
g196_res <- extract_contrasts(g196_fit, g196_feature, "GSE196870")
all_programmes[["GSE196870"]] <- g196_res$programmes
save_model_qc("GSE196870", g196_meta, g196_expr)

}

## ---------------------------------------------------------------------
## GSE312476: independent acute 0/4/8 h processed-expression validation
## ---------------------------------------------------------------------
if (wanted_dataset('GSE312476')) {
g312 <- as.data.frame(read_excel(
  nihl_inputs$GSE312476_table_s1,
  sheet = "Bulk_RNA_seq_data",
  skip = 2
))
g312_cols <- c(
  paste0("Ctrl_", 1:3),
  paste0("PN0h_", 1:3),
  paste0("PN4h_", 1:3),
  paste0("PN8h_", 1:3)
)
g312_expr0 <- as.matrix(g312[, g312_cols, drop = FALSE])
storage.mode(g312_expr0) <- "numeric"
g312_expr0 <- aggregate_counts_by_symbol(g312_expr0, g312$gene_symbol)
g312_keep <- rowSums(g312_expr0 > 1, na.rm = TRUE) >= 3
g312_expr <- log2(g312_expr0[g312_keep, , drop = FALSE] + 0.5)
g312_feature <- data.frame(
  feature_id = rownames(g312_expr),
  gene_symbol = rownames(g312_expr),
  stringsAsFactors = FALSE
)
g312_group <- factor(
  c(rep("control", 3), rep("post_0h", 3), rep("post_4h", 3), rep("post_8h", 3)),
  levels = c("control", "post_0h", "post_4h", "post_8h")
)
g312_meta <- data.frame(
  sample_id = colnames(g312_expr),
  group = as.character(g312_group),
  biological_unit = "one deposited cochlear library",
  repository_scale = paste(
    "non-integer processed quantitative matrix; log2(x+0.5) analysis",
    "(GEO text calls files raw counts, but deposited values are non-integer)"
  ),
  stringsAsFactors = FALSE
)
g312_design <- model.matrix(~0 + g312_group)
colnames(g312_design) <- levels(g312_group)
g312_contrasts <- makeContrasts(
  post_0h_vs_control = post_0h - control,
  post_4h_vs_control = post_4h - control,
  post_8h_vs_control = post_8h - control,
  post_4h_vs_0h = post_4h - post_0h,
  post_8h_vs_4h = post_8h - post_4h,
  post_8h_vs_0h = post_8h - post_0h,
  levels = g312_design
)
g312_fit <- eBayes(
  contrasts.fit(lmFit(g312_expr, g312_design), g312_contrasts),
  robust = TRUE,
  trend = TRUE
)
g312_res <- extract_contrasts(g312_fit, g312_feature, "GSE312476")
all_programmes[["GSE312476"]] <- g312_res$programmes
save_model_qc("GSE312476", g312_meta, g312_expr)

}

## ---------------------------------------------------------------------
## GSE100365: independent auditory-nerve/glial compartment time course
## ---------------------------------------------------------------------
if (wanted_dataset('GSE100365')) {
g100_geo <- read_geo_series_matrix(nihl_inputs$GSE100365_series)
g100_annot <- read_geo_annotation(nihl_inputs$GPL1261_annotation)
g100_symbol <- g100_annot$`Gene symbol`[match(g100_geo$feature_id, g100_annot$ID)]
g100_rep <- representative_by_mean(
  g100_geo$expr, g100_symbol, g100_geo$feature_id
)
g100_expr <- g100_rep$expression
g100_feature <- data.frame(
  feature_id = g100_rep$feature_ids,
  gene_symbol = g100_rep$symbols,
  stringsAsFactors = FALSE
)
g100_title <- g100_geo$sample_meta$title
g100_group <- ifelse(
  grepl("_control_", g100_title), "control",
  ifelse(
    grepl("_Immediate_", g100_title), "immediate",
    ifelse(
      grepl("_1Day_", g100_title), "day1",
      ifelse(grepl("_7Day_", g100_title), "day7", "day14")
    )
  )
)
g100_group <- factor(g100_group, levels = c("control", "immediate", "day1", "day7", "day14"))
gender_col <- grep("^characteristics_ch1_[0-9]+$", names(g100_geo$sample_meta), value = TRUE)
gender_col <- gender_col[vapply(
  g100_geo$sample_meta[gender_col],
  function(x) any(grepl("^gender:", x, ignore.case = TRUE)),
  logical(1)
)]
if (length(gender_col) != 1L) stop("Could not identify the GSE100365 gender metadata line.")
g100_sex <- factor(
  sub("^gender:\\s*", "", g100_geo$sample_meta[[gender_col]], ignore.case = TRUE)
)
g100_meta <- data.frame(
  sample_id = g100_geo$sample_meta$sample_id,
  title = g100_title,
  group = as.character(g100_group),
  sex = as.character(g100_sex),
  biological_unit = "one mouse; bilateral auditory-nerve tissue combined",
  compartment = "auditory nerve/modiolus, not whole cochlea",
  stringsAsFactors = FALSE
)
g100_design <- model.matrix(~0 + g100_group + g100_sex)
colnames(g100_design) <- sub("^g100_group", "", colnames(g100_design))
colnames(g100_design) <- sub("^g100_sex", "sex_", colnames(g100_design))
g100_contrasts <- makeContrasts(
  immediate_vs_control = immediate - control,
  day1_vs_control = day1 - control,
  day7_vs_control = day7 - control,
  day14_vs_control = day14 - control,
  day1_vs_immediate = day1 - immediate,
  day7_vs_day1 = day7 - day1,
  day14_vs_day7 = day14 - day7,
  levels = g100_design
)
g100_fit <- eBayes(
  contrasts.fit(lmFit(g100_expr, g100_design), g100_contrasts),
  robust = TRUE,
  trend = TRUE
)
g100_res <- extract_contrasts(g100_fit, g100_feature, "GSE100365")
all_programmes[["GSE100365"]] <- g100_res$programmes
save_model_qc("GSE100365", g100_meta, g100_expr)

}

programme_all <- do.call(rbind, all_programmes)
programme_all$targeted_programme <- programme_all$programme %in% target_programmes
programme_all$FDR_category <- cut(
  programme_all$FDR,
  breaks = c(-Inf, 0.05, 0.10, Inf),
  labels = c("FDR<0.05", "0.05<=FDR<0.10", "FDR>=0.10"),
  right = FALSE
)
nihl_write_csv(
  programme_all,
  file.path(result_root, "expanded_programme_results_complete.csv"),
  row.names = FALSE,
  na = ""
)
nihl_write_csv(
  programme_all[programme_all$targeted_programme, ],
  file.path(result_root, "expanded_programme_results_targeted.csv"),
  row.names = FALSE,
  na = ""
)

orthology <- merge(
  programme_all[programme_all$collection == "Human Hallmark v2024.1 direct-symbol match", ],
  programme_all[programme_all$collection == "Mouse Hallmark v2024.1 orthologized", ],
  by = c("dataset", "contrast", "programme"),
  suffixes = c("_human", "_mouse")
)
orthology$direction_preserved <- orthology$direction_human == orthology$direction_mouse
orthology$evidence_category_preserved <- orthology$FDR_category_human ==
  orthology$FDR_category_mouse
nihl_write_csv(
  orthology,
  file.path(result_root, "orthology_sensitivity_complete.csv"),
  row.names = FALSE,
  na = ""
)

session <- capture.output(sessionInfo())
writeLines(session, file.path(result_root, "sessionInfo.txt"))

cat("Expanded validation analyses completed.\n")
cat("Program-level rows:", nrow(programme_all), "\n")
print(
  programme_all[
    programme_all$targeted_programme &
      programme_all$collection == "Human Hallmark v2024.1 direct-symbol match",
    c("dataset", "contrast", "programme", "direction", "camera_t", "PValue", "FDR")
  ],
  row.names = FALSE
)
