#!/usr/bin/env Rscript
# 06_gene_set_robustness.R -- Gene-set robustness: alternative collections, covariance assumptions,
# leave-one-study-out synthesis and the expression-matched permutation null.
#
# Statistical calls are unchanged from the submitted analysis; only input and
# output locations are resolved through scripts/00_setup.R.

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
source(file.path(nihl_paths$scripts, 'utils.R'))
nihl_require_versions('3.62.2', '4.4.2')

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
})

set.seed(20260713)

root <- Sys.getenv('NIHL_ANALYSIS_ROOT', 'outputs/NIHL_submission')
out_dir <- file.path(root, 'results', 'standard_pathway_reanalysis')
src_dir <- file.path(root, 'source_data', 'standard_pathway_reanalysis')
tab_dir <- file.path(root, 'tables')
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(src_dir, recursive = TRUE, showWarnings = FALSE)

read_gmt <- function(path) {
  z <- strsplit(readLines(path, warn = FALSE), '\t', fixed = FALSE)
  z <- z[lengths(z) >= 3]
  ans <- lapply(z, function(x) unique(toupper(x[-c(1, 2)])))
  names(ans) <- vapply(z, `[[`, character(1), 1)
  ans
}

hallmark <- read_gmt(nihl_inputs$human_gmt)
core_pathways <- c(
  'HALLMARK_TNFA_SIGNALING_VIA_NFKB',
  'HALLMARK_INFLAMMATORY_RESPONSE',
  'HALLMARK_OXIDATIVE_PHOSPHORYLATION',
  'HALLMARK_INTERFERON_GAMMA_RESPONSE',
  'HALLMARK_E2F_TARGETS',
  'HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION'
)

# Fixed-correlation CAMERA-PR using the formally installed limma namespace.
camera_pr_exact <- function(statistic, pathways, inter_gene_cor = 0.01) {
  statistic <- statistic[is.finite(statistic)]
  names(statistic) <- toupper(names(statistic))
  statistic <- statistic[!duplicated(names(statistic))]
  G <- length(statistic)
  index <- lapply(pathways, function(set) which(names(statistic) %in% set))
  valid <- lengths(index) >= 5L & lengths(index) < G - 2L
  tab <- limma::cameraPR(statistic, index = index[valid],
    inter.gene.cor = inter_gene_cor, sort = FALSE)
  camera_t <- ifelse(tab$Direction == 'Up',
    qt(tab$PValue / 2, df = G - 2, lower.tail = FALSE),
    qt(tab$PValue / 2, df = G - 2))
  data.frame(pathway = rownames(tab), NGenes = tab$NGenes,
    Direction = tab$Direction, camera_t = camera_t,
    PValue = tab$PValue, FDR = tab$FDR, row.names = NULL,
    stringsAsFactors = FALSE)
}

gsea_es_fast <- function(sorted_stat, set) {
  idx <- which(names(sorted_stat) %in% set)
  N <- length(sorted_stat)
  m <- length(idx)
  if (m < 5 || m >= N) return(list(ES = NA_real_, leading = character()))
  w <- abs(sorted_stat[idx])
  if (!sum(w) > 0) w[] <- 1
  hit_cum <- cumsum(w) / sum(w)
  miss_before <- (idx - seq_len(m)) / (N - m)
  run_after <- hit_cum - miss_before
  run_before <- c(0, head(hit_cum, -1)) - miss_before
  hi <- max(run_after)
  lo <- min(run_before)
  if (abs(hi) >= abs(lo)) {
    k <- which.max(run_after)
    list(ES = hi, leading = names(sorted_stat)[idx[seq_len(k)]])
  } else {
    k <- which.min(run_before)
    list(ES = lo, leading = names(sorted_stat)[idx[k:m]])
  }
}

gsea_permutation <- function(statistic, pathways, B = 10000L) {
  statistic <- sort(statistic[is.finite(statistic)], decreasing = TRUE)
  names(statistic) <- toupper(names(statistic))
  statistic <- statistic[!duplicated(names(statistic))]
  N <- length(statistic)
  ans <- lapply(names(pathways), function(nm) {
    set <- intersect(pathways[[nm]], names(statistic))
    obs <- gsea_es_fast(statistic, set)
    m <- length(set)
    if (!is.finite(obs$ES) || m < 5) return(NULL)
    null <- numeric(B)
    for (b in seq_len(B)) {
      idx <- sort(sample.int(N, m, replace = FALSE))
      null[b] <- gsea_es_fast(statistic, names(statistic)[idx])$ES
    }
    if (obs$ES >= 0) {
      den <- mean(abs(null[null >= 0]))
      p <- (1 + sum(null >= obs$ES)) / (1 + sum(null >= 0))
    } else {
      den <- mean(abs(null[null < 0]))
      p <- (1 + sum(null <= obs$ES)) / (1 + sum(null < 0))
    }
    data.frame(pathway = nm, size = m, ES = obs$ES,
      NES = obs$ES / den, PValue = min(1, p),
      leading_edge = paste(obs$leading, collapse = ';'),
      permutations = B, stringsAsFactors = FALSE)
  })
  ans <- bind_rows(ans)
  ans$FDR <- p.adjust(ans$PValue, method = 'BH')
  ans
}

read_de <- function(path) {
  z <- read.csv(gzfile(path), stringsAsFactors = FALSE, check.names = FALSE)
  if (!'t' %in% names(z) && 'moderated_t' %in% names(z)) z$t <- z$moderated_t
  stopifnot(all(c('gene_symbol', 't', 'logFC', 'PValue') %in% names(z)))
  z
}

ranks <- readRDS(file.path(root, 'source_data', 'program_integration',
  'ranked_gene_statistics.rds'))

# Correct the bidirectional intersection-union test.
em_base <- file.path(root, 'results', 'E-MTAB-16125')
h24 <- read_de(file.path(em_base, 'E-MTAB-16125__h24_vs_control.csv.gz'))
h72 <- read_de(file.path(em_base, 'E-MTAB-16125__h72_vs_control.csv.gz'))
w1 <- read_de(file.path(em_base, 'E-MTAB-16125__week1_vs_control.csv.gz'))
m72 <- match(h24$gene_symbol, h72$gene_symbol)
m1 <- match(h24$gene_symbol, w1$gene_symbol)
stopifnot(all(!is.na(m72)), all(!is.na(m1)))
em <- data.frame(
  gene_symbol = h24$gene_symbol,
  logFC_24h = h24$logFC, PValue_24h = h24$PValue, t_24h = h24$t,
  logFC_72h = h72$logFC[m72], PValue_72h = h72$PValue[m72], t_72h = h72$t[m72],
  logFC_1w = w1$logFC[m1], PValue_1w = w1$PValue[m1], t_1w = w1$t[m1],
  stringsAsFactors = FALSE
)

one_sided <- function(effect, p_two, direction = c('up', 'down')) {
  direction <- match.arg(direction)
  if (direction == 'up') ifelse(effect >= 0, p_two / 2, 1 - p_two / 2) else
    ifelse(effect <= 0, p_two / 2, 1 - p_two / 2)
}

em$P_up <- pmax(
  one_sided(em$logFC_24h, em$PValue_24h, 'up'),
  one_sided(em$logFC_72h, em$PValue_72h, 'up'),
  one_sided(em$logFC_1w, em$PValue_1w, 'up')
)
em$P_down <- pmax(
  one_sided(em$logFC_24h, em$PValue_24h, 'down'),
  one_sided(em$logFC_72h, em$PValue_72h, 'down'),
  one_sided(em$logFC_1w, em$PValue_1w, 'down')
)
em$IUT_P_bidirectional <- pmin(1, 2 * pmin(em$P_up, em$P_down))
em$IUT_FDR_bidirectional <- p.adjust(em$IUT_P_bidirectional, method = 'BH')

signed_z <- function(effect, p_two) {
  p <- pmax(pmin(p_two, 1 - 1e-15), 1e-300)
  sign(effect) * qnorm(1 - p / 2)
}
z24 <- signed_z(em$logFC_24h, em$PValue_24h)
z72 <- signed_z(em$logFC_72h, em$PValue_72h)
z1 <- signed_z(em$logFC_1w, em$PValue_1w)

same_sign <- sign(em$t_24h) == sign(em$t_72h) & sign(em$t_72h) == sign(em$t_1w)
rank_A <- rowMeans(cbind(em$t_24h, em$t_72h, em$t_1w)) *
  abs(rowSums(sign(cbind(em$t_24h, em$t_72h, em$t_1w)))) / 3
rank_B <- ifelse(same_sign, sign(em$t_24h) *
  pmin(abs(em$t_24h), abs(em$t_72h), abs(em$t_1w)), 0)
rank_C <- (z24 + z72 + z1) / sqrt(3)

rank_fraction <- function(x, decreasing = TRUE) rank(-x, ties.method = 'average') / length(x)
up_product <- exp(rowMeans(log(cbind(
  rank_fraction(em$t_24h), rank_fraction(em$t_72h), rank_fraction(em$t_1w)
))))
down_product <- exp(rowMeans(log(cbind(
  rank_fraction(-em$t_24h), rank_fraction(-em$t_72h), rank_fraction(-em$t_1w)
))))
rank_D <- ifelse(up_product <= down_product, -log10(up_product), log10(down_product))

names(rank_A) <- names(rank_B) <- names(rank_C) <- names(rank_D) <- toupper(em$gene_symbol)
persistence_ranks <- list(
  consistency_weighted_mean_t = rank_A,
  weakest_timepoint_t = rank_B,
  stouffer_signed_z = rank_C,
  signed_rank_product = rank_D
)

write.csv(em, file.path(out_dir, 'E-MTAB-16125_corrected_bidirectional_IUT.csv'),
  row.names = FALSE)
saveRDS(persistence_ranks, file.path(src_dir, 'four_persistence_rankings.rds'))

# CAMERA-PR across the resilience axis and four persistence definitions.
bulk_ranks <- c(list(GSE8342_resilience = ranks$GSE8342_resilience_interaction),
  persistence_ranks)
camera_bulk_file <- file.path(out_dir, 'CAMERA_PR_bulk_and_persistence.csv')
if (file.exists(camera_bulk_file)) {
  camera_bulk <- read.csv(camera_bulk_file, stringsAsFactors = FALSE)
} else {
  camera_bulk <- bind_rows(lapply(names(bulk_ranks), function(nm) {
    z <- camera_pr_exact(bulk_ranks[[nm]], hallmark)
    z$analysis <- nm
    z
  }))
  write.csv(camera_bulk, camera_bulk_file, row.names = FALSE)
}

# Running-sum permutation GSEA sensitivity for the six core pathways.
gsea_core_file <- file.path(out_dir, 'permutation_GSEA_core_pathways.csv')
if (file.exists(gsea_core_file)) {
  gsea_core <- read.csv(gsea_core_file, stringsAsFactors = FALSE)
} else {
  gsea_core <- bind_rows(lapply(names(bulk_ranks), function(nm) {
    z <- gsea_permutation(bulk_ranks[[nm]], hallmark[core_pathways], B = 10000L)
    z$analysis <- nm
    z
  }))
  write.csv(gsea_core, gsea_core_file, row.names = FALSE)
}

# Direct time-point programme results are the primary temporal presentation.
time_ranks <- list(EMTAB_24h = ranks$EMTAB_h24,
  EMTAB_72h = ranks$EMTAB_h72, EMTAB_1week = ranks$EMTAB_week1)
time_camera_file <- file.path(out_dir, 'CAMERA_PR_EMTAB_timepoints.csv')
if (file.exists(time_camera_file)) {
  time_camera <- read.csv(time_camera_file, stringsAsFactors = FALSE)
} else {
  time_camera <- bind_rows(lapply(names(time_ranks), function(nm) {
    z <- camera_pr_exact(time_ranks[[nm]], hallmark)
    z$analysis <- nm
    z
  }))
  write.csv(time_camera, time_camera_file, row.names = FALSE)
}
time_gsea_file <- file.path(out_dir, 'permutation_GSEA_EMTAB_timepoints_core.csv')
if (file.exists(time_gsea_file)) {
  time_gsea <- read.csv(time_gsea_file, stringsAsFactors = FALSE)
} else {
  time_gsea <- bind_rows(lapply(names(time_ranks), function(nm) {
    z <- gsea_permutation(time_ranks[[nm]], hallmark[core_pathways], B = 10000L)
    z$analysis <- nm
    z
  }))
  write.csv(time_gsea, time_gsea_file, row.names = FALSE)
}

# All-probe/Simes GSE8342 sensitivity using a signed normal statistic.
ap <- read.csv(gzfile(file.path(root, 'results', 'GSE8342',
  'all_probe_simes__strain_by_noise_interaction.csv.gz')),
  stringsAsFactors = FALSE, check.names = FALSE)
effect_col <- intersect(c('median_logFC_same_direction', 'median_logFC', 'logFC'), names(ap))[1]
p_col <- intersect(c('Simes_PValue', 'PValue', 'simes_p'), names(ap))[1]
if (!is.na(effect_col) && !is.na(p_col)) {
  ap_stat <- signed_z(ap[[effect_col]], ap[[p_col]])
  names(ap_stat) <- toupper(ap$gene_symbol)
  ap_camera <- camera_pr_exact(ap_stat, hallmark)
  ap_camera$analysis <- 'GSE8342_all_probe_Simes'
  write.csv(ap_camera, file.path(out_dir, 'CAMERA_PR_GSE8342_all_probe_sensitivity.csv'),
    row.names = FALSE)
}

# CAMERA-PR for every eligible mouse-by-cell-class pseudobulk contrast, with
# both within-class and global multiple-testing correction.
cell_files <- list.files(file.path(root, 'results', 'GSE168041_celltype'),
  pattern = '__noise_vs_naive[.]csv[.]gz$', full.names = TRUE)
camera_cell <- bind_rows(lapply(cell_files, function(f) {
  z <- read_de(f)
  stat <- z$t
  names(stat) <- toupper(z$gene_symbol)
  ans <- camera_pr_exact(stat, hallmark)
  ans$celltype_analysis <- sub('__noise_vs_naive[.]csv[.]gz$', '', basename(f))
  ans$within_class_FDR <- ans$FDR
  ans$FDR <- NULL
  ans
}))
camera_cell$global_FDR <- p.adjust(camera_cell$PValue, method = 'BH')
write.csv(camera_cell, file.path(out_dir,
  'CAMERA_PR_cellclass_within_and_global_FDR.csv'), row.names = FALSE)

# Cross-method and cross-ranking evidence summary.
primary_camera <- camera_bulk %>%
  filter(analysis %in% c('GSE8342_resilience', 'consistency_weighted_mean_t')) %>%
  transmute(pathway, analysis, camera_direction = Direction,
    camera_score = camera_t, camera_P = PValue, camera_FDR = FDR) %>%
  pivot_wider(names_from = analysis,
    values_from = c(camera_direction, camera_score, camera_P, camera_FDR))

gsea_wide <- gsea_core %>%
  filter(analysis %in% c('GSE8342_resilience', 'consistency_weighted_mean_t')) %>%
  transmute(pathway, analysis, gsea_NES = NES, gsea_P = PValue,
    gsea_FDR = FDR, gsea_leading_edge = leading_edge) %>%
  pivot_wider(names_from = analysis,
    values_from = c(gsea_NES, gsea_P, gsea_FDR, gsea_leading_edge))

pers_stability <- camera_bulk %>%
  filter(analysis %in% names(persistence_ranks)) %>%
  group_by(pathway) %>%
  summarise(
    persistence_up_methods = sum(Direction == 'Up'),
    persistence_down_methods = sum(Direction == 'Down'),
    persistence_direction_agreement = max(persistence_up_methods,
      persistence_down_methods),
    persistence_consensus_direction = ifelse(persistence_up_methods >=
      persistence_down_methods, 'Up', 'Down'),
    min_persistence_camera_FDR = min(FDR), .groups = 'drop'
  )

cell_support <- camera_cell %>%
  filter(global_FDR < 0.10) %>%
  group_by(pathway) %>%
  summarise(
    positive_global_cell_classes = paste(celltype_analysis[Direction == 'Up'],
      collapse = ';'),
    negative_global_cell_classes = paste(celltype_analysis[Direction == 'Down'],
      collapse = ';'),
    n_global_cell_classes = n(), .groups = 'drop'
  )

time_camera_summary <- time_camera %>%
  group_by(pathway) %>%
  summarise(time_camera_directions = paste(analysis, Direction, sep = ':',
    collapse = ';'),
    time_camera_same_direction = n_distinct(Direction) == 1,
    time_camera_consensus = ifelse(time_camera_same_direction,
      first(Direction), 'mixed'),
    time_camera_significant_points = sum(FDR < 0.10), .groups = 'drop')
time_gsea_summary <- time_gsea %>%
  mutate(Direction = ifelse(NES >= 0, 'Up', 'Down')) %>%
  group_by(pathway) %>%
  summarise(time_gsea_directions = paste(analysis, Direction, sep = ':',
    collapse = ';'),
    time_gsea_same_direction = n_distinct(Direction) == 1,
    time_gsea_consensus = ifelse(time_gsea_same_direction,
      first(Direction), 'mixed'),
    time_gsea_significant_points = sum(FDR < 0.10), .groups = 'drop')

evidence <- primary_camera %>%
  full_join(gsea_wide, by = 'pathway') %>%
  full_join(pers_stability, by = 'pathway') %>%
  left_join(cell_support, by = 'pathway') %>%
  left_join(time_camera_summary, by = 'pathway') %>%
  left_join(time_gsea_summary, by = 'pathway') %>%
  mutate(
    resilience_cross_method_direction = ifelse(
      camera_direction_GSE8342_resilience ==
        ifelse(gsea_NES_GSE8342_resilience >= 0, 'Up', 'Down'),
      'concordant', 'discordant'),
    persistence_cross_method_direction = ifelse(
      camera_direction_consistency_weighted_mean_t ==
        ifelse(gsea_NES_consistency_weighted_mean_t >= 0, 'Up', 'Down'),
      'concordant', 'discordant'),
    resilience_evidence = case_when(
      camera_FDR_GSE8342_resilience < 0.05 &
        resilience_cross_method_direction == 'concordant' ~ 'High-confidence',
      camera_FDR_GSE8342_resilience < 0.10 &
        resilience_cross_method_direction == 'concordant' ~ 'Moderate',
      gsea_FDR_GSE8342_resilience < 0.10 &
        resilience_cross_method_direction == 'concordant' ~ 'Exploratory',
      TRUE ~ 'Unsupported/method-sensitive'),
    temporal_evidence = case_when(
      time_camera_same_direction & time_gsea_same_direction &
        time_camera_consensus == time_gsea_consensus &
        (time_camera_significant_points > 0 | time_gsea_significant_points > 0) ~
          paste0('Persistence-linked ', tolower(time_camera_consensus)),
      TRUE ~ 'Time-varying'),
    evidence_grade = case_when(
      resilience_evidence == 'High-confidence' &
        grepl('Persistence-linked', temporal_evidence) &
        n_global_cell_classes > 0 ~ 'High-confidence cross-axis',
      resilience_evidence %in% c('High-confidence', 'Moderate') |
        grepl('Persistence-linked', temporal_evidence) ~ 'Moderate/context-specific',
      TRUE ~ 'Exploratory')
  )
write.csv(evidence, file.path(tab_dir,
  'Table_2_standard_cross_method_programme_evidence.csv'), row.names = FALSE)

# Increase the matched null to 50,000 draws and report effect-size summaries.
s4 <- read.csv(file.path(tab_dir, 'Table_S4_GSE8342_resilience_gene_evidence.csv'),
  stringsAsFactors = FALSE)
qmap <- read.csv(file.path(root, 'source_data', 'GSE8342',
  'representative_probe_map.csv'), stringsAsFactors = FALSE)
s4 <- merge(s4, qmap[, c('gene_symbol', 'mean_expression', 'variance')],
  by = 'gene_symbol', all.x = TRUE)
emclass <- read.csv(file.path(tab_dir, 'Table_S5_E-MTAB_temporal_gene_classes.csv'),
  stringsAsFactors = FALSE)
support_cols <- intersect(c('gene_symbol', 'effect_consistent_persistent',
  'temporal_class', 'h24_logFC', 'h72_logFC', 'week1_logFC'), names(emclass))
s4 <- merge(s4, emclass[, support_cols], by = 'gene_symbol', all.x = TRUE,
  suffixes = c('', '_em'))
effect_consistent <- if ('effect_consistent_persistent' %in% names(s4))
  s4$effect_consistent_persistent else
  s4$temporal_class %in% c('persistent increase', 'persistent decrease')
s4$externally_supported <- effect_consistent &
  sign(s4$interaction_logFC) == sign(s4$h24_logFC) &
  sign(s4$interaction_logFC) == sign(s4$h72_logFC) &
  sign(s4$interaction_logFC) == sign(s4$week1_logFC)

bin_safe <- function(x, n) {
  q <- unique(quantile(x, probs = seq(0, 1, length.out = n + 1), na.rm = TRUE))
  cut(x, breaks = q, include.lowest = TRUE, labels = FALSE)
}
s4$expr_bin <- bin_safe(s4$mean_expression, 10)
s4$var_bin <- bin_safe(log1p(s4$variance), 5)
s4$stratum <- interaction(s4$expr_bin, s4$var_bin, drop = TRUE)

perm_one <- function(p_cut, fc_cut, B = 50000L) {
  candidate <- which(s4$interaction_PValue < p_cut &
    abs(s4$interaction_logFC) >= fc_cut &
    sign(s4$interaction_logFC) == sign(s4$resistant_logFC) &
    !is.na(s4$stratum))
  obs <- sum(s4$externally_supported[candidate], na.rm = TRUE)
  candidate_strata <- table(s4$stratum[candidate])
  null_mat <- sapply(names(candidate_strata), function(st) {
    pool <- which(s4$stratum == st & !seq_len(nrow(s4)) %in% candidate)
    k <- unname(candidate_strata[st])
    if (length(pool) < k) pool <- which(s4$stratum == st)
    success <- sum(s4$externally_supported[pool], na.rm = TRUE)
    rhyper(B, success, length(pool) - success, min(k, length(pool)))
  })
  null <- if (is.null(dim(null_mat))) null_mat else rowSums(null_mat)
  data.frame(P_threshold = p_cut, abs_logFC_threshold = fc_cut,
    candidate_n = length(candidate), observed = obs,
    expected = mean(null), observed_expected_ratio = obs / mean(null),
    empirical_percentile = mean(null <= obs),
    empirical_P = (1 + sum(null >= obs)) / (B + 1), permutations = B)
}
perm_grid <- bind_rows(lapply(c(0.05, 0.10), function(p)
  bind_rows(lapply(c(0.25, 0.50, 0.75), function(fc) perm_one(p, fc)))))
write.csv(perm_grid, file.path(out_dir,
  'expression_variance_matched_permutation_50000_grid.csv'), row.names = FALSE)

summary_out <- data.frame(
  metric = c('corrected_IUT_FDR_lt_0.10', 'persistence_rankings',
    'cellclass_pathway_tests', 'global_cellclass_pathway_FDR_lt_0.10'),
  value = c(sum(em$IUT_FDR_bidirectional < 0.10, na.rm = TRUE),
    length(persistence_ranks), nrow(camera_cell),
    sum(camera_cell$global_FDR < 0.10, na.rm = TRUE))
)
write.csv(summary_out, file.path(out_dir, 'reanalysis_summary.csv'), row.names = FALSE)

cat('Standard pathway and robustness reanalysis complete.\n')
print(summary_out)
print(evidence[evidence$pathway %in% core_pathways,
  c('pathway', 'evidence_grade', 'persistence_direction_agreement')])
