#!/usr/bin/env Rscript
# 98_smoke_test.R -- compare the pipeline output with the reported values.
#
# Reads results/tables/*.csv and checks a fixed list of registry keys against
# the values in the submitted manuscript. Two tolerance rules apply:
#
#   absolute 1e-8   the default, used for every derived value
#   relative 1e-5   used for the GSE100365 moderated t statistic and anything
#                   derived from it. limma's empirical-Bayes variance shrinkage
#                   follows a slightly different numerical path for that dataset
#                   on different builds, producing a systematic difference of
#                   about 7e-6 in t (relative 1.7e-6). Direction and FDR category
#                   are unchanged; see README, 'Known numerical differences'.
#
# Direction and FDR category are always required to match exactly, for every
# dataset including GSE100365.
#
# Usage: Rscript scripts/98_smoke_test.R [--strict]
#   --strict  also require the pinned limma 3.62.2 / edgeR 4.4.2 builds; without
#             it a version mismatch is a warning that weakens the comparison.

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))

args <- commandArgs(trailingOnly = TRUE)
strict <- '--strict' %in% args
if (strict) nihl_require_versions()
options(warn = 1)

tables_dir <- nihl_paths$results_tables
stopifnot(dir.exists(tables_dir))

# Tables are UTF-8 on disk; the encoding is declared explicitly so that
# programme labels carrying Greek letters compare correctly even under a C
# locale, where R would otherwise treat the bytes as unknown.
read_tab <- function(name) {
  path <- file.path(tables_dir, name)
  if (!file.exists(path)) stop('Missing table: ', name)
  read.csv(path, stringsAsFactors = FALSE, check.names = FALSE,
           encoding = 'UTF-8')
}
# A single-dataset run (run_all.R --dataset X) builds only the tables that series
# supports. Each block of checks names the tables it reads; a block whose tables
# are absent is recorded as 'not evaluated' instead of failing. In a full run
# every block is evaluated, and a missing table is a failure.
single_dataset <- nzchar(Sys.getenv('NIHL_DATASETS')) || '--single' %in% commandArgs(trailingOnly = TRUE)
not_evaluated <- character()
block <- function(label, tables, expr) {
  missing <- tables[!file.exists(file.path(tables_dir, tables))]
  if (length(missing) && single_dataset) {
    not_evaluated[[label]] <<- paste(missing, collapse = ', ')
    cat('  [not evaluated] ', label, ' - table absent in single-dataset run: ',
        paste(missing, collapse = ', '), '\n', sep = '')
    return(invisible(NULL))
  }
  eval.parent(substitute(expr))
}

# Programme labels, defined once. Matching is done through these constants so a
# label change in one place cannot silently make a check pass by skipping it.
LAB <- c(TNFA = 'TNF-\u03b1 signaling via NF-\u03baB',
         INFL = 'Inflammatory response',
         UPR = 'Unfolded protein response',
         OXPHOS = 'Oxidative phosphorylation',
         E2F = 'E2F targets')

pct <- function(x, digits = 4) formatC(x, format = 'f', digits = digits)

# ---------------------------------------------------------------- helper
results <- data.frame(key = character(), expected = character(),
                      observed = character(), tolerance = character(),
                      pass = logical(), note = character(),
                      stringsAsFactors = FALSE)
check <- function(key, expected, observed, tol = 'abs 1e-8', note = '') {
  # Tolerance strings: "abs <value>", "rel <value>" or "exact".
  parts <- strsplit(tol, ' ', fixed = TRUE)[[1]]
  if (length(observed) != 1L || length(expected) != 1L) {
    ok <- FALSE
  } else if (identical(parts[1], 'exact')) {
    ok <- identical(as.character(observed), as.character(expected)) ||
      isTRUE(all.equal(as.character(observed), as.character(expected)))
  } else if (is.numeric(observed)) {
    threshold <- as.numeric(parts[2])
    if (identical(parts[1], 'rel')) threshold <- abs(expected) * threshold
    ok <- is.finite(observed) && abs(observed - expected) <= threshold
  } else {
    ok <- identical(as.character(observed), as.character(expected))
  }
  results[nrow(results) + 1, ] <<- list(key = key,
                                        expected = as.character(expected)[1],
                                        observed = as.character(observed)[1],
                                        tolerance = tol,
                                        pass = isTRUE(ok),
                                        note = note)
  invisible(ok)
}

# ------------------------------------------------------- Table 2 (IUT)
block('Table 2 (IUT)', c('Table_2_activation_to_resolution_IUT.csv'), {
iut <- read_tab('Table_2_activation_to_resolution_IUT.csv')
row <- function(tab, program) tab[tab$Program == program, ]
# Table 2 prints t to three decimals, so 5e-4 is the exact rounding half-width.
check('iut.E-MTAB.TNFA.t_72vCtrl', 3.910,
      as.numeric(row(iut, LAB[['TNFA']])[[2]]), 'abs 5e-4',
      'manuscript reports 3.910 (three decimals)')
check('iut.E-MTAB.TNFA.t_w1v72', -5.147,
      as.numeric(row(iut, LAB[['TNFA']])[[3]]), 'abs 5e-4',
      'manuscript reports -5.147 (three decimals)')
check('iut.E-MTAB.TNFA.fdr', 0.00157,
      as.numeric(row(iut, LAB[['TNFA']])[['IUT BH FDR']]), 'abs 1e-4')
check('iut.E-MTAB.INFL.fdr', 0.0471,
      as.numeric(row(iut, LAB[['INFL']])[['IUT BH FDR']]), 'abs 1e-4')
check('iut.E-MTAB.E2F.fdr', 0.0395,
      as.numeric(row(iut, LAB[['E2F']])[['IUT BH FDR']]), 'abs 1e-4')
check('iut.E-MTAB.OXPHOS.fdr', 0.0842,
      as.numeric(row(iut, LAB[['OXPHOS']])[['IUT BH FDR']]), 'abs 1e-4')
check('iut.E-MTAB.UPR.fdr', 0.409,
      as.numeric(row(iut, LAB[['UPR']])[['IUT BH FDR']]), 'abs 1e-3')
check('iut.E-MTAB.UPR.category', 'Not supported',
      row(iut, LAB[['UPR']])[['Evidence category']])
})

# --------------------------------------------------- Table 3 (synthesis)
block('Table 3 (synthesis)', c('Table_3_cross_study_programme_evidence.csv',
                              'Table_S10_all_50_hallmark_cross_study_synthesis.csv'), {
syn <- read_tab('Table_3_cross_study_programme_evidence.csv')
acc <- function(stratum, program) {
  syn[syn$Stratum == stratum & syn$Program == program, ]
}
check('syn.acute.w_equal.TNFA.Z', 17.069,
      as.numeric(acc('Acute/exposure-end response',
                     LAB[['TNFA']])[['Directional Stouffer Z']]), 'abs 5e-4')
check('syn.acute.w_equal.INFL.Z', 4.554,
      as.numeric(acc('Acute/exposure-end response',
                     LAB[['INFL']])[['Directional Stouffer Z']]), 'abs 5e-4')
n_up <- as.integer(sub(' up.*', '',
  acc('Acute/exposure-end response',
      LAB[['TNFA']])[['Direction summary']]))
check('syn.acute.TNFA.n_up', 4L, n_up, 'exact')
check('syn.acute.TNFA.k', 4,
      acc('Acute/exposure-end response',
          LAB[['TNFA']])[['Independent studies']])
check('syn.later.UPR.perm_fdr', 0.381,
      as.numeric(acc('Later transition relative to early response',
                     LAB[['UPR']])[['Permutation FDR']]), 'abs 5e-4',
      'manuscript Table 3 value')
# The two theoretical-FDR columns must come from their own BH families: the
# 5-programme column from the focal family, the 50-set column from the
# all-Hallmark family of Table S10 (they coincide only by accident).
s10 <- read_tab('Table_S10_all_50_hallmark_cross_study_synthesis.csv')
hallmark_of <- c('TNF-\u03b1 signaling via NF-\u03baB' = 'HALLMARK_TNFA_SIGNALING_VIA_NFKB',
                 'Inflammatory response' = 'HALLMARK_INFLAMMATORY_RESPONSE',
                 'Unfolded protein response' = 'HALLMARK_UNFOLDED_PROTEIN_RESPONSE',
                 'Oxidative phosphorylation' = 'HALLMARK_OXIDATIVE_PHOSPHORYLATION',
                 'E2F targets' = 'HALLMARK_E2F_TARGETS')
stratum_s10 <- c('Acute/exposure-end response' = 'acute/exposure-end response',
                 'Approximately 24-h response' = 'approximately 24 h response',
                 'Later transition relative to early response' =
                   'later transition relative to early response')
for (i in seq_len(nrow(syn))) {
  key <- paste('syn.theory50', i, syn$Program[i], sep = '.')
  s10_row <- s10[s10$stratum == stratum_s10[[syn$Stratum[i]]] &
                 s10$program == hallmark_of[[syn$Program[i]]], ]
  check(key, s10_row$FDR,
        as.numeric(syn[['Theoretical BH FDR (50 Hallmark sets)']][i]),
        'rel 6e-3',
        'must equal Table S10 (50-set BH family), not the 5-programme family; 3-significant-digit print rounding allows up to 0.5 percent')
}
})

# ------------------------------------------------------ Table 4 (cell class)
block('Table 4 (cell class)', c('Table_4_broad_cell_class_localization.csv'), {
t4 <- read_tab('Table_4_broad_cell_class_localization.csv')
check('sc.localization.TNFA.n_pos', 3,
      t4[t4$Program == LAB[['TNFA']], ][['Positive n']])
check('sc.localization.TNFA.n_neg', 5,
      t4[t4$Program == LAB[['TNFA']], ][['Negative n']])
check('sc.localization.INFL.n_pos', 6,
      t4[t4$Program == LAB[['INFL']], ][['Positive n']])
check('sc.localization.INFL.n_neg', 2,
      t4[t4$Program == LAB[['INFL']], ][['Negative n']])
})

# -------------------------------------------------- Additional file 8 (S7)
block('Table S7 ledger', c('Table_S7_seven_programme_direction_stability_ledger.csv'), {
s7 <- read_tab('Table_S7_seven_programme_direction_stability_ledger.csv')
check('count.sc.stability.rows', 91L, nrow(s7), 'exact',
      'seven programmes x 13 combinations')
check('count.sc.stability.stable', 89L, sum(s7$stable %in% c(TRUE, 'TRUE')), 'exact')
check('def.sc_programs.n', 7L, length(unique(s7$pathway)), 'exact')
check('def.sc_contrasts.n', 13L,
      length(unique(paste(s7$tissue_cohort, s7$cell_type))), 'exact')
})

# ------------------------------------------------ Additional file 3 (S2), GSE100365
s2 <- if (file.exists(file.path(tables_dir, 'Table_S2_per_dataset_targeted_programmes.csv'))) read_tab('Table_S2_per_dataset_targeted_programmes.csv') else NULL
block('Table S2 GSE100365', 'Table_S2_per_dataset_targeted_programmes.csv', if (!single_dataset || 'GSE100365' %in% strsplit(Sys.getenv('NIHL_DATASETS'), ',')[[1]]) {
g100 <- s2[s2$dataset == 'GSE100365', ]
# GSE100365 is the only dataset that needs a relative tolerance; the moderated t
# itself is stored at full precision in Table S2, so the check uses the
# published value for the unfolded-protein response (3.442 to three decimals).
# The expected values below are the full-precision numbers stored in the
# submitted Table S2 (the same file the manuscript's rounded figures come from),
# so the relative tolerance tests the recomputation, not the rounding.
check('pre.GSE100365.immediate_vs_control.TNFA.t', 8.23109521657359,
      as.numeric(g100[g100$contrast == 'immediate_vs_control' &
                        g100$Program == LAB[['TNFA']], ]$camera_t),
      'rel 1e-5', 'GSE100365 uses relative tolerance; see README')
check('pre.GSE100365.immediate_vs_control.UPR.t', 3.44225977658585,
      as.numeric(g100[g100$contrast == 'immediate_vs_control' &
                        g100$Program == LAB[['UPR']], ]$camera_t),
      'rel 1e-5', 'GSE100365 uses relative tolerance; see README')
# Frozen baseline from the supplied submitted Table S2, independent of the
# currently generated s2 object. Require exactly the same keys and directions.
expected_g100 <- setNames(
  c('Down', 'Up', 'Down', 'Up', 'Up', 'Up', 'Up', 'Down', 'Up', 'Up', 'Down', 'Up', 'Up', 'Down', 'Up', 'Down', 'Up', 'Up', 'Down', 'Up', 'Up', 'Up', 'Up', 'Down', 'Up', 'Down', 'Down', 'Up', 'Down', 'Down', 'Up', 'Down', 'Up', 'Up', 'Up'),
  c('immediate_vs_control|E2F targets', 'immediate_vs_control|Inflammatory response', 'immediate_vs_control|Oxidative phosphorylation', 'immediate_vs_control|TNF-α signaling via NF-κB', 'immediate_vs_control|Unfolded protein response', 'day1_vs_control|E2F targets', 'day1_vs_control|Inflammatory response', 'day1_vs_control|Oxidative phosphorylation', 'day1_vs_control|TNF-α signaling via NF-κB', 'day1_vs_control|Unfolded protein response', 'day7_vs_control|E2F targets', 'day7_vs_control|Inflammatory response', 'day7_vs_control|Oxidative phosphorylation', 'day7_vs_control|TNF-α signaling via NF-κB', 'day7_vs_control|Unfolded protein response', 'day14_vs_control|E2F targets', 'day14_vs_control|Inflammatory response', 'day14_vs_control|Oxidative phosphorylation', 'day14_vs_control|TNF-α signaling via NF-κB', 'day14_vs_control|Unfolded protein response', 'day1_vs_immediate|E2F targets', 'day1_vs_immediate|Inflammatory response', 'day1_vs_immediate|Oxidative phosphorylation', 'day1_vs_immediate|TNF-α signaling via NF-κB', 'day1_vs_immediate|Unfolded protein response', 'day7_vs_day1|E2F targets', 'day7_vs_day1|Inflammatory response', 'day7_vs_day1|Oxidative phosphorylation', 'day7_vs_day1|TNF-α signaling via NF-κB', 'day7_vs_day1|Unfolded protein response', 'day14_vs_day7|E2F targets', 'day14_vs_day7|Inflammatory response', 'day14_vs_day7|Oxidative phosphorylation', 'day14_vs_day7|TNF-α signaling via NF-κB', 'day14_vs_day7|Unfolded protein response'))
g100_keys <- paste(g100$contrast, g100$Program, sep = '|')
check('pre.GSE100365.direction.consistency', TRUE,
      !anyDuplicated(g100_keys) && setequal(g100_keys, names(expected_g100)) &&
        all(g100$direction == unname(expected_g100[g100_keys])),
      'exact', 'directions and keys must match the frozen submitted baseline')
})

# ---------------------------------- the other three external datasets, absolute
block('Table S2 external rows', 'Table_S2_per_dataset_targeted_programmes.csv', {
s2 <- read_tab('Table_S2_per_dataset_targeted_programmes.csv')
for (ds in intersect(c('GSE160639', 'GSE196870', 'GSE312476'), unique(s2$dataset))) {
  sub <- s2[s2$dataset == ds, ]
  check(paste0('pre.', ds, '.rows.nonzero'), TRUE, nrow(sub) > 0, 'exact')
}
})
block('GSE160639 TNFA t', 'Table_S2_per_dataset_targeted_programmes.csv', {
s2 <- read_tab('Table_S2_per_dataset_targeted_programmes.csv')
check('pre.GSE160639.dB105_vs_70.TNFA.t', 9.0330883807,
      as.numeric(s2[s2$dataset == 'GSE160639' & s2$contrast == 'dB105_vs_70' &
                      s2$Program == LAB[['TNFA']], ]$camera_t), 'abs 5e-4')
})
if (!single_dataset || 'GSE196870' %in% strsplit(Sys.getenv('NIHL_DATASETS'), ',')[[1]]) {
check('pre.GSE196870.noise_1h_vs_control.UPR.t', 4.2362321582,
      as.numeric(s2[s2$dataset == 'GSE196870' & s2$contrast == 'noise_1h_vs_control' &
                      s2$Program == LAB[['UPR']], ]$camera_t), 'abs 5e-4')
}

# --------------------------------------------------- Supplementary S10/S11/S13
block('S10/S11/S13 row counts', c('Table_S10_all_50_hallmark_cross_study_synthesis.csv', 'Table_S11A_complete_650_primary_pseudobulk_results.csv', 'Table_S11B_complete_2640_definition_sensitivity_results.csv', 'Table_S13_GSE168041_mouse_by_class_manifest.csv'), {
check('count.hallmark.synthesis.rows', 150L,
      nrow(read_tab('Table_S10_all_50_hallmark_cross_study_synthesis.csv')), 'exact')
check('count.primary.pseudobulk.rows', 650L,
      nrow(read_tab('Table_S11A_complete_650_primary_pseudobulk_results.csv')), 'exact')
check('count.sensitivity.rows', 2640L,
      nrow(read_tab('Table_S11B_complete_2640_definition_sensitivity_results.csv')), 'exact')
check('count.mouse_class.rows', 128L,
      nrow(read_tab('Table_S13_GSE168041_mouse_by_class_manifest.csv')), 'exact')
})

# ---------------------------------------------------------------- report
n_pass <- sum(as.logical(results$pass))
n_fail <- sum(!as.logical(results$pass))
if (length(not_evaluated)) {
  cat('\nNot evaluated in this single-dataset run:', length(not_evaluated), 'blocks\n')
}
cat('\nSmoke test: ', n_pass, ' of ', nrow(results), ' checks passed',
    if (n_fail > 0) paste0(" (", n_fail, " failed)") else "", "\n", sep = "")
if (n_fail > 0) {
  print(results[!as.logical(results$pass), c('key', 'expected', 'observed', 'tolerance', 'note')],
        row.names = FALSE)
}

out <- file.path(nihl_paths$work, 'smoke_test_results.csv')
nihl_write_csv(results, out)
cat('Detailed results:', out, '\n')

if (n_fail > 0 && strict) quit(status = 1L)
invisible(results)
