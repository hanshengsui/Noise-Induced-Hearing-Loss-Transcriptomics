#!/usr/bin/env Rscript
# 01_gse8342_discovery.R -- strain-associated discovery series (Table 1, Table 3, Figure 2A).
#
# Affymetrix Mouse 430A (GPL81) microarrays, four groups in a
# strain-by-noise factorial design. Interaction coefficient = susceptible noise
# effect minus resistant noise effect, so a positive value means the noise-induced
# increase was larger in the susceptible strain (B6.CAST-Cdh23CAST/J).

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
source(file.path(nihl_paths$scripts, 'utils.R'))
nihl_require_versions('3.62.2', '4.4.2')
nihl_require_inputs(nihl_inputs[c('GSE8342_series_matrix', 'GPL81_annotation')])

set.seed(20260712)

root <- Sys.getenv('NIHL_ANALYSIS_ROOT', 'outputs/NIHL_submission')
res_dir <- file.path(root, 'results', 'GSE8342')
tab_dir <- file.path(root, 'tables')
qc_dir <- file.path(root, 'source_data', 'GSE8342')
dir.create(res_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tab_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qc_dir, recursive = TRUE, showWarnings = FALSE)

clean_symbol <- function(x) {
  x <- trimws(sub('///.*$', '', as.character(x)))
  x[x %in% c('', '---', 'NA', 'null')] <- NA_character_
  x
}

contrast_table <- function(fit, coef_name, feature_df) {
  tt <- topTable(fit, coef = coef_name, number = Inf, sort.by = 'none')
  se <- fit$stdev.unscaled[, coef_name] * sqrt(fit$s2.post)
  df <- fit$df.total
  crit <- qt(0.975, df = df)
  data.frame(
    feature_df,
    contrast = coef_name,
    logFC = tt$logFC,
    SE = se,
    CI_low = tt$logFC - crit * se,
    CI_high = tt$logFC + crit * se,
    AveExpr = tt$AveExpr,
    moderated_t = tt$t,
    PValue = tt$P.Value,
    FDR = tt$adj.P.Val,
    B = tt$B,
    df_total = df,
    stringsAsFactors = FALSE
  )
}

simes <- function(p) {
  p <- sort(p[is.finite(p)])
  if (!length(p)) return(NA_real_)
  min(1, min(length(p) * p / seq_along(p)))
}

aggregate_probes <- function(x) {
  sp <- split(seq_len(nrow(x)), x$gene_symbol)
  out <- lapply(names(sp), function(g) {
    z <- x[sp[[g]], , drop = FALSE]
    med <- median(z$logFC, na.rm = TRUE)
    d <- sign(med)
    same <- if (d == 0) rep(TRUE, nrow(z)) else sign(z$logFC) == d
    if (!any(same)) same <- rep(TRUE, nrow(z))
    data.frame(
      gene_symbol = g,
      contrast = z$contrast[1],
      n_probes = nrow(z),
      median_logFC_all = med,
      median_logFC_same_direction = median(z$logFC[same], na.rm = TRUE),
      same_direction_fraction = mean(same),
      Simes_PValue = simes(z$PValue[same]),
      min_probe_PValue = min(z$PValue, na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  })
  out <- do.call(rbind, out)
  out$Simes_FDR <- p.adjust(out$Simes_PValue, method = 'BH')
  out
}

g <- read_geo_series_matrix(nihl_inputs$GSE8342_series_matrix)
y <- g$expr
if (max(y, na.rm = TRUE) > 100) y <- log2(y + 1)

titles <- g$sample_meta$title[match(colnames(y), g$sample_meta$sample_id)]
group <- ifelse(grepl('B6\\.CAST', titles) & grepl('_noise_', titles), 'susceptible_noise',
         ifelse(grepl('B6\\.CAST', titles), 'susceptible_control',
         ifelse(grepl('_noise_', titles), 'resistant_noise', 'resistant_control')))
group <- factor(group, levels = c('resistant_control', 'resistant_noise',
                                  'susceptible_control', 'susceptible_noise'))
design <- model.matrix(~0 + group)
colnames(design) <- levels(group)

C <- cbind(
  resistant_noise_vs_control = c(-1, 1, 0, 0),
  susceptible_noise_vs_control = c(0, 0, -1, 1),
  strain_by_noise_interaction = c(-1, 1, 1, -1)
)
rownames(C) <- colnames(design)

annot <- read_geo_annotation(nihl_inputs$GPL81_annotation)
feature <- data.frame(
  probe_id = rownames(y),
  gene_symbol = clean_symbol(annot$`Gene symbol`[match(rownames(y), annot$ID)]),
  gene_title = annot$`Gene title`[match(rownames(y), annot$ID)],
  gene_id = annot$`Gene ID`[match(rownames(y), annot$ID)],
  mean_expression = rowMeans(y, na.rm = TRUE),
  variance = apply(y, 1, var, na.rm = TRUE),
  stringsAsFactors = FALSE
)

valid <- !is.na(feature$gene_symbol)
y_all <- y[valid, , drop = FALSE]
f_all <- feature[valid, , drop = FALSE]

# Main probe-to-gene strategy: highest mean expression before modelling.
ord <- order(f_all$gene_symbol, -f_all$mean_expression, -f_all$variance, f_all$probe_id)
f_ord <- f_all[ord, , drop = FALSE]
keep_rep <- !duplicated(f_ord$gene_symbol)
rep_feature <- f_ord[keep_rep, , drop = FALSE]
y_rep <- y_all[match(rep_feature$probe_id, rownames(y_all)), , drop = FALSE]

fit_rep <- lmFit(y_rep, design)
fit_rep <- contrasts.fit(fit_rep, C)
fit_rep <- eBayes(fit_rep, robust = TRUE, trend = TRUE)

rep_results <- lapply(colnames(C), function(nm) contrast_table(fit_rep, nm, rep_feature))
names(rep_results) <- colnames(C)
for (nm in names(rep_results)) {
  con <- gzfile(file.path(res_dir, paste0('representative_probe__', nm, '.csv.gz')), 'wt')
  write.csv(rep_results[[nm]], con, row.names = FALSE, na = '')
  close(con)
}

# Sensitivity strategy: model all probes, retain same-direction probe effects,
# use the median effect and Simes-combined P value.
fit_all <- lmFit(y_all, design)
fit_all <- contrasts.fit(fit_all, C)
fit_all <- eBayes(fit_all, robust = TRUE, trend = TRUE)
all_probe_results <- lapply(colnames(C), function(nm) contrast_table(fit_all, nm, f_all))
names(all_probe_results) <- colnames(C)
agg_results <- lapply(all_probe_results, aggregate_probes)
for (nm in names(agg_results)) {
  con <- gzfile(file.path(res_dir, paste0('all_probe_simes__', nm, '.csv.gz')), 'wt')
  write.csv(agg_results[[nm]], con, row.names = FALSE, na = '')
  close(con)
}

ri <- rep_results$strain_by_noise_interaction
rr <- rep_results$resistant_noise_vs_control
ss <- rep_results$susceptible_noise_vs_control
idx_r <- match(ri$gene_symbol, rr$gene_symbol)
idx_s <- match(ri$gene_symbol, ss$gene_symbol)
idx_a <- match(ri$gene_symbol, agg_results$strain_by_noise_interaction$gene_symbol)

screen <- data.frame(
  gene_symbol = ri$gene_symbol,
  representative_probe = ri$probe_id,
  interaction_logFC = ri$logFC,
  interaction_SE = ri$SE,
  interaction_CI_low = ri$CI_low,
  interaction_CI_high = ri$CI_high,
  interaction_moderated_t = ri$moderated_t,
  interaction_PValue = ri$PValue,
  interaction_FDR = ri$FDR,
  resistant_logFC = rr$logFC[idx_r],
  resistant_SE = rr$SE[idx_r],
  susceptible_logFC = ss$logFC[idx_s],
  susceptible_SE = ss$SE[idx_s],
  all_probe_median_logFC = agg_results$strain_by_noise_interaction$median_logFC_same_direction[idx_a],
  all_probe_Simes_PValue = agg_results$strain_by_noise_interaction$Simes_PValue[idx_a],
  all_probe_Simes_FDR = agg_results$strain_by_noise_interaction$Simes_FDR[idx_a],
  probe_strategy_direction_agreement = sign(ri$logFC) == sign(agg_results$strain_by_noise_interaction$median_logFC_same_direction[idx_a]),
  stringsAsFactors = FALSE
)
screen$tier1_statistical <- with(screen,
  interaction_FDR < 0.10 & abs(interaction_logFC) >= 0.5 &
  sign(resistant_logFC) == sign(interaction_logFC))
screen$tier2_effect_screen_pre_external_support <- with(screen,
  interaction_PValue < 0.10 & abs(interaction_logFC) >= 0.5 &
  sign(resistant_logFC) == sign(interaction_logFC))
screen$high_confidence_probe_mapping <- with(screen,
  probe_strategy_direction_agreement &
  sign(resistant_logFC) == sign(interaction_logFC))
screen <- screen[order(screen$interaction_PValue, -abs(screen$interaction_logFC)), ]
write.csv(screen, file.path(tab_dir, 'Table_S4_GSE8342_resilience_gene_evidence.csv'), row.names = FALSE)

# Threshold sensitivity independent of external support.
grid <- expand.grid(
  interaction_abs_logFC = c(0.25, 0.5, 0.75),
  interaction_P = c(0.05, 0.10),
  stringsAsFactors = FALSE
)
grid$n_gene_screen <- mapply(function(fc, p) {
  with(screen, sum(abs(interaction_logFC) >= fc & interaction_PValue < p &
                   sign(resistant_logFC) == sign(interaction_logFC), na.rm = TRUE))
}, grid$interaction_abs_logFC, grid$interaction_P)
grid$n_probe_strategy_agree <- mapply(function(fc, p) {
  with(screen, sum(abs(interaction_logFC) >= fc & interaction_PValue < p &
                   sign(resistant_logFC) == sign(interaction_logFC) &
                   probe_strategy_direction_agreement, na.rm = TRUE))
}, grid$interaction_abs_logFC, grid$interaction_P)
write.csv(grid, file.path(qc_dir, 'resilience_threshold_sensitivity.csv'), row.names = FALSE)

sample_meta <- data.frame(
  sample_id = colnames(y), title = titles, group = as.character(group),
  strain = ifelse(grepl('B6\\.CAST', titles), 'B6.CAST', '129X1/SvJ'),
  exposure = ifelse(grepl('_noise_', titles), 'noise', 'sham'),
  biological_unit = 'independent_pool_of_8_mice',
  stringsAsFactors = FALSE
)
write.csv(sample_meta, file.path(qc_dir, 'sample_metadata.csv'), row.names = FALSE)
write.csv(rep_feature, file.path(qc_dir, 'representative_probe_map.csv'), row.names = FALSE)

pca <- prcomp(t(y_rep), center = TRUE, scale. = FALSE)
pca_out <- cbind(sample_meta, PC1 = pca$x[, 1], PC2 = pca$x[, 2])
attr(pca_out, 'variance_explained') <- summary(pca)$importance[2, 1:2]
write.csv(pca_out, file.path(qc_dir, 'pca_coordinates.csv'), row.names = FALSE)

summary_out <- data.frame(
  metric = c('genes_tested', 'tier1_statistical', 'tier2_effect_screen_pre_external_support',
             'tier2_with_probe_strategy_agreement'),
  value = c(nrow(screen), sum(screen$tier1_statistical, na.rm = TRUE),
            sum(screen$tier2_effect_screen_pre_external_support, na.rm = TRUE),
            sum(screen$tier2_effect_screen_pre_external_support & screen$probe_strategy_direction_agreement, na.rm = TRUE)),
  stringsAsFactors = FALSE
)
write.csv(summary_out, file.path(res_dir, 'formal_summary.csv'), row.names = FALSE)

cat('GSE8342 formal limma analysis complete.\n')
print(summary_out)
