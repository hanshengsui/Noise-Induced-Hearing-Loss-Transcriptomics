#!/usr/bin/env Rscript
# 05_cellclass_localization.R -- Broad cell-class localization of the ranked programmes (Table 4 inputs).
#
# Statistical calls are unchanged from the submitted analysis; only input and
# output locations are resolved through scripts/00_setup.R.

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
source(file.path(nihl_paths$scripts, 'utils.R'))
nihl_require_versions('3.62.2', '4.4.2')

root <- Sys.getenv('NIHL_ANALYSIS_ROOT', 'outputs/NIHL_submission')
res_dir <- file.path(root,'results','GSE168041_celltype')
src_dir <- file.path(root,'source_data','GSE168041_celltype')
tab_dir <- file.path(root,'tables')
out_dir <- file.path(root,'results','celltype_program_localization')
dir.create(out_dir,recursive=TRUE,showWarnings=FALSE)

read_gmt <- function(path) {
  x <- strsplit(readLines(path,warn=FALSE),'\t',fixed=TRUE)
  z <- lapply(x,function(v)unique(toupper(v[-c(1,2)])))
  names(z) <- vapply(x,`[`,character(1),1);z
}
collapse_rank <- function(z) {
  z <- z[is.finite(z$moderated_t) & !is.na(z$gene_symbol) & nzchar(z$gene_symbol),]
  z$key <- toupper(z$gene_symbol)
  z <- z[order(z$key,-abs(z$moderated_t)),]
  z <- z[!duplicated(z$key),]
  s <- z$moderated_t;names(s)<-z$key;sort(s,decreasing=TRUE)
}
rank_enrich <- function(stats,pathways,id) {
  N <- length(stats);ra <- rank(stats,ties.method='average');names(ra)<-names(stats)
  out <- lapply(names(pathways),function(pw){
    hit <- intersect(names(stats),pathways[[pw]]);m<-length(hit);n<-N-m
    if(m<10||m>500||n<10)return(NULL)
    U <- sum(ra[hit])-m*(m+1)/2
    z <- (U-m*n/2)/sqrt(m*n*(m+n+1)/12)
    data.frame(celltype_analysis=id,pathway=pw,overlap_size=m,
      AUC=U/(m*n),NES=z,PValue=2*pnorm(-abs(z)),stringsAsFactors=FALSE)
  })
  x<-do.call(rbind,out);x$FDR<-p.adjust(x$PValue,'BH');x
}

gmt <- read_gmt(nihl_inputs$human_gmt)
files <- list.files(res_dir,pattern='__noise_vs_naive[.]csv[.]gz$',full.names=TRUE)
de <- list(); enr <- list()
for(f in files){
  z<-read.csv(gzfile(f),stringsAsFactors=FALSE)
  id<-sub('__noise_vs_naive[.]csv[.]gz$','',basename(f))
  de[[id]]<-z
  enr[[id]]<-rank_enrich(collapse_rank(z),gmt,id)
}
enr<-do.call(rbind,enr);rownames(enr)<-NULL
write.csv(enr,file.path(tab_dir,'Table_S10_celltype_ranked_Hallmark_enrichment.csv'),
          row.names=FALSE)

two_d <- read.csv(file.path(tab_dir,'Table_2_resilience_persistence_programs.csv'),
                  stringsAsFactors=FALSE)
core <- unique(head(two_d$pathway,15))
loc <- enr[enr$pathway %in% core,]
loc$cell_type <- sub('^(neuronal_focused|lateral_wall_focused)_','',
                     loc$celltype_analysis)
loc$tissue_cohort <- ifelse(grepl('^neuronal_focused',loc$celltype_analysis),
                            'neuronal_focused','lateral_wall_focused')
loc <- merge(loc,two_d[,c('pathway','resilience_NES','resilience_FDR',
                          'persistence_NES','persistence_FDR','quadrant')],
             by='pathway',all.x=TRUE)
write.csv(loc,file.path(tab_dir,'Table_3_celltype_program_localization.csv'),
          row.names=FALSE)

# Baseline expression is deliberately separate from noise responsiveness.
base <- read.csv(gzfile(file.path(src_dir,'eligible_celltype_baseline_expression.csv.gz')),
                 stringsAsFactors=FALSE)
base$key<-toupper(base$gene_symbol)
baseline_pw <- do.call(rbind,lapply(split(base,paste(base$tissue_cohort,base$cell_type,sep='__')),
  function(z)do.call(rbind,lapply(core,function(pw){
    v<-z$baseline_mean_logCPM[z$key %in% gmt[[pw]]]
    data.frame(tissue_cohort=z$tissue_cohort[1],cell_type=z$cell_type[1],
      pathway=pw,n_genes=length(v),baseline_mean_logCPM=mean(v,na.rm=TRUE),
      stringsAsFactors=FALSE)
  }))))
write.csv(baseline_pw,file.path(src_dir,'celltype_program_baseline_expression.csv'),
          row.names=FALSE)

# Gene-level evidence table with explicit evidence tiers.
s4<-read.csv(file.path(tab_dir,'Table_S4_GSE8342_resilience_gene_evidence.csv'),
             stringsAsFactors=FALSE)
em<-read.csv(file.path(tab_dir,'Table_S5_E-MTAB_temporal_gene_classes.csv'),
             stringsAsFactors=FALSE)
em$external_direction<-sign(rowMeans(cbind(em$h24_logFC,em$h72_logFC,em$week1_logFC)))
gm<-merge(s4,em[,c('gene_symbol','effect_consistent_persistent','temporal_class',
  'h24_logFC','h72_logFC','week1_logFC','IUT_FDR','external_direction')],
  by='gene_symbol',all.x=TRUE)

cell_gene <- do.call(rbind,lapply(names(de),function(id){
  z<-de[[id]][,c('gene_symbol','logFC','moderated_t','FDR')]
  z$celltype_analysis<-id;z
}))
cell_gene <- cell_gene[!is.na(cell_gene$gene_symbol)&nzchar(cell_gene$gene_symbol),]
cg_split <- split(cell_gene,cell_gene$gene_symbol)
summ <- lapply(seq_len(nrow(gm)),function(i){
  z<-cg_split[[gm$gene_symbol[i]]]
  if(is.null(z))return(data.frame(gene_symbol=gm$gene_symbol[i],
    best_celltype=NA,best_celltype_t=NA,best_celltype_FDR=NA,
    n_same_direction_celltypes_FDR_0.10=0,same_direction_celltypes=''))
  k<-which.max(abs(z$moderated_t))
  same<-z$FDR<.10 & sign(z$logFC)==sign(gm$interaction_logFC[i])
  data.frame(gene_symbol=gm$gene_symbol[i],best_celltype=z$celltype_analysis[k],
    best_celltype_t=z$moderated_t[k],best_celltype_FDR=z$FDR[k],
    n_same_direction_celltypes_FDR_0.10=sum(same,na.rm=TRUE),
    same_direction_celltypes=paste(z$celltype_analysis[same],collapse=';'),
    stringsAsFactors=FALSE)
})
summ<-do.call(rbind,summ);gm<-merge(gm,summ,by='gene_symbol',all.x=TRUE)
gm$external_same_direction <- gm$effect_consistent_persistent &
  gm$external_direction==sign(gm$interaction_logFC)
gm$evidence_tier <- ifelse(gm$tier1_statistical & gm$external_same_direction &
  gm$n_same_direction_celltypes_FDR_0.10>0,'A_formal_cross_dataset',
  ifelse(gm$tier2_effect_screen_pre_external_support & gm$external_same_direction &
    gm$n_same_direction_celltypes_FDR_0.10>0,'B_triangular_support',
  ifelse(gm$tier2_effect_screen_pre_external_support &
    (gm$external_same_direction|gm$n_same_direction_celltypes_FDR_0.10>0),
    'C_partial_support','D_context_only')))
ord<-order(factor(gm$evidence_tier,levels=c('A_formal_cross_dataset',
  'B_triangular_support','C_partial_support','D_context_only')),
  gm$interaction_PValue,-abs(gm$interaction_logFC))
gm<-gm[ord,]
write.csv(gm,file.path(tab_dir,'Table_S11_gene_evidence_ledger.csv'),row.names=FALSE)
write.csv(head(gm[gm$evidence_tier!='D_context_only',c('gene_symbol','evidence_tier',
  'interaction_logFC','interaction_PValue','interaction_FDR','temporal_class',
  'h24_logFC','h72_logFC','week1_logFC','IUT_FDR','best_celltype',
  'best_celltype_t','best_celltype_FDR','n_same_direction_celltypes_FDR_0.10',
  'same_direction_celltypes')],30),
  file.path(tab_dir,'Table_S3_representative_gene_evidence.csv'),row.names=FALSE)

cat('Cell-type programme localization complete.\n')
print(aggregate(cbind(NES,FDR)~pathway,loc,function(x)c(min=min(x),max=max(x))))
print(table(gm$evidence_tier))
