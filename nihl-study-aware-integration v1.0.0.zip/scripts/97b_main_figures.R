#!/usr/bin/env Rscript
# 97b_main_figures.R -- main Figures 1-6 of the revised manuscript.
#
# The panel designs follow the submitted figures. Inputs are the outputs of the
# pipeline stages (work/revision, work/stage1) and of the revision analyses
# (revision/<track>/results). Each figure is written as PDF and PNG to
# results/figures/, and every plotted value is written to
# work/figure_source_data_main/<Figure>.csv.
#
# Evidence marks used in the revised manuscript:
#   Figure 3C  IUT FDR < 0.05 supported; 0.05-0.10 suggestive; >= 0.10 not supported
#   Figure 4A  ** permutation FDR < 0.05 and all studies concordant;
#              *  permutation FDR 0.05-0.10 and all studies concordant
#   Other heat maps: * within-analysis FDR < 0.10 (exploratory display threshold)

options(stringsAsFactors = FALSE)
source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))

suppressPackageStartupMessages({
  library(ggplot2); library(dplyr); library(tidyr); library(patchwork)
  library(ggrepel); library(scales)
})

# Fixed seed: ggrepel label placement and guide assembly are otherwise stochastic,
# which made Figure 2 byte-different between identical runs.
set.seed(20261029)

work <- nihl_paths$work
rev_root <- file.path(nihl_paths$repo_root, 'revision')
fig_dir <- nihl_paths$results_figures
src_dir <- file.path(work, 'figure_source_data_main')
for (d in c(fig_dir, src_dir)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

inp <- function(...) {
  p <- file.path(...)
  if (!file.exists(p)) stop('Missing figure input: ', p, call. = FALSE)
  read.csv(p, stringsAsFactors = FALSE, check.names = FALSE)
}

pal <- c(navy = '#17365D', blue = '#2F6FAE', teal = '#008A91', green = '#2F7D44',
         orange = '#E17C05', red = '#C9252D', purple = '#70429A',
         grey_dark = '#58657A', grey_mid = '#98A2B3', grey_light = '#E8EDF3',
         ink = '#1F2937')
fam <- 'Arial'

theme_pub <- function(base_size = 7.3) {
  theme_classic(base_size = base_size, base_family = fam) +
    theme(
      plot.title = element_text(size = base_size + 1.4, face = 'bold',
                                colour = pal[['ink']], margin = margin(b = 2.5, l = 12)),
      plot.subtitle = element_text(size = base_size - 0.3, colour = pal[['grey_dark']],
                                   lineheight = 1.05, margin = margin(b = 4, l = 12)),
      plot.tag = element_text(size = base_size + 2.4, face = 'bold'),
      axis.title = element_text(size = base_size + 0.2, face = 'bold',
                                colour = pal[['ink']]),
      axis.text = element_text(size = base_size, colour = pal[['ink']]),
      strip.text = element_text(size = base_size, face = 'bold', colour = pal[['ink']]),
      legend.title = element_text(size = base_size - 0.3, face = 'bold'),
      legend.text = element_text(size = base_size - 0.6),
      legend.key.height = unit(3.4, 'mm'), legend.key.width = unit(3.4, 'mm'),
      panel.grid.major = element_line(colour = '#E7EBF0', linewidth = 0.28),
      panel.grid.minor = element_blank(),
      axis.line = element_line(linewidth = 0.35, colour = pal[['ink']]),
      axis.ticks = element_line(linewidth = 0.35, colour = pal[['ink']]),
      plot.title.position = 'plot',
      legend.ticks = element_blank(),
      strip.background = element_rect(fill = '#F3F5F8', colour = NA),
      plot.margin = margin(5.5, 7, 5.5, 7)
    )
}
theme_set(theme_pub())

export_figure <- function(p, name, width_mm, height_mm) {
  w <- width_mm / 25.4; h <- height_mm / 25.4
  ggsave(file.path(fig_dir, paste0(name, '.pdf')), p, width = w, height = h,
         device = cairo_pdf, bg = 'white')
  ggsave(file.path(fig_dir, paste0(name, '.png')), p, width = w, height = h,
         device = 'png', type = 'cairo', dpi = 600, bg = 'white')
}
write_source <- function(lst, name) {
  long <- bind_rows(lapply(names(lst), function(k) {
    x <- lst[[k]]; x[] <- lapply(x, as.character); x$panel <- k; x
  }))
  long <- long[, c('panel', setdiff(names(long), 'panel'))]
  write.csv(long, file.path(src_dir, paste0(name, '_source.csv')), row.names = FALSE,
            na = '')
}

prog_order <- c('HALLMARK_TNFA_SIGNALING_VIA_NFKB', 'HALLMARK_INFLAMMATORY_RESPONSE',
                'HALLMARK_UNFOLDED_PROTEIN_RESPONSE', 'HALLMARK_OXIDATIVE_PHOSPHORYLATION',
                'HALLMARK_E2F_TARGETS')
prog_code <- c(TNFA = prog_order[1], INFL = prog_order[2], UPR = prog_order[3],
               OXPHOS = prog_order[4], E2F = prog_order[5])
prog_lab <- setNames(c('TNF-\u03b1 signaling via NF-\u03baB', 'Inflammatory response',
                       'Unfolded protein response', 'Oxidative phosphorylation',
                       'E2F targets'), prog_order)
prog_short <- setNames(c('TNF-\u03b1/NF-\u03baB', 'Inflammatory', 'UPR', 'OXPHOS', 'E2F'),
                       prog_order)
lab <- function(x, short = FALSE) unname((if (short) prog_short else prog_lab)[x])
human <- 'Human Hallmark v2024.1 direct-symbol match'

heat <- function(d, x, title, subtitle, limits, rotate = 0) {
  d <- d %>% mutate(
    Program = factor(lab(programme), levels = rev(lab(prog_order))),
    txt = paste0(sprintf('%.1f', camera_t), ifelse(FDR < 0.10, '*', '')),
    tcol = ifelse(abs(camera_t) >= 0.55 * max(limits), 'white', pal[['ink']]))
  ggplot(d, aes(.data[[x]], Program, fill = camera_t)) +
    geom_tile(colour = 'white', linewidth = 0.45) +
    geom_text(aes(label = txt, colour = tcol), size = 2.3, family = fam) +
    scale_colour_identity() +
    scale_fill_gradient2(low = pal[['blue']], mid = 'white', high = pal[['red']],
                         midpoint = 0, limits = limits, oob = squish,
                         name = 'CAMERA-PR t') +
    labs(title = title, subtitle = subtitle, x = NULL, y = NULL) +
    theme(axis.text.x = element_text(angle = rotate, hjust = ifelse(rotate == 0, 0.5, 1),
                                     vjust = ifelse(rotate == 0, 0.5, 1)),
          panel.grid = element_blank(), axis.line = element_blank(),
          axis.ticks = element_blank(), legend.position = 'right')
}

# ---------------------------------------------------------------- Figure 1
roles <- tibble::tribble(
  ~dataset, ~role,
  'GSE8342', 'Strain-associated discovery', 'E-MTAB-16125', 'Temporal discovery',
  'GSE160639', 'Independent validation', 'GSE196870', 'Independent validation',
  'GSE312476', 'Independent validation', 'GSE100365', 'Compartment/time validation',
  'GSE168041', 'Broad cell-class localization', 'GSE107086', 'Acute/glucocorticoid context'
) %>% mutate(dataset = factor(dataset, levels = rev(dataset)),
             role = factor(role, levels = unique(role)))
role_cols <- c('Strain-associated discovery' = pal[['blue']],
               'Temporal discovery' = pal[['orange']],
               'Independent validation' = pal[['teal']],
               'Compartment/time validation' = pal[['purple']],
               'Broad cell-class localization' = pal[['green']],
               'Acute/glucocorticoid context' = pal[['grey_dark']])
p1a <- ggplot(roles, aes(1, dataset)) +
  geom_tile(aes(fill = role), width = 0.42, height = 0.72, colour = 'white') +
  geom_text(aes(x = 1.3, label = role), hjust = 0, size = 2.35, family = fam,
            colour = pal[['ink']]) +
  scale_fill_manual(values = role_cols, guide = 'none') +
  scale_x_continuous(limits = c(0.75, 3.6), expand = c(0, 0)) +
  labs(title = 'Design-matched dataset roles',
       subtitle = 'Eight datasets; expression matrices remain separate', x = NULL, y = NULL) +
  theme(axis.text.x = element_blank(), axis.text.y = element_text(face = 'bold'),
        panel.grid.major = element_blank(), axis.line = element_blank(), axis.ticks = element_blank())

cover <- tibble::tribble(
  ~dataset, ~time, ~material,
  'GSE160639', 'End', 'Whole cochlea', 'GSE196870', '1 h', 'Whole cochlea',
  'GSE196870', '24 h', 'Whole cochlea', 'GSE312476', 'End', 'Whole cochlea',
  'GSE312476', '4 h', 'Whole cochlea', 'GSE312476', '8 h', 'Whole cochlea',
  'E-MTAB-16125', '24 h', 'Whole cochlea', 'E-MTAB-16125', '72 h', 'Whole cochlea',
  'E-MTAB-16125', '1 wk', 'Whole cochlea', 'GSE100365', 'End', 'Auditory nerve/modiolus',
  'GSE100365', '24 h', 'Auditory nerve/modiolus', 'GSE100365', '1 wk', 'Auditory nerve/modiolus',
  'GSE100365', '2 wk', 'Auditory nerve/modiolus'
) %>% mutate(dataset = factor(dataset, levels = rev(c('GSE160639', 'GSE196870', 'GSE312476',
                                                     'E-MTAB-16125', 'GSE100365'))),
             time = factor(time, levels = c('End', '1 h', '4 h', '8 h', '24 h', '72 h',
                                            '1 wk', '2 wk')))
p1b <- ggplot(cover, aes(time, dataset, colour = material, shape = material)) +
  geom_line(aes(group = dataset), colour = pal[['grey_light']], linewidth = 2.4) +
  geom_point(size = 3.0) +
  annotate('text', x = 6, y = 2.36, label = 'mice aged ~17 months', size = 2.05,
           family = fam, colour = pal[['grey_dark']]) +
  scale_colour_manual(values = c('Whole cochlea' = pal[['teal']],
                                 'Auditory nerve/modiolus' = pal[['purple']])) +
  scale_shape_manual(values = c('Whole cochlea' = 16, 'Auditory nerve/modiolus' = 17)) +
  labs(title = 'Temporal coverage', subtitle = 'Exposure end to 2 weeks',
       x = 'Post-exposure sampling', y = NULL, colour = NULL, shape = NULL) +
  theme(panel.grid.major.y = element_blank(), axis.line.y = element_blank(),
        axis.ticks.y = element_blank(), legend.position = 'bottom')

steps <- tibble::tibble(x = 1:5, y = 1, step = c(
  'Within-study\nmodels', 'Complete\ngene rankings', 'Correlation-\nadjusted\nprogram tests',
  'Directional\ncross-study\nsynthesis', 'Mouse-level\nbroad cell-class\nlocalization'))
p1c <- ggplot(steps, aes(x, y)) +
  geom_segment(data = tibble::tibble(x = 1:4 + 0.405, xend = 2:5 - 0.405, y = 1),
               aes(x = x, xend = xend, y = y, yend = y), inherit.aes = FALSE,
               linewidth = 0.7, colour = pal[['navy']],
               arrow = arrow(length = unit(1.6, 'mm'), type = 'closed')) +
  geom_tile(width = 0.80, height = 0.62, fill = 'white', colour = pal[['navy']],
            linewidth = 0.6) +
  geom_text(aes(label = step), size = 2.2, lineheight = 0.92, family = fam,
            colour = pal[['ink']]) +
  annotate('rect', xmin = 0.62, xmax = 5.38, ymin = 0.25, ymax = 0.50,
           fill = '#F2F5F8', colour = NA) +
  annotate('text', x = 3, y = 0.375, size = 2.3, family = fam, colour = pal[['grey_dark']],
           label = 'Claim boundary: program-level associations and broad, hypothesis-generating localization; no causal claims') +
  coord_cartesian(xlim = c(0.55, 5.45), ylim = c(0.18, 1.38), clip = 'off') +
  labs(title = 'Study-aware workflow', x = NULL, y = NULL) +
  theme_void(base_family = fam) +
  theme(plot.title = element_text(size = 8.7, face = 'bold', colour = pal[['ink']],
                                  margin = margin(l = 12, b = 2.5)), plot.title.position = 'plot',
        plot.margin = margin(6, 8, 5, 8))
fig1 <- ((p1a | p1b) + plot_layout(widths = c(1, 1))) / p1c + plot_layout(heights = c(1.45, 0.82)) +
  plot_annotation(tag_levels = 'A') & theme(plot.tag = element_text(size = 10, face = 'bold'))
export_figure(fig1, 'Figure_1', 183, 128)
write_source(list(A = roles, B = cover, C = steps), 'Figure_1')

# ---------------------------------------------------------------- Figure 2
gpca <- inp(work, 'stage1', 'source_data', 'GSE8342', 'pca_coordinates.csv') %>%
  mutate(strain = factor(strain, levels = c('129X1/SvJ', 'B6.CAST'),
                         labels = c('129X1/SvJ (resistant)', 'B6.CAST (susceptible)')),
         exposure = factor(exposure, levels = c('sham', 'noise'), labels = c('Sham', 'Noise')))
p2a <- ggplot(gpca, aes(PC1, PC2, colour = strain, shape = exposure)) +
  geom_hline(yintercept = 0, colour = pal[['grey_light']]) +
  geom_vline(xintercept = 0, colour = pal[['grey_light']]) +
  geom_point(size = 3.0) +
  scale_colour_manual(values = setNames(c(pal[['blue']], pal[['orange']]), levels(gpca$strain))) +
  scale_shape_manual(values = c(Sham = 17, Noise = 16)) +
  labs(title = 'Independent pooled arrays', subtitle = 'Each point is one pool of eight mice',
       x = 'PC1', y = 'PC2', colour = NULL, shape = NULL) +
  guides(colour = guide_legend(order = 1, nrow = 2), shape = guide_legend(order = 2, nrow = 2)) +
  theme(legend.position = 'bottom', legend.box = 'horizontal')

vol <- inp(work, 'figure_source_data', 'Figure_2', 'interaction_volcano_complete.csv') %>%
  mutate(screen = as.logical(screen), neglogP = -log10(pmax(PValue, 1e-300)),
         cls = ifelse(screen, 'Exploratory effect screen', 'Other'))
vlab <- vol %>% filter(screen, gene_symbol != '') %>% arrange(PValue) %>%
  distinct(gene_symbol, .keep_all = TRUE) %>% slice_head(n = 6)
p2b <- ggplot(vol, aes(logFC, neglogP)) +
  geom_point(aes(colour = cls), size = 0.6, alpha = 0.7) +
  geom_vline(xintercept = c(-0.5, 0.5), linetype = 2, colour = pal[['navy']], linewidth = 0.35) +
  geom_hline(yintercept = 1, linetype = 2, colour = pal[['navy']], linewidth = 0.35) +
  geom_point(data = vlab, shape = 21, size = 1.5, stroke = 0.4, fill = pal[['orange']],
             colour = pal[['ink']]) +
  geom_label_repel(data = vlab, aes(label = gene_symbol), size = 2.1, colour = pal[['ink']],
                  fill = alpha('white', 0.9), label.size = 0, label.padding = unit(0.6, 'mm'),
                  family = fam, box.padding = 0.45, point.padding = 0.3, force = 3,
                  min.segment.length = 0, max.overlaps = Inf, seed = 27,
                  segment.size = 0.25, segment.colour = pal[['grey_dark']]) +
  scale_colour_manual(values = c(Other = '#DDE3EA', 'Exploratory effect screen' = pal[['orange']])) +
  labs(title = 'Strain-by-noise interaction',
       subtitle = sprintf('%d genes meet the exploratory screen; none has FDR < 0.10',
                          sum(vol$screen)),
       x = 'Interaction log2 fold-change', y = expression(-log[10]~P)) +
  theme(legend.position = 'none')

oldp <- inp(work, 'stage1', 'tables', 'Table_2_standard_cross_method_programme_evidence.csv') %>%
  filter(pathway %in% setdiff(prog_order, prog_order[3]))
cm <- bind_rows(
  transmute(oldp, programme = pathway, Method = 'CAMERA-PR t',
            Score = camera_score_GSE8342_resilience, FDR = camera_FDR_GSE8342_resilience),
  transmute(oldp, programme = pathway, Method = 'Permutation GSEA NES',
            Score = gsea_NES_GSE8342_resilience, FDR = gsea_FDR_GSE8342_resilience)) %>%
  mutate(Program = factor(lab(programme), levels = rev(lab(setdiff(prog_order, prog_order[3])))),
         Direction = ifelse(Score >= 0, 'Up', 'Down'), mark = ifelse(FDR < 0.10, '*', ''))
p2c <- ggplot(cm, aes(Score, Program, fill = Direction)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = mark, hjust = ifelse(Score >= 0, -0.5, 1.5)), size = 3, family = fam) +
  geom_vline(xintercept = 0, linewidth = 0.4) +
  facet_wrap(~Method, scales = 'free_x', labeller = label_wrap_gen(12)) +
  scale_x_continuous(expand = expansion(mult = 0.2)) +
  scale_fill_manual(values = c(Up = pal[['red']], Down = pal[['blue']])) +
  labs(title = 'Strain-associated program directions',
       subtitle = 'Positive: larger noise response in 129X1/SvJ; * FDR < 0.10',
       x = 'Interaction statistic (method-specific scale)', y = NULL) +
  theme(legend.position = 'none', panel.grid.major.y = element_blank(),
        panel.spacing.x = unit(3, 'mm'))

expt <- inp(work, 'revision', 'expanded_validation', 'expanded_programme_results_targeted.csv') %>%
  filter(collection == human, programme %in% prog_order)
acute <- c(GSE160639 = 'dB105_vs_70', GSE196870 = 'noise_1h_vs_control',
           GSE312476 = 'post_0h_vs_control', GSE100365 = 'immediate_vs_control')
acute_val <- expt %>% filter(paste(dataset, contrast) %in% paste(names(acute), acute)) %>%
  mutate(Study = factor(dataset, levels = names(acute)))
p2d <- heat(acute_val, 'Study', 'Independent acute validation',
            'CAMERA-PR t; * within-study FDR < 0.10', c(-8, 8), rotate = 25)
fig2 <- ((free(p2a, type = 'label') | p2b) + plot_layout(widths = c(1, 1))) /
  ((p2c | p2d) + plot_layout(widths = c(1.12, 1))) + plot_layout(heights = c(1, 1.12)) +
  plot_annotation(tag_levels = 'A') & theme(plot.tag = element_text(size = 10, face = 'bold'))
export_figure(fig2, 'Figure_2', 183, 168)
write_source(list(A = gpca, B = vol, C = cm, D = acute_val), 'Figure_2')

# ---------------------------------------------------------------- Figure 3
epca <- inp(work, 'revision', 'phase_transition', 'pca_source.csv') %>%
  mutate(group = factor(group, levels = c('control', 'h24', 'h72', 'week1'),
                        labels = c('Control', '24 h', '72 h', '1 week')),
         sex = factor(sex, levels = c('female', 'male'), labels = c('Female', 'Male')))
p3a <- ggplot(epca, aes(PC1, PC2, colour = group, shape = sex)) +
  geom_hline(yintercept = 0, colour = pal[['grey_light']]) +
  geom_vline(xintercept = 0, colour = pal[['grey_light']]) +
  geom_point(size = 3.0) +
  scale_colour_manual(values = c(Control = pal[['grey_dark']], '24 h' = pal[['orange']],
                                 '72 h' = pal[['red']], '1 week' = pal[['purple']])) +
  scale_shape_manual(values = c(Female = 16, Male = 17)) +
  labs(title = 'Individual-mouse time course',
       subtitle = 'n = 5 per time point; mice aged ~17 months; sex in the model',
       x = 'PC1', y = 'PC2', colour = 'Time', shape = 'Sex') +
  theme(legend.position = 'bottom', legend.box = 'horizontal')
emp <- inp(work, 'revision', 'phase_transition', 'E-MTAB-16125_programme_results_complete.csv') %>%
  filter(collection == human, programme %in% prog_order,
         contrast %in% c('h24_vs_control', 'h72_vs_control', 'week1_vs_control', 'week1_vs_h72')) %>%
  mutate(Contrast = factor(contrast, levels = c('h24_vs_control', 'h72_vs_control',
                                                'week1_vs_control', 'week1_vs_h72'),
                           labels = c('24 h vs control', '72 h vs control',
                                      '1 week vs control', '1 week vs 72 h')))
p3b <- heat(emp, 'Contrast', 'Direct temporal contrasts',
            '1 week vs 72 h tests attenuation directly; * FDR < 0.10', c(-6, 6), rotate = 25)
iut <- inp(work, 'revision', 'phase_transition', 'programme_activation_to_resolution_IUT.csv') %>%
  filter(programme %in% prog_order) %>%
  mutate(Program = factor(lab(programme), levels = rev(lab(prog_order))),
         Evidence = cut(IUT_FDR, c(-Inf, 0.05, 0.10, Inf), right = FALSE,
                        labels = c('Supported (FDR < 0.05)', 'Suggestive (0.05 \u2264 FDR < 0.10)',
                                   'Not supported (FDR \u2265 0.10)')),
         nl = -log10(IUT_FDR), label = formatC(IUT_FDR, format = 'fg', digits = 2))
p3c <- ggplot(iut, aes(nl, Program, colour = Evidence)) +
  geom_vline(xintercept = -log10(c(0.05, 0.10)), linetype = c(2, 3), colour = pal[['grey_dark']],
             linewidth = 0.4) +
  geom_segment(aes(x = 0, xend = nl, yend = Program), colour = pal[['grey_light']], linewidth = 1) +
  geom_point(size = 3.2, shape = 21, stroke = 0.9, fill = 'white') +
  geom_text(aes(x = 3.35, label = label), hjust = 0, size = 2.1, family = fam,
            colour = pal[['ink']]) +
  scale_colour_manual(values = c(pal[['red']], pal[['orange']], pal[['grey_mid']]), drop = FALSE) +
  scale_x_continuous(limits = c(0, 4.15), breaks = 0:3, expand = expansion(mult = c(0, 0))) +
  annotate('text', x = 3.35, y = 5.55, label = 'FDR', hjust = 0, size = 2.1, fontface = 'bold', family = fam) +
  coord_cartesian(clip = 'off') +
  labs(title = 'Activation-to-resolution IUT',
       subtitle = 'One-sided: 72 h > control and 1 week < 72 h',
       x = expression(-log[10]~IUT~FDR), y = NULL, colour = NULL) +
  guides(colour = guide_legend(ncol = 1)) +
  theme(legend.position = 'bottom', panel.grid.major.y = element_blank())
ext_keep <- tibble::tribble(
  ~dataset, ~contrast, ~Time,
  'GSE196870', 'noise_1h_vs_control', '1 h', 'GSE196870', 'noise_24h_vs_control', '24 h',
  'GSE312476', 'post_0h_vs_control', 'End', 'GSE312476', 'post_4h_vs_control', '4 h',
  'GSE312476', 'post_8h_vs_control', '8 h', 'GSE100365', 'immediate_vs_control', 'End',
  'GSE100365', 'day1_vs_control', '24 h', 'GSE100365', 'day7_vs_control', '1 wk',
  'GSE100365', 'day14_vs_control', '2 wk')
ext <- expt %>% inner_join(ext_keep, by = c('dataset', 'contrast')) %>%
  mutate(Time = factor(Time, levels = c('End', '1 h', '4 h', '8 h', '24 h', '1 wk', '2 wk')),
         Study = factor(dataset, levels = c('GSE196870', 'GSE312476', 'GSE100365')),
         Program = factor(lab(programme, short = TRUE), levels = rev(lab(prog_order, TRUE))),
         sym = paste0(ifelse(camera_t >= 0, '+', '\u2212'), ifelse(FDR < 0.10, '*', '')),
         tcol = ifelse(abs(camera_t) >= 5, 'white', pal[['ink']]))
p3d <- ggplot(ext, aes(Time, Program, fill = camera_t)) +
  geom_tile(colour = 'white', linewidth = 0.45) +
  geom_text(aes(label = sym, colour = tcol), size = 2.6, family = fam) +
  scale_colour_identity() +
  scale_fill_gradient2(low = pal[['blue']], mid = 'white', high = pal[['red']], midpoint = 0,
                       limits = c(-9, 9), oob = squish, name = 'CAMERA-PR t') +
  facet_grid(. ~ Study, scales = 'free_x', space = 'free_x') +
  guides(fill = guide_colourbar(barwidth = unit(28, 'mm'), barheight = unit(2.6, 'mm'),
                                title.vjust = 0.9)) +
  labs(title = 'Independent time-course evidence',
       subtitle = 'Signs show direction; * within-study FDR < 0.10', x = NULL, y = NULL) +
  theme(panel.grid = element_blank(), axis.line = element_blank(), axis.ticks = element_blank(),
        strip.text = element_text(size = 6.0), panel.spacing.x = unit(2, 'mm'),
        axis.text.x = element_text(size = 6.0), legend.position = 'bottom')
fig3 <- ((free(p3a, type = 'label') | p3b) + plot_layout(widths = c(0.9, 1.1))) /
  ((p3c | p3d) + plot_layout(widths = c(0.74, 1.26))) + plot_layout(heights = c(1, 1.08)) +
  plot_annotation(tag_levels = 'A') & theme(plot.tag = element_text(size = 10, face = 'bold'))
export_figure(fig3, 'Figure_3', 183, 178)
write_source(list(A = epca, B = emp, C = iut, D = ext), 'Figure_3')

# ---------------------------------------------------------------- Figure 4
grades <- inp(rev_root, 'synthesis', 'results', 'evidence_grades_calibrated.csv') %>%
  mutate(programme = unname(prog_code[program]),
         stratum = recode(stratum, acute = 'acute/exposure-end response',
                          h24 = 'approximately 24 h response',
                          later = 'later transition relative to early response'))
syn <- inp(work, 'revision', 'tables', 'Table_3_directional_cross_study_evidence.csv') %>%
  filter(programme %in% prog_order) %>%
  left_join(grades %>% select(stratum, programme, fdr_emp, D9_grade), by = c('stratum', 'programme')) %>%
  mutate(Stratum = factor(stratum, levels = c('acute/exposure-end response',
                                              'approximately 24 h response',
                                              'later transition relative to early response'),
                          labels = c('Acute/exposure end', 'Approximately 24 h', 'Later vs early')),
         Program = factor(lab(programme), levels = rev(lab(prog_order))),
         mark = case_when(D9_grade == 'conf' ~ '**', D9_grade == 'expl' ~ '*', TRUE ~ ''),
         display = paste0(n_up, '/', n_independent_studies, mark, '\n', sprintf('%.1f', Stouffer_Z)),
         tcol = ifelse(abs(Stouffer_Z) >= 5, 'white', pal[['ink']]))
stopifnot(nrow(syn) == 15, !anyNA(syn$D9_grade))
p4a <- ggplot(syn, aes(Stratum, Program, fill = Stouffer_Z)) +
  geom_tile(colour = 'white', linewidth = 0.5) +
  geom_text(aes(label = display, colour = tcol), size = 2.25, lineheight = 0.9, family = fam) +
  scale_colour_identity() +
  scale_fill_gradient2(low = pal[['blue']], mid = 'white', high = pal[['red']], midpoint = 0,
                       limits = c(-9, 9), oob = squish, name = 'Directional\nStouffer Z') +
  labs(title = 'Cross-study evidence by temporal stratum',
       subtitle = 'Up-direction studies/total over Stouffer Z; all studies concordant with\npermutation FDR < 0.05 (**) or 0.05\u20130.10 (*)',
       x = NULL, y = NULL) +
  theme(axis.text.x = element_text(angle = 22, hjust = 1), panel.grid = element_blank(),
        axis.line = element_blank(), axis.ticks = element_blank())
loo <- inp(work, 'revision', 'tables', 'Table_S_acute_leave_one_study_out.csv') %>%
  filter(programme %in% prog_order[1:3]) %>%
  mutate(Program = factor(lab(programme), levels = rev(lab(prog_order[1:3]))),
         omitted_study = factor(omitted_study, levels = names(acute)))
p4b <- ggplot(loo, aes(Stouffer_Z, Program, colour = omitted_study)) +
  geom_vline(xintercept = 0, colour = pal[['grey_dark']], linewidth = 0.4) +
  geom_segment(aes(x = 0, xend = Stouffer_Z, yend = Program), colour = pal[['grey_light']],
               linewidth = 0.8) +
  geom_point(size = 2.6) +
  scale_colour_manual(values = c(GSE160639 = pal[['teal']], GSE196870 = pal[['orange']],
                                 GSE312476 = pal[['purple']], GSE100365 = pal[['blue']])) +
  labs(title = 'Leave-one-study-out synthesis',
       subtitle = 'Every three-study subset remains concordant',
       x = 'Directional Stouffer Z', y = NULL, colour = 'Omitted study') +
  guides(colour = guide_legend(nrow = 2, byrow = TRUE, title.position = 'top')) +
  theme(legend.position = 'bottom', panel.grid.major.y = element_blank())
ox <- acute_val %>% filter(programme == prog_order[4]) %>%
  mutate(Context = factor(dataset, levels = rev(names(acute)),
                          labels = rev(c('GSE160639 \u00b7 whole cochlea', 'GSE196870 \u00b7 whole cochlea',
                                         'GSE312476 \u00b7 whole cochlea',
                                         'GSE100365 \u00b7 auditory nerve/modiolus'))),
         Material = ifelse(dataset == 'GSE100365', 'Auditory nerve/modiolus', 'Whole cochlea'))
p4c <- ggplot(ox, aes(camera_t, Context, colour = Material)) +
  geom_vline(xintercept = 0, colour = pal[['grey_dark']], linewidth = 0.4) +
  geom_segment(aes(x = 0, xend = camera_t, yend = Context), colour = pal[['grey_light']],
               linewidth = 0.9) +
  geom_point(aes(shape = ifelse(camera_t >= 0, 'Up', 'Down')), size = 3) +
  scale_colour_manual(values = c('Whole cochlea' = pal[['teal']],
                                 'Auditory nerve/modiolus' = pal[['purple']])) +
  scale_shape_manual(values = c(Up = 16, Down = 17)) +
  labs(title = 'Oxidative phosphorylation differs by study',
       subtitle = 'Primary acute/exposure-end contrasts', x = 'CAMERA-PR t', y = NULL) +
  theme(legend.position = 'none', panel.grid.major.y = element_blank())
orth <- inp(work, 'revision', 'expanded_validation', 'orthology_sensitivity_complete.csv') %>%
  filter(programme %in% prog_order, as.logical(targeted_programme_human),
         contrast %in% c('dB94_vs_70', 'dB105_vs_70', 'dB105_vs_94', 'noise_1h_vs_control',
                         'noise_24h_vs_control', 'post_0h_vs_control', 'post_4h_vs_control',
                         'post_8h_vs_control', 'immediate_vs_control', 'day1_vs_control',
                         'day7_vs_control')) %>%
  mutate(Program = lab(programme, short = TRUE),
         Category = ifelse(as.logical(evidence_category_preserved), 'Preserved', 'Changed'))
stopifnot(nrow(orth) == 55)
n_dir <- sum(sign(orth$camera_t_human) == sign(orth$camera_t_mouse))
p4d <- ggplot(orth, aes(camera_t_human, camera_t_mouse, colour = Program, shape = Category)) +
  geom_abline(slope = 1, intercept = 0, colour = pal[['grey_mid']], linewidth = 0.5) +
  geom_hline(yintercept = 0, colour = pal[['grey_light']]) +
  geom_vline(xintercept = 0, colour = pal[['grey_light']]) +
  geom_point(size = 2.0, alpha = 0.9, stroke = 0.7) +
  scale_colour_manual(values = setNames(c(pal[['red']], pal[['orange']], pal[['purple']],
                                          pal[['blue']], pal[['green']]), lab(prog_order, TRUE))) +
  scale_shape_manual(values = c(Preserved = 16, Changed = 4)) +
  coord_equal() +
  labs(title = 'Mouse Hallmarks preserve direction',
       subtitle = sprintf('%d/55 directions; \u00d7 marks FDR-category change', n_dir),
       x = 'Human-set CAMERA-PR t', y = 'Mouse-MH CAMERA-PR t', colour = NULL, shape = NULL) +
  guides(shape = 'none', colour = guide_legend(nrow = 2)) +
  theme(legend.position = 'bottom', legend.text = element_text(size = 5.8))
fig4 <- ((p4a | p4b) + plot_layout(widths = c(1.08, 1))) /
  ((p4c | p4d) + plot_layout(widths = c(1.08, 1))) + plot_layout(heights = c(1, 1.05)) +
  plot_annotation(tag_levels = 'A') & theme(plot.tag = element_text(size = 10, face = 'bold'))
export_figure(fig4, 'Figure_4', 183, 175)
write_source(list(A = syn, B = loo, C = ox, D = orth), 'Figure_4')

# ------------------------------ Figure 5 = forest (first cited in 3.4); Figure 6 = localization
pretty_cell <- c(spiral_ganglion_neuron = 'Spiral ganglion neuron', schwann_glial = 'Schwann/glial',
                 endothelial = 'Endothelial', fibrocyte = 'Fibrocyte',
                 pericyte_smooth_muscle = 'Pericyte/smooth muscle', immune = 'Immune',
                 intermediate_melanocyte = 'Intermediate/melanocyte', basal_cell = 'Basal cell',
                 marginal_cell = 'Marginal cell')
mk <- inp(work, 'figure_source_data', 'Figure_5', 'designated_positive_marker_validation.csv') %>%
  mutate(Cell = factor(unname(pretty_cell[assigned_cell_type]), levels = rev(pretty_cell)),
         lbl = paste0(marker_gene, ' ', round(percent_expressing), '%'))
p5a <- ggplot(mk, aes(slot, Cell)) +
  geom_point(aes(colour = mean_expression, size = percent_expressing)) +
  geom_text(aes(label = lbl), nudge_x = 0.11, hjust = 0, size = 2.0, family = fam,
            colour = pal[['ink']]) +
  scale_size_continuous(range = c(1.2, 3.4), limits = c(0, 100), breaks = c(25, 50, 75),
                        name = '% expressing') +
  scale_colour_viridis_c(option = 'C', limits = c(0, 5), oob = squish, name = 'Median\nexpression') +
  scale_x_continuous(limits = c(0.85, 3.85), expand = c(0, 0)) +
  guides(size = guide_legend(order = 1),
         colour = guide_colourbar(order = 2, barwidth = unit(22, 'mm'), barheight = unit(2.6, 'mm'),
                                  title.vjust = 0.9)) +
  labs(title = 'Annotation-panel markers',
       subtitle = 'Three designated positive markers per broad class; label gives % expressing\n(median over libraries)',
       x = NULL, y = NULL) +
  theme(panel.grid.major.x = element_blank(), axis.line = element_blank(),
        axis.ticks = element_blank(), axis.text.x = element_blank(),
        legend.position = 'bottom', legend.box = 'horizontal')
cov <- inp(work, 'figure_source_data', 'Figure_5', 'primary_cell_coverage.csv') %>%
  mutate(DisplayCell = factor(DisplayCell, levels = DisplayCell[order(cells)]),
         Cohort = factor(Cohort, levels = c('Lateral-wall-focused', 'Neuronal-focused')))
p5b <- ggplot(cov, aes(cells, DisplayCell, fill = Cohort)) +
  geom_col(width = 0.66) +
  geom_text(aes(label = comma(cells)), hjust = -0.12, size = 2.0, family = fam) +
  scale_x_continuous(breaks = c(0, 5000, 10000, 15000), labels = comma,
                     expand = expansion(mult = c(0, 0.3))) +
  scale_fill_manual(values = c('Lateral-wall-focused' = pal[['teal']],
                               'Neuronal-focused' = pal[['purple']])) +
  labs(title = 'Coverage of 13 class contrasts', subtitle = 'Cells in eligible pseudobulk contrasts',
       x = 'Cells', y = NULL, fill = NULL) +
  theme(legend.position = 'bottom', panel.grid.major.y = element_blank())
core4 <- prog_order[1:4]
cp <- inp(work, 'stage1', 'results', 'standard_pathway_reanalysis',
          'CAMERA_PR_cellclass_within_and_global_FDR.csv') %>%
  filter(pathway %in% core4) %>%
  mutate(tissue_cohort = ifelse(grepl('^lateral_wall_focused_', celltype_analysis),
                                'lateral_wall_focused', 'neuronal_focused'),
         cell_type = sub('^(lateral_wall_focused|neuronal_focused)_', '', celltype_analysis)) %>%
  inner_join(cov %>% select(tissue_cohort, cell_type, DisplayCell), by = c('tissue_cohort', 'cell_type')) %>%
  mutate(Program = factor(lab(pathway), levels = rev(lab(core4))),
         Col = factor(gsub(' \\| ', '\n', as.character(DisplayCell)),
                      levels = gsub(' \\| ', '\n', sort(as.character(cov$DisplayCell), method = 'radix'))),
         mark = ifelse(global_FDR < 0.10, '*', ''),
         tcol = ifelse(abs(camera_t) >= 4, 'white', pal[['ink']]))
stopifnot(nrow(cp) == 52)
p5c <- ggplot(cp, aes(Col, Program, fill = camera_t)) +
  geom_tile(colour = 'white', linewidth = 0.45) +
  geom_text(aes(label = mark, colour = tcol), size = 3, family = fam) +
  scale_colour_identity() +
  scale_fill_gradient2(low = pal[['blue']], mid = 'white', high = pal[['red']], midpoint = 0,
                       limits = c(-7, 7), oob = squish, name = 'CAMERA-PR t') +
  labs(title = 'Broad, hypothesis-generating program localization',
       subtitle = '* global FDR < 0.10 across 650 tests under inter.gene.cor = 0.01; directions are the primary readout',
       x = NULL, y = NULL) +
  theme(axis.text.x = element_text(angle = 40, hjust = 1, size = 5.6, lineheight = 0.9),
        panel.grid = element_blank(), axis.line = element_blank(), axis.ticks = element_blank())
led <- inp(work, 'stage1', 'results', 'cell_annotation_sensitivity',
           'Table_S7_seven_programme_direction_stability_ledger.csv')
stopifnot(nrow(led) == 91)
stab <- tibble::tibble(Status = factor(c('Concordant', 'Discordant'), levels = c('Concordant', 'Discordant')),
                       n = c(sum(as.logical(led$stable)), sum(!as.logical(led$stable))))
p5d <- ggplot(stab, aes(n, 'Combinations', fill = Status)) +
  geom_col(width = 0.5, position = position_stack(reverse = TRUE)) +
  geom_text(aes(label = n), position = position_stack(vjust = 0.5, reverse = TRUE),
            colour = 'white', size = 2.8, family = fam) +
  scale_fill_manual(values = c(Concordant = pal[['green']], Discordant = pal[['orange']])) +
  scale_x_continuous(expand = c(0, 0)) +
  labs(title = 'Direction concordance across cell definitions',
       subtitle = sprintf('%d of %d program-class combinations (seven programs \u00d7 13 contrasts) concordant across\n10-, 20- and 30-cell thresholds and strict annotation',
                          stab$n[1], sum(stab$n)), x = NULL, y = NULL, fill = NULL) +
  theme(axis.text = element_blank(), axis.line = element_blank(), axis.ticks = element_blank(),
        panel.grid = element_blank(), legend.position = 'right')
fig5 <- ((p5a | p5b) + plot_layout(widths = c(1.25, 0.95))) / p5c / p5d +
  plot_layout(heights = c(1.2, 1, 0.24)) +
  plot_annotation(tag_levels = 'A') & theme(plot.tag = element_text(size = 10, face = 'bold'))
export_figure(fig5, 'Figure_6', 183, 205)
write_source(list(A = mk, B = cov, C = cp, D = stab), 'Figure_6')

# ---------------------------------------------------------------- Figure 6
fe <- inp(rev_root, 'synthesis', 'results', 'forest_effects.csv')
lab_contrast <- c(dB105_vs_70 = '105 vs 70 dB', noise_1h_vs_control = '1 h vs control',
                  post_0h_vs_control = 'End vs control', immediate_vs_control = 'End vs control',
                  noise_24h_vs_control = '24 h vs control', day1_vs_control = 'Day 1 vs control',
                  h24_vs_control = '24 h vs control', week1_vs_h72 = 'Week 1 vs 72 h',
                  day7_vs_day1 = 'Day 7 vs day 1')
study_lab <- c(GSE160639 = 'GSE160639', GSE196870 = 'GSE196870', GSE312476 = 'GSE312476',
               GSE100365 = 'GSE100365', EMTAB = 'E-MTAB-16125')
fe <- fe %>% mutate(
  programme = unname(prog_code[program]),
  Program = factor(lab(programme), levels = lab(prog_order)),
  Stratum = factor(stratum, levels = c('acute', 'h24', 'later'),
                   labels = c('Acute/exposure end', 'Approximately 24 h', 'Later vs early')),
  row = paste0(unname(study_lab[study]), ' \u00b7 ', unname(lab_contrast[contrast])))
stopifnot(!anyNA(fe$Program), !anyNA(fe$row), nrow(fe) == 45)
fe$Row <- factor(paste(fe$Stratum, fe$row), levels = rev(sort(unique(paste(fe$Stratum, fe$row)))))
row_stratum <- function(lv) sub(' .*', '', lv)
lvl_tab <- table(factor(row_stratum(levels(fe$Row)), levels = c('Later', 'Approximately', 'Acute/exposure')))
sep_y <- c()
if (lvl_tab['Later'] > 0 && lvl_tab['Approximately'] > 0)
  sep_y <- c(sep_y, lvl_tab['Later'] + 0.5)
if (lvl_tab['Approximately'] > 0 && lvl_tab['Acute/exposure'] > 0)
  sep_y <- c(sep_y, lvl_tab['Later'] + lvl_tab['Approximately'] + 0.5)
p6 <- ggplot(fe, aes(estimate, Row, colour = Stratum)) +
  geom_vline(xintercept = 0, colour = pal[['grey_dark']], linewidth = 0.4) +
  { if (length(sep_y)) geom_hline(yintercept = sep_y, colour = pal[['grey_light']], linewidth = 0.45) } +
  geom_errorbarh(aes(xmin = ci_low, xmax = ci_high), height = 0, linewidth = 0.55) +
  geom_point(size = 1.9) +
  facet_grid(. ~ Program, scales = 'free_x', labeller = label_wrap_gen(14)) +
  scale_y_discrete(labels = function(x) sub('^(Acute/exposure end|Approximately 24 h|Later vs early) ', '', x)) +
  scale_colour_manual(values = c('Acute/exposure end' = pal[['red']],
                                 'Approximately 24 h' = pal[['orange']],
                                 'Later vs early' = pal[['blue']])) +
  labs(x = 'Difference in mean gene z score (95% CI)', y = NULL, colour = 'Stratum') +
  theme(legend.position = 'bottom', panel.grid.major.y = element_blank(),
        strip.background = element_rect(fill = '#F3F5F8', colour = NA),
        panel.spacing.x = unit(3, 'mm'), axis.text.y = element_text(size = 6.2),
        axis.text.x = element_text(size = 6))
export_figure(p6, 'Figure_5', 183, 110)
write_source(list(A = fe), 'Figure_5')

writeLines(capture.output(sessionInfo()), file.path(work, 'main_figure_sessionInfo.txt'))
message('Main Figures 1-6 written to ', fig_dir)
