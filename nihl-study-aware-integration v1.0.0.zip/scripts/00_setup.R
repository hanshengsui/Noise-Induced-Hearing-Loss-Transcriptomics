#!/usr/bin/env Rscript
# 00_setup.R -- single source of truth for every path used by the pipeline.
#
# The repository is self-contained: all inputs live under data/ (downloaded by
# scripts/00_download.R), all reference resources under resources/, and all
# outputs under results/. Nothing outside the repository is read, and no path is
# hard-coded to a particular machine or user account.
#
# Every other script starts with:
#   source(file.path(Sys.getenv("NIHL_REPO_ROOT", "."), "scripts", "00_setup.R"))
# and afterwards uses the nihl_paths object or the NIHL_* environment variables
# exported here. Environment variables that are already set take precedence, so
# a user can relocate a single input without editing any code.

# Resolve the repository root. Precedence: NIHL_REPO_ROOT if set, otherwise the
# directory two levels above this script (scripts/00_setup.R -> repository root).
# This makes every script independent of the current working directory.
.nihl_script_path <- local({
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  if (length(fa) == 1L) normalizePath(sub("^--file=", "", fa[1]), winslash = "/",
                                      mustWork = FALSE) else NA_character_
})
.nihl_script_dir <- if (is.na(.nihl_script_path)) NA_character_ else dirname(.nihl_script_path)

repo_root <- Sys.getenv("NIHL_REPO_ROOT", "")
if (!nzchar(repo_root)) {
  if (!is.na(.nihl_script_dir) && basename(.nihl_script_dir) == "scripts") {
    repo_root <- dirname(.nihl_script_dir)
  } else {
    repo_root <- getwd()
  }
}
repo_root <- normalizePath(repo_root, winslash = "/", mustWork = TRUE)
Sys.setenv(NIHL_REPO_ROOT = repo_root)

.nihl_get <- function(name, default) {
  value <- Sys.getenv(name, "")
  if (nzchar(value)) normalizePath(value, winslash = "/", mustWork = FALSE)
  else normalizePath(default, winslash = "/", mustWork = FALSE)
}

nihl_paths <- list(
  repo_root          = repo_root,
  scripts            = file.path(repo_root, "scripts"),
  config             = file.path(repo_root, "config"),
  samples            = file.path(repo_root, "config", "samples"),
  resources          = file.path(repo_root, "resources"),
  gene_sets          = file.path(repo_root, "resources", "gene_sets"),
  annotations        = file.path(repo_root, "resources", "annotations"),
  data               = .nihl_get("NIHL_DATA_ROOT", file.path(repo_root, "data")),
  raw                = file.path(.nihl_get("NIHL_DATA_ROOT", file.path(repo_root, "data")), "raw"),
  work               = .nihl_get("NIHL_WORK_ROOT", file.path(repo_root, "work")),
  results            = .nihl_get("NIHL_RESULTS_ROOT", file.path(repo_root, "results")),
  results_tables     = file.path(.nihl_get("NIHL_RESULTS_ROOT", file.path(repo_root, "results")), "tables"),
  results_figures    = file.path(.nihl_get("NIHL_RESULTS_ROOT", file.path(repo_root, "results")), "figures"),
  logs               = file.path(.nihl_get("NIHL_WORK_ROOT", file.path(repo_root, "work")), "logs")
)

# Seed: the repository fixes one global seed (config/seed.txt) for every script
# that draws random numbers. Individual scripts still set their own value at the
# top, matching the seed used when the reported results were produced.
seed_file <- file.path(nihl_paths$config, "seed.txt")
nihl_seed <- if (file.exists(seed_file)) {
  as.integer(trimws(readLines(seed_file, warn = FALSE)[1]))
} else 20261029L

# Input locations. The public datasets are downloaded into data/raw/<accession>/.
nihl_inputs <- list(
  GSE8342_series_matrix  = .nihl_get("NIHL_GSE8342_SERIES_MATRIX",
    file.path(nihl_paths$raw, "GSE8342", "GSE8342_series_matrix.txt.gz")),
  GPL81_annotation       = .nihl_get("NIHL_GPL81_ANNOTATION",
    file.path(nihl_paths$raw, "GPL81", "GPL81.annot.gz")),
  GSE160639_counts       = .nihl_get("NIHL_GSE160639_COUNTS",
    file.path(nihl_paths$raw, "GSE160639", "GSE160639_RawReadCount.txt.gz")),
  GSE196870_fpkm         = .nihl_get("NIHL_GSE196870_FPKM",
    file.path(nihl_paths$raw, "GSE196870", "GSE196870_Raw_gene_FPKM_matrix.txt.csv.gz")),
  GSE312476_table_s1     = .nihl_get("NIHL_GSE312476_TABLE_S1",
    file.path(nihl_paths$raw, "GSE312476", "GSE312476_Table_S1.xlsx")),
  GSE100365_series       = .nihl_get("NIHL_GSE100365_SERIES_MATRIX",
    file.path(nihl_paths$raw, "GSE100365", "GSE100365_series_matrix.txt.gz")),
  GPL1261_annotation     = .nihl_get("NIHL_GPL1261_ANNOTATION",
    file.path(nihl_paths$raw, "GPL1261", "GPL1261.annot.gz")),
  GSE107086_counts       = .nihl_get("NIHL_GSE107086_COUNTS",
    file.path(nihl_paths$raw, "GSE107086", "GSE107086_raw_counts.csv.gz")),
  E_MTAB_sdrf            = .nihl_get("NIHL_EMTAB_SDRF",
    file.path(nihl_paths$raw, "E-MTAB-16125", "E-MTAB-16125.sdrf.txt")),
  E_MTAB_featurecounts   = .nihl_get("NIHL_EMTAB_FEATURECOUNTS_DIR",
    file.path(nihl_paths$raw, "E-MTAB-16125", "featureCounts")),
  GSE168041_matrix_dir   = .nihl_get("NIHL_GSE168041_MATRIX_DIR",
    file.path(nihl_paths$raw, "GSE168041", "extracted")),
  GSE168041_metadata     = .nihl_get("NIHL_GSE168041_METADATA",
    file.path(nihl_paths$samples, "GSE168041_libraries.csv")),
  GSE168041_gene_map     = .nihl_get("NIHL_GSE168041_GENE_MAP",
    file.path(nihl_paths$annotations, "GSE168041_gene_map.csv")),
  gene_map_mouse         = .nihl_get("NIHL_MOUSE_GENE_MAP",
    file.path(nihl_paths$annotations, "mouse_gene_map.csv")),
  cell_type_markers      = .nihl_get("NIHL_CELL_TYPE_MARKERS",
    file.path(nihl_paths$annotations, "cell_type_markers.csv")),
  human_gmt              = .nihl_get("NIHL_HUMAN_GMT",
    file.path(nihl_paths$gene_sets, "h.all.v2024.1.Hs.symbols.gmt")),
  mouse_gmt              = .nihl_get("NIHL_MOUSE_GMT",
    file.path(nihl_paths$gene_sets, "mh.all.v2024.1.Mm.symbols.gmt")),
  mouse_core4_gmt        = .nihl_get("NIHL_MOUSE_CORE4_GMT",
    file.path(nihl_paths$gene_sets, "mh.core4.MouseMSigDB.current.symbols.gmt")),
  mouse_gmt_provenance   = .nihl_get("NIHL_MOUSE_GMT_PROVENANCE",
    file.path(nihl_paths$gene_sets, "mh.core4.MouseMSigDB.current.provenance.txt")),
  contrasts_yaml         = file.path(nihl_paths$config, "contrasts.yaml"),
  input_manifest         = file.path(nihl_paths$config, "input_manifest.csv")
)

# Intermediate and output roots, in the layout the analysis scripts expect.
# NIHL_ANALYSIS_ROOT holds stage-1 derived objects; NIHL_REVISION_ROOT holds
# everything built on top of them.
stage1_root   <- file.path(nihl_paths$work, "stage1")
revision_root <- file.path(nihl_paths$work, "revision")

for (d in c(nihl_paths$work, stage1_root, revision_root, nihl_paths$logs,
            nihl_paths$results_tables, nihl_paths$results_figures)) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

Sys.setenv(
  NIHL_REPO_ROOT              = repo_root,
  NIHL_CODE_ROOT              = repo_root,
  NIHL_CONFIG_FILE            = file.path(nihl_paths$scripts, "00_setup.R"),
  NIHL_DATA_ROOT              = nihl_paths$data,
  NIHL_WORK_ROOT              = nihl_paths$work,
  NIHL_RESULTS_ROOT           = nihl_paths$results,
  NIHL_ANALYSIS_ROOT          = stage1_root,
  NIHL_REVISION_ROOT          = revision_root,
  NIHL_REVISION_INPUT         = stage1_root,
  NIHL_LOG_DIR                = nihl_paths$logs,
  NIHL_ASSETS_ROOT            = nihl_paths$annotations,
  NIHL_GENESET_ROOT           = nihl_paths$gene_sets,
  NIHL_GSE8342_SERIES_MATRIX  = nihl_inputs$GSE8342_series_matrix,
  NIHL_GPL81_ANNOTATION       = nihl_inputs$GPL81_annotation,
  NIHL_GSE160639_COUNTS       = nihl_inputs$GSE160639_counts,
  NIHL_GSE196870_FPKM         = nihl_inputs$GSE196870_fpkm,
  NIHL_GSE312476_TABLE_S1     = nihl_inputs$GSE312476_table_s1,
  NIHL_GSE100365_SERIES_MATRIX = nihl_inputs$GSE100365_series,
  NIHL_GPL1261_ANNOTATION     = nihl_inputs$GPL1261_annotation,
  NIHL_GSE107086_COUNTS       = nihl_inputs$GSE107086_counts,
  NIHL_EMTAB_SDRF             = nihl_inputs$E_MTAB_sdrf,
  NIHL_EMTAB_FEATURECOUNTS_DIR = nihl_inputs$E_MTAB_featurecounts,
  NIHL_GSE168041_MATRIX_DIR   = nihl_inputs$GSE168041_matrix_dir,
  NIHL_GSE168041_METADATA     = nihl_inputs$GSE168041_metadata,
  NIHL_GSE168041_GENE_MAP     = nihl_inputs$GSE168041_gene_map,
  NIHL_MOUSE_GENE_MAP         = nihl_inputs$gene_map_mouse,
  NIHL_CELL_TYPE_MARKERS      = nihl_inputs$cell_type_markers,
  NIHL_HUMAN_GMT              = nihl_inputs$human_gmt,
  NIHL_MOUSE_GMT              = nihl_inputs$mouse_core4_gmt,
  NIHL_MOUSE_CORE4_GMT        = nihl_inputs$mouse_core4_gmt,
  NIHL_MOUSE_GMT_PROVENANCE   = nihl_inputs$mouse_gmt_provenance
)

# Optional side library. If NIHL_VALIDATION_LIB points at a library tree that
# holds limma 3.62.2 and edgeR 4.4.2 (the versions used for the submitted
# analyses), it is placed first on the search path so those exact builds are used.
# Extra package libraries, colon-separated, prepended in order. Used to point at
# a library tree holding the pinned limma/edgeR builds or the optional plotting
# back ends without changing any code.
extra_libs <- Sys.getenv('NIHL_LIBS', '')
if (nzchar(extra_libs)) {
  parts <- strsplit(extra_libs, .Platform$path.sep, fixed = TRUE)[[1]]
  parts <- parts[dir.exists(parts)]
  if (length(parts)) {
    .libPaths(unique(c(normalizePath(parts, winslash = '/', mustWork = TRUE),
                       .libPaths())))
  }
}

validation_lib <- Sys.getenv('NIHL_VALIDATION_LIB', '')
if (nzchar(validation_lib) && dir.exists(validation_lib)) {
  .libPaths(unique(c(normalizePath(validation_lib, winslash = '/', mustWork = TRUE),
                     .libPaths())))
}

# Version handling. The reported numbers were produced with limma 3.62.2 and
# edgeR 4.4.2. A different version does not necessarily change the results, but
# it can: limma's empirical-Bayes variance estimation has changed numerically
# between releases. The default is therefore a prominent warning plus a record in
# the session log; setting NIHL_STRICT_VERSIONS=1 turns the warning into an error,
# which is what scripts/98_smoke_test.R does so that its comparison against the
# reported values is meaningful.
nihl_require_versions <- function(limma_version = '3.62.2', edgeR_version = '4.4.2') {
  suppressPackageStartupMessages({
    library(limma)
    library(edgeR)
    library(statmod)
  })
  obs <- c(limma = as.character(packageVersion('limma')),
           edgeR = as.character(packageVersion('edgeR')))
  want <- c(limma = limma_version, edgeR = edgeR_version)
  bad <- names(want)[obs[names(want)] != want]
  if (length(bad)) {
    msg <- sprintf(paste0(
      'limma/edgeR version differs from the submitted analysis.\n',
      '  observed: %s\n  expected: %s\n',
      'Reported values were produced with limma %s and edgeR %s. ',
      'Set NIHL_VALIDATION_LIB to a library tree holding those builds, ',
      'or set NIHL_STRICT_VERSIONS=0 to silence this message.'),
      paste(names(obs), obs, collapse = ', '),
      paste(names(want), want, collapse = ', '),
      limma_version, edgeR_version)
    if (identical(Sys.getenv('NIHL_STRICT_VERSIONS', '0'), '1')) stop(msg, call. = FALSE)
    warning(msg, call. = FALSE)
  }
  invisible(obs)
}

# CSV writer. Results are written as UTF-8 regardless of the session locale.
# Under a C locale, R's write.csv() escapes non-ASCII characters, turning
# "TNF-\u03b1" into the literal text "<U+03B1>"; the same happens on a UTF-8
# workstation that reads the file back in another program. The writer below
# builds each record explicitly, so the bytes on disk are the same everywhere.
nihl_write_csv <- function(x, path, na = "", row.names = FALSE, ...) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  x <- as.data.frame(x, stringsAsFactors = FALSE)
  # Strings are tagged as UTF-8 rather than transcoded: under a C locale
  # enc2utf8() would treat already-UTF-8 bytes as native and double-encode them.
  quote_field <- function(v) {
    v <- as.character(v)
    v[is.na(v)] <- na
    enc <- Encoding(v)
    enc[enc == "unknown"] <- "UTF-8"
    Encoding(v) <- enc
    v <- gsub('"', '""', v, fixed = TRUE)
    paste0('"', v, '"')
  }
  cols <- lapply(x, function(col) {
    if (is.numeric(col) || is.integer(col)) {
      v <- as.character(col)
      v[is.na(col)] <- na
      # R's default 15 significant digits match write.csv on doubles.
      out <- format(col, trim = TRUE, scientific = NA, digits = 15)
      out[is.na(col)] <- na
      out
    } else quote_field(col)
  })
  header <- paste(quote_field(names(x)), collapse = ",")
  body <- if (nrow(x)) {
    vapply(seq_len(nrow(x)), function(i) {
      paste(vapply(cols, `[[`, character(1), i), collapse = ",")
    }, character(1))
  } else character(0)
  rows <- if (row.names) {
    vapply(seq_len(nrow(x)), function(i) {
      paste(c(quote_field(rownames(x)[i]), vapply(cols, `[[`, character(1), i)),
            collapse = ",")
    }, character(1))
  } else body
  lines <- c(header, rows)
  con <- file(path, open = "wb")
  on.exit(close(con))
  writeLines(enc2utf8(lines), con, useBytes = TRUE)
  invisible(path)
}

nihl_require_inputs <- function(paths, kinds = NULL) {
  if (is.null(kinds)) kinds <- rep('file', length(paths))
  ok <- mapply(function(p, k) if (identical(k, 'dir')) dir.exists(p) else file.exists(p),
               paths, kinds)
  if (!all(ok)) {
    stop('Missing inputs:\n  ',
         paste(sprintf('%s (%s)', paths[!ok], kinds[!ok]), collapse = '\n  '),
         '\nRun: Rscript scripts/00_download.R', call. = FALSE)
  }
  invisible(TRUE)
}
