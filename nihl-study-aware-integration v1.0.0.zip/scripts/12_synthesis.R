#!/usr/bin/env Rscript
# 12_synthesis.R -- cross-study synthesis, leave-one-study-out and orthology summaries.
#
# Combines the four external acute series and the replicated time course into the
# three temporal strata of Methods 2.3. Signed normal deviates are formed from the
# moderated t as sign(t) * qnorm(P/2, lower.tail = FALSE); the Stouffer Z is the
# unweighted sum divided by the square root of the number of studies, and BH is
# applied within each stratum over the programmes retained.
#
# Output: work/revision/tables/*.csv, consumed by 99_tables.R.

options(stringsAsFactors = FALSE)

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))

revision <- Sys.getenv('NIHL_REVISION_ROOT')
table_root <- file.path(revision, "tables")
dir.create(table_root, recursive = TRUE, showWarnings = FALSE)

programme_all <- read.csv(
  file.path(revision, "expanded_validation", "expanded_programme_results_complete.csv"),
  check.names = FALSE
)
phase_all <- read.csv(
  file.path(revision, "phase_transition", "E-MTAB-16125_programme_results_complete.csv"),
  check.names = FALSE
)

human_name <- "Human Hallmark v2024.1 direct-symbol match"
mouse_name <- "Mouse Hallmark v2024.1 orthologized"
core4 <- c(
  "HALLMARK_TNFA_SIGNALING_VIA_NFKB",
  "HALLMARK_INFLAMMATORY_RESPONSE",
  "HALLMARK_OXIDATIVE_PHOSPHORYLATION",
  "HALLMARK_E2F_TARGETS"
)
targeted_extension <- "HALLMARK_UNFOLDED_PROTEIN_RESPONSE"
targeted <- c(core4, targeted_extension)

primary_contrasts <- data.frame(
  dataset = c(
    "GSE160639", "GSE160639",
    "GSE196870", "GSE196870",
    "GSE312476", "GSE312476", "GSE312476",
    "GSE100365", "GSE100365", "GSE100365", "GSE100365"
  ),
  contrast = c(
    "dB94_vs_70", "dB105_vs_70",
    "noise_1h_vs_control", "noise_24h_vs_control",
    "post_0h_vs_control", "post_4h_vs_control", "post_8h_vs_control",
    "immediate_vs_control", "day1_vs_control", "day7_vs_control",
    "day14_vs_control"
  ),
  design_role = c(
    "moderate sound-level response", "high sound-level response",
    "whole-cochlea 1 h validation", "whole-cochlea 24 h validation",
    "exposure-end validation", "4 h validation", "8 h validation",
    "auditory-nerve immediate response", "auditory-nerve day-1 response",
    "auditory-nerve day-7 response", "auditory-nerve day-14 response"
  ),
  stringsAsFactors = FALSE
)

human <- programme_all[programme_all$collection == human_name, ]
human <- merge(human, primary_contrasts, by = c("dataset", "contrast"))
human <- human[human$programme %in% targeted, ]
human$programme_role <- ifelse(
  human$programme %in% core4,
  "original core programme",
  "targeted extension prompted by the independent acute-stress study"
)
human <- human[order(
  match(human$programme, targeted),
  match(human$dataset, unique(primary_contrasts$dataset)),
  match(human$contrast, primary_contrasts$contrast)
), ]
nihl_write_csv(
  human,
  file.path(table_root, "Table_2_external_validation_programmes.csv"),
  row.names = FALSE,
  na = ""
)

stouffer_summary <- function(tab, stratum) {
  split_tab <- split(tab, tab$programme)
  ans <- lapply(split_tab, function(z) {
    signed_z <- sign(z$camera_t) * qnorm(z$PValue / 2, lower.tail = FALSE)
    combined_z <- sum(signed_z) / sqrt(length(signed_z))
    data.frame(
      stratum = stratum,
      programme = z$programme[1],
      n_independent_studies = length(unique(z$dataset)),
      studies = paste(z$dataset, collapse = "; "),
      contrasts = paste(z$contrast, collapse = "; "),
      n_up = sum(z$camera_t > 0),
      n_down = sum(z$camera_t < 0),
      direction_concordance = max(sum(z$camera_t > 0), sum(z$camera_t < 0)) /
        length(signed_z),
      Stouffer_Z = combined_z,
      PValue = 2 * pnorm(-abs(combined_z)),
      direction = ifelse(combined_z > 0, "Up", "Down"),
      stringsAsFactors = FALSE
    )
  })
  ans <- do.call(rbind, ans)
  ans$FDR <- p.adjust(ans$PValue, method = "BH")
  ans
}

acute_keys <- data.frame(
  dataset = c("GSE160639", "GSE196870", "GSE312476", "GSE100365"),
  contrast = c(
    "dB105_vs_70", "noise_1h_vs_control", "post_0h_vs_control",
    "immediate_vs_control"
  )
)
acute <- merge(
  programme_all[programme_all$collection == human_name, ],
  acute_keys,
  by = c("dataset", "contrast")
)
acute <- acute[acute$programme %in% targeted, ]

h24_keys <- data.frame(
  dataset = c("GSE196870", "GSE100365"),
  contrast = c("noise_24h_vs_control", "day1_vs_control")
)
h24 <- merge(
  programme_all[programme_all$collection == human_name, ],
  h24_keys,
  by = c("dataset", "contrast")
)
h24 <- h24[h24$programme %in% targeted, ]
h24_emtab <- phase_all[
  phase_all$collection == human_name &
    phase_all$contrast == "h24_vs_control" &
    phase_all$programme %in% targeted,
]
h24 <- rbind(
  h24[, names(h24_emtab), drop = FALSE],
  h24_emtab
)

recovery_keys <- data.frame(
  dataset = "GSE100365",
  contrast = "day7_vs_day1"
)
recovery <- merge(
  programme_all[programme_all$collection == human_name, ],
  recovery_keys,
  by = c("dataset", "contrast")
)
recovery <- recovery[recovery$programme %in% targeted, ]
recovery_emtab <- phase_all[
  phase_all$collection == human_name &
    phase_all$contrast == "week1_vs_h72" &
    phase_all$programme %in% targeted,
]
recovery <- rbind(
  recovery[, names(recovery_emtab), drop = FALSE],
  recovery_emtab
)

meta_summary <- rbind(
  stouffer_summary(acute, "acute/exposure-end response"),
  stouffer_summary(h24, "approximately 24 h response"),
  stouffer_summary(recovery, "later transition relative to early response")
)
meta_summary$programme_role <- ifelse(
  meta_summary$programme %in% core4,
  "original core programme",
  "targeted extension"
)
nihl_write_csv(
  meta_summary,
  file.path(table_root, "Table_3_directional_cross_study_evidence.csv"),
  row.names = FALSE,
  na = ""
)

leave_one_out <- lapply(unique(acute$dataset), function(drop_study) {
  z <- acute[acute$dataset != drop_study, ]
  out <- stouffer_summary(
    z,
    paste0("acute response, excluding ", drop_study)
  )
  out$omitted_study <- drop_study
  out
})
leave_one_out <- do.call(rbind, leave_one_out)
nihl_write_csv(
  leave_one_out,
  file.path(table_root, "Table_S_acute_leave_one_study_out.csv"),
  row.names = FALSE,
  na = ""
)

phase_iut <- read.csv(
  file.path(revision, "phase_transition", "programme_activation_to_resolution_IUT.csv"),
  check.names = FALSE
)
phase_iut$programme_role <- ifelse(
  phase_iut$programme %in% core4,
  "original core programme",
  ifelse(
    phase_iut$programme == targeted_extension,
    "targeted extension",
    "other Hallmark programme"
  )
)
nihl_write_csv(
  phase_iut,
  file.path(table_root, "Table_4_activation_to_resolution_IUT.csv"),
  row.names = FALSE,
  na = ""
)

orthology <- read.csv(
  file.path(revision, "expanded_validation", "orthology_sensitivity_complete.csv"),
  check.names = FALSE
)
orthology_primary <- merge(
  orthology,
  primary_contrasts,
  by = c("dataset", "contrast")
)
orthology_primary <- orthology_primary[orthology_primary$programme %in% targeted, ]
nihl_write_csv(
  orthology_primary,
  file.path(table_root, "Table_S_orthology_sensitivity_expanded.csv"),
  row.names = FALSE,
  na = ""
)

key_summary <- data.frame(
  metric = c(
    "new independent validation studies",
    "new deposited biological libraries represented",
    "acute Stouffer analyses",
    "approximately 24 h Stouffer analyses",
    "original core programmes passing activation-to-resolution IUT FDR<0.10",
    "targeted primary human-vs-mouse direction preservation",
    "targeted primary human-vs-mouse evidence-category preservation"
  ),
  value = c(
    length(unique(primary_contrasts$dataset)),
    12 + 12 + 12 + 15,
    nrow(acute),
    nrow(h24),
    sum(phase_iut$programme %in% core4 &
          phase_iut$activation_to_resolution_supported),
    paste0(
      sum(orthology_primary$direction_preserved), "/",
      nrow(orthology_primary)
    ),
    paste0(
      sum(orthology_primary$evidence_category_preserved), "/",
      nrow(orthology_primary)
    )
  ),
  stringsAsFactors = FALSE
)
nihl_write_csv(
  key_summary,
  file.path(table_root, "key_results_summary.csv"),
  row.names = FALSE,
  na = ""
)

cat("\nCross-study directional summary:\n")
print(meta_summary)
cat("\nActivation-to-resolution IUT, targeted programmes:\n")
print(
  phase_iut[phase_iut$programme %in% targeted, c(
    "programme", "early_camera_t", "late_transition_camera_t",
    "IUT_PValue", "IUT_FDR", "activation_to_resolution_supported"
  )],
  row.names = FALSE
)
cat("\nKey summary:\n")
print(key_summary, row.names = FALSE)
