#!/usr/bin/env Rscript
# 00_download.R -- fetch every public input from GEO and ArrayExpress/BioStudies.
#
# Only the two public archives are contacted. Each file is checked against the
# MD5 recorded in config/input_manifest.csv; a mismatch is an error, not a
# warning, because a silently changed matrix would invalidate every downstream
# number. Files that are already present with the correct checksum are not
# re-downloaded, so the script is safe to run repeatedly.
#
# Usage:
#   Rscript scripts/00_download.R                 # everything
#   Rscript scripts/00_download.R GSE160639       # one dataset only
#   Rscript scripts/00_download.R --check         # verify without downloading
#
# Total transfer: about 500 MB, of which 430 MB is the single-cell archive.
# Typical wall time on a 100 Mbit/s connection: 5-10 minutes.

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))

args <- commandArgs(trailingOnly = TRUE)
check_only <- '--check' %in% args
wanted <- setdiff(args, '--check')

manifest <- read.csv(nihl_inputs$input_manifest, stringsAsFactors = FALSE)

# Local destinations, matching the layout that scripts/00_setup.R expects.
dest_dir <- c(
  GSE8342 = 'GSE8342', GPL81 = 'GPL81', `E-MTAB-16125` = 'E-MTAB-16125',
  GSE107086 = 'GSE107086', GSE160639 = 'GSE160639', GSE196870 = 'GSE196870',
  GSE312476 = 'GSE312476', GSE100365 = 'GSE100365', GPL1261 = 'GPL1261',
  GSE168041 = 'GSE168041'
)
dest_for <- function(accession, file) {
  d <- dest_dir[[accession]]
  out <- file.path(nihl_paths$raw, d, file)
  dir.create(dirname(out), recursive = TRUE, showWarnings = FALSE)
  out
}

md5_of <- function(path) {
  if (!file.exists(path)) return(NA_character_)
  unname(tools::md5sum(path))
}

# `digest` is not a base package; use the openssl-free implementation shipped
# with R via tools::md5sum, which is sufficient for integrity checking.
verify <- function(path, expected) {
  got <- md5_of(path)
  if (is.na(got)) return(FALSE)
  identical(tolower(got), tolower(expected))
}

# Downloads are retried with an extending timeout. The single-cell archive is
# about 430 MB and R's default per-request timeout of 60 s is not enough for it
# on a slow link, while the small files finish well inside their first attempt.
fetch <- function(url, dest, attempts = 3L, timeout_s = 3600L,
                  expected_bytes = NA_real_) {
  if (check_only) return(invisible(FALSE))
  old_timeout <- getOption('timeout')
  on.exit(options(timeout = old_timeout), add = TRUE)
  options(timeout = timeout_s)
  if (file.exists(dest)) unlink(dest)
  last <- NULL
  for (i in seq_len(attempts)) {
    last <- tryCatch({
      utils::download.file(url, dest, mode = 'wb', quiet = TRUE)
      NULL
    }, error = function(e) e, warning = function(w) {
      # download.file signals a warning and then an error on truncation; treat
      # the warning as a failure only when the file is short.
      NULL
    })
    # A body cut short by the network still leaves a non-empty file, so a
    # size check of "> 0" would accept a truncated download and defer the
    # failure to the checksum, where the message names the wrong cause.
    size_ok <- file.exists(dest) && file.size(dest) > 0 &&
      (is.na(expected_bytes) || file.size(dest) == expected_bytes)
    if (size_ok) return(invisible(TRUE))
    Sys.sleep(min(5 * i, 15))
  }
  if (!is.null(last)) stop('Download failed after ', attempts, ' attempts: ',
                           url, '\n  ', conditionMessage(last), call. = FALSE)
  stop('Download produced no file after ', attempts, ' attempts: ', url,
       call. = FALSE)
}

report <- data.frame(accession = character(), file = character(),
                     status = character(), stringsAsFactors = FALSE)
note <- function(accession, file, status) {
  row <- data.frame(accession = accession, file = file, status = status,
                    stringsAsFactors = FALSE)
  report <<- rbind(report, row)
  cat(sprintf('  %-14s %-56s %s\n', accession, file, status))
}

for (i in seq_len(nrow(manifest))) {
  acc <- manifest$accession[i]
  file <- manifest$file[i]
  if (length(wanted) && !acc %in% wanted) next

  if (acc == 'GSE168041') {
    # The single-cell archive is expanded into 16 barcode/gene/matrix triplets.
    tar_path <- dest_for(acc, basename(file))
    target <- file.path(nihl_paths$raw, 'GSE168041', 'extracted')
    already_extracted <-
      length(list.files(target, pattern = '_matrix[.]mtx[.]gz$')) == 16L
    if (already_extracted && (verify(tar_path, manifest$md5[i]) || !file.exists(tar_path))) {
      note(acc, 'GSE168041_RAW.tar (extracted)', 'present')
      next
    }
    if (check_only) {
      note(acc, 'GSE168041_RAW.tar', if (file.exists(tar_path)) 'present' else 'absent')
      next
    }
    if (!verify(tar_path, manifest$md5[i])) {
      fetch(manifest$url[i], tar_path, expected_bytes = as.numeric(manifest$bytes[i]))
    }
    if (!verify(tar_path, manifest$md5[i])) {
      note(acc, 'GSE168041_RAW.tar', 'MD5 MISMATCH')
      stop('Checksum mismatch for ', tar_path)
    }
    dir.create(target, recursive = TRUE, showWarnings = FALSE)
    utils::untar(tar_path, exdir = target)
    n <- length(list.files(target, pattern = '_matrix[.]mtx[.]gz$'))
    note(acc, 'GSE168041_RAW.tar (extracted)', sprintf('%d libraries', n))
    if (n != 16L) stop('Expected 16 single-cell libraries, found ', n)
    next
  }

  dest <- dest_for(acc, file)
  if (verify(dest, manifest$md5[i])) {
    note(acc, file, 'present')
    next
  }
  if (check_only) {
    note(acc, file, if (file.exists(dest)) 'CHECKSUM MISMATCH' else 'absent')
    next
  }
  fetch(manifest$url[i], dest, expected_bytes = as.numeric(manifest$bytes[i]))
  ok <- verify(dest, manifest$md5[i])
  note(acc, file, if (ok) 'downloaded' else 'MD5 MISMATCH')
  if (!ok) {
    stop('Checksum mismatch for ', dest,
         '\n  expected ', manifest$md5[i],
         '\n  observed ', md5_of(dest))
  }
}

cat('\n', if (check_only) 'Checked' else 'Processed', ' ', nrow(report),
    ' manifest rows; ', sum(report$status %in%
      c('present', 'downloaded', '16 libraries')), ' usable.\n', sep = '')
if (any(grepl('MISMATCH|absent', report$status))) {
  cat('Incomplete inputs remain. Re-run without --check to fetch them.\n')
}
invisible(report)
