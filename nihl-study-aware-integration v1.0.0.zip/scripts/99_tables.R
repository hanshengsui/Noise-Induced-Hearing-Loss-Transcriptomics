#!/usr/bin/env Rscript
# 99_tables.R -- assemble the published tables from the analysis outputs.
#
# Every main and additional table is written to results/tables/ with the
# numbering used in the revised manuscript:
#
#   Table_1_dataset_roles_and_boundaries.csv
#   Table_2_activation_to_resolution_IUT.csv          (was Table 3 in the package)
#   Table_3_cross_study_programme_evidence.csv        (was Table 2 in the package)
#   Table_4_broad_cell_class_localization.csv
#   Table_S1_dataset_screening_ledger.csv
#   Table_S2_per_dataset_targeted_programmes.csv
#   Table_S3_acute_leave_one_study_out.csv
#   Table_S4_human_vs_mouse_hallmark_sensitivity.csv
#   Table_S5_all_hallmark_activation_to_resolution_IUT.csv
#   Table_S6_targeted_cell_class_programmes.csv
#   Table_S7_seven_programme_direction_stability_ledger.csv
#   Table_S8_formal_package_numeric_validation.csv
#   Table_S9_boundary_FDR_validation.csv
#   Table_S10_all_50_hallmark_cross_study_synthesis.csv
#   Table_S11A_complete_650_primary_pseudobulk_results.csv
#   Table_S11B_complete_2640_definition_sensitivity_results.csv
#   Table_S12A_complete_GSE107086_gene_results.csv
#   Table_S12B_GSE107086_contrast_summary.csv
#   Table_S12C_GSE107086_average_sham_targeted_programmes.csv
#   Table_S13_GSE168041_mouse_by_class_manifest.csv
#
# Main-table numbering follows the revised manuscript, in which the former
# package Table_2 (cross-study evidence) and Table_3 (IUT) are swapped so that
# the IUT table precedes the synthesis table, matching the order in which the
# results are presented.

options(stringsAsFactors = FALSE)

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
})

stage1 <- Sys.getenv('NIHL_ANALYSIS_ROOT')
revision <- Sys.getenv('NIHL_REVISION_ROOT')
out_dir <- nihl_paths$results_tables
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

p <- function(...) file.path(stage1, ...)
r <- function(...) file.path(revision, ...)
write_out <- function(x, filename) {
  nihl_write_csv(x, file.path(out_dir, filename))
  cat("  ", filename, " (", nrow(x), " rows)\n", sep = "")
}
read_csv <- function(file) {
  if (!file.exists(file)) return(NULL)
  read.csv(file, stringsAsFactors = FALSE, check.names = FALSE, encoding = "UTF-8")
}

# A table is only written when every upstream file it needs is present. This
# matters for --dataset smoke runs, where only one series has been processed;
# the tables that need the others are listed as skipped rather than failing.
skipped <- character()
need <- function(...) {
  files <- c(...)
  missing <- files[!file.exists(files)]
  if (length(missing)) {
    return(paste(basename(missing), collapse = ", "))
  }
  NULL
}

programme_order <- c(
  "HALLMARK_TNFA_SIGNALING_VIA_NFKB",
  "HALLMARK_INFLAMMATORY_RESPONSE",
  "HALLMARK_UNFOLDED_PROTEIN_RESPONSE",
  "HALLMARK_OXIDATIVE_PHOSPHORYLATION",
  "HALLMARK_E2F_TARGETS"
)
# Programme labels as printed in the manuscript tables. Written with escape
# sequences so the files stay ASCII-clean in the repository while the CSV
# carries the Greek letters in UTF-8.
programme_labels <- c(
  HALLMARK_TNFA_SIGNALING_VIA_NFKB = "TNF-\u03b1 signaling via NF-\u03baB",
  HALLMARK_INFLAMMATORY_RESPONSE = "Inflammatory response",
  HALLMARK_UNFOLDED_PROTEIN_RESPONSE = "Unfolded protein response",
  HALLMARK_OXIDATIVE_PHOSPHORYLATION = "Oxidative phosphorylation",
  HALLMARK_E2F_TARGETS = "E2F targets"
)
lab <- function(x) unname(programme_labels[x])
human_name <- "Human Hallmark v2024.1 direct-symbol match"

cat("Building tables ->", out_dir, "\n")

# Each table is built by its own function and called through run_table(), which
# records a table as skipped (rather than aborting the script) when an upstream
# file is absent. A full run produces every table; a single-dataset smoke run
# produces the ones it can support and lists the rest.
skipped <- character()
require_files <- function(label, files) {
  files <- files[!vapply(files, dir.exists, logical(1))]
  missing <- files[!file.exists(files)]
  if (length(missing)) {
    skipped[[label]] <<- paste(basename(missing), collapse = ", ")
    cat("  [skipped]", label, "- missing:",
        paste(basename(missing), collapse = ", "), "\n")
    return(FALSE)
  }
  TRUE
}
run_table <- function(label, fn, files = character()) {
  if (!require_files(label, files)) return(invisible(NULL))
  withCallingHandlers(fn(), error = function(e)
    message("  [error] ", label, ": ", conditionMessage(e),
            " (an upstream input is probably missing from the files= list)"))
  invisible(NULL)
}

make_table_1 <- function() {
## ------------------------------------------------------------------ Table 1
table1 <- tibble::tribble(
  ~Dataset, ~Material_and_assay, ~Design_and_biological_unit,
  ~Present_role, ~Primary_limitation,
  "GSE8342", "Whole cochlea; Affymetrix microarray",
  "10 independent arrays; each array pools eight mice across strain \u00d7 exposure groups",
  "Strain-associated discovery",
  "Pooling prevents individual-mouse inference; no FDR-significant interaction gene",
  "E-MTAB-16125", "Whole cochlea; bulk RNA-seq",
  "Control, 24 h, 72 h and 1 week; five individual mice per time point",
  "Temporal discovery and direct activation-to-resolution testing",
  "Single source study; trajectories remain association-level",
  "GSE160639", "Whole cochlea; bulk RNA-seq raw counts",
  "70, 94 and 105 dB SPL; four deposited biological libraries per group",
  "Independent sound-level validation",
  "70 dB is a non-injurious sound reference, not a quiet sham",
  "GSE196870", "Whole cochlea; deposited processed RNA-seq matrix",
  "Control, 1 h and 24 h; four individual mice per retained group",
  "Independent early-time validation",
  "Processed FPKM-scale matrix used for directional programme analysis",
  "GSE312476", "Whole cochlea; deposited processed RNA-seq matrix",
  "Control, exposure end, 4 h and 8 h; three biological libraries per group",
  "Independent acute-time validation",
  "Associated report is a preprint; deposited values are non-integer",
  "GSE100365", "Auditory nerve/modiolus; Affymetrix microarray",
  "Control, exposure end, 1, 7 and 14 days; three individual mice per group",
  "Compartment-specific time validation",
  "Auditory nerve rather than whole cochlea",
  "GSE168041", "Cochlear single-cell RNA-seq",
  "16 mouse libraries; mouse \u00d7 broad cell class pseudobulk",
  "Broad cell-class localization",
  "Custom broad annotation; not cell-level replication",
  "GSE107086", "Cochlear bulk RNA-seq",
  "24 biological libraries in acute/glucocorticoid-context contrasts",
  "Context sensitivity",
  "Exact animal and bilateral pooling are not reported in deposited metadata"
)
write_out(table1, "Table_1_dataset_roles_and_boundaries.csv")
}

run_table('Table 1', make_table_1)


make_iut_tables <- function() {
## ----------------------------------------- Table 2 (IUT) and Table 3 (synth)
iut_all <- read_csv(r("phase_transition", "programme_activation_to_resolution_IUT.csv"))
if (is.null(iut_all)) {
  skipped <- c(skipped, "Tables 2 and S5 (need 11_emtab_phase_transition.R)")
}
iut_main <- iut_all %>%
  filter(programme %in% programme_order) %>%
  mutate(
    Programme = factor(lab(programme), levels = lab(programme_order)),
    `72 h vs control CAMERA-PR t` = sprintf("%.3f", early_camera_t),
    `1 week vs 72 h CAMERA-PR t` = sprintf("%.3f", late_transition_camera_t),
    `Activation one-sided P` = formatC(activation_one_sided_P, format = "g", digits = 3),
    `Resolution one-sided P` = formatC(resolution_one_sided_P, format = "g", digits = 3),
    `IUT BH FDR` = formatC(IUT_FDR, format = "g", digits = 3),
    `Evidence category` = case_when(
      IUT_FDR < 0.05 ~ "Supported",
      IUT_FDR < 0.10 ~ "Suggestive",
      TRUE ~ "Not supported"
    )
  ) %>%
  arrange(Programme) %>%
  transmute(
    Program = as.character(Programme),
    `72 h vs control CAMERA-PR t`, `1 week vs 72 h CAMERA-PR t`,
    `Activation one-sided P`, `Resolution one-sided P`, `IUT BH FDR`,
    `Evidence category`
  )
write_out(iut_main, "Table_2_activation_to_resolution_IUT.csv")
iut_supplement <- iut_all %>%
  rename(program = programme, legacy_FDR_below_0_10 = activation_to_resolution_supported) %>%
  mutate(activation_to_resolution_supported = IUT_FDR < 0.05,
         evidence_category = case_when(
           IUT_FDR < 0.05 ~ "Supported",
           IUT_FDR < 0.10 ~ "Suggestive",
           TRUE ~ "Not supported"))
write_out(iut_supplement, "Table_S5_all_hallmark_activation_to_resolution_IUT.csv")
}

run_table('Table 2 and Table S5', make_iut_tables, files = c(
  r("phase_transition", "programme_activation_to_resolution_IUT.csv")))


make_synthesis_tables <- function() {
## ---------------------------------------------------------------- all-50 synthesis (S10)
# The cross-study synthesis is recomputed for all 50 Hallmark sets with the same
# Stouffer rule used for the five focal programmes in 12_synthesis.R. This is the
# table the reviewers saw as Table S10, and it also carries the focal-programme
# rows that appear in Table 3.
synthesis <- read_csv(r("expanded_validation", "expanded_programme_results_complete.csv"))
phase <- read_csv(r("phase_transition", "E-MTAB-16125_programme_results_complete.csv"))

stouffer_summary <- function(tab, stratum) {
  parts <- split(tab, tab$programme)
  ans <- lapply(parts, function(z) {
    signed_z <- sign(z$camera_t) * qnorm(z$PValue / 2, lower.tail = FALSE)
    combined_z <- sum(signed_z) / sqrt(length(signed_z))
    data.frame(
      stratum = stratum, program = z$programme[1],
      n_independent_studies = length(unique(z$dataset)),
      studies = paste(z$dataset, collapse = "; "),
      contrasts = paste(z$contrast, collapse = "; "),
      n_up = sum(z$camera_t > 0), n_down = sum(z$camera_t < 0),
      direction_concordance =
        max(sum(z$camera_t > 0), sum(z$camera_t < 0)) / length(signed_z),
      Stouffer_Z = combined_z,
      PValue = 2 * pnorm(-abs(combined_z)),
      direction = ifelse(combined_z > 0, "Up", "Down"),
      stringsAsFactors = FALSE
    )
  })
  ans <- do.call(rbind, ans)
  ans$FDR <- p.adjust(ans$PValue, method = "BH")
  ans
}

# Studies are listed in the manuscript's order of presentation, not
# alphabetically, so that the table reads the same as the text.
study_order <- c("GSE160639", "GSE196870", "GSE312476", "GSE100365")
order_studies <- function(tab) {
  parts <- split(tab, tab$programme)
  for (i in seq_along(parts)) {
    z <- parts[[i]]
    z <- z[order(match(z$dataset, study_order)), ]
    parts[[i]] <- z
  }
  do.call(rbind, parts)
}

acute_keys <- data.frame(
  dataset = c("GSE160639", "GSE196870", "GSE312476", "GSE100365"),
  contrast = c("dB105_vs_70", "noise_1h_vs_control", "post_0h_vs_control",
               "immediate_vs_control")
)
h24_keys <- data.frame(
  dataset = c("GSE196870", "GSE100365"),
  contrast = c("noise_24h_vs_control", "day1_vs_control")
)
later_keys <- data.frame(dataset = "GSE100365", contrast = "day7_vs_day1")

acute <- merge(synthesis[synthesis$collection == human_name, ], acute_keys,
               by = c("dataset", "contrast"))
h24 <- merge(synthesis[synthesis$collection == human_name, ], h24_keys,
             by = c("dataset", "contrast"))
later <- merge(synthesis[synthesis$collection == human_name, ], later_keys,
               by = c("dataset", "contrast"))
h24 <- rbind(h24[, names(phase)],
             phase[phase$collection == human_name & phase$contrast == "h24_vs_control", ])
later <- rbind(later[, names(phase)],
               phase[phase$collection == human_name & phase$contrast == "week1_vs_h72", ])

# Only strata with at least one contributing study are built, so that a
# single-dataset smoke run produces the tables it can support rather than
# failing on the ones it cannot.
build_stratum <- function(tab, label) {
  if (!nrow(tab)) return(NULL)
  stouffer_summary(order_studies(tab), label)
}
synth_all <- do.call(rbind, Filter(Negate(is.null), list(
  build_stratum(acute, "acute/exposure-end response"),
  build_stratum(h24, "approximately 24 h response"),
  build_stratum(later, "later transition relative to early response")
)))
synth_all$evidence_category <- ifelse(
  synth_all$FDR < 0.05, "Supported",
  ifelse(synth_all$FDR < 0.10, "Suggestive", "Not supported"))
write_out(synth_all, "Table_S10_all_50_hallmark_cross_study_synthesis.csv")

# Table 3 reports the five focal programmes under their own BH family: five
# tests within each stratum, as declared in Methods. Table S10 reports all 50
# Hallmark sets under a 50-test family; the two families are deliberate (see the
# revision decision log, K17), and the focal programmes keep the same evidence
# category under both, except where noted there.
table3_focal <- synth_all %>% filter(program %in% programme_order)
table3_focal$FDR_focal5 <- NA_real_
for (st in unique(table3_focal$stratum)) {
  idx <- table3_focal$stratum == st
  table3_focal$FDR_focal5[idx] <- p.adjust(table3_focal$PValue[idx], method = "BH")
}
# The displayed FDR is the permutation-calibrated one: the theoretical BH values
# above assume inter.gene.cor = 0.01, which the calibration shows to be
# anti-conservative here, so they are kept as reference columns only. The
# 5-programme column is FDR_focal5; the 50-set column is the FDR inherited from
# synth_all (Benjamini-Hochberg across all 50 Hallmark sets within a stratum,
# identical to Table S10); do not overwrite it with the focal-family value. The
# evidence class follows the D9 grading (revision/synthesis/results).
grades <- read.csv(file.path(nihl_paths$repo_root, "revision", "synthesis", "results",
                             "evidence_grades_calibrated.csv"), stringsAsFactors = FALSE)
grades$program <- unname(c(
  TNFA = "HALLMARK_TNFA_SIGNALING_VIA_NFKB", INFL = "HALLMARK_INFLAMMATORY_RESPONSE",
  UPR = "HALLMARK_UNFOLDED_PROTEIN_RESPONSE", OXPHOS = "HALLMARK_OXIDATIVE_PHOSPHORYLATION",
  E2F = "HALLMARK_E2F_TARGETS")[grades$program])
grades$stratum <- unname(c(
  acute = "acute/exposure-end response", h24 = "approximately 24 h response",
  later = "later transition relative to early response")[grades$stratum])
table3_focal <- left_join(
  table3_focal, grades[, c("stratum", "program", "fdr_emp", "D9_grade", "boundary_note")],
  by = c("stratum", "program"))
stopifnot(!anyNA(table3_focal$fdr_emp), !anyNA(table3_focal$D9_grade))
table3 <- table3_focal %>%
  mutate(
    Programme = factor(lab(program), levels = lab(programme_order)),
    Stratum = recode(
      stratum,
      "acute/exposure-end response" = "Acute/exposure-end response",
      "approximately 24 h response" = "Approximately 24-h response",
      "later transition relative to early response" =
        "Later transition relative to early response"
    ),
    `Direction summary` = paste0(n_up, " up / ", n_down, " down"),
    `Direction concordance` = sprintf("%.2f", direction_concordance),
    `Directional Stouffer Z` = sprintf("%.3f", Stouffer_Z),
    `Permutation FDR` = ifelse(fdr_emp < 0.001, sprintf("%.2e", fdr_emp),
                               formatC(fdr_emp, format = "g", digits = 3)),
    `Evidence class` = paste0(
      recode(D9_grade, conf = "Confirmatory", expl = "Exploratory",
             heterogeneous = "Heterogeneous", ns = "Not supported"),
      ifelse(!is.na(boundary_note) & nzchar(boundary_note), " (boundary)", "")),
    `Theoretical BH FDR (5 programmes)` = formatC(FDR_focal5, format = "g", digits = 3),
    `Theoretical BH FDR (50 Hallmark sets)` = formatC(FDR, format = "g", digits = 3)
  ) %>%
  arrange(factor(Stratum, levels = c(
    "Acute/exposure-end response", "Approximately 24-h response",
    "Later transition relative to early response"
  )), Programme) %>%
  transmute(
    Stratum, Program = as.character(Programme),
    `Independent studies` = n_independent_studies,
    `Direction summary`, `Direction concordance`,
    `Directional Stouffer Z`, `Permutation FDR`, `Evidence class`,
    `Theoretical BH FDR (5 programmes)`, `Theoretical BH FDR (50 Hallmark sets)`
  )
write_out(table3, "Table_3_cross_study_programme_evidence.csv")
}

run_table('Table 3 and Table S10', make_synthesis_tables, files = c(
  r("expanded_validation", "expanded_programme_results_complete.csv"),
  r("phase_transition", "E-MTAB-16125_programme_results_complete.csv")))


make_cellclass_tables <- function() {
cell <- read_csv(p("results", "standard_pathway_reanalysis",
                   "CAMERA_PR_cellclass_within_and_global_FDR.csv")) %>%
  mutate(
    tissue_cohort = sub(
      "_(basal_cell|endothelial|fibrocyte|immune|intermediate_melanocyte|marginal_cell|pericyte_smooth_muscle|schwann_glial|spiral_ganglion_neuron)$",
      "", celltype_analysis),
    cell_type = sub("^(lateral_wall_focused|neuronal_focused)_", "", celltype_analysis),
    Display = paste0(ifelse(tissue_cohort == "lateral_wall_focused", "LW: ", "N: "),
                     gsub("_", " ", cell_type))
  )
cell_main <- cell %>%
  filter(pathway %in% c("HALLMARK_TNFA_SIGNALING_VIA_NFKB",
                        "HALLMARK_INFLAMMATORY_RESPONSE",
                        "HALLMARK_UNFOLDED_PROTEIN_RESPONSE",
                        "HALLMARK_OXIDATIVE_PHOSPHORYLATION")) %>%
  group_by(pathway) %>%
  summarise(
    `Positive global-FDR classes` =
      paste(Display[global_FDR < 0.10 & camera_t > 0], collapse = "; "),
    `Negative global-FDR classes` =
      paste(Display[global_FDR < 0.10 & camera_t < 0], collapse = "; "),
    `Positive n` = sum(global_FDR < 0.10 & camera_t > 0),
    `Negative n` = sum(global_FDR < 0.10 & camera_t < 0),
    .groups = "drop"
  ) %>%
  mutate(Programme = factor(lab(pathway), levels = lab(programme_order))) %>%
  arrange(Programme) %>%
  transmute(Program = as.character(Programme),
            `Positive n`, `Positive global-FDR classes`,
            `Negative n`, `Negative global-FDR classes`)
write_out(cell_main, "Table_4_broad_cell_class_localization.csv")
}

run_table('Table 4', make_cellclass_tables, files = c(
  p("results", "standard_pathway_reanalysis", "CAMERA_PR_cellclass_within_and_global_FDR.csv")))


make_s1_table <- function() {
## ------------------------------------------------------- additional tables
write_out(read_csv(file.path(nihl_paths$config, "dataset_screening_ledger.csv")),
          "Table_S1_dataset_screening_ledger.csv")

per_dataset <- read_csv(r("expanded_validation", "expanded_programme_results_targeted.csv")) %>%
  filter(collection == human_name, programme %in% programme_order) %>%
  mutate(Program = lab(programme)) %>%
  select(dataset, contrast, Program, n_genes, direction,
         camera_t, PValue, FDR, FDR_category, ranked_universe)
}

run_table('Table S1', make_s1_table)


make_s2_table <- function() {
per_dataset <- read_csv(r("expanded_validation", "expanded_programme_results_targeted.csv")) %>%
  filter(collection == human_name, programme %in% programme_order) %>%
  mutate(Program = lab(programme)) %>%
  select(dataset, contrast, Program, n_genes, direction,
         camera_t, PValue, FDR, FDR_category, ranked_universe)
write_out(per_dataset, "Table_S2_per_dataset_targeted_programmes.csv")
}

run_table('Table S2', make_s2_table, files = c(
  r("expanded_validation", "expanded_programme_results_targeted.csv")))


make_s3s4_tables <- function() {
loo <- read_csv(r("tables", "Table_S_acute_leave_one_study_out.csv")) %>%
  filter(programme %in% programme_order) %>%
  mutate(Program = lab(programme)) %>%
  select(omitted_study, Program, n_independent_studies, studies, contrasts,
         n_up, n_down, direction_concordance, Stouffer_Z, PValue, FDR)
write_out(loo, "Table_S3_acute_leave_one_study_out.csv")

# S4 restricts to the 11 primary acute contrasts (5 programmes x 11 contrasts
# = 55 rows), which is the set the reviewers saw. The remaining contrasts are
# reported in Table S2 and are not repeated here.
primary_contrasts <- data.frame(
  dataset = c("GSE160639", "GSE160639", "GSE196870", "GSE196870",
              "GSE312476", "GSE312476", "GSE312476",
              "GSE100365", "GSE100365", "GSE100365", "GSE100365"),
  contrast = c("dB94_vs_70", "dB105_vs_70",
               "noise_1h_vs_control", "noise_24h_vs_control",
               "post_0h_vs_control", "post_4h_vs_control", "post_8h_vs_control",
               "immediate_vs_control", "day1_vs_control", "day7_vs_control",
               "day14_vs_control"),
  stringsAsFactors = FALSE
)
orth <- read_csv(r("expanded_validation", "orthology_sensitivity_complete.csv")) %>%
  inner_join(primary_contrasts, by = c("dataset", "contrast")) %>%
  filter(programme %in% programme_order) %>%
  mutate(Program = lab(programme)) %>%
  select(dataset, contrast, Program,
         camera_t_human, FDR_human, FDR_category_human,
         camera_t_mouse, FDR_mouse, FDR_category_mouse,
         direction_preserved, evidence_category_preserved)
write_out(orth, "Table_S4_human_vs_mouse_hallmark_sensitivity.csv")
}

run_table('Tables S3 and S4', make_s3s4_tables, files = c(
  r("tables", "Table_S_acute_leave_one_study_out.csv"),
  r("expanded_validation", "orthology_sensitivity_complete.csv")))


make_s6_table <- function() {
# Table S6 uses the same cell-class camera-PR table as Table 4.
cell <- read_csv(p("results", "standard_pathway_reanalysis",
                   "CAMERA_PR_cellclass_within_and_global_FDR.csv"))
cell_targeted <- cell %>%
  mutate(
    tissue_cohort = sub(
      "_(basal_cell|endothelial|fibrocyte|immune|intermediate_melanocyte|marginal_cell|pericyte_smooth_muscle|schwann_glial|spiral_ganglion_neuron)$",
      "", celltype_analysis),
    cell_type = sub("^(lateral_wall_focused|neuronal_focused)_", "", celltype_analysis)) %>%
  filter(pathway %in% programme_order) %>%
  mutate(Programme = lab(pathway)) %>%
  select(Program = Programme, tissue_cohort, cell_type, NGenes, Direction,
         camera_t, PValue, within_class_FDR, global_FDR)
write_out(cell_targeted, "Table_S6_targeted_cell_class_programmes.csv")
}

run_table('Table S6', make_s6_table, files = c(
  p("results", "standard_pathway_reanalysis", "CAMERA_PR_cellclass_within_and_global_FDR.csv")))


make_s7_table <- function() {
ledger7 <- read_csv(p("results", "cell_annotation_sensitivity",
                      "Table_S7_seven_programme_direction_stability_ledger.csv"))
write_out(ledger7[, c("panel", "pathway", "tissue_cohort", "cell_type",
                      "n_evaluable_definitions", "stable", "directions",
                      "Program")],
          "Table_S7_seven_programme_direction_stability_ledger.csv")
}

run_table('Table S7', make_s7_table, files = c(
  p("results", "cell_annotation_sensitivity", "Table_S7_seven_programme_direction_stability_ledger.csv")))


make_s11_tables <- function() {
## ------------------------------------- complete single-cell result tables (S11)
# S11A: the 650 primary pseudobulk camera-PR results (13 combinations x 50 sets).
# S11B: the 2640 annotation-definition sensitivity results (53 definitions x 50 sets).
dir.create(file.path(stage1, "results", "cell_annotation_sensitivity"),
           recursive = TRUE, showWarnings = FALSE)
sens_src <- p("results", "cell_annotation_sensitivity",
              "CAMERA_PR_annotation_and_cell_threshold_sensitivity.csv")
sens <- read_csv(sens_src)
primary_keys <- read_csv(p("source_data", "GSE168041_celltype",
                           "celltype_eligibility_thresholds.csv")) %>%
  filter(min_cells == 20, inferentially_eligible) %>%
  mutate(key = paste(tissue_cohort, cell_type, sep = "__"))
parts <- strsplit(sens$analysis, "__", fixed = TRUE)
sens$definition <- paste(vapply(parts, `[[`, character(1), 1),
                         vapply(parts, `[[`, character(1), 2), sep = "_")
sens$key <- vapply(parts, function(x) paste(x[3:length(x)], collapse = "__"),
                   character(1))
# S11A uses the same column layout as the main cell-class table, with the
# cohort and class joined by an underscore and no definition prefix, so that it
# lines up with Table 4 and with Table S11B's `analysis` column.
# The global FDR in S11A is a BH correction across the 650 primary tests
# (13 combinations x 50 sets), which is the family the table itself defines.
# This differs from the `global_FDR` column of the full sensitivity grid, which
# corrects across all 2640 definition x set combinations; the two columns carry
# the same name but different families, so S11A recomputes its own.
s11a <- sens %>%
  filter(definition == "primary_20", key %in% primary_keys$key) %>%
  mutate(celltype_analysis = gsub("__", "_", sub("^primary__20__", "", analysis))) %>%
  mutate(global_FDR_650 = p.adjust(PValue, method = "BH")) %>%
  select(pathway, NGenes, Direction, camera_t = score, PValue,
         celltype_analysis, within_class_FDR, global_FDR = global_FDR_650)
write_out(s11a, "Table_S11A_complete_650_primary_pseudobulk_results.csv")
write_out(sens %>% select(pathway, NGenes, Direction, score, PValue,
                          within_class_FDR, analysis, n_naive, n_noise, global_FDR),
          "Table_S11B_complete_2640_definition_sensitivity_results.csv")
}

run_table('Tables S11A and S11B', make_s11_tables, files = c(
  p("results", "cell_annotation_sensitivity", "CAMERA_PR_annotation_and_cell_threshold_sensitivity.csv")))


make_s12_tables <- function() {
## ------------------------------------ glucocorticoid-context tables (S12)
g107_files <- list.files(p("results", "GSE107086"),
                         pattern = "^GSE107086__.*[.]csv[.]gz$", full.names = TRUE)
stopifnot(length(g107_files) == 9L)
g107 <- do.call(rbind, lapply(g107_files, function(f) read.csv(gzfile(f),
                                                               check.names = FALSE)))
write_out(g107[, c("feature_id", "gene_symbol", "contrast", "logFC", "SE",
                   "CI_low", "CI_high", "AveExpr", "moderated_t", "PValue",
                   "FDR", "B", "df_total")],
          "Table_S12A_complete_GSE107086_gene_results.csv")

contrast_type <- c(
  noise_day_ADX = "Noise effect", noise_day_shamADX = "Noise effect",
  noise_night_ADX = "Noise effect", noise_night_shamADX = "Noise effect",
  GC_dependency_day = "ADX-context interaction",
  GC_dependency_night = "ADX-context interaction",
  noise_average_shamADX = "Noise effect", noise_average_ADX = "Noise effect",
  GC_dependency_average = "ADX-context interaction"
)
contrast_display <- c(
  noise_day_ADX = "Day / ADX", noise_day_shamADX = "Day / sham",
  noise_night_ADX = "Night / ADX", noise_night_shamADX = "Night / sham",
  GC_dependency_day = "ADX interaction / day",
  GC_dependency_night = "ADX interaction / night",
  noise_average_shamADX = "Average / sham", noise_average_ADX = "Average / ADX",
  GC_dependency_average = "ADX interaction / average"
)
s12b <- g107 %>%
  group_by(contrast) %>%
  summarise(n_genes = n(),
            n_FDR_0.05 = sum(FDR < 0.05, na.rm = TRUE),
            n_FDR_0.10 = sum(FDR < 0.10, na.rm = TRUE),
            n_FDR_0.10_abs_logFC_0.5 =
              sum(FDR < 0.10 & abs(logFC) >= 0.5, na.rm = TRUE),
            .groups = "drop") %>%
  mutate(Contrast_type = unname(contrast_type[contrast]),
         Display = unname(contrast_display[contrast])) %>%
  arrange(match(contrast, names(contrast_type)))
write_out(s12b, "Table_S12B_GSE107086_contrast_summary.csv")
collection_label <- c(
  Human_Hallmark_v2024.1_symbol_match = "Human-symbol Hallmark",
  Mouse_MSigDB_MH_orthology_mapped_current = "Mouse Hallmark"
)
short_label <- c(
  HALLMARK_TNFA_SIGNALING_VIA_NFKB = "TNF-\u03b1/NF-\u03baB",
  HALLMARK_INFLAMMATORY_RESPONSE = "Inflammation",
  HALLMARK_OXIDATIVE_PHOSPHORYLATION = "OxPhos",
  HALLMARK_E2F_TARGETS = "E2F targets"
)
write_out(read_csv(r("analysis_results", "mouse_hallmark_sensitivity",
                     "core4_collection_specific_CAMERA_PR.csv")) %>%
            filter(analysis == "GSE107086_acute_noise_average_shamADX") %>%
            rename(program = programme) %>%
            mutate(Collection = unname(collection_label[collection]),
                   Program = unname(short_label[program])),
          "Table_S12C_GSE107086_average_sham_targeted_programmes.csv")
}

run_table('Tables S12A to S12C', make_s12_tables, files = c(
  p("results", "GSE107086")))


make_s13_table <- function() {
## ------------------------------- mouse-by-class eligibility manifest (S13)
counts <- read_csv(p("source_data", "GSE168041_celltype",
                     "cell_counts_and_library_sizes.csv"))
strict <- read_csv(p("source_data", "cell_annotation_sensitivity",
                     "strict_annotation_cell_counts.csv"))
elig <- read_csv(p("source_data", "GSE168041_celltype",
                   "celltype_eligibility_thresholds.csv"))
strict_k <- paste(strict$sample_id, strict$cell_type, sep = "__")
strict_us <- strict[match(paste(counts$sample_id, counts$cell_type, sep = "__"),
                          strict_k), ]
s13 <- counts %>%
  mutate(
    sex = "Not reported in deposited metadata",
    strict_n_cells = strict_us$n_cells,
    strict_library_size = strict_us$library_size
  ) %>%
  left_join(elig %>% filter(min_cells == 20) %>%
              select(tissue_cohort, cell_type, n_naive_eligible, n_noise_eligible,
                     primary_group_inferentially_eligible = inferentially_eligible),
            by = c("tissue_cohort", "cell_type")) %>%
  group_by(tissue_cohort, cell_type) %>%
  mutate(
    primary_mouse_eligible_10 = n_cells >= 10 & library_size >= 5000,
    primary_mouse_eligible_20 = n_cells >= 20 & library_size >= 5000,
    primary_mouse_eligible_30 = n_cells >= 30 & library_size >= 5000,
    # Rows with no strict-annotation counterpart (the unassigned class) stay
    # NA rather than FALSE: the class has no strict-annotation cells at all,
    # which is different from failing the 20-cell rule.
    strict_mouse_eligible_20 = ifelse(
      is.na(strict_n_cells), NA,
      strict_n_cells >= 20 & !is.na(strict_library_size) & strict_library_size >= 5000)
  ) %>%
  ungroup() %>%
  select(sample_id, tissue_cohort, condition, sex, cell_type, n_cells,
         library_size, detected_genes, primary_mouse_eligible_10,
         primary_mouse_eligible_20, primary_mouse_eligible_30,
         n_naive_eligible, n_noise_eligible,
         primary_group_inferentially_eligible, strict_n_cells,
         strict_library_size, strict_mouse_eligible_20)
write_out(s13, "Table_S13_GSE168041_mouse_by_class_manifest.csv")
}

run_table('Table S13', make_s13_table, files = c(
  p("source_data", "GSE168041_celltype", "cell_counts_and_library_sizes.csv"),
  p("source_data", "cell_annotation_sensitivity", "strict_annotation_cell_counts.csv"),
  p("source_data", "GSE168041_celltype", "celltype_eligibility_thresholds.csv")))


# Tables S8 and S9 are produced by the formal backend validation, which compares
# the archived and the formally installed Bioconductor implementations. They are
# copied from the validation output if it has been run, otherwise reported as
# absent rather than fabricated.
for (f in c("Table_S8_formal_package_numeric_validation.csv",
            "Table_S9_boundary_FDR_validation.csv")) {
  src <- p("reproducibility", f)
  if (file.exists(src)) {
    write_out(read_csv(src), f)
  } else {
    message("  ", f, ": not produced by this run (see README, 'Validation tables')")
  }
}

# Local library paths are reduced to their final component so the committed
# sessionInfo does not carry machine-specific directories.
info <- capture.output(sessionInfo())
info <- gsub("(/[^/ ]+)+/([^/ ]+)", "<path>/\\2", info)
writeLines(info, file.path(out_dir, "table_generation_sessionInfo.txt"))
if (length(skipped)) {
  cat("\nSkipped", length(skipped),
      "table blocks because upstream files were absent:\n")
  for (nm in names(skipped)) cat("  ", nm, ": ", skipped[[nm]], "\n", sep = "")
} else {
  cat("All table blocks produced.\n")
}
cat("Tables written to", out_dir, "\n")
