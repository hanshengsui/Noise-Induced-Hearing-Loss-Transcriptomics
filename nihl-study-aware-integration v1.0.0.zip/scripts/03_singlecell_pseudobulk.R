#!/usr/bin/env Rscript
# 03_singlecell_pseudobulk.R -- mouse-by-broad-cell-class pseudobulk contrast
# (Table 4, Figure 5B, Additional file 17).
#
# Reads the 16 deposited 10x libraries, applies the marker-panel annotation
# defined in resources/annotations/cell_type_markers.csv, applies the 20-cell /
# 5,000-UMI pseudobulk rule, and fits the noise-vs-naive contrast per class.

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
nihl_require_versions('3.62.2', '4.4.2')
nihl_require_inputs(nihl_inputs[c('GSE168041_matrix_dir', 'GSE168041_metadata',
                                  'GSE168041_gene_map', 'cell_type_markers')],
                    c('dir', 'file', 'file', 'file'))

suppressPackageStartupMessages(library(Matrix))

set.seed(20260712)

# Keep a persistent execution log when the script is launched as a detached
# process by the desktop runner.
log_dir <- Sys.getenv('NIHL_LOG_DIR', 'work/final_submission/logs')
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
log_con <- file(file.path(log_dir, 'gse168041_r.log'), open = 'wt')
sink(log_con, type = 'output')
sink(log_con, type = 'message')
on.exit({
  sink(type = 'message')
  sink(type = 'output')
  close(log_con)
}, add = TRUE)

root <- Sys.getenv('NIHL_ANALYSIS_ROOT', 'outputs/NIHL_submission')
out_dir <- file.path(root, 'results', 'GSE168041_celltype')
src_dir <- file.path(root, 'source_data', 'GSE168041_celltype')
tab_dir <- file.path(root, 'tables')
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(src_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tab_dir, recursive = TRUE, showWarnings = FALSE)

meta <- read.csv(nihl_inputs$GSE168041_metadata, stringsAsFactors = FALSE)
markers <- read.csv(nihl_inputs$cell_type_markers, stringsAsFactors = FALSE)
master <- read.csv(nihl_inputs$GSE168041_gene_map, stringsAsFactors = FALSE)
master_gene <- master$gene_id
master_symbol <- master$gene_symbol

base_dir <- nihl_inputs$GSE168041_matrix_dir
files <- list.files(base_dir, pattern = '_matrix[.]mtx[.]gz$', full.names = TRUE)

all_cell_meta <- list()
all_pb <- list()
count_rows <- list()
score_rows <- list()

for (i in seq_len(nrow(meta))) {
  sm <- meta[i, ]
  prefix <- file.path(base_dir, sm$sample_label)
  message('Processing ', sm$sample_id, ' (', i, '/', nrow(meta), ')')
  m <- as(readMM(gzfile(paste0(prefix, '_matrix.mtx.gz'))), 'CsparseMatrix')
  feat <- read.delim(gzfile(paste0(prefix, '_genes.tsv.gz')), header = FALSE,
                     stringsAsFactors = FALSE)
  colnames(feat)[1:2] <- c('gene_id','gene_symbol')
  bc <- readLines(gzfile(paste0(prefix, '_barcodes.tsv.gz')))
  stopifnot(nrow(m) == nrow(feat), ncol(m) == length(bc))

  n_count <- Matrix::colSums(m)
  n_feature <- diff(m@p)
  mt <- grepl('^mt-', feat$gene_symbol, ignore.case = TRUE)
  percent_mito <- Matrix::colSums(m[mt, , drop = FALSE]) / pmax(n_count, 1) * 100
  qc_keep <- n_count >= 1000 & n_feature >= 500 & n_feature <= 7500 & percent_mito <= 20

  cohort_markers <- markers[markers$cohort_scope %in% c('both', sm$tissue_cohort), ]
  marker_genes <- unique(cohort_markers$marker_gene)
  marker_idx <- match(marker_genes, feat$gene_symbol)
  present <- !is.na(marker_idx)
  marker_genes <- marker_genes[present]
  marker_idx <- marker_idx[present]
  mm <- m[marker_idx, qc_keep, drop = FALSE]
  lib <- n_count[qc_keep]
  mm_norm <- mm %*% Diagonal(x = 1e4 / pmax(lib, 1))
  mm_norm@x <- log1p(mm_norm@x)

  types <- unique(cohort_markers$cell_type)
  score <- sapply(types, function(ct) {
    genes <- cohort_markers$marker_gene[cohort_markers$cell_type == ct]
    idx <- match(genes, marker_genes)
    idx <- idx[!is.na(idx)]
    if (!length(idx)) return(rep(0, ncol(mm_norm)))
    Matrix::colMeans(mm_norm[idx, , drop = FALSE])
  })
  if (is.vector(score)) score <- matrix(score, ncol = 1, dimnames = list(NULL, types))
  top_i <- max.col(score, ties.method = 'first')
  top_score <- score[cbind(seq_len(nrow(score)), top_i)]
  second_score <- apply(score, 1, function(z) sort(z, decreasing = TRUE)[min(2, length(z))])
  margin <- top_score - second_score
  assigned <- types[top_i]
  assigned[top_score < 0.05 | margin < 0.01] <- 'unassigned'

  cm <- data.frame(
    barcode = bc[qc_keep], sample_id = sm$sample_id,
    tissue_cohort = sm$tissue_cohort, condition = sm$condition,
    n_count = n_count[qc_keep], n_feature = n_feature[qc_keep],
    percent_mito = percent_mito[qc_keep], cell_type = assigned,
    top_marker_score = top_score, marker_score_margin = margin,
    stringsAsFactors = FALSE
  )
  all_cell_meta[[sm$sample_id]] <- cm

  for (ct in unique(assigned)) {
    cells <- which(qc_keep)[assigned == ct]
    if (!length(cells)) next
    agg <- Matrix::rowSums(m[, cells, drop = FALSE])
    mapped <- numeric(length(master_gene))
    mi <- match(feat$gene_id, master_gene)
    ok <- !is.na(mi)
    mapped[mi[ok]] <- agg[ok]
    key <- paste(sm$sample_id, ct, sep = '__')
    all_pb[[key]] <- mapped
    count_rows[[key]] <- data.frame(
      sample_id = sm$sample_id, tissue_cohort = sm$tissue_cohort,
      condition = sm$condition, cell_type = ct, n_cells = length(cells),
      library_size = sum(mapped), detected_genes = sum(mapped > 0),
      stringsAsFactors = FALSE
    )
  }

  # Store marker scores in long format because the two tissue cohorts have
  # different admissible broad cell classes.  A wide rbind would otherwise
  # fail when cohort-specific marker columns differ.
  sr <- do.call(rbind, lapply(seq_along(types), function(k) {
    z <- aggregate(score[, k], by = list(assigned_cell_type = assigned), FUN = mean)
    names(z)[2] <- 'mean_marker_score'
    z$scored_cell_type <- types[k]
    z
  }))
  sr$sample_id <- sm$sample_id
  sr$tissue_cohort <- sm$tissue_cohort
  score_rows[[sm$sample_id]] <- sr[, c('sample_id','tissue_cohort',
                                       'assigned_cell_type','scored_cell_type',
                                       'mean_marker_score')]
  rm(m, mm, mm_norm, score); invisible(gc())
}

cell_meta <- do.call(rbind, all_cell_meta)
con <- gzfile(file.path(src_dir, 'cell_metadata_marker_guided.csv.gz'), 'wt')
write.csv(cell_meta, con, row.names = FALSE, na = '')
close(con)

cell_counts <- do.call(rbind, count_rows)
rownames(cell_counts) <- NULL
write.csv(cell_counts, file.path(src_dir, 'cell_counts_and_library_sizes.csv'), row.names = FALSE)

score_summary <- do.call(rbind, score_rows)
rownames(score_summary) <- NULL
write.csv(score_summary, file.path(src_dir, 'marker_score_summary.csv'), row.names = FALSE)

pb <- do.call(cbind, all_pb)
rownames(pb) <- master_gene
con <- gzfile(file.path(src_dir, 'mouse_celltype_pseudobulk_counts.csv.gz'), 'wt')
write.csv(data.frame(gene_id = master_gene, gene_symbol = master_symbol, pb,
                     check.names = FALSE), con, row.names = FALSE)
close(con)

# Pre-specified eligibility across cell thresholds.
thresholds <- c(10,20,30)
eligibility <- list()
for (th in thresholds) {
  for (cohort in unique(meta$tissue_cohort)) {
    types <- setdiff(unique(cell_counts$cell_type[cell_counts$tissue_cohort == cohort]), 'unassigned')
    for (ct in types) {
      z <- cell_counts[cell_counts$tissue_cohort == cohort & cell_counts$cell_type == ct, ]
      samples <- meta[meta$tissue_cohort == cohort, c('sample_id','condition')]
      z <- merge(samples, z, by = c('sample_id','condition'), all.x = TRUE)
      z$n_cells[is.na(z$n_cells)] <- 0
      z$library_size[is.na(z$library_size)] <- 0
      n_naive <- sum(z$condition == 'naive' & z$n_cells >= th & z$library_size >= 5000)
      n_noise <- sum(z$condition == 'noise' & z$n_cells >= th & z$library_size >= 5000)
      eligibility[[paste(th,cohort,ct,sep='__')]] <- data.frame(
        min_cells = th, tissue_cohort = cohort, cell_type = ct,
        n_naive_eligible = n_naive, n_noise_eligible = n_noise,
        inferentially_eligible = n_naive >= 3 & n_noise >= 3,
        stringsAsFactors = FALSE
      )
    }
  }
}
eligibility <- do.call(rbind, eligibility)
rownames(eligibility) <- NULL
write.csv(eligibility, file.path(src_dir, 'celltype_eligibility_thresholds.csv'), row.names = FALSE)

# Primary threshold: >=20 cells and >=5000 UMI per mouse-cell-type pseudobulk.
primary <- eligibility[eligibility$min_cells == 20 & eligibility$inferentially_eligible, ]
de_summary <- list()
baseline_list <- list()

for (j in seq_len(nrow(primary))) {
  cohort <- primary$tissue_cohort[j]
  ct <- primary$cell_type[j]
  z <- cell_counts[cell_counts$tissue_cohort == cohort & cell_counts$cell_type == ct &
                   cell_counts$n_cells >= 20 & cell_counts$library_size >= 5000, ]
  z <- z[order(z$condition, z$sample_id), ]
  keys <- paste(z$sample_id, z$cell_type, sep = '__')
  counts <- pb[, keys, drop = FALSE]
  colnames(counts) <- z$sample_id
  condition <- factor(z$condition, levels = c('naive','noise'))
  design <- model.matrix(~0 + condition)
  colnames(design) <- c('naive','noise')
  C <- matrix(c(-1,1), ncol = 1, dimnames = list(colnames(design), 'noise_vs_naive'))
  keep <- filterByExpr(counts, design = design, min.count = 10, min.total.count = 15)
  counts_f <- counts[keep, , drop = FALSE]
  nf <- calcNormFactors(counts_f, method = 'TMM')
  lib <- colSums(counts_f) * nf
  v <- voom(counts_f, design = design, lib.size = lib, normalize.method = 'none', plot = FALSE)
  fit <- lmFit(v, design)
  fit <- contrasts.fit(fit, C)
  fit <- eBayes(fit, robust = TRUE, trend = FALSE)
  tt <- topTable(fit, coef = 1, number = Inf, sort.by = 'none')
  se <- fit$stdev.unscaled[,1] * sqrt(fit$s2.post)
  crit <- qt(0.975, fit$df.total)
  feature_idx <- match(rownames(counts_f), master_gene)
  res <- data.frame(
    gene_id = rownames(counts_f), gene_symbol = master_symbol[feature_idx],
    tissue_cohort = cohort, cell_type = ct, contrast = 'noise_vs_naive',
    logFC = tt$logFC, SE = se, CI_low = tt$logFC - crit*se,
    CI_high = tt$logFC + crit*se, AveExpr = tt$AveExpr,
    moderated_t = tt$t, PValue = tt$P.Value, FDR = tt$adj.P.Val,
    n_naive = sum(condition == 'naive'), n_noise = sum(condition == 'noise'),
    min_cells = 20, stringsAsFactors = FALSE
  )
  safe <- gsub('[^A-Za-z0-9]+','_',paste(cohort,ct,sep='__'))
  con <- gzfile(file.path(out_dir, paste0(safe, '__noise_vs_naive.csv.gz')), 'wt')
  write.csv(res, con, row.names = FALSE, na = '')
  close(con)
  de_summary[[safe]] <- data.frame(
    tissue_cohort = cohort, cell_type = ct,
    n_naive = sum(condition == 'naive'), n_noise = sum(condition == 'noise'),
    n_genes = nrow(res), n_FDR_0.05 = sum(res$FDR < 0.05),
    n_FDR_0.10 = sum(res$FDR < 0.10),
    n_FDR_0.10_abs_logFC_0.5 = sum(res$FDR < 0.10 & abs(res$logFC) >= 0.5),
    stringsAsFactors = FALSE
  )

  naive_cols <- which(condition == 'naive')
  baseline <- rowMeans(v$E[, naive_cols, drop = FALSE])
  baseline_list[[safe]] <- data.frame(
    gene_id = rownames(v$E), gene_symbol = master_symbol[match(rownames(v$E), master_gene)],
    tissue_cohort = cohort, cell_type = ct,
    baseline_mean_logCPM = baseline, stringsAsFactors = FALSE
  )
}

de_summary <- if (length(de_summary)) do.call(rbind, de_summary) else data.frame()
baseline <- if (length(baseline_list)) do.call(rbind, baseline_list) else data.frame()
write.csv(de_summary, file.path(tab_dir, 'Table_S9_celltype_pseudobulk_summary.csv'), row.names = FALSE)
con <- gzfile(file.path(src_dir, 'eligible_celltype_baseline_expression.csv.gz'), 'wt')
write.csv(baseline, con, row.names = FALSE, na = '')
close(con)

annotation_summary <- data.frame(
  metric = c('cells_deposited','cells_passing_QC','cells_assigned','cells_unassigned',
             'primary_eligible_cohort_celltypes'),
  value = c(sum(meta$n_cells), nrow(cell_meta), sum(cell_meta$cell_type != 'unassigned'),
            sum(cell_meta$cell_type == 'unassigned'), nrow(primary)),
  stringsAsFactors = FALSE
)
write.csv(annotation_summary, file.path(out_dir, 'annotation_summary.csv'), row.names = FALSE)

cat('GSE168041 marker-guided broad-cell-type pseudobulk complete.\n')
print(annotation_summary)
print(de_summary)
