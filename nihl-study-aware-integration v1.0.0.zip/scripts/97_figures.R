#!/usr/bin/env Rscript
# 97_figures.R -- every main and supplementary figure.
#
# Each figure is written twice, as PDF (vector, for typesetting) and as a
# 600-dpi PNG (for review). Source data for every panel are written to
# work/figure_source_data/<figure>/ so each plotted value can be traced back to
# a table.
#
# Figure numbering follows the revised manuscript:
#   Figure 1  study-aware design and claim boundaries
#   Figure 2  strain-associated discovery and independent acute validation
#   Figure 3  direct and independent temporal evidence
#   Figure 4  cross-study robustness, heterogeneity and orthology sensitivity
#   Figure 5  mouse-level broad cell-class localization
#   Figures S1-S7  supplementary panels (Additional file 18)
#
# Runtime: about 3 minutes. The figures are produced, not reviewed here.

options(stringsAsFactors = FALSE)

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(patchwork)
  library(ggrepel)
  library(scales)
  library(grid)
})

set.seed(20260713)

analysis_root <- Sys.getenv('NIHL_ANALYSIS_ROOT', 'outputs/NIHL_submission')
revision_input <- Sys.getenv('NIHL_REVISION_INPUT', 'outputs/NIHL_submission_revision5')
fig_dir <- nihl_paths$results_figures
sup_dir <- file.path(nihl_paths$results_figures, 'supplementary')
src_dir <- file.path(nihl_paths$work, 'figure_source_data')
qa_dir <- file.path(nihl_paths$work, 'figure_QA')
# Kept for the panel audit trail and for the figure-source writers below; the
# figure root in the submitted script was the same object.
root <- file.path(nihl_paths$work, 'figure_build')
for (d in c(fig_dir, sup_dir, src_dir, qa_dir, root)) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

# Restrained, colour-blind-conscious palette used consistently across figures.
blue <- '#2C6EAA'
orange <- '#D97706'
red <- '#B42318'
teal <- '#087F8C'
purple <- '#7A5195'
green <- '#3A7D44'
grey <- '#667085'
ink <- '#101828'
mid_grey <- '#98A2B3'
light_grey <- '#D0D5DD'
pale <- '#EAECF0'
very_pale <- '#F2F4F7'

theme_pub <- theme_minimal(base_size = 8.0, base_family = 'Arial') +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(linewidth = 0.25, colour = '#EAECF0'),
    axis.title = element_text(face = 'bold', colour = ink, size = 7.6),
    axis.text = element_text(colour = '#344054', size = 6.9),
    plot.title = element_text(face = 'bold', colour = ink, size = 8.7,
                              margin = margin(b = 2.0)),
    plot.subtitle = element_text(colour = grey, size = 6.7, lineheight = 0.96,
                                 margin = margin(b = 3.0)),
    strip.text = element_text(face = 'bold', colour = ink, size = 7.2),
    strip.background = element_rect(fill = very_pale, colour = NA),
    legend.title = element_text(face = 'bold', colour = ink, size = 6.8),
    legend.text = element_text(colour = '#344054', size = 6.6),
    legend.key.height = unit(3.2, 'mm'),
    legend.key.width = unit(4.2, 'mm'),
    legend.spacing.x = unit(1.5, 'mm'),
    legend.box.spacing = unit(1.0, 'mm'),
    plot.margin = margin(5, 6, 5, 6),
    plot.tag = element_text(face = 'bold', colour = ink, size = 10.0),
    plot.tag.position = 'topleft'
  )
theme_set(theme_pub)

# Figure export. PDF and PNG are always written, through R's cairo devices,
# which ship with R and need no additional system libraries. SVG and 600-dpi
# TIFF use svglite and ragg when those packages are installed; both are listed
# in env/environment.yml but are optional at run time, because they depend on
# systemfonts and textshaping, which fail to build on some systems. Set
# NIHL_FIGURE_FORMATS to control the set (default "pdf,png").
figure_formats <- strsplit(Sys.getenv('NIHL_FIGURE_FORMATS', 'pdf,png'), ',')[[1]]

has_pkg <- function(p) requireNamespace(p, quietly = TRUE)

export_figure <- function(p, name, width, height, dir = fig_dir) {
  formats <- figure_formats
  if ('svg' %in% formats && !has_pkg('svglite')) {
    warning('svglite is not installed; skipping SVG output for ', name, call. = FALSE)
    formats <- setdiff(formats, 'svg')
  }
  if ('tiff' %in% formats && !has_pkg('ragg')) {
    warning('ragg is not installed; skipping TIFF output for ', name, call. = FALSE)
    formats <- setdiff(formats, 'tiff')
  }
  if ('pdf' %in% formats) {
    ggsave(file.path(dir, paste0(name, '.pdf')), p, width = width, height = height,
           device = cairo_pdf, bg = 'white')
  }
  if ('png' %in% formats) {
    ggsave(file.path(dir, paste0(name, '.png')), p, width = width, height = height,
           device = 'png', type = 'cairo', dpi = 600, bg = 'white')
  }
  if ('svg' %in% formats) {
    ggsave(file.path(dir, paste0(name, '.svg')), p, width = width, height = height,
           device = svglite::svglite, bg = 'white')
  }
  if ('tiff' %in% formats) {
    ggsave(file.path(dir, paste0(name, '.tiff')), p, width = width, height = height,
           device = ragg::agg_tiff, dpi = 600, compression = 'lzw', bg = 'white')
  }
}

save_src <- function(x, figure, file) {
  d <- file.path(src_dir, figure)
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
  write.csv(x, file.path(d, file), row.names = FALSE, na = '')
}

tag_panel <- function(p, tag) p + labs(tag = tag)

clean_pw <- function(x, short = FALSE) {
  full <- c(
    HALLMARK_TNFA_SIGNALING_VIA_NFKB = paste0('TNF-NF-', '\u03ba', 'B signalling'),
    HALLMARK_INFLAMMATORY_RESPONSE = 'Inflammatory response',
    HALLMARK_OXIDATIVE_PHOSPHORYLATION = 'Oxidative phosphorylation',
    HALLMARK_INTERFERON_GAMMA_RESPONSE = paste0('Interferon-', '\u03b3', ' response'),
    HALLMARK_E2F_TARGETS = 'E2F targets',
    HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION = 'EMT-related programme'
  )
  compact <- c(
    HALLMARK_TNFA_SIGNALING_VIA_NFKB = paste0('TNF-NF-', '\u03ba', 'B'),
    HALLMARK_INFLAMMATORY_RESPONSE = 'Inflammation',
    HALLMARK_OXIDATIVE_PHOSPHORYLATION = 'Oxidative\nphosphorylation',
    HALLMARK_E2F_TARGETS = 'E2F targets'
  )
  map <- if (short) compact else full
  out <- unname(map[x])
  missing <- is.na(out)
  out[missing] <- tools::toTitleCase(tolower(gsub('_', ' ', sub('^HALLMARK_', '', x[missing]))))
  out
}

pretty_cell <- c(
  spiral_ganglion_neuron = 'Spiral ganglion neuron',
  schwann_glial = 'Schwann/glial',
  endothelial = 'Endothelial',
  fibrocyte = 'Fibrocyte',
  pericyte_smooth_muscle = 'Pericyte/smooth muscle',
  immune = 'Immune',
  intermediate_melanocyte = 'Intermediate/melanocyte',
  basal_cell = 'Basal cell',
  marginal_cell = 'Marginal cell'
)

short_cell <- c(
  spiral_ganglion_neuron = 'SG neuron',
  schwann_glial = 'Schwann/glial',
  endothelial = 'Endothelial',
  fibrocyte = 'Fibrocyte',
  pericyte_smooth_muscle = 'Pericyte/SMC',
  immune = 'Immune',
  intermediate_melanocyte = 'Intermed./mel.',
  basal_cell = 'Basal',
  marginal_cell = 'Marginal'
)

core4 <- c(
  'HALLMARK_TNFA_SIGNALING_VIA_NFKB',
  'HALLMARK_INFLAMMATORY_RESPONSE',
  'HALLMARK_OXIDATIVE_PHOSPHORYLATION',
  'HALLMARK_E2F_TARGETS'
)
programme_order <- clean_pw(core4)

audit <- data.frame(
  figure = character(), check = character(), expected = character(),
  observed = character(), pass = logical(), detail = character(),
  stringsAsFactors = FALSE
)
add_audit <- function(figure, check, expected, observed, pass, detail = '') {
  audit <<- bind_rows(audit, data.frame(
    figure = figure, check = check, expected = as.character(expected),
    observed = as.character(observed), pass = isTRUE(pass), detail = detail,
    stringsAsFactors = FALSE
  ))
  if (!isTRUE(pass)) stop(sprintf('%s: %s failed (expected %s; observed %s)',
                                  figure, check, expected, observed))
}

# -------------------------------------------------------------------------
# Figure 1. Study-aware design and claim boundary
# -------------------------------------------------------------------------
roles <- data.frame(
  x = c(1.42, 2.14, 2.86, 3.58), y = 0.80,
  Dataset = c('GSE8342', 'E-MTAB-16125', 'GSE168041', 'GSE107086'),
  Role = c('Strain-associated\nresponse', 'Temporal\ncharacterization',
           'Broad cell-class\nlocalization', 'Acute/GC\ncontext'),
  Unit = c('10 pooled arrays', '20 mice', '16 mouse libraries', '24 mice'),
  Colour = c(blue, orange, teal, purple), stringsAsFactors = FALSE
)

p1a <- ggplot(roles) +
  annotate('segment', x = 1.30, xend = 3.70, y = 0.52, yend = 0.52,
           colour = grey, linewidth = 0.55) +
  geom_segment(aes(x = x, xend = x, y = 0.65, yend = 0.55),
               colour = light_grey, linewidth = 0.45) +
  geom_point(aes(x = x, y = 0.52, fill = Colour), shape = 21,
             colour = 'white', stroke = 0.35, size = 2.6) +
  geom_label(aes(x = x, y = y, label = paste0(Dataset, '\n', Role), fill = Colour),
             colour = 'white', linewidth = 0, size = 2.25, lineheight = 0.88,
             label.padding = unit(1.1, 'mm'), label.r = unit(1.3, 'mm')) +
  geom_text(aes(x = x, y = 0.32, label = Unit), colour = grey, size = 2.03) +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0.50, 4.50), ylim = c(0.20, 1.02), clip = 'off') +
  labs(title = 'Each study answers one design-matched question',
       subtitle = 'Expression matrices remain separate; integration uses signed programmes',
       tag = 'A') +
  theme_void(base_family = 'Arial', base_size = 8) +
  theme(plot.title = element_text(face = 'bold', colour = ink, size = 8.8),
        plot.subtitle = element_text(colour = grey, size = 6.8),
        plot.tag = element_text(face = 'bold', colour = ink, size = 10),
        plot.tag.position = 'topleft', plot.margin = margin(3, 12, 14, 8))

framework <- data.frame(
  x = 1:6, y = 1,
  Step = c('Design\naudit', 'Outcome-independent\nfeature mapping',
           'Within-study\nmodels', 'Complete\nranks', 'Programme\ntests',
           'Mouse-level\nlocalization'), stringsAsFactors = FALSE
)
p1b <- ggplot(framework) +
  annotate('segment', x = 0.78, xend = 6.40, y = 1, yend = 1,
           colour = grey, linewidth = 0.52,
           arrow = arrow(length = unit(1.8, 'mm'), type = 'open')) +
  geom_label(aes(x = x, y = y, label = Step), fill = 'white', colour = ink,
             linewidth = 0.38, size = 2.18, lineheight = 0.91,
             label.padding = unit(1.2, 'mm'), label.r = unit(1.2, 'mm')) +
  coord_cartesian(xlim = c(0.58, 6.58), ylim = c(0.72, 1.28), clip = 'off') +
  labs(title = 'Final analysis framework', tag = 'B') +
  theme_void(base_family = 'Arial', base_size = 8) +
  theme(plot.title = element_text(face = 'bold', colour = ink, size = 8.8),
        plot.tag = element_text(face = 'bold', colour = ink, size = 10),
        plot.tag.position = 'topleft', plot.margin = margin(5, 12, 9, 8))

claim <- data.frame(
  x = c(1, 2, 3), y = 1,
  Level = c('Supported', 'Qualified', 'Not claimed'),
  Text = c('Programme direction\nBroad cell-class localization',
           'Resilience-associated\nPersistence-linked',
           'Causality\nValidated biomarkers'),
  Fill = c(green, orange, grey), stringsAsFactors = FALSE
)
p1c <- ggplot(claim) +
  geom_tile(aes(x = x, y = y, fill = Fill), width = 0.76, height = 0.54) +
  geom_text(aes(x = x, y = y, label = Text), colour = 'white', fontface = 'bold',
            size = 2.28, lineheight = 0.92) +
  geom_text(aes(x = x, y = 0.62, label = Level), colour = '#344054', size = 2.10) +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0.50, 3.50), ylim = c(0.48, 1.34), clip = 'off') +
  labs(title = 'Claim boundary for the final analysis', tag = 'C') +
  theme_void(base_family = 'Arial', base_size = 8) +
  theme(plot.title = element_text(face = 'bold', colour = ink, size = 8.8),
        plot.tag = element_text(face = 'bold', colour = ink, size = 10),
        plot.tag.position = 'topleft', plot.margin = margin(4, 12, 4, 8))

fig1 <- p1a / p1b / p1c + plot_layout(heights = c(1.15, 0.82, 0.96))
export_figure(fig1, 'Figure_1', 7.2, 5.55)
save_src(roles, 'Figure_1', 'dataset_roles.csv')
save_src(framework, 'Figure_1', 'final_analysis_framework.csv')
save_src(claim, 'Figure_1', 'claim_boundary.csv')

# -------------------------------------------------------------------------
# Figure 2. Strain-associated resilience programmes
# -------------------------------------------------------------------------
pc <- read.csv(file.path(analysis_root, 'source_data', 'GSE8342', 'pca_coordinates.csv'))
p2a <- ggplot(pc, aes(PC1, PC2, colour = strain, shape = exposure)) +
  geom_point(size = 2.7, stroke = 0.75) +
  scale_colour_manual(values = c('129X1/SvJ' = blue, 'B6.CAST' = orange), drop = TRUE) +
  scale_shape_manual(values = c(sham = 16, noise = 17),
                     labels = c(sham = 'Sham', noise = 'Noise'), drop = TRUE) +
  labs(title = 'Independent pooled arrays',
       subtitle = 'Each point represents one pool of eight mice',
       colour = 'Strain', shape = 'Exposure', tag = 'A') +
  guides(colour = guide_legend(nrow = 1, order = 1),
         shape = guide_legend(nrow = 1, order = 2)) +
  theme(legend.position = 'bottom', legend.box = 'horizontal',
        legend.margin = margin(t = -2), plot.margin = margin(5, 8, 4, 6))

genes <- read.csv(gzfile(file.path(
  analysis_root, 'results', 'GSE8342',
  'representative_probe__strain_by_noise_interaction.csv.gz'
)))
gene_evidence <- read.csv(file.path(
  analysis_root, 'tables', 'Table_S4_GSE8342_resilience_gene_evidence.csv'
)) %>%
  select(representative_probe, tier2_effect_screen_pre_external_support,
         probe_strategy_direction_agreement)
genes <- genes %>%
  left_join(gene_evidence, by = c('probe_id' = 'representative_probe')) %>%
  mutate(screen = tier2_effect_screen_pre_external_support %in% TRUE,
         point_class = ifelse(screen, 'Primary exploratory screen', 'Other'))
n_screen <- sum(genes$screen, na.rm = TRUE)
formal_summary <- read.csv(file.path(
  analysis_root, 'results', 'GSE8342', 'formal_summary.csv'
))
expected_screen <- formal_summary$value[
  formal_summary$metric == 'tier2_effect_screen_pre_external_support'
]
add_audit('Figure 2B', 'Primary exploratory screen count', expected_screen,
          n_screen, identical(as.integer(n_screen), as.integer(expected_screen)),
          'Colour flag is joined from the formal gene-evidence table.')
labs2 <- genes %>%
  filter(screen, !is.na(gene_symbol), nzchar(gene_symbol)) %>%
  group_by(gene_symbol) %>% slice_min(PValue, n = 1, with_ties = FALSE) %>%
  ungroup() %>% arrange(PValue) %>% slice_head(n = 6)

p2b <- ggplot(genes, aes(logFC, -log10(pmax(PValue, 1e-300)), colour = point_class)) +
  geom_point(size = 0.58, alpha = 0.62) +
  geom_vline(xintercept = c(-0.5, 0.5), linetype = 2, colour = mid_grey,
             linewidth = 0.35) +
  geom_hline(yintercept = 1, linetype = 2, colour = mid_grey, linewidth = 0.35) +
  geom_text_repel(data = labs2, aes(label = gene_symbol), size = 2.05,
                  max.overlaps = Inf, box.padding = 0.48, point.padding = 0.18,
                  force = 2.0, min.segment.length = 0,
                  show.legend = FALSE, seed = 20260713) +
  scale_colour_manual(values = c('Other' = light_grey,
                                 'Primary exploratory screen' = orange),
                      breaks = c('Primary exploratory screen', 'Other'), drop = TRUE) +
  labs(title = 'Exploratory strain-by-noise interaction',
       subtitle = sprintf('%s genes in the primary screen; none reached FDR < 0.10',
                          comma(n_screen)),
       x = 'Interaction log2 fold-change', y = expression(-log[10](P)),
       colour = NULL, tag = 'B') +
  guides(colour = guide_legend(nrow = 1, override.aes = list(size = 2, alpha = 1))) +
  theme(legend.position = 'bottom', legend.margin = margin(t = -2),
        plot.margin = margin(5, 6, 4, 8))

ev <- read.csv(file.path(
  analysis_root, 'tables', 'Table_2_standard_cross_method_programme_evidence.csv'
))
e2 <- ev %>% filter(pathway %in% core4) %>%
  mutate(Programme = clean_pw(pathway),
         Programme = factor(Programme, levels = rev(programme_order)))
p2c_data <- e2 %>%
  select(Programme,
         `CAMERA-PR t` = camera_score_GSE8342_resilience,
         `Permutation GSEA NES` = gsea_NES_GSE8342_resilience) %>%
  pivot_longer(-Programme, names_to = 'Method', values_to = 'Score') %>%
  mutate(Direction = factor(ifelse(Score >= 0, 'Positive', 'Negative'),
                            levels = c('Negative', 'Positive')),
         Method = factor(Method, levels = c('CAMERA-PR t', 'Permutation GSEA NES')))
p2c <- ggplot(p2c_data, aes(Score, Programme, colour = Direction)) +
  geom_vline(xintercept = 0, colour = mid_grey, linewidth = 0.35) +
  geom_segment(aes(x = 0, xend = Score, yend = Programme), linewidth = 0.65) +
  geom_point(size = 2.3) +
  facet_wrap(~Method, scales = 'free_x', nrow = 1) +
  scale_colour_manual(values = c(Negative = blue, Positive = red), drop = TRUE) +
  labs(title = 'Cross-method resilience direction',
       subtitle = 'Facet-specific statistics are shown on separate scales; only direction is compared',
       x = 'Method-specific signed statistic', y = NULL, colour = 'Direction', tag = 'C') +
  guides(colour = guide_legend(nrow = 1)) +
  theme(legend.position = 'bottom', panel.grid.major.y = element_blank(),
        plot.margin = margin(5, 6, 4, 6))

fig2 <- (p2a | p2b) / p2c +
  plot_layout(heights = c(1.02, 0.94), widths = c(1.03, 0.97))
export_figure(fig2, 'Figure_2', 7.2, 6.45)
save_src(pc, 'Figure_2', 'PCA.csv')
save_src(genes, 'Figure_2', 'interaction_volcano_complete.csv')
save_src(e2, 'Figure_2', 'programme_evidence.csv')
save_src(p2c_data, 'Figure_2', 'cross_method_signed_statistics.csv')

# -------------------------------------------------------------------------
# Figure 3. Temporal characterization
# -------------------------------------------------------------------------
epc <- read.csv(file.path(
  analysis_root, 'results', 'E-MTAB-16125', 'E-MTAB-16125__pca.csv'
))
emeta <- read.csv(file.path(
  analysis_root, 'results', 'E-MTAB-16125', 'sample_metadata.csv'
))
epc <- merge(epc, emeta[, c('sample_id', 'group', 'sex')], by = 'sample_id')
epc$group <- factor(epc$group, levels = c('control', 'h24', 'h72', 'week1'))
p3a <- ggplot(epc, aes(PC1, PC2, colour = group, shape = sex)) +
  geom_point(size = 2.7, stroke = 0.75) +
  scale_colour_manual(values = c(control = grey, h24 = orange, h72 = red,
                                 week1 = purple),
                      labels = c(control = 'Control', h24 = '24 h', h72 = '72 h',
                                 week1 = '1 week'), drop = TRUE) +
  scale_shape_manual(values = c(female = 16, male = 17),
                     labels = c(female = 'Female', male = 'Male'), drop = TRUE) +
  labs(title = 'Individual-mouse time course',
       subtitle = 'n = 5 per time point; sex included in the model',
       colour = 'Time', shape = 'Sex', tag = 'A') +
  guides(colour = guide_legend(nrow = 1, order = 1),
         shape = guide_legend(nrow = 1, order = 2)) +
  theme(legend.position = 'bottom', legend.box = 'horizontal',
        legend.margin = margin(t = -2), plot.margin = margin(5, 8, 4, 6))

temporal_summary <- read.csv(file.path(
  analysis_root, 'results', 'E-MTAB-16125', 'formal_temporal_summary.csv'
))
cls <- temporal_summary %>%
  filter(temporal_class %in% c('delayed', 'persistent_decrease',
                               'persistent_increase', 'reversal',
                               'transient_early', 'other'))
total <- sum(cls$n_genes)
other_n <- cls$n_genes[cls$temporal_class == 'other']
other_pct <- 100 * other_n / total
dynamic <- cls %>% filter(temporal_class != 'other') %>%
  mutate(Percent = 100 * n_genes / total,
         Label = recode(temporal_class,
                        delayed = 'Delayed',
                        persistent_decrease = 'Persistent decrease',
                        persistent_increase = 'Persistent increase',
                        reversal = 'Reversal',
                        transient_early = 'Transient early'))
p3b <- ggplot(dynamic, aes(Percent, reorder(Label, Percent), fill = temporal_class)) +
  geom_col(width = 0.65) +
  geom_text(aes(label = sprintf('%s (%.1f%%)', comma(n_genes), Percent)),
            hjust = -0.08, size = 2.05, colour = ink) +
  scale_fill_manual(values = c(delayed = orange, persistent_decrease = blue,
                               persistent_increase = red, reversal = purple,
                               transient_early = teal), drop = TRUE) +
  scale_x_continuous(limits = c(0, max(dynamic$Percent) * 1.28),
                     expand = expansion(mult = c(0, 0.02))) +
  guides(fill = 'none') +
  labs(title = 'Operational temporal classes',
       subtitle = sprintf('Not shown: Other, %s genes (%.1f%%)', comma(other_n), other_pct),
       x = 'Genes (%)', y = NULL, tag = 'B') +
  theme(panel.grid.major.y = element_blank(), plot.margin = margin(5, 6, 4, 8))

timecam <- read.csv(file.path(
  analysis_root, 'results', 'standard_pathway_reanalysis',
  'CAMERA_PR_EMTAB_timepoints.csv'
)) %>%
  filter(pathway %in% core4) %>%
  mutate(Programme = clean_pw(pathway),
         Programme = factor(Programme, levels = rev(programme_order)),
         Time = factor(sub('EMTAB_', '', analysis),
                       levels = c('24h', '72h', '1week'),
                       labels = c('24 h', '72 h', '1 week')),
         score = pmax(pmin(camera_t, 6), -6),
         mark = paste0(ifelse(Direction == 'Up', '\u2191', '\u2193'),
                       ifelse(FDR < 0.10, '*', '')))
add_audit('Figure 3C', 'Time-programme cells', 12, nrow(timecam), nrow(timecam) == 12)
add_audit('Figure 3C', 'FDR < 0.10 marks', 7, sum(timecam$FDR < 0.10),
          sum(timecam$FDR < 0.10) == 7)
p3c <- ggplot(timecam, aes(Time, Programme, fill = score)) +
  geom_tile(colour = 'white', linewidth = 0.8) +
  geom_text(aes(label = mark), size = 2.55, colour = ink) +
  scale_fill_gradient2(low = blue, mid = 'white', high = red, limits = c(-6, 6),
                       name = 'CAMERA-PR t',
                       guide = guide_colourbar(direction = 'horizontal',
                                               barwidth = unit(28, 'mm'),
                                               barheight = unit(2.4, 'mm'))) +
  labs(title = 'Time-resolved programme directions',
       subtitle = 'Arrows show direction; * FDR < 0.10', x = NULL, y = NULL,
       tag = 'C') +
  theme(panel.grid = element_blank(), legend.position = 'bottom',
        legend.title.position = 'top', plot.margin = margin(5, 10, 5, 6))

funnel_map <- c(
  effect_consistent_persistent = 'Effect-consistent\ntrajectory',
  strict_persistent = 'Strict operational\nrule',
  high_confidence_IUT = 'Corrected\nbidirectional IUT'
)
funnel <- temporal_summary %>%
  filter(temporal_class %in% names(funnel_map)) %>%
  mutate(Stage = unname(funnel_map[temporal_class]),
         y = match(temporal_class,
                   c('high_confidence_IUT', 'strict_persistent',
                     'effect_consistent_persistent')),
         Fill = c(effect_consistent_persistent = teal,
                  strict_persistent = orange,
                  high_confidence_IUT = grey)[temporal_class],
         Label = paste0(Stage, '\n', 'n = ', comma(n_genes)))
add_audit('Figure 3D', 'Persistence funnel counts', '1263/1/0',
          paste(funnel$n_genes[match(c('effect_consistent_persistent',
                                      'strict_persistent', 'high_confidence_IUT'),
                                    funnel$temporal_class)], collapse = '/'),
          identical(as.integer(funnel$n_genes[match(
            c('effect_consistent_persistent', 'strict_persistent', 'high_confidence_IUT'),
            funnel$temporal_class)]), c(1263L, 1L, 0L)))
p3d <- ggplot(funnel) +
  annotate('segment', x = 1, xend = 1, y = 2.72, yend = 2.28,
           colour = mid_grey, linewidth = 0.45,
           arrow = arrow(length = unit(1.5, 'mm'), type = 'open')) +
  annotate('segment', x = 1, xend = 1, y = 1.72, yend = 1.28,
           colour = mid_grey, linewidth = 0.45,
           arrow = arrow(length = unit(1.5, 'mm'), type = 'open')) +
  geom_label(aes(x = 1, y = y, label = Label, fill = Fill),
             colour = 'white', fontface = 'bold', size = 2.15,
             lineheight = 0.92, linewidth = 0,
             label.padding = unit(1.4, 'mm'), label.r = unit(1.1, 'mm')) +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0.45, 1.55), ylim = c(0.62, 3.38), clip = 'off') +
  labs(title = 'Gene-level persistence funnel', tag = 'D') +
  theme_void(base_family = 'Arial', base_size = 8) +
  theme(plot.title = element_text(face = 'bold', colour = ink, size = 8.7),
        plot.tag = element_text(face = 'bold', colour = ink, size = 10),
        plot.tag.position = 'topleft', plot.margin = margin(5, 6, 5, 10))

top3 <- p3a + p3b + plot_layout(widths = c(1.04, 0.96))
bottom3 <- p3c + p3d + plot_layout(widths = c(1.10, 0.90))
fig3 <- top3 / bottom3 + plot_layout(heights = c(1.02, 0.98))
export_figure(fig3, 'Figure_3', 7.2, 6.65)
save_src(epc, 'Figure_3', 'PCA_with_metadata.csv')
save_src(dynamic, 'Figure_3', 'dynamic_class_percentages.csv')
save_src(timecam, 'Figure_3', 'direct_timepoint_CAMERA.csv')
save_src(funnel, 'Figure_3', 'persistence_funnel.csv')

# -------------------------------------------------------------------------
# Figure 4. Cross-study programme integration
# -------------------------------------------------------------------------
plot4 <- e2 %>%
  transmute(pathway, Programme = as.character(Programme),
            Resilience = camera_score_GSE8342_resilience,
            Temporal = camera_score_consistency_weighted_mean_t,
            Temporal_class = ifelse(pathway == 'HALLMARK_OXIDATIVE_PHOSPHORYLATION',
                                    'Persistence-linked', 'Time-varying'))
p4a <- ggplot(plot4, aes(Resilience, Temporal, label = Programme,
                         colour = Temporal_class)) +
  geom_hline(yintercept = 0, colour = mid_grey, linewidth = 0.35) +
  geom_vline(xintercept = 0, colour = mid_grey, linewidth = 0.35) +
  geom_point(size = 2.8) +
  geom_text_repel(size = 2.05, box.padding = 0.22, point.padding = 0.16,
                  force = 1.25, min.segment.length = 0, max.overlaps = Inf,
                  show.legend = FALSE, seed = 20260713) +
  scale_colour_manual(values = c('Persistence-linked' = green,
                                 'Time-varying' = orange), drop = TRUE) +
  scale_x_continuous(expand = expansion(mult = c(0.14, 0.20))) +
  scale_y_continuous(expand = expansion(mult = c(0.20, 0.18))) +
  labs(title = 'Distinct resilience and temporal axes',
       subtitle = 'Oxidative phosphorylation has opposite signs in the two contrasts',
       x = 'Resilience CAMERA-PR t', y = 'Composite temporal CAMERA-PR t',
       colour = NULL, tag = 'A') +
  guides(colour = guide_legend(nrow = 1)) +
  theme(legend.position = 'bottom', legend.margin = margin(t = -2),
        plot.margin = margin(5, 8, 5, 6))

method <- e2 %>%
  transmute(
    Programme = as.character(Programme),
    `CAMERA-PR` = ifelse(camera_score_GSE8342_resilience >= 0, 'Up', 'Down'),
    `Permutation GSEA` = ifelse(gsea_NES_GSE8342_resilience >= 0, 'Up', 'Down'),
    `Direct-time consistency` = ifelse(time_camera_same_direction,
                                       ifelse(time_camera_consensus == 'Down', 'Down', 'Up'),
                                       'Mixed')
  ) %>%
  pivot_longer(-Programme, names_to = 'Evidence', values_to = 'Category') %>%
  mutate(
    Programme = factor(Programme, levels = rev(programme_order)),
    Evidence = factor(Evidence,
                      levels = c('CAMERA-PR', 'Permutation GSEA',
                                 'Direct-time consistency'),
                      labels = c('CAMERA-PR', 'Permutation\nGSEA',
                                 'Direct-time\nconsistency')),
    Category = factor(Category, levels = c('Down', 'Mixed', 'Up')),
    Symbol = recode(as.character(Category), Down = '\u2193', Mixed = '\u2195', Up = '\u2191')
  )
p4b <- ggplot(method, aes(Evidence, Programme, fill = Category)) +
  geom_tile(colour = 'white', linewidth = 0.8) +
  geom_text(aes(label = Symbol), colour = ink, size = 2.55) +
  scale_fill_manual(values = c(Down = '#BFD7EA', Mixed = very_pale, Up = '#F4B8B2'),
                    drop = TRUE) +
  labs(title = 'Direction and direct-time consistency', x = NULL, y = NULL,
       fill = NULL, tag = 'B') +
  guides(fill = guide_legend(nrow = 1)) +
  theme(panel.grid = element_blank(), legend.position = 'bottom',
        axis.text.x = element_text(size = 6.3, lineheight = 0.92),
        plot.margin = margin(5, 6, 5, 8))

grid_data <- read.csv(file.path(
  analysis_root, 'results', 'standard_pathway_reanalysis',
  'expression_variance_matched_permutation_50000_grid.csv'
)) %>%
  mutate(P_group = factor(P_threshold, levels = c(0.05, 0.10),
                          labels = c('P < 0.05', 'P < 0.10')),
         Primary = P_threshold == 0.10 & abs_logFC_threshold == 0.50,
         FDR_status = ifelse(empirical_P < 0.05, 'Empirical P < 0.05',
                             'Empirical P >= 0.05'))
p4c <- ggplot(grid_data,
              aes(abs_logFC_threshold, empirical_P, colour = P_group, group = P_group)) +
  geom_hline(yintercept = 0.05, linetype = 2, colour = mid_grey, linewidth = 0.35) +
  geom_line(linewidth = 0.65) +
  geom_point(aes(shape = Primary), size = 2.5, stroke = 0.8) +
  geom_text(data = filter(grid_data, Primary), aes(label = sprintf('  %.3f', empirical_P)),
            hjust = 0, vjust = -0.55, colour = ink, size = 2.0,
            show.legend = FALSE) +
  scale_colour_manual(values = c('P < 0.05' = teal, 'P < 0.10' = orange), drop = TRUE) +
  scale_shape_manual(values = c(`FALSE` = 1, `TRUE` = 16),
                     labels = c(`FALSE` = 'Other threshold', `TRUE` = 'Primary threshold'),
                     drop = TRUE) +
  scale_x_continuous(breaks = c(0.25, 0.50, 0.75)) +
  scale_y_continuous(limits = c(0, 0.10), breaks = c(0, 0.025, 0.05, 0.075, 0.10)) +
  labs(title = 'Matched overlap is threshold-sensitive',
       subtitle = 'Filled point: primary P < 0.10 and |log2FC| > 0.50 screen',
       x = 'Minimum |interaction log2FC|', y = 'Empirical P (50,000 draws)',
       colour = 'Candidate P rule', shape = NULL, tag = 'C') +
  guides(colour = guide_legend(nrow = 1, order = 1),
         shape = guide_legend(nrow = 1, order = 2)) +
  theme(legend.position = 'bottom', legend.box = 'vertical',
        plot.margin = margin(5, 8, 5, 6))

timecam4 <- timecam %>%
  mutate(Significant = factor(FDR < 0.10, levels = c(FALSE, TRUE),
                              labels = c('No', 'Yes')),
         Evidence = -log10(pmax(FDR, 1e-5)))
p4d <- ggplot(timecam4, aes(Time, Programme)) +
  geom_line(aes(group = Programme), colour = light_grey, linewidth = 0.45) +
  geom_point(aes(size = Evidence, fill = score, colour = Significant),
             shape = 21, stroke = 0.9) +
  scale_fill_gradient2(low = blue, mid = 'white', high = red, limits = c(-6, 6),
                       name = 'CAMERA-PR t',
                       guide = guide_colourbar(direction = 'horizontal',
                                               barwidth = unit(24, 'mm'),
                                               barheight = unit(2.4, 'mm'), order = 1)) +
  scale_colour_manual(values = c(No = light_grey, Yes = ink), guide = 'none', drop = TRUE) +
  scale_size_continuous(range = c(1.7, 4.7), breaks = c(1, 2, 3),
                        limits = c(0, 3.05), name = expression(-log[10]('FDR')),
                        guide = guide_legend(nrow = 1, order = 2)) +
  labs(title = 'Direct-time competitive support',
       subtitle = 'Black outline: FDR < 0.10', x = NULL, y = NULL, tag = 'D') +
  theme(legend.position = 'bottom', legend.box = 'vertical',
        legend.direction = 'horizontal',
        panel.grid.major.y = element_blank(), plot.margin = margin(5, 6, 5, 8))
add_audit('Figure 4D', 'Black-outlined FDR < 0.10 points', 7,
          sum(timecam4$Significant == 'Yes'), sum(timecam4$Significant == 'Yes') == 7)

top4 <- p4a + p4b + plot_layout(widths = c(1.05, 0.95))
bottom4 <- p4c + p4d + plot_layout(widths = c(0.92, 1.08))
fig4 <- top4 / bottom4 + plot_layout(heights = c(0.98, 1.02))
export_figure(fig4, 'Figure_4', 7.2, 6.65)
save_src(plot4, 'Figure_4', 'programme_axes.csv')
save_src(method, 'Figure_4', 'direction_consistency.csv')
save_src(grid_data, 'Figure_4', 'threshold_grid.csv')
save_src(timecam4, 'Figure_4', 'direct_timepoint_CAMERA_for_panel_D.csv')

# -------------------------------------------------------------------------
# Figure 5. Broad cell-class localization
# -------------------------------------------------------------------------
marker_def <- data.frame(
  cell_type = rep(names(pretty_cell), each = 3),
  marker_gene = c(
    'Nefh', 'Nefl', 'Snap25', 'Mpz', 'Plp1', 'Sox10',
    'Pecam1', 'Cdh5', 'Emcn', 'Col1a1', 'Dcn', 'Lum',
    'Rgs5', 'Pdgfrb', 'Cspg4', 'Ptprc', 'Tyrobp', 'Cd74',
    'Dct', 'Mitf', 'Slc45a2', 'Cldn11', 'Gjb2', 'Krt18',
    'Kcne1', 'Kcnq1', 'Atp1b1'
  ), stringsAsFactors = FALSE
) %>% group_by(cell_type) %>% mutate(slot = row_number()) %>% ungroup()
marker_raw <- read.csv(file.path(
  analysis_root, 'source_data', 'cell_annotation_sensitivity',
  'marker_dotplot_sample_level.csv'
))
markers <- marker_raw %>%
  inner_join(marker_def, by = c('assigned_cell_type' = 'cell_type', 'marker_gene')) %>%
  group_by(assigned_cell_type, marker_gene, slot) %>%
  summarise(mean_expression = median(mean_log_normalized),
            percent_expressing = median(percent_expressing), .groups = 'drop') %>%
  mutate(Cell = unname(pretty_cell[assigned_cell_type]),
         y = match(assigned_cell_type, rev(names(pretty_cell))),
         x = c(1.0, 2.55, 4.10)[slot],
         Marker_label = paste0(marker_gene, '\n', round(percent_expressing), '%'),
         designated_positive_pair = TRUE)
add_audit('Figure 5A', 'Designated positive marker pairs', 27, nrow(markers),
          nrow(markers) == 27,
          'The panel is a three-slot list, not an incomplete class-by-gene matrix.')
p5a <- ggplot(markers, aes(x, y)) +
  annotate('rect', xmin = c(0.72, 2.27, 3.82), xmax = c(2.18, 3.73, 5.28),
           ymin = 0.5, ymax = 9.5, fill = c('#F8FAFC', 'white', '#F8FAFC'),
           colour = NA) +
  geom_point(aes(colour = mean_expression), size = 2.65) +
  geom_text(aes(x = x + 0.16, label = Marker_label), hjust = 0, size = 1.75,
            lineheight = 0.88, colour = ink, family = 'Arial') +
  scale_y_continuous(breaks = 1:9, labels = unname(rev(pretty_cell)),
                     limits = c(0.5, 9.5), expand = c(0, 0)) +
  scale_x_continuous(limits = c(0.70, 5.42), breaks = NULL, expand = c(0, 0)) +
  scale_colour_viridis_c(option = 'C', limits = c(0, 5), oob = squish,
                         name = 'Median expression',
                         guide = guide_colourbar(direction = 'horizontal',
                                                 barwidth = unit(28, 'mm'),
                                                 barheight = unit(2.4, 'mm'))) +
  labs(title = 'Canonical markers support broad annotations',
       subtitle = 'Designated positive pairs; labels show median % expressing',
       x = NULL, y = NULL, tag = 'A') +
  theme(panel.grid = element_blank(), legend.position = 'bottom',
        legend.title.position = 'top', axis.text.y = element_text(size = 6.2),
        plot.margin = margin(5, 8, 5, 6))

primary13 <- read.csv(file.path(
  revision_input, 'analysis_results', 'primary_13_cell_class_combinations.csv'
))
counts <- read.csv(file.path(
  analysis_root, 'source_data', 'GSE168041_celltype',
  'cell_counts_and_library_sizes.csv'
)) %>%
  mutate(key = paste(tissue_cohort, cell_type, sep = '__')) %>%
  filter(key %in% primary13$key) %>%
  group_by(tissue_cohort, cell_type) %>%
  summarise(cells = sum(n_cells), .groups = 'drop') %>%
  left_join(primary13 %>% select(tissue_cohort, cell_type, n_naive_eligible,
                                n_noise_eligible),
            by = c('tissue_cohort', 'cell_type')) %>%
  mutate(Cohort = ifelse(tissue_cohort == 'lateral_wall_focused',
                         'Lateral-wall-focused', 'Neuronal-focused'),
         Cell = unname(short_cell[cell_type]),
         Label = paste0(Cell, '  '),
         cells_label = comma(cells))
counts <- counts %>% group_by(Cohort) %>%
  mutate(Cell_order = factor(Cell, levels = rev(Cell[order(cells)]))) %>% ungroup()
lw_count_cells <- unname(short_cell[c(
  'intermediate_melanocyte', 'marginal_cell', 'basal_cell', 'endothelial',
  'fibrocyte', 'immune', 'pericyte_smooth_muscle'
)])
n_count_cells <- unname(short_cell[c(
  'spiral_ganglion_neuron', 'schwann_glial', 'endothelial', 'fibrocyte',
  'immune', 'pericyte_smooth_muscle'
)])
count_order_top <- c(paste0('LW | ', lw_count_cells),
                     paste0('N | ', n_count_cells))
counts <- counts %>%
  mutate(DisplayCell = paste0(ifelse(tissue_cohort == 'lateral_wall_focused',
                                     'LW | ', 'N | '), Cell),
         DisplayCell = factor(DisplayCell, levels = rev(count_order_top)))
add_audit('Figure 5B', 'Primary cohort-class combinations', 13, nrow(counts),
          nrow(counts) == 13)
p5b <- ggplot(counts, aes(cells, DisplayCell, colour = Cohort)) +
  geom_hline(yintercept = 6.5, colour = mid_grey, linewidth = 0.4) +
  geom_point(size = 2.25) +
  geom_text(aes(label = cells_label), hjust = -0.18, size = 1.85, colour = ink) +
  scale_x_log10(labels = label_number(big.mark = ','),
                expand = expansion(mult = c(0.04, 0.28))) +
  scale_colour_manual(values = c('Lateral-wall-focused' = teal,
                                 'Neuronal-focused' = purple), guide = 'none') +
  labs(title = 'Eligible cell-class coverage',
       subtitle = 'Total cells; >=3 mouse libraries per group',
       x = 'Total cells (log scale)', y = NULL, tag = 'B') +
  theme(panel.grid.major.y = element_blank(),
        axis.text.y = element_text(size = 6.0), plot.margin = margin(5, 6, 5, 8))

camcell <- read.csv(file.path(
  analysis_root, 'results', 'standard_pathway_reanalysis',
  'CAMERA_PR_cellclass_within_and_global_FDR.csv'
))
# The stability flags come from the seven-programme ledger built by
# 09_stability_ledger.R. Figure 5C shows the four programmes of the main panel,
# so the extra three programmes are simply not plotted here.
ledger <- read.csv(file.path(
  analysis_root, 'results', 'cell_annotation_sensitivity',
  'Table_S7_seven_programme_direction_stability_ledger.csv'
))
heat <- primary13 %>%
  select(tissue_cohort, cell_type) %>%
  crossing(pathway = core4) %>%
  mutate(celltype_analysis = paste(tissue_cohort, cell_type, sep = '_')) %>%
  left_join(camcell, by = c('pathway', 'celltype_analysis')) %>%
  left_join(ledger %>% select(pathway, tissue_cohort, cell_type, stable),
            by = c('pathway', 'tissue_cohort', 'cell_type')) %>%
  mutate(Programme = factor(clean_pw(pathway, short = TRUE),
                            levels = clean_pw(core4, short = TRUE)),
         Cohort = factor(ifelse(tissue_cohort == 'lateral_wall_focused',
                                'Lateral-wall-focused', 'Neuronal-focused'),
                         levels = c('Lateral-wall-focused', 'Neuronal-focused')),
         Cell = unname(short_cell[cell_type]),
         Displayed = !is.na(global_FDR) & global_FDR < 0.10 & stable %in% TRUE,
         score = pmax(pmin(camera_t, 7), -7))
lw_heat_cells <- unname(short_cell[c(
  'pericyte_smooth_muscle', 'marginal_cell', 'intermediate_melanocyte',
  'immune', 'fibrocyte', 'endothelial', 'basal_cell'
)])
n_heat_cells <- unname(short_cell[c(
  'spiral_ganglion_neuron', 'schwann_glial', 'pericyte_smooth_muscle',
  'immune', 'fibrocyte', 'endothelial'
)])
heat_order_top <- c(paste0('LW | ', lw_heat_cells),
                    paste0('N | ', n_heat_cells))
heat <- heat %>%
  mutate(DisplayCell = paste0(ifelse(tissue_cohort == 'lateral_wall_focused',
                                     'LW | ', 'N | '), Cell),
         DisplayCell = factor(DisplayCell, levels = rev(heat_order_top)))
add_audit('Figure 5C', 'Complete primary grid', 52, nrow(heat), nrow(heat) == 52)
add_audit('Figure 5C', 'Stable global-FDR associations', 26, sum(heat$Displayed),
          sum(heat$Displayed) == 26)
p5c <- ggplot(heat, aes(Programme, DisplayCell)) +
  geom_tile(fill = very_pale, colour = 'white', linewidth = 0.75) +
  geom_tile(data = filter(heat, Displayed), aes(fill = score),
            colour = 'white', linewidth = 0.75) +
  geom_hline(yintercept = 6.5, colour = mid_grey, linewidth = 0.5) +
  scale_fill_gradient2(low = blue, mid = 'white', high = red, limits = c(-7, 7),
                       name = 'CAMERA-PR t',
                       guide = guide_colourbar(direction = 'horizontal',
                                               barwidth = unit(30, 'mm'),
                                               barheight = unit(2.5, 'mm'))) +
  labs(title = 'Stable programme associations across broad classes',
       subtitle = 'Colour: stable, global FDR < 0.10; grey: other tested cells',
       x = NULL, y = NULL, tag = 'C') +
  theme(panel.grid = element_blank(), legend.position = 'bottom',
        legend.title.position = 'top',
        axis.text.x = element_text(size = 6.1, lineheight = 0.90),
        axis.text.y = element_text(size = 6.1), plot.margin = margin(5, 8, 5, 6))

stability <- data.frame(
  Status = c('Stable', 'Changed'),
  Combinations = c(sum(ledger$stable), sum(!ledger$stable)),
  stringsAsFactors = FALSE
)
total_stability <- sum(stability$Combinations)
stable_n <- stability$Combinations[stability$Status == 'Stable']
p5d <- ggplot() +
  annotate('text', x = 0.5, y = 1.30,
           label = sprintf('%.1f%%', 100 * stable_n / total_stability),
           colour = green, fontface = 'bold', size = 6.0) +
  annotate('rect', xmin = 0.08, xmax = 0.08 + 0.84 * stable_n / total_stability,
           ymin = 0.88, ymax = 0.98, fill = green) +
  annotate('rect', xmin = 0.08 + 0.84 * stable_n / total_stability, xmax = 0.92,
           ymin = 0.88, ymax = 0.98, fill = orange) +
  annotate('text', x = 0.5, y = 0.64,
           label = sprintf('%d/%d directions\nstable', stable_n, total_stability),
           colour = ink, size = 2.2, lineheight = 0.95) +
  annotate('text', x = 0.5, y = 0.35,
           label = sprintf('%d changed', total_stability - stable_n),
           colour = orange, fontface = 'bold', size = 2.05) +
  coord_cartesian(xlim = c(0, 1), ylim = c(0.18, 1.48), clip = 'off') +
  labs(title = 'Stability audit', subtitle = '78 combinations', tag = 'D') +
  theme_void(base_family = 'Arial', base_size = 8) +
  theme(plot.title = element_text(face = 'bold', colour = ink, size = 8.7),
        plot.subtitle = element_text(colour = grey, size = 6.7),
        plot.tag = element_text(face = 'bold', colour = ink, size = 10),
        plot.tag.position = 'topleft', plot.margin = margin(5, 6, 5, 8))

top5 <- p5a + p5b + plot_layout(widths = c(1.12, 0.88))
bottom5 <- p5c + p5d + plot_layout(widths = c(1.55, 0.45))
fig5 <- top5 / bottom5 + plot_layout(heights = c(1.02, 1.18))
export_figure(fig5, 'Figure_5', 7.2, 7.55)
save_src(markers, 'Figure_5', 'designated_positive_marker_validation.csv')
save_src(counts, 'Figure_5', 'primary_cell_coverage.csv')
save_src(heat, 'Figure_5', 'complete_cell_programme_grid.csv')
save_src(stability, 'Figure_5', 'stability_counts.csv')

# -------------------------------------------------------------------------
# Supplementary Figure S1. Probe and threshold sensitivity
# -------------------------------------------------------------------------
sen <- read.csv(file.path(
  analysis_root, 'source_data', 'GSE8342', 'resilience_threshold_sensitivity.csv'
)) %>%
  mutate(P_rule = factor(interaction_P, levels = c(0.05, 0.10),
                         labels = c('P < 0.05', 'P < 0.10')),
         Primary = interaction_P == 0.10 & interaction_abs_logFC == 0.50)
primary_sen <- sen %>% filter(Primary)
agreement <- data.frame(
  Screened = primary_sen$n_gene_screen,
  Direction_preserved = primary_sen$n_probe_strategy_agree,
  Discordant = primary_sen$n_gene_screen - primary_sen$n_probe_strategy_agree
) %>%
  mutate(Percent = 100 * Direction_preserved / Screened)
add_audit('Figure S1', 'Primary screen/direction preserved', '627/611',
          paste(agreement$Screened, agreement$Direction_preserved, sep = '/'),
          agreement$Screened == 627 & agreement$Direction_preserved == 611)
s1a <- ggplot(sen, aes(interaction_abs_logFC, n_gene_screen,
                       colour = P_rule, group = P_rule)) +
  geom_line(linewidth = 0.7) + geom_point(size = 2.3) +
  geom_point(data = primary_sen, shape = 21, fill = 'white', colour = ink,
             stroke = 0.9, size = 3.0) +
  geom_text(data = primary_sen, aes(label = n_gene_screen), colour = ink,
            hjust = -0.45, vjust = -0.55, size = 2.05) +
  scale_colour_manual(values = c('P < 0.05' = teal, 'P < 0.10' = orange), drop = TRUE) +
  scale_x_continuous(breaks = c(0.25, 0.50, 0.75)) +
  labs(title = 'Effect-screen threshold grid',
       subtitle = 'Outlined point: primary threshold',
       x = 'Minimum |interaction log2FC|', y = 'Candidate genes',
       colour = 'P rule', tag = 'A') +
  guides(colour = guide_legend(nrow = 1)) +
  theme(legend.position = 'bottom', plot.margin = margin(5, 8, 5, 6))
s1b <- ggplot() +
  annotate('rect', xmin = 0, xmax = agreement$Screened, ymin = 0.78, ymax = 1.22,
           fill = light_grey) +
  annotate('rect', xmin = 0, xmax = agreement$Direction_preserved,
           ymin = 0.78, ymax = 1.22, fill = orange) +
  annotate('text', x = agreement$Direction_preserved / 2, y = 1.0,
           label = sprintf('%d/%d (%.1f%%)', agreement$Direction_preserved,
                           agreement$Screened, agreement$Percent),
           colour = 'white', fontface = 'bold', size = 2.45) +
  annotate('text', x = agreement$Screened / 2, y = 0.52,
           label = sprintf('%d genes changed probe-strategy direction', agreement$Discordant),
           colour = grey, size = 2.0) +
  coord_cartesian(xlim = c(0, agreement$Screened), ylim = c(0.36, 1.48), clip = 'off') +
  labs(title = 'Probe-selection agreement',
       subtitle = 'Primary exploratory screen', tag = 'B') +
  theme_void(base_family = 'Arial', base_size = 8) +
  theme(plot.title = element_text(face = 'bold', colour = ink, size = 8.7),
        plot.subtitle = element_text(colour = grey, size = 6.7),
        plot.tag = element_text(face = 'bold', colour = ink, size = 10),
        plot.tag.position = 'topleft', plot.margin = margin(5, 6, 5, 8))
s1 <- s1a + s1b + plot_layout(widths = c(1.15, 0.85))
export_figure(s1, 'Figure_S1', 7.2, 3.45, sup_dir)
save_src(sen, 'Supplementary_Figure_S1', 'threshold_grid.csv')
save_src(agreement, 'Supplementary_Figure_S1', 'probe_selection_direction_summary.csv')

# -------------------------------------------------------------------------
# Supplementary Figure S2. Persistence-rank and IUT sensitivity
# -------------------------------------------------------------------------
cam_supp <- read.csv(file.path(
  analysis_root, 'results', 'standard_pathway_reanalysis',
  'CAMERA_PR_bulk_and_persistence.csv'
))
rank_order <- c('consistency_weighted_mean_t', 'weakest_timepoint_t',
                'stouffer_signed_z', 'signed_rank_product')
rank_labels <- c('Weighted\nmean t', 'Weakest\ntime t', 'Stouffer\nz', 'Rank\nproduct')
rankcam <- cam_supp %>% filter(pathway %in% core4, analysis %in% rank_order) %>%
  mutate(Programme = factor(clean_pw(pathway), levels = rev(programme_order)),
         Rank = factor(analysis, levels = rank_order, labels = rank_labels))
s2a <- ggplot(rankcam, aes(Rank, Programme, fill = camera_t)) +
  geom_tile(colour = 'white', linewidth = 0.8) +
  scale_fill_gradient2(low = blue, mid = 'white', high = red,
                       name = 'CAMERA-PR t',
                       guide = guide_colourbar(direction = 'horizontal',
                                               barwidth = unit(28, 'mm'),
                                               barheight = unit(2.4, 'mm'))) +
  labs(title = 'Directions across four persistence ranks', x = NULL, y = NULL,
       tag = 'A') +
  theme(panel.grid = element_blank(), legend.position = 'bottom',
        axis.text.x = element_text(size = 6.3, lineheight = 0.90),
        plot.margin = margin(5, 10, 5, 6))
iut <- funnel %>%
  transmute(Test = factor(Stage,
                          levels = c('Corrected\nbidirectional IUT',
                                     'Strict operational\nrule',
                                     'Effect-consistent\ntrajectory')),
            Genes = n_genes,
            y = as.numeric(Test), Fill = Fill,
            Label = paste0(as.character(Test), '\n', 'n = ', comma(Genes)))
s2b <- ggplot(iut) +
  annotate('segment', x = 1, xend = 1, y = 2.72, yend = 2.28,
           colour = mid_grey, linewidth = 0.45,
           arrow = arrow(length = unit(1.5, 'mm'), type = 'open')) +
  annotate('segment', x = 1, xend = 1, y = 1.72, yend = 1.28,
           colour = mid_grey, linewidth = 0.45,
           arrow = arrow(length = unit(1.5, 'mm'), type = 'open')) +
  geom_label(aes(x = 1, y = y, label = Label, fill = Fill),
             colour = 'white', fontface = 'bold', size = 2.05,
             lineheight = 0.90, linewidth = 0,
             label.padding = unit(1.3, 'mm'), label.r = unit(1.1, 'mm')) +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0.45, 1.55), ylim = c(0.60, 3.40), clip = 'off') +
  labs(title = 'Persistence funnel reaches zero', tag = 'B') +
  theme_void(base_family = 'Arial', base_size = 8) +
  theme(plot.title = element_text(face = 'bold', colour = ink, size = 8.7),
        plot.tag = element_text(face = 'bold', colour = ink, size = 10),
        plot.tag.position = 'topleft', plot.margin = margin(5, 6, 5, 10))
s2 <- s2a + s2b + plot_layout(widths = c(1.24, 0.76))
export_figure(s2, 'Figure_S2', 7.2, 3.75, sup_dir)
save_src(rankcam, 'Supplementary_Figure_S2', 'persistence_rank_CAMERA.csv')
save_src(iut, 'Supplementary_Figure_S2', 'persistence_IUT_funnel.csv')

# -------------------------------------------------------------------------
# Supplementary Figure S3. Cell-definition sensitivity
# -------------------------------------------------------------------------
elig <- read.csv(file.path(
  analysis_root, 'source_data', 'GSE168041_celltype',
  'celltype_eligibility_thresholds.csv'
)) %>% group_by(min_cells) %>%
  summarise(eligible = sum(inferentially_eligible), .groups = 'drop') %>%
  mutate(Rule = ifelse(min_cells == 20, 'Primary', 'Sensitivity'))
assign <- read.csv(file.path(
  analysis_root, 'source_data', 'cell_annotation_sensitivity',
  'assigned_unassigned_sensitivity.csv'
)) %>%
  separate(definition, c('annotation_definition', 'assignment_status'), sep = '_') %>%
  mutate(annotation_definition = factor(annotation_definition,
                                        levels = c('primary', 'strict'),
                                        labels = c('Primary', 'Strict')))
assign_summary <- assign %>%
  filter(assignment_status == 'assigned') %>%
  transmute(annotation_definition, assigned_fraction = fraction,
            Label = sprintf('%.1f%% assigned', 100 * fraction))
add_audit('Figure S3A', 'Eligible contrasts at 10/20/30 cells', '14/13/13',
          paste(elig$eligible[match(c(10, 20, 30), elig$min_cells)], collapse = '/'),
          identical(as.integer(elig$eligible[match(c(10, 20, 30), elig$min_cells)]),
                    c(14L, 13L, 13L)))
s3a <- ggplot(elig, aes(factor(min_cells), eligible, fill = Rule)) +
  geom_col(width = 0.56) +
  geom_text(aes(label = eligible), vjust = -0.35, size = 2.35, colour = ink) +
  scale_fill_manual(values = c(Primary = orange, Sensitivity = teal), guide = 'none') +
  scale_y_continuous(limits = c(0, 15), breaks = c(0, 5, 10, 15),
                     expand = expansion(mult = c(0, 0.03))) +
  labs(title = 'Eligible cohort-by-class contrasts',
       subtitle = 'Orange: primary 20-cell definition',
       x = 'Minimum cells per mouse library', y = 'Eligible contrasts', tag = 'A') +
  theme(panel.grid.major.x = element_blank(), plot.margin = margin(5, 8, 5, 6))
s3b <- ggplot(assign_summary, aes(assigned_fraction, annotation_definition)) +
  geom_col(aes(x = 1), fill = light_grey, width = 0.55) +
  geom_col(fill = green, width = 0.55) +
  geom_text(aes(x = assigned_fraction - 0.018, label = Label), hjust = 1,
            size = 2.15, colour = 'white', fontface = 'bold') +
  scale_x_continuous(limits = c(0, 1.02), breaks = c(0, 0.5, 1), labels = percent) +
  labs(title = 'Assignment sensitivity',
       subtitle = 'Grey remainder: unassigned cells', x = 'Fraction of QC-passing cells',
       y = NULL, tag = 'B') +
  theme(panel.grid.major.y = element_blank(), plot.margin = margin(5, 6, 5, 8))
s3 <- s3a + s3b + plot_layout(widths = c(0.94, 1.06))
export_figure(s3, 'Figure_S3', 7.2, 3.45, sup_dir)
save_src(elig, 'Supplementary_Figure_S3', 'eligibility_by_minimum_cell_threshold.csv')
save_src(assign, 'Supplementary_Figure_S3', 'annotation_assignment_sensitivity.csv')
save_src(assign_summary, 'Supplementary_Figure_S3', 'assigned_fraction_plot_data.csv')

# -------------------------------------------------------------------------
# Supplementary Figure S4. Acute and glucocorticoid-context analyses
# -------------------------------------------------------------------------
gcp <- read.csv(file.path(
  analysis_root, 'results', 'GSE107086', 'formal_summary.csv'
)) %>%
  mutate(Type = ifelse(grepl('^GC_dependency', contrast),
                       'GC dependence', 'Acute noise effect'),
         Contrast = recode(contrast,
                           noise_day_ADX = 'Day, ADX',
                           noise_day_shamADX = 'Day, sham ADX',
                           noise_night_ADX = 'Night, ADX',
                           noise_night_shamADX = 'Night, sham ADX',
                           noise_average_ADX = 'Average, ADX',
                           noise_average_shamADX = 'Average, sham ADX',
                           GC_dependency_day = 'Day',
                           GC_dependency_night = 'Night',
                           GC_dependency_average = 'Average'),
         log_count = log10(n_FDR_0.10 + 1),
         Type = factor(Type, levels = c('Acute noise effect', 'GC dependence')))
gcp_order_top <- c('Noise | Day, ADX', 'Noise | Day, sham ADX',
                   'Noise | Night, ADX', 'Noise | Night, sham ADX',
                   'Noise | Average, ADX', 'Noise | Average, sham ADX',
                   'GC | Day', 'GC | Night', 'GC | Average')
gcp <- gcp %>%
  mutate(Display = paste0(ifelse(Type == 'Acute noise effect', 'Noise | ', 'GC | '),
                          Contrast),
         Display = factor(Display, levels = rev(gcp_order_top)))
add_audit('Figure S4', 'Zero GC-dependence contrasts', 3,
          sum(gcp$Type == 'GC dependence' & gcp$n_FDR_0.10 == 0),
          sum(gcp$Type == 'GC dependence' & gcp$n_FDR_0.10 == 0) == 3)
s4 <- ggplot(gcp, aes(log_count, Display, colour = Type)) +
  geom_hline(yintercept = 3.5, colour = mid_grey, linewidth = 0.4) +
  geom_segment(aes(x = 0, xend = log_count, yend = Display), linewidth = 0.75) +
  geom_point(size = 2.5) +
  geom_text(aes(label = n_FDR_0.10), hjust = -0.30, size = 2.15, colour = ink) +
  scale_colour_manual(values = c('Acute noise effect' = teal,
                                 'GC dependence' = orange), guide = 'none') +
  scale_x_continuous(limits = c(0, 3.55),
                     breaks = log10(c(1, 11, 101, 1001)),
                     labels = c('0', '10', '100', '1,000')) +
  labs(title = 'Acute noise responses, no detected GC-dependence signal',
       subtitle = 'Points remain visible when the FDR < 0.10 count is zero',
       x = 'Genes at FDR < 0.10 (log10[count + 1] scale)', y = NULL) +
  theme(panel.grid.major.y = element_blank(),
        plot.margin = margin(5, 8, 5, 8))
export_figure(s4, 'Figure_S4', 7.2, 4.05, sup_dir)
save_src(gcp, 'Supplementary_Figure_S4', 'glucocorticoid_context_summary.csv')

# -------------------------------------------------------------------------
# Supplementary Figure S5. Targeted resilience-persistence RRHO
# -------------------------------------------------------------------------
rr_complete <- read.csv(file.path(
  analysis_root, 'source_data', 'program_integration',
  'rank_rank_hypergeometric_grid.csv'
))
rr <- rr_complete %>%
  filter(analysis_a == 'GSE8342_resilience_interaction',
         analysis_b == 'EMTAB_persistence') %>%
  mutate(logFDR = -log10(pmax(FDR, 1e-300)),
         cut_a = factor(cut_a, levels = c(100, 250, 500, 1000)),
         cut_b = factor(cut_b, levels = c(100, 250, 500, 1000)),
         tail = factor(tail, levels = c('lower', 'upper'),
                       labels = c('Lower tail', 'Upper tail')))
add_audit('Figure S5', 'Unique plotted RRHO cells', 32,
          nrow(unique(rr[c('tail', 'cut_a', 'cut_b')])),
          nrow(rr) == 32 && nrow(unique(rr[c('tail', 'cut_a', 'cut_b')])) == 32,
          'Only the design-matched resilience-interaction versus persistence pair is plotted.')
s5 <- ggplot(rr, aes(cut_a, cut_b, fill = logFDR)) +
  geom_tile(colour = 'white', linewidth = 0.9) +
  facet_wrap(~tail, nrow = 1) +
  scale_fill_viridis_c(option = 'C', name = expression(-log[10]('FDR')),
                       guide = guide_colourbar(direction = 'horizontal',
                                               barwidth = unit(32, 'mm'),
                                               barheight = unit(2.6, 'mm'))) +
  coord_equal() +
  labs(title = 'No RRHO support for resilience-persistence rank overlap',
       subtitle = sprintf('Minimum FDR = %.3f; exploratory sensitivity only', min(rr$FDR)),
       x = 'Resilience rank cut', y = 'Persistence rank cut') +
  theme(panel.grid = element_blank(), legend.position = 'bottom',
        plot.margin = margin(5, 8, 5, 8))
export_figure(s5, 'Figure_S5', 7.2, 4.05, sup_dir)
save_src(rr, 'Supplementary_Figure_S5', 'resilience_persistence_RRHO_plot_data.csv')
save_src(rr_complete, 'Supplementary_Figure_S5', 'rank_rank_hypergeometric_grid_complete.csv')

# -------------------------------------------------------------------------
# Supplementary Figure S6. Exploratory Tier-B genes
# -------------------------------------------------------------------------
# The submitted pipeline wrote the evidence-graded gene table as
# Table_3_evidence_graded_genes.csv from the component parts of
# Table_S11_gene_evidence_ledger.csv. The ledger is the file that actually
# exists after a clean run, so it is the one read here; the columns needed for
# this panel are identical.
tierb_plot <- read.csv(file.path(
  analysis_root, 'tables', 'Table_S11_gene_evidence_ledger.csv'
)) %>%
  filter(evidence_tier == 'B_triangular_support') %>%
  transmute(Gene = gene_symbol,
            Interaction_log2FC = as.numeric(interaction_logFC),
            Mean_time_effect = (as.numeric(h24_logFC) + as.numeric(h72_logFC) +
                                  as.numeric(week1_logFC)) / 3,
            Temporal_class = factor(temporal_class,
                                    levels = c('persistent_decrease',
                                               'persistent_increase'),
                                    labels = c('Persistent decrease',
                                               'Persistent increase')),
            Interaction_FDR = as.numeric(interaction_FDR),
            Corrected_IUT_FDR = as.numeric(IUT_FDR))
add_audit('Figure S6', 'Labeled Tier-B genes', 8, nrow(tierb_plot),
          nrow(tierb_plot) == 8 & all(nzchar(tierb_plot$Gene)))
s6 <- ggplot(tierb_plot,
             aes(Interaction_log2FC, Mean_time_effect, label = Gene,
                 colour = Temporal_class)) +
  geom_hline(yintercept = 0, colour = mid_grey, linewidth = 0.35) +
  geom_vline(xintercept = 0, colour = mid_grey, linewidth = 0.35) +
  geom_point(size = 2.5) +
  geom_text_repel(size = 2.15, show.legend = FALSE, seed = 20260713,
                  max.overlaps = Inf, box.padding = 0.28, point.padding = 0.18,
                  min.segment.length = 0) +
  scale_colour_manual(values = c('Persistent decrease' = '#F97066',
                                 'Persistent increase' = '#06B6C1'), drop = TRUE) +
  scale_x_continuous(expand = expansion(mult = c(0.08, 0.12))) +
  scale_y_continuous(expand = expansion(mult = c(0.12, 0.12))) +
  labs(title = 'Tier-B genes remain hypothesis-generating',
       subtitle = 'n = 8; no gene passed interaction FDR or corrected persistence IUT',
       x = 'Interaction log2FC', y = 'Mean temporal log2FC',
       colour = 'Temporal class') +
  guides(colour = guide_legend(nrow = 1)) +
  theme(legend.position = 'bottom', plot.margin = margin(5, 8, 5, 8))
export_figure(s6, 'Figure_S6', 7.2, 4.05, sup_dir)
save_src(tierb_plot, 'Supplementary_Figure_S6',
         'exploratory_Tier_B_gene_plot_data.csv')

# -------------------------------------------------------------------------
# Supplementary Figure S7. Annotation confidence among assigned classes
# -------------------------------------------------------------------------
ann_complete <- read.csv(file.path(
  analysis_root, 'source_data', 'cell_annotation_sensitivity',
  'annotation_confidence_by_class.csv'
))
ann <- ann_complete %>%
  filter(cell_type != 'unassigned') %>%
  mutate(Cell = unname(pretty_cell[cell_type]),
         Percent_label = sprintf('%.1f%%', 100 * retained_strict_fraction))
add_audit('Figure S7', 'Assigned broad classes plotted', 9, nrow(ann),
          nrow(ann) == 9 && !any(ann$cell_type == 'unassigned'),
          'The definition-driven unassigned=100% row is retained only in complete source data.')
s7 <- ggplot(ann, aes(retained_strict_fraction,
                      reorder(Cell, retained_strict_fraction))) +
  geom_segment(aes(x = 0.85, xend = retained_strict_fraction,
                   yend = reorder(Cell, retained_strict_fraction)),
               colour = light_grey, linewidth = 0.65) +
  geom_point(aes(size = n_cells, colour = margin_median)) +
  geom_text(aes(x = retained_strict_fraction + 0.004, label = Percent_label),
            hjust = 0, size = 2.0, colour = ink) +
  scale_x_continuous(labels = percent, limits = c(0.85, 1.015),
                     breaks = c(0.85, 0.90, 0.95, 1.00)) +
  scale_size_continuous(range = c(1.8, 5.2), breaks = c(2500, 7500, 12500),
                        labels = label_number(big.mark = ','), name = 'Assigned cells') +
  scale_colour_viridis_c(option = 'C', name = 'Median score margin',
                         guide = guide_colourbar(direction = 'horizontal',
                                                 barwidth = unit(28, 'mm'),
                                                 barheight = unit(2.5, 'mm'))) +
  labs(title = 'Strict annotation retains 88-99% within assigned classes',
       x = 'Fraction retained under strict annotation', y = NULL) +
  guides(size = guide_legend(nrow = 1, order = 1),
         colour = guide_colourbar(direction = 'horizontal', order = 2,
                                  barwidth = unit(28, 'mm'),
                                  barheight = unit(2.5, 'mm'))) +
  theme(legend.position = 'bottom', legend.box = 'horizontal',
        panel.grid.major.y = element_blank(), plot.margin = margin(5, 12, 5, 8))
export_figure(s7, 'Figure_S7', 7.2, 4.25, sup_dir)
save_src(ann, 'Supplementary_Figure_S7', 'assigned_class_annotation_confidence_plot_data.csv')
save_src(ann_complete, 'Supplementary_Figure_S7', 'annotation_confidence_complete.csv')

write.csv(audit, file.path(qa_dir, 'figure_data_and_annotation_audit.csv'),
          row.names = FALSE, na = '')
if (!all(audit$pass)) stop('One or more figure data audits failed.')

cat('Redesigned main and supplementary figures written to:',
    normalizePath(root), '\n')
cat('Data/annotation audits passed:', sum(audit$pass), 'of', nrow(audit), '\n')
