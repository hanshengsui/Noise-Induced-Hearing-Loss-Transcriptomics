#!/usr/bin/env Rscript
# 11_emtab_phase_transition.R -- activation-to-resolution intersection-union test
# (Table 2, Figure 3C, Additional file 6).
#
# E-MTAB-16125 time course, five individual mice per time point, sex-adjusted
# TMM-voom. The activation component is the 72 h versus control contrast
# (one-sided, greater); the resolution component is the 1 week versus 72 h
# contrast (one-sided, less). The IUT P value is the maximum of the two
# one-sided P values, and BH is applied across the programmes reported.
#
# Runtime: under a minute.

options(stringsAsFactors = FALSE)

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
nihl_require_versions('3.62.2', '4.4.2')
nihl_require_inputs(nihl_inputs[c('E_MTAB_sdrf', 'E_MTAB_featurecounts',
                                  'GSE168041_gene_map')])

result_root <- file.path(nihl_paths$work, 'revision', 'phase_transition')
dir.create(result_root, recursive = TRUE, showWarnings = FALSE)

read_gmt <- function(path) {
  parts <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  parts <- parts[lengths(parts) >= 3L]
  ans <- lapply(parts, function(x) unique(toupper(x[-c(1L, 2L)])))
  names(ans) <- vapply(parts, `[[`, character(1), 1L)
  ans
}

camera_pr <- function(statistic, pathways, collection, contrast) {
  statistic <- statistic[is.finite(statistic)]
  names(statistic) <- toupper(names(statistic))
  statistic <- statistic[!duplicated(names(statistic))]
  index <- lapply(pathways, function(set) which(names(statistic) %in% set))
  valid <- lengths(index) >= 5L & lengths(index) < length(statistic) - 2L
  tab <- cameraPR(
    statistic,
    index = index[valid],
    inter.gene.cor = 0.01,
    use.ranks = FALSE,
    sort = FALSE
  )
  signed_t <- ifelse(
    tab$Direction == "Up",
    qt(tab$PValue / 2, df = length(statistic) - 2, lower.tail = FALSE),
    qt(tab$PValue / 2, df = length(statistic) - 2)
  )
  data.frame(
    dataset = "E-MTAB-16125",
    contrast = contrast,
    collection = collection,
    programme = rownames(tab),
    n_genes = tab$NGenes,
    direction = tab$Direction,
    camera_t = signed_t,
    PValue = tab$PValue,
    FDR = tab$FDR,
    stringsAsFactors = FALSE,
    row.names = NULL
  )
}

human_hallmark <- read_gmt(nihl_inputs$human_gmt)
mouse_hallmark <- read_gmt(nihl_inputs$mouse_gmt)

sdrf_path <- nihl_inputs$E_MTAB_sdrf
count_dir <- nihl_inputs$E_MTAB_featurecounts
sdrf <- read.delim(sdrf_path, check.names = TRUE)
meta <- unique(sdrf[, c(
  "Source.Name", "Characteristics.sex.", "Derived.Array.Data.File",
  "Factor.Value.time.", "Factor.Value.injury."
)])
names(meta) <- c("sample_id", "sex", "count_file", "time_label", "injury")
meta$group <- ifelse(
  meta$time_label == "control", "control",
  ifelse(
    grepl("^24h", meta$time_label), "h24",
    ifelse(grepl("^72h", meta$time_label), "h72", "week1")
  )
)
meta <- meta[
  order(match(meta$group, c("control", "h24", "h72", "week1")), meta$sample_id),
]

counts_list <- vector("list", nrow(meta))
genes <- NULL
for (i in seq_len(nrow(meta))) {
  tab <- read.delim(
    file.path(count_dir, meta$count_file[i]),
    header = FALSE,
    col.names = c("gene_id", "count")
  )
  if (is.null(genes)) genes <- tab$gene_id
  if (!identical(genes, tab$gene_id)) stop("Feature-count gene order mismatch.")
  counts_list[[i]] <- tab$count
}
counts <- do.call(cbind, counts_list)
rownames(counts) <- genes
colnames(counts) <- meta$sample_id
storage.mode(counts) <- "numeric"

gene_map <- read.csv(nihl_inputs$GSE168041_gene_map)
gene_map$stable_id <- sub("\\..*$", "", gene_map$gene_id)
symbols <- gene_map$gene_symbol[
  match(sub("\\..*$", "", rownames(counts)), gene_map$stable_id)
]
ok <- !is.na(symbols) & nzchar(symbols)
counts <- rowsum(counts[ok, , drop = FALSE], toupper(symbols[ok]), reorder = FALSE)

group <- factor(meta$group, levels = c("control", "h24", "h72", "week1"))
sex <- factor(meta$sex)
design <- model.matrix(~0 + group + sex)
colnames(design) <- sub("^group", "", colnames(design))
colnames(design) <- sub("^sex", "sex_", colnames(design))
contrast_matrix <- makeContrasts(
  h24_vs_control = h24 - control,
  h72_vs_control = h72 - control,
  week1_vs_control = week1 - control,
  h72_vs_h24 = h72 - h24,
  week1_vs_h72 = week1 - h72,
  week1_vs_h24 = week1 - h24,
  levels = design
)

keep <- filterByExpr(counts, design = design, min.count = 10, min.total.count = 15)
dge <- DGEList(counts[keep, , drop = FALSE])
dge <- calcNormFactors(dge, method = "TMM")
v <- voom(dge, design, plot = FALSE)
fit <- eBayes(
  contrasts.fit(lmFit(v, design), contrast_matrix),
  robust = TRUE,
  trend = FALSE
)

gene_results <- list()
programme_results <- list()
for (contrast in colnames(fit$coefficients)) {
  tt <- topTable(fit, coef = contrast, number = Inf, sort.by = "none")
  gene_tab <- data.frame(
    dataset = "E-MTAB-16125",
    contrast = contrast,
    feature_id = rownames(fit$coefficients),
    gene_symbol = rownames(fit$coefficients),
    logFC = tt$logFC,
    AveExpr = tt$AveExpr,
    moderated_t = tt$t,
    PValue = tt$P.Value,
    FDR = tt$adj.P.Val,
    B = tt$B,
    stringsAsFactors = FALSE
  )
  con <- gzfile(file.path(result_root, paste0(
    "E-MTAB-16125__", contrast, "__complete_results.csv.gz"
  )), "wt")
  write.csv(gene_tab, con, row.names = FALSE, na = "")
  close(con)
  statistic <- gene_tab$moderated_t
  names(statistic) <- gene_tab$gene_symbol
  programme_results[[paste0(contrast, "_human")]] <- camera_pr(
    statistic,
    human_hallmark,
    "Human Hallmark v2024.1 direct-symbol match",
    contrast
  )
  programme_results[[paste0(contrast, "_mouse")]] <- camera_pr(
    statistic,
    mouse_hallmark,
    "Mouse Hallmark v2024.1 orthologized",
    contrast
  )
  gene_results[[contrast]] <- gene_tab
}
programme_results <- do.call(rbind, programme_results)
nihl_write_csv(
  programme_results,
  file.path(result_root, "E-MTAB-16125_programme_results_complete.csv"),
  row.names = FALSE,
  na = ""
)
nihl_write_csv(meta, file.path(result_root, "sample_metadata.csv"), na = "")

# Formal programme-level activation-to-resolution test. The two component
# hypotheses are fixed by the design: activation at 72 h relative to control,
# followed by a decline from 72 h to one week. A programme passes the
# intersection-union test only when both one-sided component tests pass.
human <- programme_results[
  programme_results$collection == "Human Hallmark v2024.1 direct-symbol match",
]
early <- human[human$contrast == "h72_vs_control", ]
late <- human[human$contrast == "week1_vs_h72", ]
late <- late[match(early$programme, late$programme), ]

one_sided_up <- function(direction, p) {
  ifelse(direction == "Up", p / 2, 1 - p / 2)
}
one_sided_down <- function(direction, p) {
  ifelse(direction == "Down", p / 2, 1 - p / 2)
}

phase_iut <- data.frame(
  programme = early$programme,
  early_contrast = "h72_vs_control",
  early_direction = early$direction,
  early_camera_t = early$camera_t,
  early_two_sided_P = early$PValue,
  late_transition_contrast = "week1_vs_h72",
  late_transition_direction = late$direction,
  late_transition_camera_t = late$camera_t,
  late_transition_two_sided_P = late$PValue,
  activation_one_sided_P = one_sided_up(early$direction, early$PValue),
  resolution_one_sided_P = one_sided_down(late$direction, late$PValue),
  stringsAsFactors = FALSE
)
phase_iut$IUT_PValue <- pmax(
  phase_iut$activation_one_sided_P,
  phase_iut$resolution_one_sided_P
)
phase_iut$IUT_FDR <- p.adjust(phase_iut$IUT_PValue, method = "BH")
phase_iut$activation_to_resolution_supported <- phase_iut$IUT_FDR < 0.10
nihl_write_csv(
  phase_iut,
  file.path(result_root, "programme_activation_to_resolution_IUT.csv"),
  row.names = FALSE,
  na = ""
)

pca <- prcomp(t(v$E), center = TRUE, scale. = FALSE)
nihl_write_csv(
  data.frame(
    sample_id = rownames(pca$x),
    PC1 = pca$x[, 1],
    PC2 = pca$x[, 2],
    meta[match(rownames(pca$x), meta$sample_id), c("group", "sex")]
  ),
  file.path(result_root, "pca_source.csv"),
  row.names = FALSE
)

writeLines(capture.output(sessionInfo()), file.path(result_root, "sessionInfo.txt"))
cat("E-MTAB-16125 direct-transition analysis completed.\n")
print(
  phase_iut[
    phase_iut$programme %in% c(
      "HALLMARK_TNFA_SIGNALING_VIA_NFKB",
      "HALLMARK_INFLAMMATORY_RESPONSE",
      "HALLMARK_OXIDATIVE_PHOSPHORYLATION",
      "HALLMARK_E2F_TARGETS",
      "HALLMARK_UNFOLDED_PROTEIN_RESPONSE"
    ),
  ],
  row.names = FALSE
)
