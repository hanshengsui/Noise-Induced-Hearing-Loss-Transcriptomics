#!/usr/bin/env Rscript
# 09_stability_ledger.R -- seven-programme direction-stability ledger
# (Table S7 / Additional file 8; Figure 5D).
#
# The ledger crosses the seven programmes used for the single-cell sensitivity
# analysis against the 13 primary cohort-by-class combinations, and records the
# camera-PR direction obtained under each of the four annotation definitions
# (primary 10/20/30 cells, strict 20 cells). A combination is stable when all
# evaluable definitions give the same direction.
#
# Scope note: 7 programmes x 13 combinations = 91 rows. An earlier version of the
# supplementary table restricted the same ledger to six programmes (78 rows); the
# revised manuscript reports the seven-programme version, which includes the
# unfolded-protein response. This script always emits the seven-programme form.
#
# Inputs (produced by 07_annotation_sensitivity.R):
#   results/cell_annotation_sensitivity/CAMERA_PR_annotation_and_cell_threshold_sensitivity.csv
#   source_data/GSE168041_celltype/celltype_eligibility_thresholds.csv
#
# Outputs:
#   results/cell_annotation_sensitivity/Table_S7_seven_programme_direction_stability_ledger.csv
#   results/cell_annotation_sensitivity/stability_summary_by_programme.csv

options(stringsAsFactors = FALSE)

source(file.path(Sys.getenv('NIHL_REPO_ROOT', '.'), 'scripts', '00_setup.R'))
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
})

stage1 <- Sys.getenv('NIHL_ANALYSIS_ROOT')
sens_dir <- file.path(stage1, 'results', 'cell_annotation_sensitivity')
src_dir <- file.path(stage1, 'source_data', 'GSE168041_celltype')
tab_dir <- file.path(stage1, 'tables')
dir.create(tab_dir, recursive = TRUE, showWarnings = FALSE)

# The seven programmes analysed in the single-cell sensitivity analysis. These
# are the five focal programmes of the bulk synthesis plus interferon-gamma
# response and epithelial-mesenchymal transition.
core7 <- c(
  'HALLMARK_TNFA_SIGNALING_VIA_NFKB',
  'HALLMARK_INFLAMMATORY_RESPONSE',
  'HALLMARK_UNFOLDED_PROTEIN_RESPONSE',
  'HALLMARK_OXIDATIVE_PHOSPHORYLATION',
  'HALLMARK_INTERFERON_GAMMA_RESPONSE',
  'HALLMARK_E2F_TARGETS',
  'HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION'
)
core6 <- setdiff(core7, 'HALLMARK_UNFOLDED_PROTEIN_RESPONSE')

pretty_programme <- c(
  HALLMARK_TNFA_SIGNALING_VIA_NFKB = 'TNF-\u03b1/NF-\u03baB',
  HALLMARK_INFLAMMATORY_RESPONSE = 'Inflammation',
  HALLMARK_UNFOLDED_PROTEIN_RESPONSE = 'UPR',
  HALLMARK_OXIDATIVE_PHOSPHORYLATION = 'OxPhos',
  HALLMARK_INTERFERON_GAMMA_RESPONSE = 'IFN-\u03b3 response',
  HALLMARK_E2F_TARGETS = 'E2F targets',
  HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION = 'EMT'
)
definitions <- c('primary_10', 'primary_20', 'primary_30', 'strict_20')

# ---- 13 primary combinations: the 20-cell pseudobulk rule with at least three
#      libraries per group in both conditions.
elig <- read.csv(file.path(src_dir, 'celltype_eligibility_thresholds.csv'),
                 stringsAsFactors = FALSE)
primary <- elig %>%
  filter(min_cells == 20, inferentially_eligible) %>%
  select(tissue_cohort, cell_type, n_naive_eligible, n_noise_eligible)
stopifnot(nrow(primary) == 13L)

# The 13 primary combinations are also written on their own so that the figure
# script can read them without repeating the eligibility rule.
res_dir <- file.path(stage1, 'analysis_results')
dir.create(res_dir, recursive = TRUE, showWarnings = FALSE)
primary_out <- primary
primary_out$key <- paste(primary_out$tissue_cohort, primary_out$cell_type, sep = '__')
nihl_write_csv(primary_out, file.path(res_dir, 'primary_13_cell_class_combinations.csv'))

# ---- camera-PR directions under every annotation definition.
sens <- read.csv(file.path(sens_dir,
                           'CAMERA_PR_annotation_and_cell_threshold_sensitivity.csv'),
                 stringsAsFactors = FALSE)
parts <- strsplit(sens$analysis, '__', fixed = TRUE)
sens$annotation_definition <- vapply(parts, `[[`, character(1), 1)
sens$min_cells <- as.integer(vapply(parts, `[[`, character(1), 2))
sens$tissue_cohort <- vapply(parts, `[[`, character(1), 3)
sens$cell_type <- vapply(parts, function(x) paste(x[4:length(x)], collapse = '__'),
                         character(1))
sens$definition <- paste(sens$annotation_definition, sens$min_cells, sep = '_')

build_ledger <- function(programmes) {
  rows <- list()
  for (pw in programmes) {
    for (i in seq_len(nrow(primary))) {
      co <- primary$tissue_cohort[i]
      ct <- primary$cell_type[i]
      dirs <- vapply(definitions, function(d) {
        hit <- sens[sens$pathway == pw & sens$tissue_cohort == co &
                      sens$cell_type == ct & sens$definition == d, 'Direction']
        if (length(hit)) hit[1] else NA_character_
      }, character(1))
      observed <- dirs[!is.na(dirs)]
      unique_dirs <- sort(unique(observed))
      rows[[length(rows) + 1]] <- data.frame(
        panel = 'A_stability',
        pathway = pw,
        tissue_cohort = co,
        cell_type = ct,
        primary_10 = dirs[['primary_10']],
        primary_20 = dirs[['primary_20']],
        primary_30 = dirs[['primary_30']],
        strict_20 = dirs[['strict_20']],
        n_evaluable_definitions = length(observed),
        directions = paste(ifelse(is.na(dirs), 'Not evaluable', dirs), collapse = '; '),
        stable = length(unique_dirs) <= 1L && length(observed) > 0L,
        stringsAsFactors = FALSE
      )
    }
  }
  ledger <- do.call(rbind, rows)
  ledger$Program <- unname(pretty_programme[ledger$pathway])
  ledger[, c('panel', 'pathway', 'tissue_cohort', 'cell_type',
             'n_evaluable_definitions', 'stable', 'directions', 'Program')]
}

ledger7 <- build_ledger(core7)
stopifnot(nrow(ledger7) == 91L)

nihl_write_csv(ledger7, file.path(sens_dir,
                                  'Table_S7_seven_programme_direction_stability_ledger.csv'),
               na = 'Not evaluable')
nihl_write_csv(ledger7, file.path(tab_dir,
                                  'Table_S7_seven_programme_direction_stability_ledger.csv'),
               na = 'Not evaluable')

# Per-programme summary: the counts quoted in Figure 5D and in Results 3.5.
by_programme <- ledger7 %>%
  group_by(Program, pathway) %>%
  summarise(n_combinations = n(), n_stable = sum(stable),
            n_unstable = sum(!stable), .groups = 'drop') %>%
  arrange(match(pathway, core7))
nihl_write_csv(by_programme, file.path(sens_dir, 'stability_summary_by_programme.csv'))

# The six-programme form is retained only so that the earlier supplementary
# version can be regenerated if needed; it is not written to results/tables/.
ledger6 <- build_ledger(core6)
nihl_write_csv(ledger6, file.path(sens_dir,
                              'stability_ledger_six_programme_78_rows.csv'),
               na = 'Not evaluable')

cat('Seven-programme ledger:', nrow(ledger7), 'rows;',
    sum(ledger7$stable), 'stable;', sum(!ledger7$stable), 'unstable\n')
cat('Six-programme ledger:  ', nrow(ledger6), 'rows;',
    sum(ledger6$stable), 'stable\n')
print(by_programme, row.names = FALSE)
print(ledger7[!ledger7$stable, c('Program', 'tissue_cohort', 'cell_type', 'directions')],
      row.names = FALSE)
