# Install the exact limma and edgeR builds used for the reported results
# (Bioconductor 3.20) from source into a side library, then point
# NIHL_VALIDATION_LIB at it; scripts/00_setup.R prepends it to .libPaths().
lib <- Sys.getenv('NIHL_VALIDATION_LIB', file.path(getwd(), 'Rlib'))
dir.create(lib, showWarnings = FALSE, recursive = TRUE)
pkgs <- c(limma = '3.62.2', edgeR = '4.4.2')
for (p in names(pkgs)) {
  v <- pkgs[[p]]
  urls <- c(sprintf('https://bioconductor.org/packages/3.20/bioc/src/contrib/%s_%s.tar.gz', p, v),
            sprintf('https://bioconductor.org/packages/3.20/bioc/src/contrib/Archive/%s/%s_%s.tar.gz', p, p, v))
  ok <- FALSE
  for (u in urls) {
    tf <- tempfile(fileext = '.tar.gz')
    if (!inherits(try(download.file(u, tf, quiet = TRUE), silent = TRUE), 'try-error')) {
      install.packages(tf, lib = lib, repos = NULL, type = 'source'); ok <- TRUE; break
    }
  }
  if (!ok) stop('Could not download ', p, ' ', v)
}
.libPaths(c(lib, .libPaths()))
stopifnot(as.character(packageVersion('limma')) == '3.62.2',
          as.character(packageVersion('edgeR')) == '4.4.2')
cat('Installed into', lib, '\n')
