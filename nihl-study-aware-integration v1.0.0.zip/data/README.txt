Raw inputs are downloaded by scripts/00_download.R into this folder (run_all.R calls it first).
