#!/usr/bin/env Rscript
# run_all.R -- run the analysis pipeline from the repository root.
#
# Usage:
#   Rscript run_all.R                                  # everything
#   Rscript run_all.R --dataset GSE160639 --from-download
#   Rscript run_all.R --stage tables                   # only rebuild the tables
#
# Stages run in this order and each stage depends on the one before it:
#   download  scripts/00_download.R                  fetch and checksum public inputs
#   01..03    per-dataset statistics                 GSE8342; E-MTAB + GSE107086; GSE168041
#   10..12    external validation and synthesis      four external bulk series; time course; synthesis
#   04..08    programme integration and robustness   cross-study integration, localization, robustness
#   09        stability ledger                       seven-programme direction ledger
#   99        tables                                 every manuscript table
#   97        figures                                submitted-design main figures and S1-S7
#   97b       revised main figures                   revised-layout main Figures 1-6 (overwrites 97's main figures)
#
# The pipeline writes intermediates to work/ and final tables and figures to
# results/. Nothing outside the repository is written.

args <- commandArgs(trailingOnly = TRUE)
get_arg <- function(flag, default = NULL) {
  i <- match(flag, args)
  if (is.na(i) || i == length(args)) return(default)
  args[i + 1]
}
has_flag <- function(flag) flag %in% args

stage <- get_arg('--stage', 'all')
dataset <- get_arg('--dataset', NULL)
from_download <- has_flag('--from-download')

repo_arg <- grep('^--file=', commandArgs(trailingOnly = FALSE), value = TRUE)
root <- normalizePath(
  if (length(repo_arg) == 1L) dirname(sub('^--file=', '', repo_arg[1]))
  else Sys.getenv('NIHL_REPO_ROOT', '.'),
  winslash = '/', mustWork = TRUE)
Sys.setenv(NIHL_REPO_ROOT = root)
rscript <- file.path(R.home('bin'), 'Rscript')

# On Windows the executable carries a .exe suffix.
if (.Platform$OS.type == 'windows') rscript <- paste0(rscript, '.exe')

run <- function(script, label, extra_args = character()) {
  path <- file.path(root, 'scripts', script)
  if (!file.exists(path)) stop('Missing script: ', path)
  cat('\n=== ', label, ' :: ', script, '\n', sep = '')
  t0 <- Sys.time()
  env_vars <- paste0('NIHL_REPO_ROOT=', shQuote(root),
                     if (!is.null(dataset)) paste0(' NIHL_DATASETS=', dataset) else '')
  status <- system2(rscript, c(shQuote(path), extra_args), env = env_vars)
  elapsed <- as.numeric(difftime(Sys.time(), t0, units = 'mins'))
  if (!identical(status, 0L)) stop('Stage failed (status ', status, '): ', script)
  cat(sprintf('--- %s finished in %.1f min\n', script, elapsed))
  invisible(elapsed)
}

timings <- list()

run_stage <- function(script, label) {
  t0 <- Sys.time()
  run(script, label)
  # `timings` lives in the global environment; assigning there rather than to a
  # local copy is what makes the runtime summary list every stage.
  timings[[script]] <<- as.numeric(difftime(Sys.time(), t0, units = 'mins'))
}
want <- function(s) stage == 'all' || stage == s

if (from_download || want('download')) {
  # --dataset restricts the download when exactly one accession is named; a
  # full run fetches everything.
  extra <- if (!is.null(dataset)) shQuote(dataset) else character()
  t0 <- Sys.time()
  run('00_download.R', 'download and verify public inputs', extra_args = extra)
  timings[['00_download.R']] <- as.numeric(difftime(Sys.time(), t0, units = 'mins'))
}
# A single-dataset run (--dataset) is the smoke-test path: it takes that one
# external series from download through the tables that depend on it and skips
# the stages that need the other datasets.
single <- !is.null(dataset)
if (want('datasets') || want('all')) {
  if (!single) {
  run_stage('01_gse8342_discovery.R', 'strain-associated discovery series')
  run_stage('02_emtab_and_glucocorticoid.R', 'replicated time course and glucocorticoid context')
  run_stage('03_singlecell_pseudobulk.R', 'single-cell pseudobulk contrast')
  }
}
if (want('validation') || want('all')) {
  run_stage('10_expanded_validation.R',
            if (single) paste('single external series:', dataset)
            else 'four external bulk series')
  if (!single) {
    run_stage('11_emtab_phase_transition.R', 'activation-to-resolution time course')
    run_stage('12_synthesis.R', 'cross-study synthesis')
  }
}
if (!single && (want('integration') || want('all'))) {
  run_stage('04_programme_integration.R', 'cross-study programme integration')
  run_stage('05_cellclass_localization.R', 'broad cell-class localization')
  run_stage('06_gene_set_robustness.R', 'gene-set robustness')
  run_stage('07_annotation_sensitivity.R', 'annotation and minimum-cell sensitivity')
  run_stage('08_mouse_hallmark.R', 'human versus mouse-Hallmark sensitivity')
  run_stage('09_stability_ledger.R', 'seven-programme stability ledger')
}
if (want('tables') || want('all')) {
  run_stage('99_tables.R', if (single) 'tables for the downloaded series only'
            else 'manuscript tables')
}
if (!single && (want('figures') || want('all'))) {
  run_stage('97_figures.R', 'manuscript figures')
  # The revised manuscript uses the 183 mm main-figure layout that 97b writes;
  # 97_figures.R draws the submitted layout. This stage runs second on purpose
  # so the revised main figures, not the submitted ones, are what remains in
  # results/figures/. The S1-S7 panels come from 97_figures.R and are untouched.
  run_stage('97b_main_figures.R', 'manuscript main figures (revision layout)')
}

cat('\nRuntime summary (minutes):\n')
for (nm in names(timings)) cat(sprintf('  %-34s %6.1f\n', nm, timings[[nm]]))
cat(sprintf('  %-34s %6.1f\n', 'total', sum(unlist(timings))))
