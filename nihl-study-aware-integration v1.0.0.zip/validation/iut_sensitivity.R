# Reproduce the primary temporal IUT and evaluate correlation assumptions.
source('scripts/11_emtab_phase_transition.R')
idx <- lapply(human_hallmark,function(g)which(rownames(v$E)%in%g))
idx <- idx[lengths(idx)>=5]
contr <- c('h72_vs_control','week1_vs_h72')
res <- list()
for(setting in c('0.01','0.05','0.1','estimated','fry')) {
 tabs <- lapply(contr,function(cn) {
  if(setting %in% c('0.01','0.05','0.1')) {
   stat <- fit$t[,cn];names(stat)<-rownames(fit$t)
   cameraPR(stat,idx,inter.gene.cor=as.numeric(setting),sort=FALSE)
  } else if(setting=='estimated') camera(v,idx,design,contrast=contrast_matrix[,cn],inter.gene.cor=NA,sort=FALSE)
  else fry(v,idx,design,contrast=contrast_matrix[,cn],sort=FALSE)
 })
 a<-tabs[[1]][names(idx),];b<-tabs[[2]][names(idx),]
 pa<-ifelse(a$Direction=='Up',a$PValue/2,1-a$PValue/2)
 pb<-ifelse(b$Direction=='Down',b$PValue/2,1-b$PValue/2)
 pp<-pmax(pa,pb);q<-p.adjust(pp,'BH')
 res[[setting]]<-data.frame(setting,program=names(idx),activation_direction=a$Direction,resolution_direction=b$Direction,activation_P=pa,resolution_P=pb,IUT_P=pp,IUT_FDR=q,tier=ifelse(q<.05,'Supported',ifelse(q<.1,'Suggestive','Not supported')))
}
ans<-do.call(rbind,res)
write.csv(ans,'validation/iut_sensitivity.csv',row.names=FALSE)
print(ans[ans$program%in%c('HALLMARK_TNFA_SIGNALING_VIA_NFKB','HALLMARK_INFLAMMATORY_RESPONSE','HALLMARK_E2F_TARGETS','HALLMARK_OXIDATIVE_PHOSPHORYLATION','HALLMARK_UNFOLDED_PROTEIN_RESPONSE'),c('setting','program','IUT_FDR','tier')],row.names=FALSE)
writeLines(capture.output(sessionInfo()),'validation/sessionInfo.txt')
