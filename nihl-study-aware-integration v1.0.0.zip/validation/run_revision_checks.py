"""Run the revision analyses after Rscript run_all.R has completed."""
from pathlib import Path
import argparse,csv,os,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--line',choices=['all','synthesis','preprocessing','single_cell'],default='all');ap.add_argument('--rscript',default=os.environ.get('RSCRIPT','Rscript'));args=ap.parse_args()
env=os.environ.copy();env['SC_W']=str(root/'work');env['SC_OUT']=str(root/'work/sc_out');env['MPLCONFIGDIR']=str(root/'work/mpl-cache');env['XDG_CACHE_HOME']=str(root/'work/runtime-cache');env['SC_STABLE_TABLE']=str(root/'work/sc_out/stable_marker_direction_comparison.csv');env['SC_PRIMARY_TABLE']=str(root/'results/tables/Table_S11A_complete_650_primary_pseudobulk_results.csv');env['PYTHON']=sys.executable
for n in ['SC_OUT','MPLCONFIGDIR','XDG_CACHE_HOME']:Path(env[n]).mkdir(parents=True,exist_ok=True)
def run(path):
 exe=args.rscript if path.endswith('.R')else sys.executable
 print('Running',path,flush=True);subprocess.run([exe,str(root/path)],cwd=root,env=env,check=True)
def link(path,target):
 path.parent.mkdir(parents=True,exist_ok=True)
 if not path.exists():path.symlink_to(target,target_is_directory=True)
if args.line in ['all','synthesis']:run('revision/synthesis/scripts/run_synthesis.R')
if args.line in ['all','preprocessing']:
 env.update(SC_ROOT=str(root),SC_SCR=str(root/'revision/synthesis/scripts'));run('revision/synthesis/scripts/00_stage_inputs.R')
 w=root/'work/preprocessing_run';w.mkdir(exist_ok=True);env.update(A2_W=str(w),A2_SCR=str(root/'revision/preprocessing/scripts'))
 for a,b in [('prj/Expanded_Validation/downloads','revision/synthesis/inputs/downloads'),('prj/Expanded_Validation/results/expanded_validation','work/revision/expanded_validation'),('out/legacy','work/stage1')]:link(w/a,root/b)
 (w/'rev/pkg').mkdir(parents=True,exist_ok=True)
 for f in (root/'revision/preprocessing/inputs/frozen_package_results').glob('*.csv'):shutil.copy2(f,w/'rev'/('pkg'if f.name.startswith('E-MTAB')else'')/f.name)
 for n in ['01_gse196870.R','01b_scale_identification.R','02_gse196870_figs.R','03_gse312476.R','08_gse312476_figs.R','08b_gse312476_qc.R','04_propagate.R','05_retention.R','06_coverage.R','07_representative_genes.R','10_additionalfiles.R','11_summary.R']:run('revision/preprocessing/scripts/'+n)
 with (root/'revision/TABLE_TO_SCRIPT.csv').open(encoding='utf-8-sig')as f:
  rows=list(csv.DictReader(f))
 for r in rows:
  vals=list(r.values())
  if vals[0]=='preprocessing':shutil.copy2(w/'rev'/vals[1],root/'revision/preprocessing/results'/vals[1])
if args.line in ['all','single_cell']:
 steps=['build_raw.py','check_repro.py','haircell.py','haircell2.py','haircell3.py','haircell4.py','build_adata.py','c2_umap.py','c2_leiden.py','c1_rev.py','c1_eligibility.py','c1_tables_rev.py','tables_c1.py','c2_figs.py','c2_figs_rev.py','c1_cluster_markers.py','c3_overlap.R','c3_responsive.R','c4_reassign.py','c4_hybrid.py','c4_confusion.py','c4_pseudobulk_build.py','c4_camera.R','c5_composition.R','c4c5_figs.py','c4c5_figs_rev.py','sc_igc_sensitivity.R','sc_igc_tables.R','stable_marker_common42.R','build_cl29_counts.py','cl29_exclusion.R','final_tables.py']
 for n in steps:run('revision/single_cell/scripts/'+n)
 with (root/'revision/TABLE_TO_SCRIPT.csv').open(encoding='utf-8-sig')as f:rows=list(csv.DictReader(f))
 for r in rows:
  vals=list(r.values())
  if vals[0]=='single_cell':shutil.copy2(root/'work/sc_out'/vals[1],root/'revision/single_cell/results'/vals[1])
print('Requested revision analyses completed.',flush=True)
