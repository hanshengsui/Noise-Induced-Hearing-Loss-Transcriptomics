## Self-test C: the refit path used inside the permutation must reproduce the main-analysis
## signed z from the real labels (all.equal, tol = 1e-8), for every study and contrast used.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R")); source(file.path(SC_SCR, "07_perm_engine.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds")); H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))
STR <- syn_strata()
scheme_for <- function(study) if (study=="GSE196870") "GSE196870_S0" else
  if (study=="EMTAB") "EMTAB" else study
rows <- list()
for (s in names(STR)) for (study in names(STR[[s]])) {
  src <- switch(study, GSE160639="GSE160639", GSE196870="GSE196870_S0", GSE312476="GSE312476",
                GSE100365="GSE100365", EMTAB="EMTAB")
  obj <- O[[src]]; cn <- STR[[s]][[study]]
  lp <- syn_levelpairs()[[study]][[cn]]; g2 <- lp[1]; g1 <- lp[2]
  obs_refit <- observed_z(obj, paste0(g2,"|",g1), H$hallmark, H$order50)
  obs_main  <- z_vector(obj$camera[obj$camera$contrast==cn,], H$order50)
  d <- abs(obs_refit - obs_main)
  rows[[length(rows)+1]] <- data.frame(stratum=s, study=study, contrast=cn,
    n_programs_compared=sum(is.finite(d)), max_abs_diff=max(d, na.rm=TRUE),
    agree_1e8=isTRUE(all.equal(unname(obs_refit), unname(obs_main), tolerance=1e-8)))
}
R <- do.call(rbind, rows)
print(R, row.names=FALSE, digits=6)
write.csv(R, file.path(SC_OUT, "perm_selftest_observed_agreement.csv"), row.names=FALSE)
cat("\nALL AGREE:", all(R$agree_1e8), "\n")
