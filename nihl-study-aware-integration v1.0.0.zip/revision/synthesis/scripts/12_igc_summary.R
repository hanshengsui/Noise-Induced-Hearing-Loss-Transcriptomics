## Direction retention and FDR-category retention across the inter.gene.cor settings.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R"))
X <- readRDS(file.path(SC_CACHE, "igc.rds")); IG <- X$IG; EC <- X$EC
O <- readRDS(file.path(SC_CACHE, "expr.rds"))
## focal-programme names in the analysis key form
key_of <- c(TNFA="HALLMARK_TNFA_SIGNALING_VIA_NFKB", INFL="HALLMARK_INFLAMMATORY_RESPONSE",
            UPR="HALLMARK_UNFOLDED_PROTEIN_RESPONSE", OXPHOS="HALLMARK_OXIDATIVE_PHOSPHORYLATION",
            E2F="HALLMARK_E2F_TARGETS")
cat_cut <- function(p) as.character(cut(p, c(-Inf,.05,.10,Inf), labels=c("conf","expl","ns")))

base <- IG[which(IG$rho == 0.01), c("stratum","study","contrast","programme","direction","PValue","FDR")]
names(base)[5:7] <- c("dir_base","p_base","fdr_base")
base$cat_base <- cat_cut(base$fdr_base)
alt <- list(rho0.05 = IG[which(IG$rho == 0.05), ], rho0.1 = IG[which(IG$rho == 0.1), ],
            estimated = IG[which(is.na(IG$rho) & !is.na(IG$n_genes)), ],
            fry = IG[which(is.na(IG$rho) & is.na(IG$n_genes)), ])
rows <- list()
for (nm in names(alt)) {
  a <- alt[[nm]]
  m <- merge(base, a[, c("stratum","study","contrast","programme","direction","PValue","FDR")],
             by=c("stratum","study","contrast","programme"))
  m$cat_alt <- cat_cut(m$FDR)
  m$setting <- nm
  rows[[nm]] <- m
}
M <- do.call(rbind, rows); rownames(M) <- NULL
## Note: the estimated/fry settings only cover the 45 (9 study-contrasts x 50) sets each,
## camera(estimated) has no fixed correlation so 'rho' is NA; fry is the rotation test.
summ <- do.call(rbind, lapply(split(M, M$setting), function(z) data.frame(
  setting = z$setting[1], n_comparisons = nrow(z),
  direction_preserved = mean(z$dir_base == z$direction, na.rm=TRUE),
  fdr_category_preserved = mean(z$cat_base == z$cat_alt, na.rm=TRUE))))
## focal-programme detail
focal_rows <- M[M$programme %in% key_of, ]
write.csv(M, file.path(SC_OUT, "igc_sensitivity_paired.csv"), row.names=FALSE)
write.csv(summ, file.path(SC_OUT, "igc_retention_summary.csv"), row.names=FALSE)
write.csv(focal_rows, file.path(SC_OUT, "igc_focal_programmes.csv"), row.names=FALSE)
print(summ, digits=4, row.names=FALSE)
cat("\n--- estimated correlations (per Hallmark, across studies) ---\n")
EC$setting <- "camera_estimated"
q <- do.call(rbind, lapply(split(EC$correlation, EC$programme), function(v)
  data.frame(n_studies=length(v), median=median(v,na.rm=TRUE), min=min(v,na.rm=TRUE), max=max(v,na.rm=TRUE))))
q$programme <- names(split(EC$correlation, EC$programme)); q <- q[order(-q$median),]
cat("across all 50 Hallmarks x 9 study-contrasts:\n")
cat(sprintf("  median of per-set medians = %.3f; range %.3f - %.3f; IQR %.3f - %.3f\n",
            median(q$median), min(q$min), max(q$max), quantile(q$median,.25), quantile(q$median,.75)))
cat(sprintf("  fraction of sets with median estimated correlation > 0.01: %.2f\n", mean(q$median > 0.01)))
write.csv(q, file.path(SC_OUT, "igc_estimated_correlation_by_programme.csv"), row.names=FALSE)
cat("\n--- focal programmes: direction & category vs baseline (0.01) ---\n")
f <- focal_rows[, c("setting","stratum","study","programme","dir_base","direction","cat_base","cat_alt")]
print(head(f, 40), row.names=FALSE)
