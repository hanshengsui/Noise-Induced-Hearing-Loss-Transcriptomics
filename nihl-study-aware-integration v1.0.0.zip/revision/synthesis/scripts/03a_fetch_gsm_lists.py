import urllib.request, os
# Fetch the per-accession GSM listings (brief SOFT) that 04_independence.py parses.
import os
# SC_CACHE / SC_OUT as for the R scripts (defaults: revision/synthesis/cache and revision/synthesis/results)
_ROOT = os.environ.get("SC_ROOT", os.path.abspath(os.path.join(os.getcwd(), "..", "..", "..")))
CACHE = os.environ.get("SC_CACHE", os.path.join(_ROOT, "revision", "synthesis", "cache"))
OUT   = os.environ.get("SC_OUT",   os.path.join(_ROOT, "revision", "synthesis", "results"))
RAW   = os.path.join(CACHE, "gsm_raw")
os.makedirs(RAW, exist_ok=True); os.makedirs(OUT, exist_ok=True)
accs=["GSE160639","GSE196870","GSE312476","GSE100365","GSE168041","GSE107086","GSE312646","GSE8342","GSE107087"]
for a in accs:
    out=os.path.join(RAW, f"{a}_gsm.txt")
    if os.path.exists(out) and os.path.getsize(out)>1000: continue
    url=f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={a}&targ=gsm&form=text&view=brief"
    req=urllib.request.Request(url)
    d=urllib.request.urlopen(req,timeout=120).read().decode("utf-8","replace")
    open(out,"w").write(d); print(a,len(d))
