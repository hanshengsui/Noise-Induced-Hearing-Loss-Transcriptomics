## Appendix B2.5 -- inter.gene.cor sensitivity + CAMERA estimated correlation + fry rotation test.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
suppressPackageStartupMessages({library(limma); library(edgeR); library(statmod)})
O <- readRDS(file.path(SC_CACHE, "expr.rds")); H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))
STR <- syn_strata(); LP <- syn_levelpairs()
src_of <- function(study) switch(study, GSE160639="GSE160639", GSE196870="GSE196870_S0",
  GSE312476="GSE312476", GSE100365="GSE100365", EMTAB="EMTAB")
idx_of <- function(obj) {
  tt <- obj$camera  # only for ordering; recompute names from the observed t vector
  stat <- obj$tstat[[1]]
  nm <- toupper(names(stat)); nm <- nm[!duplicated(nm)]
  lapply(H$hallmark, function(set) which(nm %in% set))
}
rows <- list(); est_cor <- list(); ext <- list()
for (s in names(STR)) for (study in names(STR[[s]])) {
  obj <- O[[src_of(study)]]; cn <- STR[[s]][[study]]; lp <- LP[[study]][[cn]]
  stat <- obj$tstat[[cn]]
  stat <- stat[is.finite(stat)]; names(stat) <- toupper(names(stat))
  stat <- stat[!duplicated(names(stat))]
  idx <- lapply(H$hallmark, function(set) which(names(stat) %in% set))
  valid <- lengths(idx) >= 5L & lengths(idx) < length(stat) - 2L
  idxv <- idx[valid]
  ## --- cameraPR at the three fixed correlations
  res <- list()
  for (rho in c(0.01, 0.05, 0.1)) {
    tab <- cameraPR(stat, index = idxv, inter.gene.cor = rho, use.ranks = FALSE, sort = FALSE)
    res[[as.character(rho)]] <- data.frame(programme = rownames(tab), direction = tab$Direction,
                                           PValue = tab$PValue, FDR = tab$FDR,
                                           n_genes = tab$NGenes, rho = rho,
                                           stratum = s, study = study, contrast = cn)
  }
  ## --- camera() with data-estimated correlation, on the main-analysis expression object
  design <- obj$design
  cm <- obj$contrasts[, cn, drop = FALSE]
  stopifnot(identical(rownames(cm), colnames(design)))
  cam_est <- tryCatch({
    if (obj$scale == "voom") {
      dge <- DGEList(obj$counts); dge$samples$norm.factors <- obj$norm_factors
      v <- voom(dge, design, plot = FALSE)
      camera(v, idxv, design, contrast = cm, inter.gene.cor = NA)
    } else {
      camera(obj$E, idxv, design, contrast = cm, inter.gene.cor = NA)
    }
  }, error = function(e) { cat("camera(estimated) failed:", study, cn, conditionMessage(e), "\n"); NULL })
  if (!is.null(cam_est)) {
    res[["estimated"]] <- data.frame(programme = rownames(cam_est), direction = cam_est$Direction,
      PValue = cam_est$PValue, FDR = cam_est$FDR, n_genes = cam_est$NGenes, rho = NA_real_,
      stratum = s, study = study, contrast = cn)
    est_cor[[paste(s, study, sep="|")]] <- data.frame(stratum=s, study=study, contrast=cn,
      programme=rownames(cam_est), correlation=cam_est$Correlation)
  }
  ## --- fry rotation test (self-contained)
  fry_res <- tryCatch({
    if (obj$scale == "voom") {
      dge <- DGEList(obj$counts); dge$samples$norm.factors <- obj$norm_factors
      v <- voom(dge, design, plot = FALSE)
      fry(v, idxv, design, contrast = cm)
    } else fry(obj$E, idxv, design, contrast = cm)
  }, error = function(e) { cat("fry failed:", study, cn, conditionMessage(e), "\n"); NULL })
  if (!is.null(fry_res)) {
    ## fry returns one row per set with Direction / PValue / PValue.Mixed
    res[["fry"]] <- data.frame(programme = rownames(fry_res), direction = fry_res$Direction,
      PValue = fry_res$PValue, FDR = p.adjust(fry_res$PValue, "BH"),
      n_genes = NA_integer_, rho = NA_real_, stratum = s, study = study, contrast = cn)
    ext[["fry"]] <- data.frame(stratum=s, study=study, contrast=cn,
      programme=rownames(fry_res), p_mixed=fry_res$PValue.Mixed)
  }
  rows[[paste(s, study)]] <- do.call(rbind, res)
}
IG <- do.call(rbind, rows); rownames(IG) <- NULL
write.csv(IG, file.path(SC_OUT, "igc_sensitivity_long.csv"), row.names=FALSE)
EC <- do.call(rbind, est_cor)
write.csv(EC, file.path(SC_OUT, "camera_estimated_correlation.csv"), row.names=FALSE)
EX <- do.call(rbind, ext); rownames(EX) <- NULL
write.csv(EX, file.path(SC_OUT, "fry_pvalue_mixed.csv"), row.names=FALSE)
cat("long rows:", nrow(IG), " estimated-corr rows:", nrow(EC), "\n")
print(table(IG$rho, useNA="ifany"))
saveRDS(list(IG=IG, EC=EC), file.path(SC_CACHE, "igc.rds"))
