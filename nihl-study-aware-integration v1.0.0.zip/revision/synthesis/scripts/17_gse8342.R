## GSE8342: reproduce the strain x noise interaction statistic and its sign, then resolve the
## direction of the positive coefficient against the strain phenotypes.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R"))
suppressPackageStartupMessages({library(limma)})
H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))
lines <- readLines(gzfile(file.path(SC_DL, "GSE8342_series_matrix.txt.gz")), warn = FALSE)
titles <- gsub('"', "", strsplit(grep("^!Sample_title", lines, value=TRUE), "\t")[[1]][-1])
acc <- gsub('"', "", strsplit(grep("^!Sample_geo_accession", lines, value=TRUE), "\t")[[1]][-1])
chars <- grep("^!Sample_characteristics_ch1", lines, value=TRUE)
## expression block
i0 <- grep("^!series_matrix_table_begin", lines)
i1 <- grep("^!series_matrix_table_end", lines)
tab <- read.delim(text = paste(lines[(i0+1):(i1-1)], collapse="\n"), check.names=FALSE, row.names=1)
y <- as.matrix(tab); if (max(y, na.rm=TRUE) > 100) y <- log2(y + 1)
grp <- ifelse(grepl("B6\\.CAST", titles) & grepl("_noise_", titles), "susceptible_noise",
       ifelse(grepl("B6\\.CAST", titles), "susceptible_control",
       ifelse(grepl("_noise_", titles), "resistant_noise", "resistant_control")))
grp <- factor(grp, levels=c("resistant_control","resistant_noise","susceptible_control","susceptible_noise"))
des <- model.matrix(~0+grp); colnames(des) <- levels(grp)
C <- cbind(resistant_noise_vs_control=c(-1,1,0,0), susceptible_noise_vs_control=c(0,0,-1,1),
           strain_by_noise_interaction=c(-1,1,1,-1))
rownames(C) <- colnames(des)
## representative probe per symbol, matching the legacy strategy (highest mean, then variance, then id)
source(file.path(SC_SCR, "utils.R"))
annot <- read_geo_annotation(file.path(SC_DL, "GPL81.annot.gz"))
sy <- annot[["Gene symbol"]][match(rownames(y), annot[["ID"]])]
sy <- toupper(sub("\\s*///.*$", "", sy)); sy[!nzchar(sy)] <- NA
keep <- !is.na(sy)
y2 <- y[keep,,drop=FALSE]; s2 <- sy[keep]; id2 <- rownames(y)[keep]
avg <- rowMeans(y2, na.rm=TRUE); vr <- apply(y2,1,var,na.rm=TRUE)
o <- order(s2, -avg, -vr, id2); y2 <- y2[o,,drop=FALSE]; s2 <- s2[o]; id2 <- id2[o]
k <- !duplicated(s2); y2 <- y2[k,,drop=FALSE]; s2 <- s2[k]
fit <- eBayes(contrasts.fit(lmFit(y2, des), C), robust=TRUE, trend=FALSE)
res <- list()
for (cn in colnames(C)) {
  tt <- topTable(fit, coef=cn, number=Inf, sort.by="none")
  stat <- tt$t; names(stat) <- s2
  cam <- camera_pr_signed(stat, H$hallmark)
  cam$contrast <- cn
  res[[cn]] <- cam
}
R <- do.call(rbind, res); rownames(R) <- NULL
write.csv(R, file.path(SC_OUT, "gse8342_camera_all_contrasts.csv"), row.names=FALSE)
cat("=== GSE8342 focal programmes, all three contrasts ===\n")
print(R[R$programme %in% FOCAL, c("contrast","programme","n_genes","direction","camera_t","PValue","FDR")],
      digits=4, row.names=FALSE)
## direct expression check: interaction t for the TNFA set members, and the group means of the score
sc <- { E <- y2; rownames(E) <- s2
  g <- intersect(rownames(E), H$hallmark[["HALLMARK_TNFA_SIGNALING_VIA_NFKB"]])
  Z <- t(scale(t(E[g,,drop=FALSE]))); colMeans(Z, na.rm=TRUE) }
cat("\n=== TNFA gene-set score by group (GSE8342) ===\n")
print(round(tapply(sc, grp, mean), 4))
mu <- tapply(sc, grp, mean)
cat(sprintf("resistant  noise effect = %+.4f\n", mu["resistant_noise"]-mu["resistant_control"]))
cat(sprintf("susceptible noise effect = %+.4f\n", mu["susceptible_noise"]-mu["susceptible_control"]))
cat(sprintf("interaction (resistant - susceptible) = %+.4f\n",
            (mu["resistant_noise"]-mu["resistant_control"]) - (mu["susceptible_noise"]-mu["susceptible_control"])))
## per-sample phenotype evidence from GEO characteristics (ABR / hair-cell loss text)
cat("\n=== sample titles -> GSM ===\n")
print(data.frame(GSM=acc, title=titles, group=as.character(grp)), row.names=FALSE)
saveRDS(R, file.path(SC_CACHE, "gse8342.rds"))
