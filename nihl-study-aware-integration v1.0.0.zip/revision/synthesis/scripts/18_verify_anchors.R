## Explicit, code-computed verification of anchor 1 and anchor 2.  No value below is read
## from a printed table by eye: every comparison is computed from the saved files.
##
## Usage: Rscript 18_verify_anchors.R <syn_repro_S0.rds> <S1_out_dir> <out_anchor_txt>
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R"))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) >= 3L)

## =========================== ANCHOR 1 ===========================
R <- readRDS(A[1])
sub <- R[R$scheme == "S0", ]
SUB <- c(acute_TNFA=17.069, acute_INFL=4.554, acute_UPR=7.929, acute_OXPHOS=0.509, acute_E2F=4.551,
         h24_TNFA=8.562, h24_INFL=7.478, h24_UPR=5.017, h24_OXPHOS=2.363, h24_E2F=2.960,
         later_TNFA=-6.597, later_INFL=-4.169, later_UPR=-2.184, later_OXPHOS=-0.408, later_E2F=-5.475)
stopifnot(nrow(sub) == 15L, all(paste(sub$stratum, sub$program, sep="_") %in% names(SUB)))
key <- paste(sub$stratum, sub$program, sep="_")
d <- data.frame(stratum=sub$stratum, program=sub$program,
                submitted=as.numeric(SUB[key]), recomputed=sub$Z, stringsAsFactors=FALSE)
d$abs_diff <- abs(d$recomputed - d$submitted)
d$pass <- d$abs_diff < 0.005
write.csv(d, sub("[.]txt$", ".csv", A[3]), row.names=FALSE)
L <- c(sprintf("ANCHOR 1 -- synthesis Z under the S0 primary scheme (tolerance |dZ| < 0.005): %s",
               if (all(d$pass)) sprintf("PASS %d/15", sum(d$pass)) else sprintf("FAIL %d/15", sum(d$pass))),
  sprintf("  %-7s %-7s %11s %15s %11s  %s", "stratum","program","submitted","recomputed","abs_diff","pass"),
  sprintf("  %-7s %-7s %11.3f %15.6f %11.2e  %s", d$stratum, d$program, d$submitted,
          d$recomputed, d$abs_diff, ifelse(d$pass,"TRUE","FALSE")),
  sprintf("  maximum |dZ| across the 15 = %.3e", max(d$abs_diff)),
  sprintf("  sign reproduced in all 15: %s",
          ifelse(all(sign(d$submitted)==sign(d$recomputed)), "yes", "NO")),
  "")

## =========================== ANCHOR 2 ===========================
## Expected values as stated in the task (they are the archived pre-switch results).
EXP_RET <- data.frame(
  setting = c("rho0.05","rho0.1","estimated","fry"),
  direction_kept = c(15L,15L,15L,14L), category_kept = c(12L,6L,8L,9L),
  changed_to_ns = c(3L,6L,7L,6L), changed_from_ns = c(0L,0L,0L,0L), stringsAsFactors=FALSE)
EXP_SUM <- data.frame(
  setting = c("estimated","fry","rho0.05","rho0.1"),
  direction_preserved = c(0.9689, 0.9289, 1.0000, 1.0000),
  fdr_category_preserved = c(0.6422, 0.7311, 0.7111, 0.6667), stringsAsFactors=FALSE)
## And against the archived wide table that the repository ships (the strongest check).
ARCHIVE_WIDE <- A[4]   # passed as 4th arg if present
RET <- read.csv(file.path(A[2], "igc_synthesis_retention.csv"), stringsAsFactors=FALSE)
SUM <- read.csv(file.path(A[2], "igc_retention_summary.csv"), stringsAsFactors=FALSE)
RET <- RET[match(EXP_RET$setting, RET$setting), ]
SUM <- SUM[match(EXP_SUM$setting, SUM$setting), ]
cmp_ret <- data.frame(setting=EXP_RET$setting,
  d_dir = RET$direction_kept - EXP_RET$direction_kept,
  d_cat = RET$category_kept - EXP_RET$category_kept,
  d_ns  = RET$changed_to_ns - EXP_RET$changed_to_ns,
  d_fr  = RET$changed_from_ns - EXP_RET$changed_from_ns)
ok_ret <- all(cmp_ret[,-1] == 0)
ok_sum <- all(abs(SUM$direction_preserved - EXP_SUM$direction_preserved) < 5e-5) &&
          all(abs(SUM$fdr_category_preserved - EXP_SUM$fdr_category_preserved) < 5e-5)
L <- c(L, sprintf("ANCHOR 2 -- S1-scheme rerun must reproduce the archived pre-switch results: %s",
                  if (ok_ret && ok_sum) "PASS" else "FAIL"),
  "  igc_synthesis_retention.csv (15 stratum x programme focal combinations)",
  sprintf("    %-10s %8s %8s %8s %8s %8s   expected dir/cat/to_ns/from_ns",
          "setting","dir","cat","to_ns","from_ns","all_match"),
  sprintf("    %-10s %8d %8d %8d %8d %8s   %d/%d/%d/%d",
          RET$setting, RET$direction_kept, RET$category_kept, RET$changed_to_ns,
          RET$changed_from_ns, ifelse(cmp_ret$d_dir==0 & cmp_ret$d_cat==0 & cmp_ret$d_ns==0 &
          cmp_ret$d_fr==0, "TRUE","FALSE"),
          EXP_RET$direction_kept, EXP_RET$category_kept, EXP_RET$changed_to_ns,
          EXP_RET$changed_from_ns),
  sprintf("  igc_retention_summary.csv (450 study-contrast x programme combinations)"),
  sprintf("    %-10s %22s %26s", "setting","direction_preserved","fdr_category_preserved"),
  sprintf("    %-10s %22.6f %26.6f", SUM$setting, SUM$direction_preserved, SUM$fdr_category_preserved),
  sprintf("    %-10s %22.4f %26.4f   <- expected", "expected", EXP_SUM$direction_preserved,
          EXP_SUM$fdr_category_preserved),
  sprintf("  retention table reproduced exactly: %s; retention summary reproduced: %s",
          ifelse(ok_ret,"yes","NO"), ifelse(ok_sum,"yes","NO")),
  "")
L <- c(L, sprintf("  whole-chain check -- the S1 igc_sensitivity.csv against the archived copy:"), "")
if (length(A) >= 4L && file.exists(A[4])) {
  EX <- read.csv(A[4], stringsAsFactors=FALSE, check.names=FALSE)
  S1 <- read.csv(file.path(A[2], "igc_sensitivity.csv"), stringsAsFactors=FALSE, check.names=FALSE)
  num <- names(EX)[vapply(EX, is.numeric, logical(1))]
  mx <- max(sapply(num, function(j) max(abs(EX[[j]] - S1[[j]]), na.rm=TRUE)))
  chr <- setdiff(names(EX), num)
  nchr <- sum(sapply(chr, function(j) sum(as.character(EX[[j]]) != as.character(S1[[j]]))))
  L <- c(L, sprintf("    max |dFDR| over the 5 FDR columns = %.2e; non-numeric cells differing = %d",
                    mx, nchr),
         sprintf("    -> %s", ifelse(mx < 1e-9 && nchr == 0,
                   "the rerun reproduces the archived wide table (float noise < 1e-9 only)", "DIFFERENCE")))
}
cat(paste(L, collapse="\n"), "\n")
writeLines(L, A[3])
saveRDS(list(anchor1=d, anchor1_pass=all(d$pass), anchor2_pass=(ok_ret && ok_sum)),
        file.path(SC_CACHE, "anchors.rds"))
