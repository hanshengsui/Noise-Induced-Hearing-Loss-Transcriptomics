## Self-test B(i): under a true null, the enumeration-based empirical p is ~uniform.
## One gene set per simulated dataset -> p-values are independent across datasets.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R"))
suppressPackageStartupMessages({library(limma)})
SEED <- SEED_GLOBAL
NDAT <- 300; NG <- 1000; N1 <- 5; N2 <- 5; SETSZ <- 60
set.seed(SEED)
pv <- numeric(NDAT); Z0sd <- numeric(NDAT)
for (r in seq_len(NDAT)) {
  E <- matrix(rnorm(NG*(N1+N2)), NG, dimnames=list(paste0("G",1:NG), NULL))
  grp <- factor(rep(c("c","t"), c(N1,N2)))
  sets <- setNames(lapply(1:5, function(i) sample(rownames(E), SETSZ)), paste0("S",1:5))
  fitstat <- function(E, d) { f <- eBayes(contrasts.fit(lmFit(E,d),
                     matrix(c(-1,1),2,1,dimnames=list(colnames(d),"diff"))), robust=TRUE, trend=FALSE)
                   t <- f$t[,1]; names(t) <- rownames(E); t }
  d <- model.matrix(~0+grp); colnames(d) <- c("c","t")
  cam <- camera_pr_signed(fitstat(E,d), sets)
  zobs <- signed_z_of(cam$PValue, cam$direction)[1]   # use S1 only -> independent across datasets
  perms <- enumerate_relabelings(as.character(grp))
  Z0 <- numeric(length(perms))
  for (b in seq_along(perms)) {
    gg <- factor(perms[[b]], levels=c("c","t")); dd <- model.matrix(~0+gg); colnames(dd) <- c("c","t")
    c2 <- camera_pr_signed(fitstat(E,dd), sets)
    Z0[b] <- signed_z_of(c2$PValue, c2$direction)[1]
  }
  pv[r] <- (1 + sum(abs(Z0) >= abs(zobs))) / (length(Z0)+1)
  Z0sd[r] <- sd(Z0)
  if (r %% 50 == 0) cat("  sim", r, "/", NDAT, "\n")
}
ks <- suppressWarnings(ks.test(pv, "punif", exact=FALSE))
B <- length(enumerate_relabelings(as.character(factor(rep(c("c","t"), c(N1,N2))))))
cat(sprintf("\nB=%d per dataset; n_datasets=%d\n", B, NDAT))
cat(sprintf("KS D=%.4f p=%.3g; mean p=%.4f (expect 0.5); median=%.4f\n",
            ks$statistic, ks$p.value, mean(pv), median(pv)))
alphas <- c(0.01,0.02,0.05,0.10,0.25,0.50)
cal <- data.frame(alpha=alphas,
                  observed=vapply(alphas, function(a) mean(pv <= a), numeric(1)),
                  discrete_expect=vapply(alphas, function(a) sum((1:B)/(B+1) <= a)/B, numeric(1)))
cal$binom_p <- mapply(function(o,a) binom.test(round(o*NDAT), NDAT, min(max(a,1e-9),1))$p.value,
                      cal$observed, cal$discrete_expect)
print(cal, row.names=FALSE)
write.csv(cal, file.path(SC_OUT, "perm_selftest_uniformity_bins.csv"), row.names=FALSE)
write.csv(data.frame(dataset=seq_len(NDAT), p=pv, null_sd_z=Z0sd),
          file.path(SC_OUT, "perm_selftest_uniformity_raw.csv"), row.names=FALSE)
cat("\nVERDICT:", ifelse(ks$p.value > 0.05, "PASS", "FAIL"), "\n")
saveRDS(list(pv=pv, ks=ks, cal=cal, B=B), file.path(SC_CACHE, "selftest_uniform.rds"))
