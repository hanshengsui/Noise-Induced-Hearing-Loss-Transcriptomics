## D6-relevant: does the inter.gene.cor setting change the SYNTHESIS-level FDR category
## for the five focal programmes?
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
X <- readRDS(file.path(SC_CACHE, "igc.rds")); IG <- X$IG
STR <- syn_strata()
cat_cut <- function(p) as.character(cut(p, c(-Inf,.05,.10,Inf), labels=c("conf","expl","ns")))
settings <- list(rho0.01=0.01, rho0.05=0.05, rho0.1=0.1)
rows <- list()
pick <- function(s, study, cn, setting) {
  z <- if (setting %in% names(settings)) IG[which(IG$stratum==s & IG$study==study & IG$contrast==cn &
          !is.na(IG$rho) & IG$rho == settings[[setting]]), ]
       else if (setting=="estimated") IG[which(IG$stratum==s & IG$study==study & IG$contrast==cn &
          is.na(IG$rho) & !is.na(IG$n_genes)), ]
       else IG[which(IG$stratum==s & IG$study==study & IG$contrast==cn & is.na(IG$rho) & is.na(IG$n_genes)), ]
  z
}
for (setting in c(names(settings), "estimated", "fry")) {
  for (s in names(STR)) for (p in names(FOCAL)) {
    zs <- sapply(names(STR[[s]]), function(d) {
      z <- pick(s, d, STR[[s]][[d]], setting)
      z <- z[z$programme == FOCAL[[p]], ]
      signed_z_of(z$PValue, z$direction)
    })
    Z <- sum(zs)/sqrt(length(zs))
    rows[[length(rows)+1]] <- data.frame(setting=setting, stratum=s, program=p, k=length(zs),
      n_up=sum(zs>0), Z=Z, p=2*pnorm(-abs(Z)), z_by_study=paste(round(zs,3),collapse="|"))
  }
}
S <- do.call(rbind, rows); rownames(S) <- NULL
for (st in unique(S$setting)) {
  i <- S$setting==st
  S$fdr5[i] <- ave(S$p[i], S$stratum[i], FUN=function(x) p.adjust(x,"BH"))
}
S$cat5 <- cat_cut(S$fdr5)
write.csv(S, file.path(SC_OUT, "igc_synthesis.csv"), row.names=FALSE)
## retention versus the pre-specified 0.01 baseline, at the SYNTHESIS level
bas <- S[S$setting=="rho0.01", c("stratum","program","Z","fdr5","cat5")]
names(bas)[3:5] <- c("Z_base","fdr_base","cat_base")
out <- list()
for (st in setdiff(unique(S$setting), "rho0.01")) {
  a <- merge(bas, S[S$setting==st, c("stratum","program","Z","fdr5","cat5")], by=c("stratum","program"))
  out[[st]] <- data.frame(setting=st, focus_programmes=15,
    direction_kept=sum(sign(a$Z_base)==sign(a$Z)), category_kept=sum(a$cat_base==a$cat5),
    changed_to_ns=sum(a$cat_base!="ns" & a$cat5=="ns"),
    changed_from_ns=sum(a$cat_base=="ns" & a$cat5!="ns"))
}
RET <- do.call(rbind, out); rownames(RET) <- NULL
write.csv(RET, file.path(SC_OUT, "igc_synthesis_retention.csv"), row.names=FALSE)
print(RET, row.names=FALSE)
cat("\n=== synthesis-level FDR by setting, focal programmes ===\n")
print(reshape(S[,c("stratum","program","setting","Z","fdr5","cat5")], idvar=c("stratum","program"),
      timevar="setting", direction="wide"), digits=3, row.names=FALSE)
