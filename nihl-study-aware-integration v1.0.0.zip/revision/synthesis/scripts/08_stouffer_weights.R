## Weighted Stouffer sensitivity, Appendix B2.2.  All three weightings reported side by side.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds"))
STR <- syn_strata(); NU <- syn_nunits()

build <- function(scheme) {
  IMM <- syn_objects(O, scheme)
  rows <- list()
  for (s in names(STR)) for (p in names(FOCAL)) {
    d <- names(STR[[s]])
    zs <- sapply(d, function(k) z_of(IMM[[k]], STR[[s]][[k]], FOCAL[[p]]))
    n12 <- NU[[s]][d]                       # biological units per group
    dfm <- sapply(d, function(k) df_total_median(IMM[[k]], STR[[s]][[k]]))
    w_eq  <- rep(1, length(zs))
    w_sn  <- sqrt(2 * n12)                  # sqrt(n1 + n2)
    w_df  <- sqrt(dfm)                      # sqrt(df.residual + df.prior)
    Zeq <- sum(w_eq*zs)/sqrt(sum(w_eq^2))
    Zsn <- sum(w_sn*zs)/sqrt(sum(w_sn^2))
    Zdf <- sum(w_df*zs)/sqrt(sum(w_df^2))
    rows[[length(rows)+1]] <- data.frame(
      scheme_GSE196870 = scheme, stratum = s, program = p,
      k = length(zs), n_up = sum(zs > 0), n_down = sum(zs < 0),
      Z_equal = Zeq, Z_sqrtn = Zsn, Z_df = Zdf,
      dZ_sqrtn_vs_equal = Zsn - Zeq, dZ_df_vs_equal = Zdf - Zeq,
      sign_same_sqrtn = sign(Zsn) == sign(Zeq), sign_same_df = sign(Zdf) == sign(Zeq),
      studies = paste(d, collapse = ";"),
      z_by_study = paste(sprintf("%s:%.4f", d, zs), collapse = " | "),
      w_sqrtn = paste(sprintf("%s:%.4f", d, w_sn), collapse = " | "),
      w_df = paste(sprintf("%s:%.3f", d, w_df), collapse = " | "))
  }
  R <- do.call(rbind, rows)
  R$p_equal <- 2*pnorm(-abs(R$Z_equal)); R$p_sqrtn <- 2*pnorm(-abs(R$Z_sqrtn)); R$p_df <- 2*pnorm(-abs(R$Z_df))
  for (col in c("equal","sqrtn","df")) {
    R[[paste0("fdr5_",col)]]  <- ave(R[[paste0("p_",col)]], R$stratum, FUN=function(x) p.adjust(x,"BH"))
    R[[paste0("fdr50_",col)]] <- ave(R[[paste0("p_",col)]], R$stratum, FUN=function(x) p.adjust(x,"BH"))
  }
  R$cat5_equal  <- cut(R$fdr5_equal,  c(-Inf,.05,.10,Inf), labels=c("conf","expl","ns"))
  R$cat5_sqrtn  <- cut(R$fdr5_sqrtn,  c(-Inf,.05,.10,Inf), labels=c("conf","expl","ns"))
  R$cat5_df     <- cut(R$fdr5_df,     c(-Inf,.05,.10,Inf), labels=c("conf","expl","ns"))
  R
}
ALL <- rbind(build(PRIMARY_SCHEME), build(ALT_SCHEME))
write.csv(ALL, file.path(SC_OUT, "stouffer_sensitivity_prelim.csv"), row.names=FALSE)
print(ALL[ALL$scheme_GSE196870==PRIMARY_SCHEME, c("stratum","program","k","n_up","Z_equal","Z_sqrtn","Z_df",
      "fdr5_equal","fdr5_sqrtn","fdr5_df","cat5_equal","cat5_sqrtn","cat5_df")], digits=5, row.names=FALSE)
cat("\n--- sign agreement of the three weightings (S1), 15 combinations ---\n")
S1 <- ALL[ALL$scheme_GSE196870==PRIMARY_SCHEME,]
cat("sign same (sqrtn vs equal):", sum(S1$sign_same_sqrtn), "/", nrow(S1), "\n")
cat("sign same (df vs equal):", sum(S1$sign_same_df), "/", nrow(S1), "\n")
cat("category same (sqrtn vs equal):", sum(S1$cat5_sqrtn==S1$cat5_equal), "/", nrow(S1), "\n")
cat("category same (df vs equal):", sum(S1$cat5_df==S1$cat5_equal), "/", nrow(S1), "\n")
saveRDS(ALL, file.path(SC_CACHE, "stouffer_weights.rds"))
