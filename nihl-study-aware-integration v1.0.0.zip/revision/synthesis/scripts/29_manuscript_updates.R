## Problem 1 and 2 of the first rework: every number the manuscript and the response letter carry
## from the IGC analysis, side by side with its S0 value, plus the two replacement sentences.
##
## Values are read from the delivered tables only; nothing is typed in by hand.
## Usage: Rscript 29_manuscript_updates.R <S0_dir> <S1_dir> <out_updates.csv> <out_counts.csv> <out_sentences.txt>
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R"))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) == 5L)
rd <- function(d,f) read.csv(file.path(d,f), stringsAsFactors = FALSE, check.names = FALSE)

## ---------- Problem 1: the six 450-comparison proportions ----------
S0 <- rd(A[1], "igc_retention_summary.csv"); S1 <- rd(A[2], "igc_retention_summary.csv")
m <- function(z, st, col) z[[col]][z$setting == st]
U <- list()
add <- function(claim_key, position, old, new, fmt) {
  U[[length(U)+1]] <<- data.frame(claim_key = claim_key, position = position,
    original_value = old, S0_value = new,
    changed = ifelse(isTRUE(all.equal(as.character(old), as.character(new))), "no", "YES"),
    display = fmt, stringsAsFactors = FALSE)
}
order_st <- c("rho0.05","rho0.1","estimated","fry")
## direction preserved
for (st in order_st) {
  o <- m(S1, st, "direction_preserved"); n <- m(S0, st, "direction_preserved")
  add(sprintf("direction_preserved_%s", st), "Manuscript Results 3.4 / response letter R1-3(d)",
      sprintf("%.4f", o), sprintf("%.4f", n),
      sprintf("%s: %s -> %s%s", st, sprintf("%.4f", o), sprintf("%.4f", n),
              if (sprintf("%.4f", o) == sprintf("%.4f", n)) " (unchanged)" else " (CHANGED)"))
}
for (st in order_st) {
  o <- m(S1, st, "fdr_category_preserved"); n <- m(S0, st, "fdr_category_preserved")
  add(sprintf("fdr_category_preserved_%s", st), "Manuscript Results 3.4 / response letter R1-3(d)",
      sprintf("%.4f", o), sprintf("%.4f", n),
      sprintf("%s: %s -> %s%s", st, sprintf("%.4f", o), sprintf("%.4f", n),
              if (sprintf("%.4f", o) == sprintf("%.4f", n)) " (unchanged)" else " (CHANGED)"))
}
## the synthesis-level retention rows, for completeness (these do NOT change)
R0 <- rd(A[1], "igc_synthesis_retention.csv"); R1 <- rd(A[2], "igc_synthesis_retention.csv")
for (st in order_st) {
  for (col in c("direction_kept","category_kept","changed_to_ns","changed_from_ns")) {
    o <- R1[[col]][R1$setting == st]; n <- R0[[col]][R0$setting == st]
    add(sprintf("synthesis_%s_%s", col, st), "Manuscript Results 3.4 / response letter R1-3(d)",
        as.character(o), as.character(n), sprintf("%s %s: %s -> %s (unchanged)", st, col, o, n))
  }
}
## 7 of 15
c0 <- rd(A[1], "igc_conf_to_ns_estimated.csv"); c0 <- c0[c0$scheme == "S0_primary", ]
add("conf_to_ns_estimated_count", "Manuscript Results 3.4 / response letter R1-3(d)",
    "7 of 15", sprintf("%d of 15", nrow(c0)),
    sprintf("estimated: 7 of 15 -> %d of 15%s", nrow(c0), if (nrow(c0) == 7) " (unchanged)" else " (CHANGED)"))

U <- do.call(rbind, U)
write.csv(U, A[3], row.names = FALSE)

## ---------- Problem 2: the five-setting category counts and the two sentences ----------
f <- rd(A[1], "igc_synthesis_focal15.csv")
sets <- c("rho0.01","rho0.05","rho0.1","estimated","fry")
CNT <- do.call(rbind, lapply(sets, function(st) {
  v <- f[[paste0("cat5_", st)]]
  data.frame(setting = st, conf = sum(v == "conf"), expl = sum(v == "expl"), ns = sum(v == "ns"),
             total = length(v), stringsAsFactors = FALSE)
}))
write.csv(CNT, A[4], row.names = FALSE)

allc <- f$stratum[f$cat5_rho0.01 != ""]
keep_all <- which(apply(sapply(sets, function(st) f[[paste0("cat5_", st)]] == "conf"), 1, all))
ns_all   <- which(apply(sapply(sets, function(st) f[[paste0("cat5_", st)]] == "ns"), 1, all))
same_all <- which(apply(sapply(sets, function(st) f[[paste0("cat5_", st)]] == f$cat5_rho0.01), 1, all))
## manuscript wording for the five programmes and the three strata
PLAB <- c(TNFA = "TNF-alpha/NF-kB signalling", INFL = "inflammatory response",
          UPR = "unfolded protein response", OXPHOS = "oxidative phosphorylation",
          E2F = "E2F targets")
SLAB <- c(acute = "acute", h24 = "approximately 24-h", later = "later")
lab <- function(i) sprintf("%s %s", f$stratum[i], f$program[i])
named <- function(strat, prog) sprintf("%s %s", SLAB[strat], PLAB[prog])
confns <- rd(A[1], "igc_conf_to_ns_estimated.csv"); confns <- confns[confns$scheme == "S0_primary", ]
confns <- confns[order(match(confns$stratum, c("acute","h24","later")), match(confns$program, names(FOCAL))), ]

fmt_list <- function(x, last = " and ") paste0(paste(x[-length(x)], collapse = ", "), last, x[length(x)])
s1 <- sprintf(paste0("Under the data-estimated correlation, %d of the 15 focal stratum-by-programme combinations ",
  "that reached FDR < 0.05 at the pre-specified inter-gene correlation of 0.01 lost that category (%s); ",
  "all seven kept their direction, and the same seven combinations are affected under either GSE196870 scale."),
  nrow(confns), fmt_list(mapply(named, confns$stratum, confns$program)))
s2 <- sprintf(paste0("%s retained the confident category under all five settings (%d of 15); ",
  "%s remained non-significant throughout, and the remaining %d changed category in at least one setting."),
  fmt_list(mapply(named, f$stratum[keep_all], f$program[keep_all])), length(keep_all),
  fmt_list(mapply(named, f$stratum[ns_all], f$program[ns_all])),
  15L - length(keep_all) - length(ns_all))
L <- c("REPLACEMENT SENTENCES (Results 3.4, inter-gene correlation paragraph)", "",
  "Sentence 1 -- replaces the partial list 'acute E2F and the approximately 24-h oxidative",
  "phosphorylation and E2F results':", "", s1, "",
  "Sentence 2 -- replaces 'TNF-alpha/NF-kB and unfolded protein response retained their evidence",
  "classes under all settings':", "", s2, "",
  "Five settings x category counts (igc_synthesis_focal15.csv, S0 primary scheme):",
  sprintf("  %-10s %5s %5s %5s %6s", "setting","conf","expl","ns","total"),
  sprintf("  %-10s %5d %5d %5d %6d", CNT$setting, CNT$conf, CNT$expl, CNT$ns, CNT$total), "",
  "Confident under all five settings:", sprintf("  %s", sprintf("%s %s", f$stratum[keep_all], f$program[keep_all])),
  "Non-significant under all five settings:", sprintf("  %s", sprintf("%s %s", f$stratum[ns_all], f$program[ns_all])),
  "Category identical to rho0.01 under all five settings:",
  sprintf("  %s", sprintf("%s %s", f$stratum[same_all], f$program[same_all])), "",
  "Notes computed from the table, not asserted:",
  sprintf("  later UPR is %s under %s -- so the old sentence is false for the later stratum",
          paste(unique(unlist(lapply(c("rho0.05","rho0.1","estimated"), function(st)
            f[[paste0("cat5_", st)]][f$stratum=="later" & f$program=="UPR"]))), collapse="/"),
          "rho0.05, rho0.1 and estimated"),
  sprintf("  acute UPR is conf under all five settings: %s", all(f[f$stratum=="acute" & f$program=="UPR",
          paste0("cat5_", sets)] == "conf")),
  sprintf("  h24 UPR is conf under all five settings: %s (rho0.1 = %s)", all(f[f$stratum=="h24" & f$program=="UPR",
          paste0("cat5_", sets)] == "conf"), f$cat5_rho0.1[f$stratum=="h24" & f$program=="UPR"]),
  sprintf("  the %d combinations that are neither all-conf nor all-ns all change category in at least one setting: %s",
          15 - length(keep_all) - length(ns_all),
          all(vapply(seq_len(nrow(f)), function(i)
            if (i %in% c(keep_all, ns_all)) TRUE else
              any(vapply(sets, function(st) f[[paste0("cat5_",st)]][i] != f$cat5_rho0.01[i], logical(1))),
            logical(1)))))
cat(paste(L, collapse = "\n"), "\n"); writeLines(L, A[5])

## the two sentences also go into manuscript_number_updates.csv as extra rows
S <- rbind(U, data.frame(claim_key = c("replacement_sentence_1", "replacement_sentence_2"),
  position = "Manuscript Results 3.4", original_value = c(
    "acute E2F and the approximately 24-h oxidative phosphorylation and E2F results",
    "TNF-alpha/NF-kB and unfolded protein response retained their evidence classes under all settings"),
  S0_value = c(s1, s2), changed = "YES",
  display = c("sentence listing the seven combinations", "sentence naming the combinations that hold"),
  stringsAsFactors = FALSE))
write.csv(S, A[3], row.names = FALSE)
cat("\nupdates rows:", nrow(S), " changed:", sum(S$changed == "YES"), "\n")
