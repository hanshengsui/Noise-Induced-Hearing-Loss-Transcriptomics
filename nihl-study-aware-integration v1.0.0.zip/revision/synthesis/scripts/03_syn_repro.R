# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds"))
for (scheme in c(PRIMARY_SCHEME, ALT_SCHEME)) {
  IMM <- syn_objects(O, scheme); STR <- syn_strata(); NU <- syn_nunits()
  rows <- list()
  for (s in names(STR)) for (p in names(FOCAL)) {
    zs <- sapply(names(STR[[s]]), function(d) z_of(IMM[[d]], STR[[s]][[d]], FOCAL[[p]]))
    Z <- sum(zs)/sqrt(length(zs))
    rows[[length(rows)+1]] <- data.frame(scheme=scheme, stratum=s, program=p, k=length(zs),
      n_up=sum(zs>0), Z=Z, p=2*pnorm(-abs(Z)), z=paste(round(zs,4),collapse="|"),
      studies=paste(names(zs),collapse=";"))
  }
  R <- do.call(rbind, rows)
  R$fdr5 <- ave(R$p, R$stratum, FUN=function(x) p.adjust(x,"BH"))
  cat("\n==== GSE196870 scheme:", scheme, "\n")
  print(R[,c("stratum","program","k","n_up","Z","fdr5")], digits=5, row.names=FALSE)
  saveRDS(R, file.path(SC_CACHE, paste0("syn_repro_", scheme, ".rds")))
}
