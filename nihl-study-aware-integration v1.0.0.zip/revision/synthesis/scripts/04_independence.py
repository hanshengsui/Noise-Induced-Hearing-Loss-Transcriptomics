import os
# SC_CACHE / SC_OUT as for the R scripts (defaults: revision/synthesis/cache and revision/synthesis/results)
_ROOT = os.environ.get("SC_ROOT", os.path.abspath(os.path.join(os.getcwd(), "..", "..", "..")))
CACHE = os.environ.get("SC_CACHE", os.path.join(_ROOT, "revision", "synthesis", "cache"))
OUT   = os.environ.get("SC_OUT",   os.path.join(_ROOT, "revision", "synthesis", "results"))
RAW   = os.path.join(CACHE, "gsm_raw")
os.makedirs(RAW, exist_ok=True); os.makedirs(OUT, exist_ok=True)
import glob, os, re, json, itertools, csv
def parse(f):
    recs={}; cur=None
    for line in open(f,errors="replace"):
        line=line.rstrip("\r\n")
        if line.startswith("^SAMPLE"):
            cur=line.split("=")[1].strip(); recs[cur]={}
        elif cur and line.startswith("!"):
            body=line[1:]
            if " = " in body:
                k,v=body.split(" = ",1)
                recs[cur].setdefault(k,[]).append(v.strip())
    return recs

accs=["GSE160639","GSE196870","GSE312476","GSE100365","GSE168041","GSE107086","GSE312646","GSE8342","GSE107087"]
info={}
for f in sorted(glob.glob(RAW+"/*_gsm.txt")):
    acc=os.path.basename(f).split("_")[0]
    r=parse(f)
    bios=set(); srxs=set(); gsms=set(r); strains=set(); tissues=set(); libs=set()
    for gs,d in r.items():
        for rel in d.get("Sample_relation",[]):
            m=re.search(r"biosample/(SAM\w+)",rel,re.I)
            if m: bios.add(m.group(1))
            m=re.search(r"sra\?term=(SR[RX]\d+)",rel,re.I)
            if m: srxs.add(m.group(1))
        for c in d.get("Sample_characteristics_ch1",[]):
            m=re.match(r"(?i)strain:\s*(.+)",c)
            if m: strains.add(m.group(1).strip())
            m=re.match(r"(?i)tissue:\s*(.+)",c)
            if m: tissues.add(m.group(1).strip())
        for k in ("Sample_library_strategy",):
            for v in d.get(k,[]): libs.add(v)
    info[acc]=dict(n_gsm=len(gsms), gsms=sorted(gsms), biosamples=sorted(bios), srxs=sorted(srxs),
                   strains=sorted(strains), tissues=sorted(tissues), library_strategy=sorted(libs))
    print(f"{acc:10s} GSM={len(gsms):3d} BioSample={len(bios):3d} SRX={len(srxs):3d} strains={sorted(strains)}")

print("\n=== pairwise overlaps ===")
found=False
for a,b in itertools.combinations(accs,2):
    if a not in info or b not in info: continue
    o1=set(info[a]["gsms"])&set(info[b]["gsms"])
    o2=set(info[a]["biosamples"])&set(info[b]["biosamples"])
    o3=set(info[a]["srxs"])&set(info[b]["srxs"])
    if o1 or o2 or o3:
        found=True; print(a,b,"GSM",len(o1),"BioSample",len(o2),"SRX",len(o3))
if not found: print("no GSM/BioSample/SRX overlap in any pair")
json.dump(info, open(RAW+"/independence_raw.json","w"), indent=1)
