## Unit test: sign convention of the strain x noise interaction contrast in 01_GSE8342_analysis.R
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
suppressPackageStartupMessages({library(limma)})
lv <- c("resistant_control","resistant_noise","susceptible_control","susceptible_noise")
des <- model.matrix(~0 + factor(rep(lv, each = 3), levels = lv)); colnames(des) <- lv
C <- cbind(strain_by_noise_interaction = c(-1,1,1,-1)); rownames(C) <- lv
mk <- function(mu, seed) { set.seed(seed)
  base <- rep(mu[lv], each = 3)                    # 12 samples in design order
  y <- matrix(rep(base, times = 24) + rnorm(24*12, sd = 0.05), nrow = 24, byrow = TRUE)
  rownames(y) <- paste0("g", seq_len(24)); colnames(y) <- paste0("s", seq_len(12)); y }
run <- function(mu, seed) { y <- mk(mu, seed); f <- eBayes(contrasts.fit(lmFit(y, des), C))
  f$coefficients[1,1] }
caseA <- run(c(resistant_control=0, resistant_noise=2, susceptible_control=0, susceptible_noise=0.5), 11)
caseB <- run(c(resistant_control=0, resistant_noise=0.5, susceptible_control=0, susceptible_noise=2), 11)
out <- data.frame(
  case = c("resistant effect +2.0, susceptible effect +0.5", "resistant effect +0.5, susceptible effect +2.0"),
  expected_interaction = c(1.5, -1.5),
  estimated_interaction = c(caseA, caseB),
  sign_matches = sign(c(caseA, caseB)) == sign(c(1.5, -1.5)))
print(out, digits = 4, row.names = FALSE)
stopifnot(all(out$sign_matches))
cat("\nCONCLUSION: with levels ordered resistant_control < resistant_noise < susceptible_control < susceptible_noise",
    "\nand contrast c(-1,+1,+1,-1), a POSITIVE coefficient means the noise-induced increase is LARGER IN THE",
    "\nRESISTANT (129X1/SvJ) strain, i.e. interaction = (resistant_noise - resistant_control) -",
    "\n(susceptible_noise - susceptible_control).\n")
write.csv(out, file.path(SC_OUT, "gse8342_interaction_sign_unit_test.csv"), row.names = FALSE)
