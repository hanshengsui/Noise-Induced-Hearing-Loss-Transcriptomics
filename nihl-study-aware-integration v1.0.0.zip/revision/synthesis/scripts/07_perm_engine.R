## ---------------------------------------------------------------------------
## Appendix B2.3 engine: within-study label permutation (fully enumerated where possible)
## -> study-level signed-z null -> synthesis-null by independent row draws.
## Every refit reproduces the main-analysis model exactly (same series/variable set,
## same covariates, same trend/robust settings); for voom studies the voom weights are
## re-estimated on the permuted design so the whole pipeline is inside the permutation.
## ---------------------------------------------------------------------------
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R"))
suppressPackageStartupMessages({library(limma); library(edgeR); library(statmod)})

fitstat_from_labels <- function(obj, lab, contrast_name) {
  gv <- obj$group_var
  cov <- obj$covar_frame          # covariate columns; dropped for single-level factors
  if (!is.null(cov)) cov <- cov[, vapply(seq_len(ncol(cov)), function(j) length(unique(cov[,j]))>1, logical(1)), drop=FALSE]
  lvls <- obj$lvls
  grp <- factor(lab, levels = lvls)
  d <- model.matrix(~ 0 + grp)
  colnames(d) <- lvls
  if (!is.null(cov) && ncol(cov) > 0) d <- cbind(d, cov)
  if (obj$scale == "voom") {
    dge <- DGEList(obj$counts)
    dge$samples$norm.factors <- obj$norm_factors
    v <- voom(dge, d, plot = FALSE)
    fit <- lmFit(v, d)
  } else {
    fit <- lmFit(obj$E, d)
  }
  sp <- strsplit(contrast_name, "|", fixed = TRUE)[[1]]        # "g2|g1"
  cm <- matrix(0, ncol(d), 1, dimnames = list(colnames(d), "diff"))
  cm[sp[1], 1] <- 1; cm[sp[2], 1] <- -1
  f <- eBayes(contrasts.fit(fit, cm), robust = TRUE, trend = obj$trend)
  tt <- topTable(f, coef = 1, number = Inf, sort.by = "none")
  stat <- tt$t; names(stat) <- obj$symbols
  stat
}


## Observed study-level signed z, computed from the real labels only.
observed_z <- function(obj, contrast_name, hallmark, order50, inter.gene.cor = 0.01) {
  stat <- fitstat_from_labels(obj, obj$meta[[obj$group_var]], contrast_name)
  z_vector(camera_pr_signed(stat, hallmark, inter.gene.cor), order50)
}

## Enumerated null for one study/contrast.
perm_null_study <- function(obj, g1, g2, block_col = NULL, hallmark, order50,
                            inter.gene.cor = 0.01, verbose = FALSE) {
  lab_all <- as.character(obj$meta[[obj$group_var]])
  s <- which(lab_all %in% c(g1, g2))
  lab <- lab_all[s]
  blk <- if (!is.null(block_col)) as.character(obj$meta[[block_col]][s]) else NULL
  perms <- enumerate_relabelings(lab, blk)
  Z <- matrix(NA_real_, length(perms), length(order50), dimnames = list(NULL, order50))
  cn <- paste0(g2, "|", g1)
  for (b in seq_along(perms)) {
    lab2 <- lab_all; lab2[s] <- perms[[b]]
    stat <- fitstat_from_labels(obj, lab2, cn)
    Z[b, ] <- z_vector(camera_pr_signed(stat, hallmark, inter.gene.cor), order50)
    if (verbose && b %% 25 == 0) cat("    perm", b, "/", length(perms), "\n")
  }
  list(null = Z, n_perms = length(perms), observed = lab, perms = perms, block = block_col)
}
