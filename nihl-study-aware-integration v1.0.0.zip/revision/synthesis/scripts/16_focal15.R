## Step 8 -- per-combination table for the 15 focal stratum x programme combinations, and the
## list of combinations whose synthesis-level FDR category moves conf -> ns under the
## data-estimated correlation setting, for BOTH GSE196870 schemes.
##
## Z, fdr5 and cat5 are computed exactly as in 13_igc_synthesis.R:
##   Z(s,p)  = sum_k z_k / sqrt(k),  z_k = signed_z_of(PValue, direction)
##   fdr5    = BH across the 5 focal programmes WITHIN the stratum, per setting
##   cat5    = cut(fdr5, c(-Inf,.05,.10,Inf)) -> conf / expl / ns
## No statistic is recomputed here: everything is read from the two runs' igc.rds.
## Usage: Rscript 16_focal15.R <S0 igc.rds> <S1 igc.rds> <out_focal15.csv> <out_confns.csv>
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R"))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) == 4L)
cat_cut <- function(p) as.character(cut(p, c(-Inf,.05,.10,Inf), labels=c("conf","expl","ns")))
STR <- syn_strata()
settings <- list(rho0.01=0.01, rho0.05=0.05, rho0.1=0.1)

## pick() copied verbatim from 13_igc_synthesis.R
pick <- function(IG, s, study, cn, setting) {
  z <- if (setting %in% names(settings)) IG[which(IG$stratum==s & IG$study==study & IG$contrast==cn &
          !is.na(IG$rho) & IG$rho == settings[[setting]]), ]
       else if (setting=="estimated") IG[which(IG$stratum==s & IG$study==study & IG$contrast==cn &
          is.na(IG$rho) & !is.na(IG$n_genes)), ]
       else IG[which(IG$stratum==s & IG$study==study & IG$contrast==cn & is.na(IG$rho) & is.na(IG$n_genes)), ]
  z
}
## synthesis table for one run -- identical loop structure to 13_igc_synthesis.R
synth_table <- function(rds) {
  IG <- readRDS(rds)$IG
  rows <- list()
  for (setting in c(names(settings), "estimated", "fry")) {
    for (s in names(STR)) for (p in names(FOCAL)) {
      zs <- sapply(names(STR[[s]]), function(d) {
        z <- pick(IG, s, d, STR[[s]][[d]], setting)
        z <- z[z$programme == FOCAL[[p]], ]
        signed_z_of(z$PValue, z$direction)
      })
      Z <- sum(zs)/sqrt(length(zs))
      rows[[length(rows)+1]] <- data.frame(setting=setting, stratum=s, program=p, k=length(zs),
        n_up=sum(zs>0), Z=Z, p=2*pnorm(-abs(Z)), z_by_study=paste(round(zs,3),collapse="|"))
    }
  }
  S <- do.call(rbind, rows); rownames(S) <- NULL
  for (st in unique(S$setting)) {
    i <- S$setting==st
    S$fdr5[i] <- ave(S$p[i], S$stratum[i], FUN=function(x) p.adjust(x,"BH"))
  }
  S$cat5 <- cat_cut(S$fdr5)
  S
}
S0 <- synth_table(A[1]); S1 <- synth_table(A[2])
## sanity: same 15x5 grid in both
stopifnot(nrow(S0) == 75L, nrow(S1) == 75L)

## ---- focal15 wide table
f <- S0[S0$setting=="rho0.01", c("stratum","program","k","n_up")]
stopifnot(nrow(f) == 15L)
ord <- c("rho0.01","rho0.05","rho0.1","estimated","fry")
f <- f[order(match(f$stratum, c("acute","h24","later")), match(f$program, names(FOCAL))), ]
for (st in ord) {
  z <- S0[S0$setting==st, ]
  m <- match(paste(f$stratum, f$program), paste(z$stratum, z$program))
  f[[paste0("Z_", st)]]       <- z$Z[m]
  f[[paste0("fdr5_", st)]]    <- z$fdr5[m]
  f[[paste0("cat5_", st)]]    <- z$cat5[m]
}
z1 <- S1[S1$setting=="estimated", ]
m1 <- match(paste(f$stratum, f$program), paste(z1$stratum, z1$program))
f$Z_estimated_S1 <- z1$Z[m1]; f$fdr5_estimated_S1 <- z1$fdr5[m1]; f$cat5_estimated_S1 <- z1$cat5[m1]
## names requested: Z, fdr5, cat5 per setting
names(f) <- sub("^(Z|fdr5|cat5)_rho0[.]01$", "\\1_0.01", names(f))
names(f) <- sub("^(Z|fdr5|cat5)_rho0[.]05$", "\\1_0.05", names(f))
names(f) <- sub("^(Z|fdr5|cat5)_rho0[.]1$",   "\\1_0.1",  names(f))
write.csv(f, A[3], row.names = FALSE)

## ---- conf -> ns list under 'estimated', computed from the full 15-row table for each run
confns <- function(S, scheme) {
  b <- S[S$setting=="rho0.01", c("stratum","program","Z","fdr5","cat5")]
  names(b)[3:5] <- c("Z_001","fdr5_001","cat5_001")
  e <- S[S$setting=="estimated", c("stratum","program","Z","fdr5","cat5")]
  names(e)[3:5] <- c("Z_est","fdr5_est","cat5_est")
  m <- merge(b, e, by=c("stratum","program"))
  m <- m[m$cat5_001 == "conf" & m$cat5_est == "ns", ]
  m <- m[order(match(m$stratum, c("acute","h24","later")), match(m$program, names(FOCAL))), ]
  data.frame(scheme=scheme, stratum=m$stratum, program=m$program,
             Z_0.01=m$Z_001, fdr5_0.01=m$fdr5_001, Z_estimated=m$Z_est, fdr5_estimated=m$fdr5_est,
             stringsAsFactors=FALSE)
}
CN <- rbind(confns(S0, "S0_primary"), confns(S1, "S1_sensitivity"))
write.csv(CN, A[4], row.names = FALSE)
cat("focal15 rows:", nrow(f), " conf->ns rows:", nrow(CN), "\n")
cat("  by scheme:", paste(names(table(CN$scheme)), as.integer(table(CN$scheme)), collapse=" / "), "\n")
cat("S0 conf->ns:\n"); print(CN[CN$scheme=="S0_primary", c("stratum","program","Z_0.01","Z_estimated")], row.names=FALSE, digits=4)
cat("S1 conf->ns:\n"); print(CN[CN$scheme=="S1_sensitivity", c("stratum","program","Z_0.01","Z_estimated")], row.names=FALSE, digits=4)
saveRDS(list(S0=S0, S1=S1, focal15=f, confns=CN), file.path(SC_CACHE, "focal15.rds"))
