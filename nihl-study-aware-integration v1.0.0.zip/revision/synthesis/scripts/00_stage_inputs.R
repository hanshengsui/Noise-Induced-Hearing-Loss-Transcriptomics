## Assemble the flat input directory that the synthesis scripts read.
## Source files come from the pipeline's own download tree (data/raw, filled by scripts/00_download.R)
## and from resources/.  Every file is checked against the MD5 in config/input_manifest.csv.
SC_ROOT <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_DL   <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
raw <- file.path(SC_ROOT, "data", "raw")
dir.create(file.path(SC_DL, "E-MTAB-16125", "featureCounts"), recursive = TRUE, showWarnings = FALSE)
man <- read.csv(file.path(SC_ROOT, "config", "input_manifest.csv"), stringsAsFactors = FALSE)
man <- man[man$accession != "GSE168041", ]          # the single-cell archive is not used by the synthesis scripts
plan <- data.frame(from = character(), to = character(), md5 = character(), stringsAsFactors = FALSE)
for (i in seq_len(nrow(man))) {
  acc <- man$accession[i]; f <- man$file[i]
  from <- file.path(raw, acc, f)
  to <- if (acc == "E-MTAB-16125") file.path(SC_DL, "E-MTAB-16125", f) else file.path(SC_DL, basename(f))
  plan[nrow(plan) + 1L, ] <- list(from, to, man$md5[i])
}
for (i in seq_len(nrow(plan))) {
  stopifnot(file.exists(plan$from[i]))
  got <- unname(tools::md5sum(plan$from[i]))
  if (!identical(tolower(got), tolower(plan$md5[i]))) stop("MD5 mismatch: ", plan$from[i])
  file.copy(plan$from[i], plan$to[i], overwrite = TRUE)
}
file.copy(file.path(SC_ROOT, "resources", "annotations", "mouse_gene_map.csv"), file.path(SC_DL, "mouse_gene_map.csv"), overwrite = TRUE)
file.copy(file.path(SC_ROOT, "resources", "gene_sets", "h.all.v2024.1.Hs.symbols.gmt"), file.path(SC_DL, "h.all.v2024.1.Hs.symbols.gmt"), overwrite = TRUE)
cat(sprintf("staged %d public input files (MD5-verified) plus the gene map and the Hallmark GMT in %s\n", nrow(plan), SC_DL))
