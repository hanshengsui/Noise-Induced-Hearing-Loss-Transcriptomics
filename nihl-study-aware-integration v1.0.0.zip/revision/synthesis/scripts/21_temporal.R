## B2.7 temporal evidence table + D5 evidence grading + the two BH families (K17).
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds")); H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))
STR <- syn_strata(); NU <- syn_nunits(); LP <- syn_levelpairs()
set.seed(SEED_GLOBAL)
B <- 100000L
P <- readRDS(file.path(SC_CACHE, "perm_null_S0.rds"))
nulls <- list()
for (k in names(P$nulls)) { sp <- strsplit(k, "|", fixed=TRUE)[[1]]
  nulls[[sp[1]]][[sp[2]]] <- P$nulls[[k]] }
IUT <- read.csv(file.path(SC_PKG, "programme_activation_to_resolution_IUT.csv"))   # programme-level IUT (from the submitted package machine-readable tree)
print(head(IUT, 2)); cat("IUT columns:", paste(names(IUT), collapse=" | "), "\n")
## The IUT file is keyed by pathway; map the focal programmes
iut_of <- function(p) IUT[IUT$programme == FOCAL[[p]], ]
rows <- list()
for (p in names(FOCAL)) {
  rec <- list(program=p)
  for (s in c("acute","h24","later")) {
    d <- names(STR[[s]])
    zs <- sapply(d, function(k) z_of(O[[switch(k, GSE160639="GSE160639", GSE196870="GSE196870_S0",
      GSE312476="GSE312476", GSE100365="GSE100365", EMTAB="EMTAB")]], STR[[s]][[k]], FOCAL[[p]]))
    Z <- sum(zs)/sqrt(length(zs))
    ## permutation p, equal weights (recomputed here so the table is self-contained)
    set.seed(SEED_GLOBAL + match(s, c("acute","h24","later")))
    draws <- lapply(d, function(k) { M <- nulls[[s]][[k]]; M[sample.int(nrow(M), B, replace=TRUE), FOCAL[[p]]] })
    Z0 <- Reduce(`+`, draws)/sqrt(length(d))
    rec[[paste0(s,"_n_up")]] <- sum(zs > 0); rec[[paste0(s,"_k")]] <- length(zs)
    rec[[paste0(s,"_Z")]] <- Z
    rec[[paste0(s,"_p_emp")]] <- (1 + sum(abs(Z0) >= abs(Z) - 1e-10 * max(1, abs(Z))))/(B+1)
    rec[[paste0(s,"_z_by_study")]] <- paste(sprintf("%s:%+.3f", d, zs), collapse="|")
  }
  ii <- iut_of(p)
  rec$IUT_fdr <- if (nrow(ii)) ii$IUT_FDR[1] else NA_real_
  rec$IUT_supported <- if (nrow(ii)) ii$activation_to_resolution_supported[1] else NA
  rec$IUT_t_activation <- if (nrow(ii)) ii$early_camera_t[1] else NA_real_
  rec$IUT_t_resolution <- if (nrow(ii)) ii$late_transition_camera_t[1] else NA_real_
  rows[[p]] <- as.data.frame(rec, stringsAsFactors=FALSE)
}
T <- do.call(rbind, rows); rownames(T) <- NULL
## ---- D5 grading, applied verbatim: concordant = k/k same sign AND both weighted and unweighted
## synthesis FDR < 0.05.  FDR < 1e-10 is reported as a bound only.
W <- read.csv(file.path(SC_OUT, "stouffer_sensitivity.csv"))
W <- W[W$scheme_GSE196870==PRIMARY_SCHEME, ]
for (s in c("acute","h24","later")) for (p in names(FOCAL)) {
  i <- which(T$program==p)
  we <- W$fdr_emp[W$stratum==s & W$program==p & W$weighting=="w_equal"]
  ws <- W$fdr_emp[W$stratum==s & W$program==p & W$weighting=="w_sqrtn"]
  wd <- W$fdr_emp[W$stratum==s & W$program==p & W$weighting=="w_df"]
  T[[paste0(s,"_fdr_equal")]][i] <- we
  T[[paste0(s,"_fdr_sqrtn")]][i] <- ws
  T[[paste0(s,"_fdr_df")]][i] <- wd
  T[[paste0(s,"_grade")]][i] <- if (T[[paste0(s,"_n_up")]][i] == 0) {
      if (max(we,ws,wd) < 0.05) "concordant_decrease" else "direction_consistent_not_significant"
    } else if (T[[paste0(s,"_n_up")]][i] == T[[paste0(s,"_k")]][i]) {
      if (max(we,ws,wd) < 0.05) "concordant_increase" else "direction_consistent_not_significant"
    } else if (abs(2*T[[paste0(s,"_n_up")]][i] - T[[paste0(s,"_k")]][i]) <= 1) "majority_consistent"
      else "heterogeneous"
}
T$evidence_grade <- paste0("acute=", T$acute_grade, "; h24=", T$h24_grade, "; later=", T$later_grade)
## UPR must be labelled explicitly per D8
T$UPR_note <- ifelse(T$program=="UPR",
  "direction consistent early and in the later decline, but the formal activation-resolution IUT was NOT supported", "")
## later-stratum caveat (R2-m5)
T$later_stratum_note <- ifelse(T$program!="",
  "later stratum = 2 studies only (GSE100365 day 7 vs day 1, auditory nerve/modiolus; E-MTAB-16125 week 1 vs 72 h, whole cochlea); different intervals and different tissues, so not a common cochlear-compartment time response", "")
write.csv(T, file.path(SC_OUT, "temporal_evidence.csv"), row.names=FALSE)
print(T[, c("program","acute_n_up","acute_k","acute_Z","acute_p_emp","h24_n_up","h24_k","h24_Z","h24_p_emp",
            "later_n_up","later_k","later_Z","later_p_emp","IUT_fdr","IUT_supported","IUT_t_activation","IUT_t_resolution")], digits=4, row.names=FALSE)
cat("\n=== evidence grade (D5) ===\n")
print(T[, c("program","acute_grade","h24_grade","later_grade")], row.names=FALSE)
cat("\n=== FDR bounds: values below 1e-10 reported as a bound (publication rule) ===\n")
for (s in c("acute","h24","later")) for (w in c("fdr_equal","fdr_sqrtn","fdr_df")) {
  v <- T[[paste0(s,"_",w)]]
  cat(sprintf("%-6s %-10s min=%.3e  n_below_1e-10=%d\n", s, w, min(v,na.rm=TRUE), sum(v<1e-10,na.rm=TRUE)))
}
saveRDS(T, file.path(SC_CACHE, "temporal.rds"))
