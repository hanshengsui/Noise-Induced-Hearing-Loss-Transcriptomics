## Audit: which E-MTAB-16125 cameraPR table does my synthesis use?
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R"))
PK <- read.csv(file.path(SC_PKG, "E-MTAB-16125_programme_results_complete.csv"))   # package 06_Machine_Readable_Results/phase_transition
PK <- PK[PK$collection == "Human Hallmark v2024.1 direct-symbol match", ]
ALT <- read.csv(file.path(SC_PKG, "CAMERA_PR_EMTAB_timepoints.csv")) # legacy reanalysis
MINE <- readRDS(file.path(SC_CACHE, "expr.rds"))$EMTAB$camera
used <- c("h24_vs_control","week1_vs_h72")
## what the alternative (legacy reanalysis) table contains
cat("legacy reanalysis table: rows =", nrow(ALT), " analyses =", paste(unique(ALT$analysis), collapse=", "), "\n")
cat("legacy 'analysis' values vs my contrasts overlap:", sum(unique(ALT$analysis) %in% used), "\n")
cmp <- function(a, b, tag) {
  m <- merge(a, b, by=c("contrast","programme"), suffixes=c("_mine","_pkg"))
  data.frame(comparison=tag, n_cells=nrow(m),
    max_abs_dP=max(abs(m$PValue_mine-m$PValue_pkg)),
    max_abs_dt=max(abs(m$camera_t_mine-m$camera_t_pkg)),
    n_direction_mismatch=sum(m$direction_mine!=m$direction_pkg),
    n_ngenes_diff=sum(m$n_genes_mine!=m$n_genes_pkg))
}
r <- cmp(MINE, PK, "my_EMTAB_camera_vs_package_phase_transition")
r$n_cells_in_focal_contrasts <- sum(merge(MINE[MINE$contrast %in% used,], PK[PK$contrast %in% used,],
      by=c("contrast","programme"))$programme %in% FOCAL)
print(r, digits=6, row.names=FALSE)
## focal cells only, exact
m <- merge(MINE[MINE$programme %in% FOCAL & MINE$contrast %in% used,],
           PK[PK$programme %in% FOCAL & PK$contrast %in% used,],
           by=c("contrast","programme"), suffixes=c("_mine","_pkg"))
cat("\nfocal cells actually entering the synthesis:", nrow(m),
    " max|dP| =", max(abs(m$PValue_mine-m$PValue_pkg)),
    " max|dt| =", max(abs(m$camera_t_mine-m$camera_t_pkg)),
    " direction mismatches =", sum(m$direction_mine!=m$direction_pkg), "\n")
write.csv(r, file.path(SC_OUT, "emtrab_source_audit.csv"), row.names=FALSE)
## and record why the legacy reanalysis table was NOT used
L <- data.frame(
  item=c("legacy_reanalysis_ranked_universe","package_phase_transition_ranked_universe",
         "my_EMTAB_ranked_universe","legacy_analyses","legacy_reanalysis_contrasts_usable_for_synthesis"),
  value=c("15793 genes (full gene set, per the task note)",
          "14207 genes (filterByExpr before voom)",
          "14207 genes (reconstructed with the package script 03_emtab_phase_transition.R settings)",
          paste(unique(ALT$analysis), collapse="; "),
          paste(setdiff(unique(ALT$analysis), used), collapse="; ")))
write.csv(L, file.path(SC_OUT, "emtrab_source_notes.csv"), row.names=FALSE)
print(L, row.names=FALSE)
