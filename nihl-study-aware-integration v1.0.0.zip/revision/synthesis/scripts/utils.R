options(stringsAsFactors = FALSE)

ensure_dir <- function(path) {
  if (!dir.exists(path)) dir.create(path, recursive = TRUE, showWarnings = FALSE)
  invisible(path)
}

strip_quotes <- function(x) {
  x <- sub('^"', '', x)
  sub('"$', '', x)
}

read_geo_series_matrix <- function(path) {
  con <- gzfile(path, open = 'rt')
  on.exit(close(con), add = TRUE)
  lines <- readLines(con, warn = FALSE)
  begin <- grep('^!series_matrix_table_begin', lines)
  end <- grep('^!series_matrix_table_end', lines)
  if (length(begin) != 1L || length(end) != 1L || end <= begin) {
    stop('Could not locate GEO series-matrix table markers in: ', path)
  }

  sample_lines <- lines[seq_len(begin - 1L)]
  sample_lines <- sample_lines[grepl('^!Sample_', sample_lines)]
  meta_list <- list()
  key_counts <- integer()
  for (line in sample_lines) {
    parts <- strsplit(line, '\t', fixed = FALSE)[[1L]]
    key <- sub('^!Sample_', '', parts[1L])
    key_counts[key] <- ifelse(is.na(key_counts[key]), 1L, key_counts[key] + 1L)
    if (key_counts[key] > 1L) key_out <- paste0(key, '_', key_counts[key]) else key_out <- key
    meta_list[[key_out]] <- strip_quotes(parts[-1L])
  }

  table_lines <- lines[(begin + 1L):(end - 1L)]
  table_text <- paste(table_lines, collapse = '\n')
  tab <- read.delim(text = table_text, check.names = FALSE, quote = '"', comment.char = '')
  feature_id <- as.character(tab[[1L]])
  if (ncol(tab) > 1L) {
    expr <- as.matrix(tab[-1L])
    storage.mode(expr) <- 'numeric'
    rownames(expr) <- feature_id
    colnames(expr) <- strip_quotes(colnames(expr))
  } else {
    expr <- matrix(numeric(), nrow = length(feature_id), ncol = 0L)
    rownames(expr) <- feature_id
  }

  sample_ids <- if ('geo_accession' %in% names(meta_list)) meta_list[['geo_accession']] else colnames(expr)
  n <- length(sample_ids)
  sample_meta <- data.frame(sample_id = sample_ids, stringsAsFactors = FALSE)
  for (key in names(meta_list)) {
    value <- meta_list[[key]]
    if (length(value) == n) sample_meta[[key]] <- value
  }

  list(expr = expr, feature_id = feature_id, sample_meta = sample_meta, raw_lines = lines)
}

read_geo_annotation <- function(path) {
  con <- gzfile(path, open = 'rt')
  on.exit(close(con), add = TRUE)
  lines <- readLines(con, warn = FALSE)
  header <- grep('^ID\t', lines)[1L]
  if (is.na(header)) stop('Annotation table header not found in: ', path)
  read.delim(text = paste(lines[header:length(lines)], collapse = '\n'),
             check.names = FALSE, quote = '', comment.char = '')
}

median_ratio_normalize <- function(counts, min_count = 10, min_samples = 3, pseudocount = 0.5) {
  counts <- as.matrix(counts)
  storage.mode(counts) <- 'numeric'
  keep <- rowSums(counts >= min_count, na.rm = TRUE) >= min_samples
  filtered <- counts[keep, , drop = FALSE]
  if (nrow(filtered) == 0L) stop('No genes passed the count filter.')

  log_counts <- log(filtered)
  log_counts[!is.finite(log_counts)] <- NA_real_
  gm <- exp(rowMeans(log_counts, na.rm = TRUE))
  valid <- is.finite(gm) & gm > 0
  ratios <- sweep(filtered[valid, , drop = FALSE], 1L, gm[valid], '/')
  size_factors <- apply(ratios, 2L, function(z) median(z[is.finite(z) & z > 0], na.rm = TRUE))
  if (any(!is.finite(size_factors) | size_factors <= 0)) {
    stop('Failed to estimate positive median-ratio size factors.')
  }
  size_factors <- size_factors / exp(mean(log(size_factors)))
  normalized <- sweep(filtered, 2L, size_factors, '/')
  log_expr <- log2(normalized + pseudocount)
  list(counts = filtered, normalized = normalized, log_expr = log_expr,
       size_factors = size_factors, keep = keep)
}

fit_ols_contrasts <- function(y, design, contrasts, feature_table = NULL) {
  y <- as.matrix(y)
  design <- as.matrix(design)
  if (ncol(y) != nrow(design)) stop('Expression columns must match design rows.')
  if (qr(design)$rank < ncol(design)) stop('Design matrix is not full rank.')

  xtx_inv <- solve(crossprod(design))
  beta <- xtx_inv %*% crossprod(design, t(y))
  fitted <- design %*% beta
  residuals <- t(y) - fitted
  df <- nrow(design) - ncol(design)
  if (df <= 0L) stop('No residual degrees of freedom.')
  sigma2 <- colSums(residuals^2) / df

  output <- list()
  for (name in names(contrasts)) {
    cvec <- contrasts[[name]]
    if (is.null(names(cvec))) {
      if (length(cvec) != ncol(design)) stop('Unnamed contrast has wrong length: ', name)
      cfull <- as.numeric(cvec)
    } else {
      cfull <- setNames(rep(0, ncol(design)), colnames(design))
      unknown <- setdiff(names(cvec), colnames(design))
      if (length(unknown)) stop('Unknown design columns in contrast ', name, ': ', paste(unknown, collapse = ', '))
      cfull[names(cvec)] <- cvec
    }
    effect <- drop(cfull %*% beta)
    variance_multiplier <- drop(t(cfull) %*% xtx_inv %*% cfull)
    se <- sqrt(pmax(sigma2 * variance_multiplier, 0))
    statistic <- effect / se
    p_value <- 2 * pt(-abs(statistic), df = df)
    result <- data.frame(
      feature_id = rownames(y),
      contrast = name,
      log2FC = effect,
      SE = se,
      t = statistic,
      df = df,
      PValue = p_value,
      FDR = p.adjust(p_value, method = 'BH'),
      stringsAsFactors = FALSE
    )
    if (!is.null(feature_table)) {
      result <- cbind(feature_table[match(result$feature_id, feature_table$feature_id), , drop = FALSE],
                      result[, setdiff(names(result), 'feature_id'), drop = FALSE])
    }
    result <- result[order(result$PValue, -abs(result$log2FC)), , drop = FALSE]
    rownames(result) <- NULL
    output[[name]] <- result
  }
  output
}

write_result_list <- function(results, out_dir, prefix) {
  ensure_dir(out_dir)
  for (name in names(results)) {
    path <- file.path(out_dir, paste0(prefix, '__', name, '.csv.gz'))
    con <- gzfile(path, open = 'wt')
    write.csv(results[[name]], con, row.names = FALSE, na = '')
    close(con)
  }
}

summarize_result_list <- function(results, dataset, evidence_tier, provisional = TRUE) {
  do.call(rbind, lapply(names(results), function(name) {
    x <- results[[name]]
    data.frame(
      dataset = dataset,
      contrast = name,
      n_features = nrow(x),
      n_fdr_005 = sum(x$FDR < 0.05, na.rm = TRUE),
      n_abs_log2fc_05 = sum(abs(x$log2FC) >= 0.5, na.rm = TRUE),
      n_fdr_005_abs_log2fc_05 = sum(x$FDR < 0.05 & abs(x$log2FC) >= 0.5, na.rm = TRUE),
      evidence_tier = evidence_tier,
      provisional_ols = provisional,
      stringsAsFactors = FALSE
    )
  }))
}

collapse_to_symbols <- function(result, symbol_col = 'gene_symbol') {
  if (!symbol_col %in% names(result)) stop('Missing symbol column: ', symbol_col)
  x <- result[!is.na(result[[symbol_col]]) & nzchar(result[[symbol_col]]), , drop = FALSE]
  x <- x[order(x$PValue, -abs(x$log2FC)), , drop = FALSE]
  x[!duplicated(x[[symbol_col]]), , drop = FALSE]
}

