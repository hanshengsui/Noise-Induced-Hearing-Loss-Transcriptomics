## The permutation null shows the per-study signed z has SD ~1.5-2.0 and the synthesis null
## SD is 2.1-4.6, not 1.  This quantifies the inflation and gives the null-calibrated statistic.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
SS <- read.csv(file.path(SC_OUT, "stouffer_sensitivity.csv"))
S1 <- SS[SS$scheme_GSE196870 == PRIMARY_SCHEME, ]
S1$Z_calibrated <- S1$Z / S1$null_sd
S1$p_calibrated_two_sided <- 2*pnorm(-abs(S1$Z_calibrated))
for (w in unique(S1$weighting)) { i <- S1$weighting==w
  S1$fdr_calibrated[i] <- ave(S1$p_calibrated_two_sided[i], S1$stratum[i], FUN=function(x) p.adjust(x,"BH")) }
S1$fdr_inflation_factor <- S1$fdr_theory / pmax(S1$fdr_emp, 1e-300)
write.csv(S1, file.path(SC_OUT, "stouffer_calibrated.csv"), row.names=FALSE)
cat("=== equal weights: theoretical vs permutation-calibrated ===\n")
print(S1[S1$weighting=="w_equal", c("stratum","program","k","n_up","Z","null_sd","Z_calibrated",
      "p_theory","p_emp","fdr_theory","fdr_emp","fdr_calibrated")], digits=4, row.names=FALSE)
cat("\n=== how far the theoretical p is from the permutation p (equal weights) ===\n")
x <- S1[S1$weighting=="w_equal", c("stratum","program","p_theory","p_emp")]
x$orders_of_magnitude <- log10(pmax(x$p_theory,1e-300)) - log10(pmax(x$p_emp,1e-300))
print(x, digits=3, row.names=FALSE)
cat(sprintf("\nmedian ratio p_emp / p_theory = %.3g  (range %.3g - %.3g)\n",
    median(x$p_emp/x$p_theory), min(x$p_emp/x$p_theory), max(x$p_emp/x$p_theory)))
cat(sprintf("null-SD range across the 15 combinations: %.2f - %.2f (median %.2f)\n",
    min(S1$null_sd), max(S1$null_sd), median(S1$null_sd)))
## per-study null SD table for the methods paragraph
P <- readRDS(file.path(SC_CACHE, "perm_null_S0.rds"))
ps <- do.call(rbind, lapply(names(P$nulls), function(k) {
  M <- P$nulls[[k]]; sds <- apply(M, 2, sd, na.rm=TRUE)
  data.frame(study_contrast=k, n_perms=nrow(M), median_sd=median(sds),
             q25=quantile(sds,.25), q75=quantile(sds,.75), min_sd=min(sds), max_sd=max(sds)) }))
ps$stratum <- sub("\\|.*$", "", ps$study_contrast)
write.csv(ps, file.path(SC_OUT, "perm_null_dispersion.csv"), row.names=FALSE)
cat("\n=== per-study null dispersion of the CAMERA-PR signed z (50 Hallmarks) ===\n")
print(ps[, c("study_contrast","n_perms","median_sd","q25","q75")], digits=3, row.names=FALSE)
cat("\nIf CAMERA-PR were correctly calibrated under label permutation, these SDs would all be ~1.\n")
