## igc_sensitivity.csv (wide, per study-contrast x programme x 5 settings).
## Logic extracted verbatim from 23_consolidate.R lines 74-98 (the "---- igc_sensitivity.csv"
## block).  Only additions: the source of cat_cut (23_consolidate.R line 6, copied verbatim)
## and the input/output paths, which are taken from the command line so that the S0 and S1
## runs write to separate files.
##
## Usage: Rscript 14_igc_wide.R <igc_sensitivity_long.csv> <out.csv>
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R"))                       # FOCAL
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2L)
IN_LONG <- args[1]; OUT_WIDE <- args[2]
cat_cut <- function(p) as.character(cut(p, c(-Inf,.05,.10,Inf), labels=c("conf","expl","ns")))  # 23_consolidate.R:6

## ---- 23_consolidate.R:74-98 ----
IG <- read.csv(IN_LONG)
w <- reshape(IG[!is.na(IG$rho), c("stratum","study","contrast","programme","rho","direction","FDR")],
             idvar=c("stratum","study","contrast","programme"), timevar="rho", direction="wide")
est <- IG[is.na(IG$rho) & !is.na(IG$n_genes), c("stratum","study","contrast","programme","direction","FDR")]
names(est)[5:6] <- c("direction.estimated","FDR.estimated")
fry <- IG[is.na(IG$rho) & is.na(IG$n_genes), c("stratum","study","contrast","programme","direction","FDR")]
names(fry)[5:6] <- c("direction.fry","FDR.fry")
M <- Reduce(function(a,b) merge(a,b,by=c("stratum","study","contrast","programme"), all=TRUE), list(w, est, fry))
for (rho in c("0.01","0.05","0.1")) {
  M[[paste0("cat.", rho)]] <- cat_cut(M[[paste0("FDR.", rho)]])
}
M[["cat.estimated"]] <- cat_cut(M[["FDR.estimated"]])
M[["cat.fry"]] <- cat_cut(M[["FDR.fry"]])
M$direction_preserved_0.05 <- M[["direction.0.01"]] == M[["direction.0.05"]]
M$direction_preserved_0.1  <- M[["direction.0.01"]] == M[["direction.0.1"]]
M$direction_preserved_estimated <- M[["direction.0.01"]] == M[["direction.estimated"]]
M$direction_preserved_fry <- M[["direction.0.01"]] == M[["direction.fry"]]
M$category_preserved_0.05 <- M[["cat.0.01"]] == M[["cat.0.05"]]
M$category_preserved_0.1  <- M[["cat.0.01"]] == M[["cat.0.1"]]
M$category_preserved_estimated <- M[["cat.0.01"]] == M[["cat.estimated"]]
M$category_preserved_fry <- M[["cat.0.01"]] == M[["cat.fry"]]
M$is_focal_programme <- M$programme %in% FOCAL
write.csv(M, OUT_WIDE, row.names=FALSE)
## ---- end 23_consolidate.R:74-98 ----
cat("wrote", OUT_WIDE, nrow(M), "rows", ncol(M), "cols\n")
cat(sprintf("  direction preserved (0.05/0.1/estimated/fry): %.3f / %.3f / %.3f / %.3f\n",
  mean(M$direction_preserved_0.05), mean(M$direction_preserved_0.1),
  mean(M$direction_preserved_estimated, na.rm=TRUE), mean(M$direction_preserved_fry, na.rm=TRUE)))
cat(sprintf("  category preserved (0.05/0.1/estimated/fry): %.3f / %.3f / %.3f / %.3f\n",
  mean(M$category_preserved_0.05), mean(M$category_preserved_0.1),
  mean(M$category_preserved_estimated, na.rm=TRUE), mean(M$category_preserved_fry, na.rm=TRUE)))
