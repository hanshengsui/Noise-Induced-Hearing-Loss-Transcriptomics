## Step 9b -- summary of the CAMERA data-estimated correlation, per study-contrast.
## All values computed from the full camera_estimated_correlation table (9 x 50 = 450 rows).
## Usage: Rscript 17_corr_summary.R <camera_estimated_correlation.csv> <out.txt> [tag]
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R"))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) >= 2L)
EC <- read.csv(A[1], stringsAsFactors = FALSE)
stopifnot(nrow(EC) == 450L, length(unique(EC$programme)) == 50L,
          length(unique(paste(EC$stratum, EC$study, EC$contrast))) == 9L)
sc <- unique(EC[, c("stratum","study","contrast")])
sc <- sc[order(match(sc$stratum, c("acute","h24","later")), sc$study, sc$contrast), ]
rows <- list()
for (i in seq_len(nrow(sc))) {
  z <- EC[EC$stratum==sc$stratum[i] & EC$study==sc$study[i] & EC$contrast==sc$contrast[i], ]
  fo <- z[z$programme %in% FOCAL, ]
  rows[[i]] <- data.frame(stratum=sc$stratum[i], study=sc$study[i], contrast=sc$contrast[i],
    n_programmes=nrow(z), median_all50=median(z$correlation), min_all50=min(z$correlation),
    max_all50=max(z$correlation), median_focal5=median(fo$correlation),
    min_focal5=min(fo$correlation), max_focal5=max(fo$correlation), n_focal5=nrow(fo),
    stringsAsFactors=FALSE)
}
T <- do.call(rbind, rows)
write.csv(T, sub("[.]txt$", ".csv", A[2]), row.names = FALSE)
L <- c(sprintf("camera estimated correlation -- per study-contrast (%s)", if (length(A)>=3) A[3] else ""),
  "", "per study-contrast medians:",
  sprintf("  %-6s %-11s %-22s all50 med %7.4f  focal5 med %7.4f  n_focal5 %d",
    T$stratum, T$study, T$contrast, T$median_all50, T$median_focal5, as.integer(T$n_focal5)),
  "",
  sprintf("all 9 study-contrasts, median over the 50 Hallmarks: %.4f - %.4f (grand median %.4f)",
    min(T$median_all50), max(T$median_all50), median(T$median_all50)),
  sprintf("all 9 study-contrasts, per-contrast focal-5 median:   %.4f - %.4f (grand median %.4f)",
    min(T$median_focal5), max(T$median_focal5), median(T$median_focal5)),
  sprintf("all 450 (9 x 50) individual correlations: %.4f - %.4f, median %.4f",
    min(EC$correlation), max(EC$correlation), median(EC$correlation)),
  sprintf("focal programmes only (%d values): %.4f - %.4f, median %.4f",
    sum(EC$programme %in% FOCAL), min(EC$correlation[EC$programme %in% FOCAL]),
    max(EC$correlation[EC$programme %in% FOCAL]), median(EC$correlation[EC$programme %in% FOCAL])))
cat(paste(L, collapse="\n"), "\n")
writeLines(L, A[2])
