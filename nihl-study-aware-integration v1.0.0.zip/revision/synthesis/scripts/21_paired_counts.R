## Exact counts of study-contrast x programme combinations whose retention verdict changes
## between the two schemes (450 per setting).  Computed from the paired tables.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R"))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) == 3L)
P0 <- read.csv(file.path(A[1],"igc_sensitivity_paired.csv"), stringsAsFactors=FALSE)
P1 <- read.csv(file.path(A[2],"igc_sensitivity_paired.csv"), stringsAsFactors=FALSE)
K <- c("setting","stratum","study","contrast","programme")
kk <- function(z) do.call(paste, c(z[K], sep="|"))
stopifnot(setequal(kk(P0), kk(P1)), nrow(P0) == 1800L, nrow(P1) == 1800L)
j <- match(kk(P0), kk(P1))
L <- c("Paired (setting x stratum x study x contrast x programme), 1800 rows each; per setting 450",
  sprintf("  %-10s %22s %22s %20s %20s", "setting","dir_kept S1 -> S0","cat_kept S1 -> S0",
          "dir flips","cat flips"),
  sapply(c("rho0.05","rho0.1","estimated","fry"), function(st) {
    a <- P0[P0$setting==st, ]; b <- P1[P1$setting==st, ]
    jj <- match(do.call(paste,c(a[c("stratum","study","contrast","programme")],sep="|")),
                do.call(paste,c(b[c("stratum","study","contrast","programme")],sep="|")))
    d0 <- a$dir_base == a$direction; d1 <- b$dir_base[jj] == b$direction[jj]
    c0 <- a$cat_base == a$cat_alt;  c1 <- b$cat_base[jj] == b$cat_alt[jj]
    sprintf("  %-10s %10d -> %-10d %10d -> %-10d %6d %6d %6d %6d", st,
            sum(d1), sum(d0), sum(c1), sum(c0), sum(d0 & !d1), sum(!d0 & d1),
            sum(c0 & !c1), sum(!c0 & c1))
  }), "")
cat(paste(L, collapse="\n"), "\n"); writeLines(L, A[3])
