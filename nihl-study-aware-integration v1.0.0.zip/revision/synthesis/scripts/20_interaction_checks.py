import os
# SC_CACHE / SC_OUT as for the R scripts (defaults: revision/synthesis/cache and revision/synthesis/results)
_ROOT = os.environ.get("SC_ROOT", os.path.abspath(os.path.join(os.getcwd(), "..", "..", "..")))
CACHE = os.environ.get("SC_CACHE", os.path.join(_ROOT, "revision", "synthesis", "cache"))
OUT   = os.environ.get("SC_OUT",   os.path.join(_ROOT, "revision", "synthesis", "results"))
RAW   = os.path.join(CACHE, "gsm_raw")
os.makedirs(RAW, exist_ok=True); os.makedirs(OUT, exist_ok=True)
import csv
rows=[]
# --- GSE8342 block
rows.append(dict(
  check="GSE8342_strain_labels", dataset="GSE8342",
  code_reference="prj/Legacy_Core_Analysis/Scripts/01_GSE8342_analysis.R L70-72 (factor levels) and L76-81 (contrast matrix)",
  code_levels="resistant_control, resistant_noise, susceptible_control, susceptible_noise (reference = resistant_control)",
  code_label_mapping="129X1/SvJ -> resistant ; B6.CAST -> susceptible",
  interaction_column_name="strain_by_noise_interaction",
  interaction_contrast_vector="c(-1, +1, +1, -1) on (resistant_control, resistant_noise, susceptible_control, susceptible_noise)",
  interaction_equals="(resistant_noise - resistant_control) - (susceptible_noise - susceptible_control)",
  positive_means="larger noise-induced increase in the RESISTANT (129X1/SvJ) strain",
  geo_evidence="GSE8342 series matrix !Series_summary: 'a permanent loss of about 40 dB in sensitivity for auditory brainstem responses in susceptible B6.CAST mice, but no threshold elevations for the two resistant 129S1/SvImJ and 129X1/SvJ substrains'",
  paper_citation="Gratton et al. 2011, Hearing Research 277:196-211, doi 10.1016/j.heares.2010.12.014 (PMID 21187137)",
  paper_quote="'The noise-exposure protocol produced a loss of 40 dB in hearing sensitivity in susceptible B6 mice, but no loss for the two resistant 129 substrains.'",
  paper_quote_location="Abstract, sentence 3 (PMC3098916)",
  paper_quote_words=26,
  paper_quote2="'...was detected only in the resistant mice.'",
  paper_quote2_location="Abstract, sentence 6 (cell-survival pathway induction: HSP70, HSP40, GADD45beta, p21)",
  numeric_anchor="HSPA1A group means: resistant_control 9.65 -> resistant_noise 11.05 (delta +1.40); susceptible_control 9.75 -> susceptible_noise 9.97 (delta +0.22); interaction logFC +1.06 (t=2.70). GADD45B +3.22 vs +1.14; CDKN1A +0.94 vs +0.59",
  unit_test="a3/18_interaction_sign_test.R: synthetic data with a known larger resistant effect returns a POSITIVE coefficient (1.584) and the mirrored case returns a NEGATIVE one (-1.416)",
  registry_agreement_note="Verified against the deposited factor levels, an arithmetic unit test on synthetic data and three anchor genes (Hspa1a, Gadd45b, Cdkn1a).",
  resolution="Direction confirmed before manuscript revision: positive interaction = larger noise-induced increase in the resistant strain.",))
# --- GSE107086 block
for r in csv.DictReader(open(OUT+"/gse107086_interaction_mde.csv")):
    rows.append(dict(
      check="GSE107086_interaction_CI_MDE", dataset="GSE107086",
      code_reference="prj/Legacy_Core_Analysis/Scripts/02_EMTAB16125_and_GSE107086_analysis.R L196-215 (8-cell group factor; GC_dependency_day/night/average contrasts)",
      code_levels="DNADX, DNShADX, NNADX, NNShADX, ShDNADX, ShDNShADX, ShNNADX, ShNNShADX",
      code_label_mapping="D=day, N=night, Sh=sham noise, ADX=adrenalectomised; 3 mice per cell, 24 libraries",
      interaction_column_name=r["contrast"],
      interaction_contrast_vector="see a3/16_interactions.R (explicit 8-element vector per contrast)",
      interaction_equals="(ADX noise effect) - (sham-ADX noise effect) within the stated time-of-day, i.e. the glucocorticoid-dependence of the noise response",
      positive_means="larger noise-induced change when the adrenal gland is absent",
      geo_evidence="GSE107086 SubSeries of SuperSeries GSE107087; BioProject PRJNA418971",
      paper_citation="PMID 31353184 (Cederroth/Weger/Canlon); not independently verified here",
      paper_quote="",
      paper_quote_location="",
      paper_quote_words="",
      paper_quote2="",
      paper_quote2_location="",
      numeric_anchor=f"programme {r['program']}: estimate {float(r['estimate']):+.4f} (95% CI {float(r['ci_low']):+.4f} to {float(r['ci_high']):+.4f}), p = {float(r['p']):.4f}, MDE(80%, alpha=0.05) = {float(r['mde_80']):.4f} z-score units, df = {r['df']}",
      unit_test="MDE formula mde = (qt(0.975,df) + qt(0.80,df))*se as specified in Appendix B2.7",
      registry_agreement_note="n/a",
      resolution="None; reported as pre-specified."))
with open(OUT+"/interaction_checks.csv","w",newline="") as f:
    w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
print(len(rows),"rows")
for r in rows[:1]:
    for k,v in r.items(): print(f"  {k}: {str(v)[:200]}")
