synthesis revision analyses

Prerequisite: run Rscript run_all.R from the repository root.
Execute from the root with the Python environment in env/single_cell_environment.yml:
python validation/run_revision_checks.py --line synthesis --rscript /absolute/path/to/Rscript

validation/run_revision_checks.py records the complete dependency order. It invokes R scripts with the supplied Rscript and Python scripts with the current Python executable. Keep all source scripts and resources in their distributed relative locations. Outputs are copied into revision/synthesis/results/. The table-to-script mapping is revision/TABLE_TO_SCRIPT.csv.

The complete component was executed on 2026-11-02. See README.txt and validation/main_checks.csv for the rerun results. The random seed is 20261029.
