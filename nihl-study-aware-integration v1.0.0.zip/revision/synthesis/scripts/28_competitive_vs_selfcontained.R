## Do the competitive CAMERA-PR direction and the sample-level gene-set-score direction agree?
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
F <- read.csv(file.path(SC_OUT, "forest_effects.csv"))
O <- readRDS(file.path(SC_CACHE, "expr.rds")); STR <- syn_strata()
src <- function(k) switch(k, GSE160639="GSE160639", GSE196870="GSE196870_S0",
                          GSE312476="GSE312476", GSE100365="GSE100365", EMTAB="EMTAB")
rows <- list()
for (s in names(STR)) for (k in names(STR[[s]])) for (p in names(FOCAL)) {
  cam <- O[[src(k)]]$camera
  cam <- cam[cam$contrast == STR[[s]][[k]] & cam$programme == FOCAL[[p]], ]
  fr <- F[F$stratum==s & F$study==k & F$program==p, ]
  if (!nrow(cam) || !nrow(fr)) next
  rows[[length(rows)+1]] <- data.frame(stratum=s, study=k, program=p,
    camera_direction=cam$direction, camera_t=cam$camera_t,
    score_estimate=fr$estimate, score_direction=fr$direction,
    agree=as.character(cam$direction)==as.character(fr$direction))
}
D <- do.call(rbind, rows); rownames(D) <- NULL
write.csv(D, file.path(SC_OUT, "competitive_vs_selfcontained.csv"), row.names=FALSE)
cat("agreement across the", nrow(D), "study-contrast-program cells:", sum(D$agree), "\n")
print(D[!D$agree, c("stratum","study","program","camera_direction","camera_t","score_estimate")],
      digits=3, row.names=FALSE)
cat("\nagreement by program:\n"); print(table(D$program, D$agree))
cat("\nagreement by stratum:\n"); print(table(D$stratum, D$agree))
