# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds"))
set.seed(SEED_GLOBAL)
## Duplicate-data check per B2.1: sample-level correlation between studies on common genes.
## All five synthesis-eligible expression matrices are used, on the genes common to all pairs.
objs <- list(GSE160639=O$GSE160639, GSE196870=O$GSE196870_S0, GSE312476=O$GSE312476,
             GSE100365=O$GSE100365, `E-MTAB-16125`=O$EMTAB, GSE107086=O$GSE107086)
## standardise each study's matrix to ranks then use Pearson on within-study z-scores so that
## scale differences (FPKM / log2 / voom) do not manufacture or mask near-identity.
prep <- function(x) { z <- t(scale(t(x))); z[!is.finite(z)] <- 0; z }
res <- list()
acc <- names(objs)
for (i in 1:(length(acc)-1)) for (j in (i+1):length(acc)) {
  a <- acc[i]; b <- acc[j]
  g <- intersect(toupper(objs[[a]]$symbols), toupper(objs[[b]]$symbols))
  if (length(g) < 500) { res[[length(res)+1]] <- data.frame(study_a=a, study_b=b, n_common_genes=length(g),
      max_r=NA, n_pairs_over_0.999=NA, note="too few common genes"); next }
  A <- prep(objs[[a]]$E[match(g, toupper(objs[[a]]$symbols)), , drop=FALSE])
  B <- prep(objs[[b]]$E[match(g, toupper(objs[[b]]$symbols)), , drop=FALSE])
  C <- cor(A, B, use="pairwise.complete.obs")
  mx <- max(abs(C), na.rm=TRUE)
  res[[length(res)+1]] <- data.frame(study_a=a, study_b=b, n_common_genes=length(g),
     max_r=round(mx,6), n_pairs_over_0.999=sum(abs(C) > 0.999, na.rm=TRUE),
     note=ifelse(mx > 0.999, "INVESTIGATE: possible duplicate samples", "no near-identity"))
}
D <- do.call(rbind,res)
write.csv(D, file.path(SC_OUT, "duplicate_sample_check.csv"), row.names=FALSE)
print(D, row.names=FALSE)
