## Why is the permutation null wider than the theoretical one?  Test the obvious mechanism:
## CAMERA-PR is run with a fixed inter.gene.cor = 0.01 while the measured correlation is higher.
## Recompute the same null at the data-estimated correlation and see whether the SD returns to ~1.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R")); source(file.path(SC_SCR, "07_perm_engine.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds")); H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))
STR <- syn_strata(); LP <- syn_levelpairs()
EC <- read.csv(file.path(SC_OUT, "camera_estimated_correlation.csv"))
targets <- list(c("acute","GSE160639"), c("acute","GSE312476"), c("acute","GSE100365"),
                c("h24","GSE100365"), c("later","GSE100365"))
out <- list()
for (tg in targets) {
  s <- tg[1]; study <- tg[2]
  obj <- O[[switch(study, GSE160639="GSE160639", GSE196870="GSE196870_S0", GSE312476="GSE312476",
                   GSE100365="GSE100365", EMTAB="EMTAB")]]
  cn <- STR[[s]][[study]]; lp <- LP[[study]][[cn]]
  blk <- switch(study, GSE100365="sex", EMTAB="sex", NULL)
  lab_all <- as.character(obj$meta[[obj$group_var]]); ss <- which(lab_all %in% lp)
  nb <- if (is.null(blk)) NA else length(enumerate_relabelings(lab_all[ss], as.character(obj$meta[[blk]][ss])))
  use_blk <- !is.na(nb) && nb >= 10
  ## observed estimated correlation for this study-contrast
  rho_est <- median(EC$correlation[EC$stratum==s & EC$study==study], na.rm=TRUE)
  for (igc in c(0.01, round(rho_est,3))) {
    pn <- perm_null_study(obj, lp[2], lp[1], block_col=if (use_blk) blk else NULL,
                          hallmark=H$hallmark, order50=H$order50, inter.gene.cor=igc)
    sds <- apply(pn$null, 2, sd, na.rm=TRUE)
    out[[length(out)+1]] <- data.frame(stratum=s, study=study, inter_gene_cor_used=igc,
      n_perms=nrow(pn$null), median_z_null_sd=median(sds), q25=quantile(sds,.25), q75=quantile(sds,.75),
      measured_correlation_median=rho_est)
  }
  cat(sprintf("%-6s %-10s measured rho=%.3f\n", s, study, rho_est))
}
D <- do.call(rbind, out); rownames(D) <- NULL
write.csv(D, file.path(SC_OUT, "perm_null_sd_diagnosis.csv"), row.names=FALSE)
print(D, digits=3, row.names=FALSE)
cat("\nIf the null SD drops toward 1 when inter.gene.cor is raised to the measured value,\n")
cat("the z inflation is the known CAMERA-PR behaviour of under-specifying inter-gene correlation,\n")
cat("not a defect of the permutation scheme itself.\n")
