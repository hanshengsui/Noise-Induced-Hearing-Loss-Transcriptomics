## Per-combination detail behind the "7 of 15" statement, and the 24 changed category cells
## in the 450-row wide table.  Computed from the full tables only.
## Usage: Rscript 20_combo_detail.R <S0 dir> <S1 dir> <out_dir>
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R"))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) == 3L)
f0 <- read.csv(file.path(A[1],"igc_synthesis.csv"), stringsAsFactors=FALSE)
f1 <- read.csv(file.path(A[2],"igc_synthesis.csv"), stringsAsFactors=FALSE)
KEY <- c("setting","stratum","program")
kk <- function(z) paste(z$setting,z$stratum,z$program,sep="|")
stopifnot(setequal(kk(f0), kk(f1)), nrow(f0)==75L)
i <- match(kk(f0), kk(f1))
out <- data.frame(setting=f0$setting, stratum=f0$stratum, program=f0$program, k=f0$k, n_up=f0$n_up,
  Z_S0=f0$Z, fdr5_S0=f0$fdr5, cat5_S0=f0$cat5,
  Z_S1=f1$Z[i], fdr5_S1=f1$fdr5[i], cat5_S1=f1$cat5[i], stringsAsFactors=FALSE)
out$dZ <- out$Z_S0 - out$Z_S1
out$same_cat <- out$cat5_S0 == out$cat5_S1
out <- out[order(match(out$stratum,c("acute","h24","later")), match(out$program,names(FOCAL)),
                 match(out$setting,c("rho0.01","rho0.05","rho0.1","estimated","fry"))), ]
write.csv(out, file.path(A[3], "igc_synthesis_all15x5_S0_vs_S1.csv"), row.names=FALSE)

## the summary the report needs: how many of the 15 combinations keep their category at each
## setting, plus the Z shift
L <- c("SYNTHESIS LEVEL, per setting (S0 primary vs S1 sensitivity), all computed from the 75-row table",
  sprintf("  %-10s %6s %6s %10s %10s %10s %10s", "setting","cat_kept","cat_chg","max|dZ|","med|dZ|",
          "max|dZ|focal","n>0.05"),
  sapply(c("rho0.01","rho0.05","rho0.1","estimated","fry"), function(st) {
    z <- out[out$setting==st, ]
    sprintf("  %-10s %6d %6d %10.4f %10.4f %10.4f %10d", st, sum(z$same_cat), sum(!z$same_cat),
            max(abs(z$dZ)), median(abs(z$dZ)), max(abs(z$dZ)), sum(abs(z$dZ) > 0.05))
  }), "")

## the 24 changed category cells in the 450-row table, listed
w0 <- read.csv(file.path(A[1],"igc_sensitivity.csv"), stringsAsFactors=FALSE)
w1 <- read.csv(file.path(A[2],"igc_sensitivity.csv"), stringsAsFactors=FALSE)
k0 <- paste(w0$stratum,w0$study,w0$contrast,w0$programme,sep="|")
k1 <- paste(w1$stratum,w1$study,w1$contrast,w1$programme,sep="|")
stopifnot(setequal(k0,k1), nrow(w0)==450L)
j <- match(k0,k1)
catc <- grep("^cat[.]", names(w0), value=TRUE)
rows <- list()
for (cc in catc) {
  st <- sub("^cat[.]","",cc)
  d <- !is.na(w0[[cc]]) & !is.na(w1[[cc]][j]) & w0[[cc]] != w1[[cc]][j]
  if (any(d)) rows[[cc]] <- data.frame(
    stratum=w0$stratum[d], study=w0$study[d], contrast=w0$contrast[d], programme=w0$programme[d],
    setting=st, cat_existing_S1=w1[[cc]][j][d], cat_S0=w0[[cc]][d],
    fdr_existing_S1=w1[[grep(paste0("FDR[.]",st,"$"),names(w1))]][j][d],
    fdr_S0=w0[[grep(paste0("FDR[.]",st,"$"),names(w0))]][d],
    is_focal=w0$programme[d] %in% FOCAL, stringsAsFactors=FALSE)
}
CC <- do.call(rbind, rows); rownames(CC) <- NULL
CC <- CC[order(match(CC$stratum,c("acute","h24","later")), CC$study, CC$contrast,
               match(CC$setting,c("0.01","0.05","0.1","estimated","fry"))), ]
write.csv(CC, file.path(A[3], "igc_category_changes_S0_vs_S1.csv"), row.names=FALSE)
L <- c(L, sprintf("Changed FDR-category cells in the 450-row table: %d total, %d in focal programmes",
                  nrow(CC), sum(CC$is_focal)),
  sprintf("  by setting: %s", paste(names(table(CC$setting)), as.integer(table(CC$setting)),
                                   sep="=", collapse="  ")),
  sprintf("  by study  : %s", paste(names(table(CC$study)), as.integer(table(CC$study)),
                                   sep="=", collapse="  ")),
  "  directions of change (S1 -> S0):",
  sprintf("    %-12s %d", names(table(paste(CC$cat_existing_S1, "->", CC$cat_S0))),
          as.integer(table(paste(CC$cat_existing_S1, "->", CC$cat_S0)))))
cat(paste(L, collapse="\n"), "\n")
writeLines(L, file.path(A[3], "combo_detail.txt"))
