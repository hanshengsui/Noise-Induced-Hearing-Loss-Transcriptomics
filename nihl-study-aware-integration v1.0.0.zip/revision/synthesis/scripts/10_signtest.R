## B2.4 exact sign test, with the three unit tests written as assertions.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "00b_scheme.R"))
ut <- data.frame(k=c(4,3,2), all_same_two_sided=c(binom.test(4,4,0.5)$p.value,
                                                  binom.test(3,3,0.5)$p.value,
                                                  binom.test(2,2,0.5)$p.value),
                 expected=c(0.125,0.25,0.5))
ut$pass <- isTRUE(all.equal(ut$all_same_two_sided, ut$expected, tolerance=1e-12))
print(ut, row.names=FALSE)
stopifnot(all(ut$pass))
write.csv(ut, file.path(SC_OUT, "signtest_unit_tests.csv"), row.names=FALSE)

R <- read.csv(file.path(SC_OUT, "stouffer_sensitivity.csv"))
R <- R[R$scheme_GSE196870==PRIMARY_SCHEME & R$weighting=="w_equal", ]
R$p_sign <- mapply(function(u, k) binom.test(u, k, 0.5)$p.value, R$n_up, R$k)
R$sign_interpretation <- ifelse(R$n_up == R$k | R$n_up == 0, "all_same_direction",
                         ifelse(pmax(R$n_up, R$k-R$n_up) == R$k-1, "one_discordant", "split"))
R$description_only <- TRUE   # k<=4 can never reach two-sided p<0.05
write.csv(R[, c("stratum","program","k","n_up","p_sign","sign_interpretation","description_only","Z","p_emp")],
          file.path(SC_OUT, "sign_test_results.csv"), row.names=FALSE)
print(R[, c("stratum","program","k","n_up","p_sign","sign_interpretation","p_emp")], digits=4, row.names=FALSE)
cat("\nNote: minimum attainable two-sided binomial p at k=4 is 0.125, k=3 is 0.25, k=2 is 0.50;\n")
cat("therefore no stratum can reach p<0.05 by the sign test alone. Reported as descriptive only.\n")
