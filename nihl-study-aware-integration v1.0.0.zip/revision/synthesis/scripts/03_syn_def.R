## Shared definition of synthesis strata + Z reconstruction.  Sourced by others.
## Strata per Appendix B0.2.  S1 = log2(FPKM+1) for GSE196870 (D1 primary);
## S0 = the submitted scheme (no log) is carried alongside for the submitted-version comparison.
syn_objects <- function(O, gse196870 = c("S0","S1")) {
  g <- match.arg(gse196870)
  list(GSE160639 = O$GSE160639,
       GSE196870 = if (g=="S1") O$GSE196870_S1 else O$GSE196870_S0,
       GSE312476 = O$GSE312476,
       GSE100365 = O$GSE100365,
       EMTAB     = O$EMTAB)
}
## stratum -> named vector of (contrast, n_biological_units)
syn_strata <- function() list(
  acute = c(GSE160639 = "dB105_vs_70", GSE196870 = "noise_1h_vs_control",
            GSE312476 = "post_0h_vs_control", GSE100365 = "immediate_vs_control"),
  h24   = c(GSE196870 = "noise_24h_vs_control", GSE100365 = "day1_vs_control",
            EMTAB = "h24_vs_control"),
  later = c(GSE100365 = "day7_vs_day1", EMTAB = "week1_vs_h72"))
## biological units per group (n1 = n2), from Table 1 / sample metadata
syn_nunits <- function() list(acute = c(GSE160639=4, GSE196870=4, GSE312476=3, GSE100365=3),
                             h24   = c(GSE196870=4, GSE100365=3, EMTAB=5),
                             later = c(GSE100365=3, EMTAB=5))
z_of <- function(obj, contrast, prog) {
  cam <- obj$camera[obj$camera$contrast == contrast & obj$camera$programme == prog, ]
  signed_z_of(cam$PValue, cam$direction)
}
df_total_median <- function(obj, contrast) median(obj$fit$df.total)

## Explicit level pairs (g2 = numerator, g1 = reference) for each analysis contrast.
## Kept separate from the contrast *name* so that the permutation refit cannot mis-parse it.
syn_levelpairs <- function() list(
  GSE160639 = list(dB94_vs_70 = c("94dB","70dB"), dB105_vs_70 = c("105dB","70dB")),
  GSE196870 = list(noise_1h_vs_control = c("noise_1h","control"),
                   noise_24h_vs_control = c("noise_24h","control")),
  GSE312476 = list(post_0h_vs_control = c("post_0h","control"),
                   post_4h_vs_control = c("post_4h","control"),
                   post_8h_vs_control = c("post_8h","control")),
  GSE100365 = list(immediate_vs_control = c("immediate","control"),
                   day1_vs_control = c("day1","control"),
                   day7_vs_control = c("day7","control"),
                   day14_vs_control = c("day14","control"),
                   day7_vs_day1 = c("day7","day1")),
  EMTAB = list(h24_vs_control = c("h24","control"), h72_vs_control = c("h72","control"),
               week1_vs_control = c("week1","control"), week1_vs_h72 = c("week1","h72")),
  GSE107086 = list(noise_day_ADX = c("DNADX","ShDNADX"), noise_day_shamADX = c("DNShADX","ShDNShADX"),
                   noise_night_ADX = c("NNADX","ShNNADX"), noise_night_shamADX = c("NNShADX","ShNNShADX"),
                   GC_dependency_day = NULL, GC_dependency_night = NULL,
                   noise_average_shamADX = NULL, noise_average_ADX = NULL,
                   GC_dependency_average = NULL))
## block column per study (the only design-level grouping that is not the exposure label)
syn_blockcol <- function(study) switch(study, GSE100365 = "sex", EMTAB = "sex", NULL)
