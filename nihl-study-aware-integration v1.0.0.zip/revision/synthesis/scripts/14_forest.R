## Appendix B2.6 -- sample-level gene-set score, original design linear model, t-based 95% CI.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds")); H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))
STR <- syn_strata(); LP <- syn_levelpairs()

score_set <- function(E, genes) {
  g <- intersect(toupper(rownames(E)), genes)
  if (length(g) < 2) return(rep(NA_real_, ncol(E)))
  Z <- t(scale(t(E[g, , drop = FALSE])))
  Z[!is.finite(Z)] <- NA
  colMeans(Z, na.rm = TRUE)
}
## map mouse symbols: the analysis matrices already carry upper-case mouse symbols
score_study <- function(obj, genes) {
  E <- obj$E
  ## rows are indexed by feature id for the array studies; use the stored symbol vector
  rownames(E) <- toupper(obj$symbols)
  ## representative row per symbol (highest mean) if duplicates exist
  if (any(duplicated(rownames(E)))) {
    avg <- rowMeans(E, na.rm = TRUE)
    o <- order(rownames(E), -avg)
    E <- E[o, , drop = FALSE][!duplicated(rownames(E)[o]), , drop = FALSE]
  }
  score_set(E, genes)
}

fit_contrast <- function(sc, obj, lp) {
  meta <- obj$meta
  gl <- intersect(obj$lvls, unique(as.character(meta[[obj$group_var]])))
  grp <- factor(as.character(meta[[obj$group_var]]), levels = gl)
  df <- data.frame(sc = sc, grp = grp)
  cov <- obj$covar_frame
  if (!is.null(cov)) for (j in seq_len(ncol(cov))) { v <- cov[, j]; if (length(unique(v)) > 1) df[[paste0("cv", j)]] <- v }
  cvn <- setdiff(grep("^cv", names(df), value = TRUE), character(0))
  forms <- "sc ~ 0 + grp"
  if (length(cvn)) forms <- paste0(forms, " + ", paste(cvn, collapse = " + "))
  fit <- tryCatch(lm(as.formula(forms), data = df), error=function(e) { cat("LM FAIL", obj$group_var, "|", paste(lp,collapse="/"), "| lvls:", paste(levels(df$grp),collapse=","), "| forms:", forms, "| cov:", paste(cvn,collapse=","), "\n"); print(table(df$grp)); NULL })
  if (is.null(fit)) return(NULL)
  b <- coef(fit); V <- vcov(fit)
  ## match coefficient names robustly (R may drop unused levels)
  k2 <- grep(paste0("^grp", gsub("([.()+])", "\\\\\\1", lp[1]), "$"), names(b))
  k1 <- grep(paste0("^grp", gsub("([.()+])", "\\\\\\1", lp[2]), "$"), names(b))
  if (!length(k2) || !length(k1)) return(NULL)
  est <- b[k2] - b[k1]
  se  <- sqrt(V[k2, k2] + V[k1, k1] - 2 * V[k2, k1])
  dfe <- df.residual(fit)
  crit <- qt(0.975, dfe)
  data.frame(estimate = est, se = se, df = dfe, ci_low = est - crit*se, ci_high = est + crit*se,
             p = 2*pt(-abs(est/se), dfe),
             mde_80 = (qt(0.975, dfe) + qt(0.80, dfe)) * se,
             n_samples_scored = sum(is.finite(sc)))
}
## secondary metric: mean within-set gene logFC (machine-readable only)
mean_logfc <- function(obj, cn, genes) {
  tt <- obj$tstat[[cn]]
  ## logFC is not stored for every study; recompute from the fit saved in the object
  f <- obj$fit
  if (!is.null(f)) {
    lf <- f$coefficients[, cn]
    names(lf) <- toupper(names(lf))
    lf <- lf[!duplicated(names(lf))]
    g <- intersect(names(lf), genes)
    if (length(g) < 2) return(NA_real_)
    return(mean(lf[g], na.rm = TRUE))
  }
  NA_real_
}
rows <- list()
for (s in names(STR)) for (study in names(STR[[s]])) for (p in names(FOCAL)) {
  obj <- O[[switch(study, GSE160639="GSE160639", GSE196870="GSE196870_S0",
                   GSE312476="GSE312476", GSE100365="GSE100365", EMTAB="EMTAB")]]
  genes <- H$hallmark[[FOCAL[[p]]]]
  sc <- score_study(obj, genes)
  cn <- STR[[s]][[study]]; lp <- LP[[study]][[cn]]
  ## the score dataframe must only contain the two groups of the contrast
  keep <- as.character(obj$meta[[obj$group_var]]) %in% lp
  obj2 <- obj; obj2$meta <- obj$meta[keep, , drop=FALSE]
  if (!is.null(obj$covar_frame)) obj2$covar_frame <- obj$covar_frame[keep, , drop=FALSE]
  r <- fit_contrast(sc[keep], obj2, lp)
  if (is.null(r)) { cat("contrast failed:", study, cn, "\n"); next }
  rows[[length(rows)+1]] <- data.frame(stratum=s, study=study, contrast=cn, program=p,
    geneset=FOCAL[[p]], n_samples_scored=r$n_samples_scored,
    n_genes_in_set_with_data=length(intersect(toupper(obj$symbols), genes)), estimate=r$estimate, se=r$se,
    df=r$df, ci_low=r$ci_low, ci_high=r$ci_high, p=r$p, mde_80=r$mde_80,
    mean_logfc_secondary=mean_logfc(obj, cn, genes),
    direction=ifelse(r$estimate > 0, "Up", "Down"))
}
F <- do.call(rbind, rows); rownames(F) <- NULL
write.csv(F, file.path(SC_OUT, "forest_effects.csv"), row.names=FALSE)
print(F[, c("stratum","study","program","n_genes_in_set_with_data","estimate","ci_low","ci_high","p","mde_80")],
      digits=4, row.names=FALSE)
saveRDS(F, file.path(SC_CACHE, "forest.rds"))
