## D9 evidence grading from the pre-specified empirical (permutation) FDR.
##   * evidence_grades_calibrated.csv  -- 15 stratum x programme synthesis cells
##   * temporal_evidence.csv           -- 21_temporal.R output with the D9 columns appended
##
## Rule D9 (fixed before the calibrated numbers were inspected):
##   conf          = k/k studies in one direction and fdr_emp <  0.05
##   expl          = k/k studies in one direction and 0.05 <= fdr_emp < 0.10
##   heterogeneous = direction split between studies
##   ns            = every other case
## fdr_emp is the Benjamini-Hochberg adjustment (five programmes within a stratum) of the empirical
## permutation p of the equal-weight Stouffer synthesis (stouffer_sensitivity.csv, S0 scheme).
## A cell is flagged as lying on the boundary when fdr_emp is within 0.01 of 0.05.
## The "original grade" is the grade the same rule gives with the theoretical FDR (fdr_theory).
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "00b_scheme.R"))

SS <- read.csv(file.path(SC_OUT, "stouffer_sensitivity.csv"), stringsAsFactors = FALSE)
SS <- SS[SS$scheme_GSE196870 == PRIMARY_SCHEME & SS$weighting == "w_equal", ]
ord <- data.frame(stratum = rep(c("acute","h24","later"), each = 5),
                  program = rep(c("TNFA","INFL","UPR","OXPHOS","E2F"), 3), stringsAsFactors = FALSE)
SS <- SS[match(paste(ord$stratum, ord$program), paste(SS$stratum, SS$program)), ]
stopifnot(nrow(SS) == 15L, !anyNA(SS$Z))

grade <- function(k, n_up, fdr) {
  same <- n_up == 0L | n_up == k
  ifelse(!same, "heterogeneous",
         ifelse(fdr < 0.05, "conf", ifelse(fdr < 0.10, "expl", "ns")))
}
E <- data.frame(stratum = SS$stratum, program = SS$program, k = SS$k, n_up = SS$n_up,
                n_down = SS$k - SS$n_up,
                direction = ifelse(SS$n_up == SS$k, "Up", ifelse(SS$n_up == 0L, "Down", "split")),
                Z = SS$Z, p_emp = SS$p_emp, fdr_emp = SS$fdr_emp,
                resolution_floor = SS$resolution_floor, empirical_floor = SS$empirical_floor,
                B = SS$B, fdr_theory = SS$fdr_theory, stringsAsFactors = FALSE)
E$original_grade <- grade(E$k, E$n_up, E$fdr_theory)
E$D9_grade       <- grade(E$k, E$n_up, E$fdr_emp)
E$changed        <- E$original_grade != E$D9_grade
E$boundary_note  <- ifelse(abs(E$fdr_emp - 0.05) < 0.01 & E$D9_grade %in% c("conf", "expl"),
                           "fdr_emp within 0.01 of 0.05", NA_character_)
write.csv(E, file.path(SC_OUT, "evidence_grades_calibrated.csv"), row.names = FALSE, na = "")

## ---- temporal_evidence.csv: D9 columns appended to the 21_temporal.R output ----
TE <- read.csv(file.path(SC_OUT, "temporal_evidence.csv"), stringsAsFactors = FALSE)
if (!"acute_grade_superseded" %in% names(TE)) {          # first pass: keep the pre-D9 grades under a new name
  for (s in c("acute", "h24", "later")) names(TE)[names(TE) == paste0(s, "_grade")] <- paste0(s, "_grade_superseded")
  names(TE)[names(TE) == "evidence_grade"] <- "evidence_grade_superseded"
  TE <- TE[, !names(TE) %in% c("acute_fdr_emp","acute_grade_D9","h24_fdr_emp","h24_grade_D9",
                              "later_fdr_emp","later_grade_D9","IUT_category","evidence_grade_D9")]
}
for (s in c("acute", "h24", "later")) {
  e <- E[E$stratum == s, ]
  TE[[paste0(s, "_fdr_emp")]]  <- e$fdr_emp[match(TE$program, e$program)]
  TE[[paste0(s, "_grade_D9")]] <- e$D9_grade[match(TE$program, e$program)]
}
TE$IUT_category <- ifelse(TE$IUT_fdr < 0.05, "supported", ifelse(TE$IUT_fdr < 0.10, "suggestive", "not supported"))
TE$evidence_grade_D9 <- sprintf("acute=%s; h24=%s; later=%s; IUT=%s",
                                TE$acute_grade_D9, TE$h24_grade_D9, TE$later_grade_D9, TE$IUT_category)
i <- TE$program == "UPR"
TE$UPR_note <- NA_character_
TE$UPR_note[i] <- sprintf(paste0("Early increase concordant (acute %d/%d conf; h24 %d/%d conf); later decrease direction-consistent ",
  "%d/%d but ns (fdr_emp %.2f); IUT not supported (FDR %.3f). Do not write UPR as 'attenuated' alongside TNF/INFL (D8)."),
  TE$acute_n_up[i], TE$acute_k[i], TE$h24_n_up[i], TE$h24_k[i], TE$later_k[i] - TE$later_n_up[i], TE$later_k[i],
  TE$later_fdr_emp[i], TE$IUT_fdr[i])
base_note <- paste0("later stratum = 2 studies only (GSE100365 day 7 vs day 1, auditory nerve/modiolus; E-MTAB-16125 week 1 vs 72 h, ",
                    "whole cochlea); different intervals and different tissues, so not a common cochlear-compartment time response")
TE$later_stratum_note <- base_note
j <- TE$program == "TNFA"
TE$later_stratum_note[j] <- sprintf("%s | later TNFA fdr_emp %.4f = conf at boundary; resolution floor %g",
                                    base_note, TE$later_fdr_emp[j], E$resolution_floor[E$stratum == "later" & E$program == "TNFA"])
write.csv(TE, file.path(SC_OUT, "temporal_evidence.csv"), row.names = FALSE)
cat("D9 grades written:", nrow(E), "cells;", sum(E$changed), "changed relative to the theoretical-FDR grade\n")
