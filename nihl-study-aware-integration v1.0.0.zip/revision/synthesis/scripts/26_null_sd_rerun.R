## Null-SD diagnosis, recomputed under whichever GSE196870 scheme the surrounding tree
## implements.  This is 25_null_sd_diagnosis.R with the output schema requested by review:
##   study, contrast, rho_assumed, null_sd_at_0.01, null_sd_at_measured, measured_rho
##
## Everything else is deliberately identical to 25_null_sd_diagnosis.R:
##   * the same five tested study-contrasts (the ones named in the manuscript sentence),
##   * the same null engine (07_perm_engine.R, fully enumerated relabellings, sex-blocked
##     where the block structure allows >= 10 relabellings),
##   * rho_assumed = round(measured median, 3), exactly as the original script does,
##   * the same 1/2-sided z-vector definition via 00_common.R.
## The two GSE196870 contrasts are added as extra rows flagged in_original_five = FALSE so that
## the effect of the scheme switch is visible; they are NOT part of the manuscript's five.
##
## Usage: Rscript 26_null_sd_rerun.R <camera_estimated_correlation.csv> <out.csv> <tag>
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R")); source(file.path(SC_SCR, "07_perm_engine.R"))
suppressPackageStartupMessages({library(limma); library(edgeR); library(statmod)})
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) >= 3L)
## the scheme whose GSE196870 object is used; the S1 control tree passes "S1" explicitly
SCHEME <- if (length(A) >= 4L) A[4] else PRIMARY_SCHEME
O <- readRDS(file.path(SC_CACHE, "expr.rds")); H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))
STR <- syn_strata(); LP <- syn_levelpairs()
EC <- read.csv(A[1], stringsAsFactors = FALSE)
## the five study-contrasts of the original script, then the two GSE196870 ones as extras
targets <- list(c("acute","GSE160639"), c("acute","GSE312476"), c("acute","GSE100365"),
                c("h24","GSE100365"), c("later","GSE100365"))
extras  <- list(c("acute","GSE196870"), c("h24","GSE196870"))
src_of <- function(study) switch(study, GSE160639="GSE160639", GSE196870=PRIMARY_SCHEME,
                                 GSE312476="GSE312476", GSE100365="GSE100365", EMTAB="EMTAB")
out <- list()
run_one <- function(tg, in5) {
  s <- tg[1]; study <- tg[2]
  obj <- O[[if (study == "GSE196870") paste0("GSE196870_", SCHEME) else src_of(study)]]
  cn <- STR[[s]][[study]]; lp <- LP[[study]][[cn]]
  blk <- switch(study, GSE100365="sex", EMTAB="sex", NULL)
  lab_all <- as.character(obj$meta[[obj$group_var]]); ss <- which(lab_all %in% lp)
  nb <- if (is.null(blk)) NA else length(enumerate_relabelings(lab_all[ss], as.character(obj$meta[[blk]][ss])))
  use_blk <- !is.na(nb) && nb >= 10
  rho_est <- median(EC$correlation[EC$stratum==s & EC$study==study], na.rm=TRUE)
  rho_assumed <- round(rho_est, 3)
  sds <- list()
  for (igc in c(0.01, rho_assumed)) {
    pn <- perm_null_study(obj, lp[2], lp[1], block_col=if (use_blk) blk else NULL,
                          hallmark=H$hallmark, order50=H$order50, inter.gene.cor=igc)
    sds[[if (igc == 0.01) "a" else "b"]] <- apply(pn$null, 2, sd, na.rm=TRUE)
    n_perms <- nrow(pn$null)
  }
  cat(sprintf("  %-6s %-10s %-24s rho=%.4f -> assumed %.3f ; perms %d ; sd %.3f -> %.3f\n",
              s, study, cn, rho_est, rho_assumed, n_perms,
              median(sds$a), median(sds$b)))
  data.frame(study=study, contrast=cn, stratum=s, rho_assumed=rho_assumed,
    null_sd_at_0.01=median(sds$a), null_sd_at_measured=median(sds$b),
    measured_rho=rho_est, n_perms=n_perms,
    q25_at_measured=quantile(sds$b,.25), q75_at_measured=quantile(sds$b,.75),
    in_original_five=in5, scheme=SCHEME, stringsAsFactors=FALSE)
}
cat("scheme:", SCHEME, "  rho source:", A[1], "\n")
for (tg in targets) out[[length(out)+1]] <- run_one(tg, TRUE)
for (tg in extras)  out[[length(out)+1]] <- run_one(tg, FALSE)
out <- do.call(rbind, out)
N <- out[out$in_original_five, ]
cat(sprintf("\n[%s] five tested contrasts: measured rho %.4f - %.4f ; null SD at measured rho %.4f - %.4f\n",
            A[3], min(N$measured_rho), max(N$measured_rho),
            min(N$null_sd_at_measured), max(N$null_sd_at_measured)))
cat(sprintf("[%s] null SD at 0.01            : %.4f - %.4f\n", A[3],
            min(N$null_sd_at_0.01), max(N$null_sd_at_0.01)))
write.csv(out, A[2], row.names=FALSE)
