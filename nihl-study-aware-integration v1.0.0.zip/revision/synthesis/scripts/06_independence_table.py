import os
# SC_CACHE / SC_OUT as for the R scripts (defaults: revision/synthesis/cache and revision/synthesis/results)
_ROOT = os.environ.get("SC_ROOT", os.path.abspath(os.path.join(os.getcwd(), "..", "..", "..")))
CACHE = os.environ.get("SC_CACHE", os.path.join(_ROOT, "revision", "synthesis", "cache"))
OUT   = os.environ.get("SC_OUT",   os.path.join(_ROOT, "revision", "synthesis", "results"))
RAW   = os.path.join(CACHE, "gsm_raw")
os.makedirs(RAW, exist_ok=True); os.makedirs(OUT, exist_ok=True)
import csv, json, re
raw=json.load(open(RAW+"/independence_raw.json"))
dup={ (r["study_a"],r["study_b"]): r for r in csv.DictReader(open(OUT+"/duplicate_sample_check.csv")) }
def dmax(a,b):
    r=dup.get((a,b)) or dup.get((b,a))
    return r["max_r"] if r else ""
meta={
 "GSE8342":   dict(lab="University of California, Davis (Vazquez / Lonsbury-Martin)", pmid="21187137", lab_short="UC Davis",
                   rel="BioProject PRJNA101347; no SuperSeries", strain="129X1/SvJ, B6.CAST", tissue="microdissected membranous labyrinth",
                   in_synthesis="strain-interaction discovery (not in Stouffer synthesis)", n_gsm=10),
 "E-MTAB-16125": dict(lab="University of Antwerp (Sels / Aben / Verdoodt)", pmid="", lab_short="Antwerp",
                   rel="ArrayExpress/BioStudies E-MTAB-16125; not a GEO series", strain="CBA/CaJ (17-month-old adults)", tissue="whole cochlea",
                   in_synthesis="h24 and later strata", n_gsm=20),
 "GSE160639": dict(lab="Northwestern University (Savas)", pmid="33238128", lab_short="Northwestern (Savas)",
                   rel="BioProject PRJNA673829; no SuperSeries", strain="FVB/NCrl", tissue="whole cochlea",
                   in_synthesis="acute", n_gsm=12),
 "GSE196870": dict(lab="Kunming Institute of Zoology (Hao)", pmid="40919728", lab_short="Kunming (Hao)",
                   rel="BioProject PRJNA807641; no SuperSeries", strain="C57BL/6", tissue="whole cochlea",
                   in_synthesis="acute and h24", n_gsm=27),
 "GSE312476": dict(lab="Northwestern University (Savas)", pmid="41415422", lab_short="Northwestern (Savas)",
                   rel="BioProject PRJNA1373571; same publication as GSE312646 but separate BioProject and separate samples",
                   strain="CBA/CaJ", tissue="whole cochlea", in_synthesis="acute", n_gsm=12),
 "GSE312646": dict(lab="Northwestern University (Savas)", pmid="41415422", lab_short="Northwestern (Savas)",
                   rel="BioProject PRJNA1375652; GeoMx spatial transcriptomics", strain="CBA/CaJ", tissue="whole cochlea (GeoMx ROIs)",
                   in_synthesis="not analysed (spatial assay, different technology)", n_gsm=51),
 "GSE100365": dict(lab="Medical University of South Carolina (Barth)", pmid="29437856", lab_short="MUSC (Barth)",
                   rel="BioProject PRJNA391458; no SuperSeries", strain="CBA/CaJ", tissue="auditory nerve / modiolus",
                   in_synthesis="acute, h24 and later", n_gsm=15),
 "GSE168041": dict(lab="Decibel Therapeutics (Pregernig)", pmid="34592158", lab_short="Decibel Tx (Pregernig)",
                   rel="BioProject PRJNA705914; no SuperSeries", strain="CBA/CaJ", tissue="single-cell, neuronal and lateral-wall dissections",
                   in_synthesis="single-cell localization only", n_gsm=16),
 "GSE107086": dict(lab="EPFL / Karolinska (Weger / Canlon)", pmid="31353184", lab_short="EPFL (Weger)",
                   rel="SubSeries of SuperSeries GSE107087 (which is also SuperSeries of GSE88954); BioProject PRJNA418971",
                   strain="CBA/Sca", tissue="whole cochlea", in_synthesis="context sensitivity only (not in Stouffer synthesis)", n_gsm=24),
}
order=["GSE160639","GSE196870","GSE312476","GSE100365","E-MTAB-16125","GSE8342","GSE168041","GSE107086","GSE312646"]
rows=[]
for a in order:
    m=meta[a]; r=raw.get(a,{})
    nchk=max([float(v["max_r"]) for k,v in dup.items() if a in k] or [0])
    rows.append(dict(
      accession=a, n_GSM_or_samples=r.get("n_gsm", m["n_gsm"]),
      submitter_contact=m["lab"], contact_institute=m["lab_short"],
      pubmed_id=m["pmid"] or "NA (no associated publication in the ArrayExpress record)",
      series_relations=m["rel"],
      strain=m["strain"], tissue=m["tissue"],
      biosample_ids_retrieved=len(r.get("biosamples",[])),
      sra_experiment_ids_retrieved=len(r.get("srxs",[])),
      overlaps_with_other_accessions="none (0 shared GSM, 0 shared BioSample, 0 shared SRX across all pairs)",
      max_cross_study_sample_correlation=round(nchk,4) if nchk else "NA",
      duplicate_data_flag="no" if nchk < 0.999 else "YES - investigate",
      role_in_this_study=m["in_synthesis"],
      independence_status="independent",
      evidence=("GEO/BioStudies metadata: distinct BioProject or ArrayExpress accession, distinct submitter laboratory, "
                "no shared GSM/BioSample/SRA experiment; cross-study sample correlation max |r| = "
                f"{round(nchk,3) if nchk else 'NA'} (no near-identity pair)")))
# same-lab note for the two Northwestern series
for r in rows:
    if r["accession"] in ("GSE312476",):
        r["independence_status"]="independent, same_lab"
        r["evidence"] += ("; SAME LABORATORY as GSE160639 (Savas, Northwestern) but a different experiment "
                          "(different mouse strain FVB/NCrl vs CBA/CaJ, different exposure protocol, different BioProject) "
                          "and zero shared samples - treated as independent, source noted in Methods")
with open(OUT+"/accession_independence.csv","w",newline="") as f:
    w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
print(len(rows),"rows written")
for r in rows: print(r["accession"], "|", r["independence_status"], "|", r["max_cross_study_sample_correlation"])
