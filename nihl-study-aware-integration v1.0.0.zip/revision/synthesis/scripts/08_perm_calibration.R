## Appendix B2.3 -- real calibration.  Run only after the three self-tests pass.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R")); source(file.path(SC_SCR, "07_perm_engine.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds")); H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))
STR <- syn_strata(); NU <- syn_nunits(); LP <- syn_levelpairs()
SEED <- SEED_GLOBAL

## study key -> cached object name
src_of <- function(study, scheme) switch(study,
  GSE160639="GSE160639", GSE196870=if (scheme==PRIMARY_SCHEME) "GSE196870_S0" else "GSE196870_S1",
  GSE312476="GSE312476", GSE100365="GSE100365", EMTAB="EMTAB")

run_scheme <- function(scheme, igc = 0.01) {
  nulls <- list()
  ledger <- list()
  for (s in names(STR)) for (study in names(STR[[s]])) {
    cn <- STR[[s]][[study]]; obj <- O[[src_of(study, scheme)]]
    g2 <- LP[[study]][[cn]][1]; g1 <- LP[[study]][[cn]][2]
    blk <- syn_blockcol(study)
    ## enumerate blocked and unblocked; choose blocked when it keeps >= 10 relabelings
    lab_all <- as.character(obj$meta[[obj$group_var]]); ss <- which(lab_all %in% c(g1,g2))
    n_unb <- length(enumerate_relabelings(lab_all[ss], NULL))
    n_blk <- if (is.null(blk)) NA_integer_ else
      length(enumerate_relabelings(lab_all[ss], as.character(obj$meta[[blk]][ss])))
    use_blk <- !is.na(n_blk) && n_blk >= 10
    cat(sprintf("%-7s %-12s %-22s enums: blocked=%s unblocked=%d -> using %s\n",
        s, study, cn, ifelse(is.na(n_blk), "n/a", n_blk), n_unb,
        if (use_blk) "BLOCKED" else "unblocked"))
    t0 <- Sys.time()
    pn <- perm_null_study(obj, g1, g2, block_col = if (use_blk) blk else NULL,
                          hallmark = H$hallmark, order50 = H$order50, inter.gene.cor = igc)
    el <- as.numeric(difftime(Sys.time(), t0, units="secs"))
    obs <- observed_z(obj, paste0(g2,"|",g1), H$hallmark, H$order50, inter.gene.cor = igc)
    ## assertion: observed value must agree with the main-analysis z
    main <- z_vector(obj$camera[obj$camera$contrast == cn, ], H$order50)
    stopifnot(isTRUE(all.equal(unname(obs), unname(main), tolerance = 1e-8)))
    key <- paste(s, study, sep="|")
    nulls[[key]] <- pn$null
    ledger[[key]] <- data.frame(stratum=s, study=study, contrast=cn, scheme=scheme,
      block=if (use_blk) blk else NA, n_perms=pn$n_perms,
      n_perms_blocked=n_blk, n_perms_unblocked=n_unb,
      resolution_insufficient = pn$n_perms < 10,
      observed_in_perm_set = any(vapply(pn$perms, function(v) all(v == pn$observed), logical(1))),
      seconds=round(el,2))
  }
  list(nulls=nulls, ledger=do.call(rbind, ledger), observed=NULL)
}

RES <- list()
for (scheme in c(PRIMARY_SCHEME, ALT_SCHEME)) {
  cat("\n###### GSE196870 scheme", scheme, "######\n")
  RES[[scheme]] <- run_scheme(scheme)
  saveRDS(RES[[scheme]], file.path(SC_CACHE, sprintf("perm_null_%s.rds", scheme)))
}
LED <- do.call(rbind, lapply(RES, `[[`, "ledger"))
rownames(LED) <- NULL
print(LED, row.names=FALSE)
cat("\nresolution floors (product of per-study enumeration counts):\n")
for (s in names(STR)) {
  L <- LED[LED$stratum==s & LED$scheme==PRIMARY_SCHEME,]
  cat(sprintf("  %-6s k=%d  prod(n_perms)=%s  floor p = %.3g\n", s, nrow(L),
              format(prod(L$n_perms), big.mark=","), 1/prod(L$n_perms)))
}
write.csv(LED, file.path(SC_OUT, "perm_calibration_ledger.csv"), row.names=FALSE)
