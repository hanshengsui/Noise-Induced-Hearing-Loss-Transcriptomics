## A3 Synthesis -- common helpers.  Seeds are passed explicitly everywhere.
options(stringsAsFactors = FALSE)
SEED_GLOBAL <- 20261029L

read_gmt <- function(path) {
  parts <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  parts <- parts[lengths(parts) >= 3L]
  ans <- lapply(parts, function(x) unique(toupper(x[-c(1L, 2L)])))
  names(ans) <- vapply(parts, `[[`, character(1), 1L)
  ans
}

FOCAL <- c(TNFA = "HALLMARK_TNFA_SIGNALING_VIA_NFKB",
           INFL = "HALLMARK_INFLAMMATORY_RESPONSE",
           UPR  = "HALLMARK_UNFOLDED_PROTEIN_RESPONSE",
           OXPHOS = "HALLMARK_OXIDATIVE_PHOSPHORYLATION",
           E2F  = "HALLMARK_E2F_TARGETS")

## exactly the wrapper used by the main analysis (01_expanded_bulk_validation.R)
camera_pr_signed <- function(statistic, pathways, inter.gene.cor = 0.01,
                             use.ranks = FALSE) {
  statistic <- statistic[is.finite(statistic)]
  names(statistic) <- toupper(names(statistic))
  statistic <- statistic[!duplicated(names(statistic))]
  index <- lapply(pathways, function(set) which(names(statistic) %in% set))
  valid <- lengths(index) >= 5L & lengths(index) < length(statistic) - 2L
  tab <- limma::cameraPR(statistic, index = index[valid],
                         inter.gene.cor = inter.gene.cor,
                         use.ranks = use.ranks, sort = FALSE)
  signed_t <- ifelse(tab$Direction == "Up",
                     qt(tab$PValue / 2, df = length(statistic) - 2, lower.tail = FALSE),
                     qt(tab$PValue / 2, df = length(statistic) - 2))
  data.frame(programme = rownames(tab), n_genes = tab$NGenes,
             direction = tab$Direction, camera_t = signed_t,
             PValue = tab$PValue, FDR = tab$FDR,
             n_sets_tested = sum(valid), ranked_universe = length(statistic),
             row.names = NULL)
}

signed_z_of <- function(p, direction) {
  ifelse(direction == "Up", 1, -1) * qnorm(p / 2, lower.tail = FALSE)
}

## Signed z on a FIXED programme order (the 50 Hallmarks), NA when not tested
z_vector <- function(cam, order50) {
  z <- signed_z_of(cam$PValue, cam$direction)
  names(z) <- cam$programme
  out <- rep(NA_real_, length(order50)); names(out) <- order50
  out[names(z)] <- z
  out
}

## Enumerate all distinct relabellings of the two-group label vector, optionally
## restricted to within-block exchanges.  Returns a list of label vectors
## (including the observed one).  Verified against closed forms: 4v4 -> 70, 3v3 -> 20.
enumerate_relabelings <- function(lab, block = NULL) {
  u <- unique(lab)
  stopifnot(length(u) == 2L)
  a1 <- u[1]; a2 <- u[2]                    # a1 = reference (first in the vector), a2 = other
  idx1 <- which(lab == a1)
  n <- length(lab)
  if (is.null(block)) {
    combos <- combn(n, length(idx1), simplify = FALSE)
    labs <- lapply(combos, function(cc) { v <- lab; v[] <- a2; v[cc] <- a1; v })
  } else {
    stopifnot(length(block) == n)
    bl <- split(seq_len(n), block)
    per_block <- lapply(bl, function(ii) {
      k <- sum(lab[ii] == a1)
      if (k == 0L || k == length(ii)) return(list(lab[ii]))
      lapply(combn(length(ii), k, simplify = FALSE), function(cc) {
        v <- lab[ii]; v[] <- a2; v[cc] <- a1; v })
    })
    grid <- expand.grid(lapply(per_block, seq_along), KEEP.OUT.ATTRS = FALSE)
    labs <- lapply(seq_len(nrow(grid)), function(r) {
      v <- lab
      for (b in seq_along(bl)) v[bl[[b]]] <- per_block[[b]][[grid[r, b]]]
      v })
  }
  key <- vapply(labs, paste, character(1), collapse = "")
  out <- labs[!duplicated(key)]
  ## guarantee the observed labelling is present and first
  obs <- which(vapply(out, function(v) all(v == lab), logical(1)))
  c(out[obs], out[-obs])
}

bh <- function(p) p.adjust(p, method = "BH")

summ_stat <- function(cam, order50) {
  z <- z_vector(cam, order50)
  tibble::tibble(programme = order50, z = as.numeric(z),
                 fdr50 = cam$FDR[match(order50, cam$programme)],
                 n_genes = cam$n_genes[match(order50, cam$programme)])
}
