## Consolidate the per-item deliverables named in the A3 task specification.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds"))
STR <- syn_strata()
cat_cut <- function(p) as.character(cut(p, c(-Inf,.05,.10,Inf), labels=c("conf","expl","ns")))

## ---- perm_calibration.csv : per-study enumeration counts, resolution floors, and the
## synthesis-level empirical p for the three weightings.
LED <- read.csv(file.path(SC_OUT, "perm_calibration_ledger.csv"))
SS  <- read.csv(file.path(SC_OUT, "stouffer_sensitivity.csv"))
SS  <- SS[SS$scheme_GSE196870 == PRIMARY_SCHEME, ]
rows <- list()
for (s in names(STR)) {
  L <- LED[LED$stratum == s & LED$scheme == "S1", ]
  prod_n <- prod(L$n_perms)
  for (p in names(FOCAL)) for (w in c("w_equal","w_sqrtn","w_df")) {
    r <- SS[SS$stratum == s & SS$program == p & SS$weighting == w, ]
    rows[[length(rows)+1]] <- data.frame(stratum=s, program=p, weighting=w,
      per_study_n_perms = paste(sprintf("%s=%d", L$study, L$n_perms), collapse="; "),
      n_studies = nrow(L), perm_product = prod_n,
      resolution_floor_theoretical = 1/prod_n,
      B_draws = r$B, empirical_floor = 1/(r$B+1),
      Z_obs = r$Z, p_theory = r$p_theory, p_emp = r$p_emp,
      n_draws_exceeding = r$n_draws_if_hit,
      null_sd_of_synthesis_Z = r$null_sd,
      resolution_insufficient = any(L$resolution_insufficient),
      block_used = paste(sprintf("%s=%s", L$study, ifelse(is.na(L$block),"none",L$block)), collapse="; "))
  }
}
PC <- do.call(rbind, rows); rownames(PC) <- NULL
write.csv(PC, file.path(SC_OUT, "perm_calibration.csv"), row.names=FALSE)
cat("perm_calibration.csv:", nrow(PC), "rows\n")

## ---- perm_selftest.csv : the three self-tests in one table
A <- read.csv(file.path(SC_OUT, "perm_selftest_enumeration.csv"))
B <- read.csv(file.path(SC_OUT, "perm_selftest_blocking.csv"))
C <- read.csv(file.path(SC_OUT, "perm_selftest_uniformity_bins.csv"))
st <- readRDS(file.path(SC_CACHE, "selftest_uniform.rds"))
rows <- list()
for (i in seq_len(nrow(A))) rows[[length(rows)+1]] <- data.frame(
  selftest="A_enumeration", item=A$design[i],
  observed=sprintf("n_relabelings=%d", A$n_relabelings[i]),
  expected=sprintf("closed_form=%d", A$closed_form[i]),
  pass=A$matches_closed_form[i] && A$observed_first[i],
  detail=sprintf("observed labelling present and first: %s", A$observed_first[i]))
for (i in seq_len(nrow(B))) rows[[length(rows)+1]] <- data.frame(
  selftest="B_blocking", item=B$design[i],
  observed=sprintf("n_perms=%d, frac_label_vectors_changed=%.3f", B$n_perms[i], B$frac_label_vectors_changed[i]),
  expected="labels change; within-block multiset preserved; 0 cross-block moves",
  pass=(is.na(B$n_perms_with_cross_block_moves[i]) || B$n_perms_with_cross_block_moves[i]==0) &&
       (is.na(B$within_block_multiset_preserved[i]) || B$within_block_multiset_preserved[i]),
  detail=sprintf("cross_block_moves=%s; within_block_multiset_preserved=%s",
                 B$n_perms_with_cross_block_moves[i], B$within_block_multiset_preserved[i]))
rows[[length(rows)+1]] <- data.frame(
  selftest="B_uniformity_KS", item=sprintf("%d simulated null datasets, B=%d relabelings each", length(st$pv), st$B),
  observed=sprintf("KS D=%.4f, p=%.4f, mean p=%.3f", st$ks$statistic, st$ks$p.value, mean(st$pv)),
  expected="empirical p approximately uniform; KS p > 0.05",
  pass=st$ks$p.value > 0.05, detail="one gene set per simulated dataset so p-values are independent")
for (i in seq_len(nrow(C))) rows[[length(rows)+1]] <- data.frame(
  selftest="B_uniformity_bin", item=sprintf("alpha=%.2f", C$alpha[i]),
  observed=sprintf("%.4f", C$observed[i]), expected=sprintf("%.4f", C$discrete_expect[i]),
  pass=C$binom_p[i] > 0.05, detail=sprintf("binomial p=%.3f", C$binom_p[i]))
D <- read.csv(file.path(SC_OUT, "perm_selftest_observed_agreement.csv"))
for (i in seq_len(nrow(D))) rows[[length(rows)+1]] <- data.frame(
  selftest="C_observed_agreement", item=paste(D$stratum[i], D$study[i], D$contrast[i]),
  observed=sprintf("max|z_refit - z_main| = %.3e over %d programmes", D$max_abs_diff[i], D$n_programs_compared[i]),
  expected="all.equal(tolerance = 1e-8)", pass=D$agree_1e8[i],
  detail="observed value computed from the real labels only, never from the null matrix")
SEL <- do.call(rbind, rows); rownames(SEL) <- NULL
write.csv(SEL, file.path(SC_OUT, "perm_selftest.csv"), row.names=FALSE)
cat("perm_selftest.csv:", nrow(SEL), "rows; all pass =", all(SEL$pass), "\n")

## ---- igc_sensitivity.csv : wide per-set table across the five settings
IG <- read.csv(file.path(SC_OUT, "igc_sensitivity_long.csv"))
w <- reshape(IG[!is.na(IG$rho), c("stratum","study","contrast","programme","rho","direction","FDR")],
             idvar=c("stratum","study","contrast","programme"), timevar="rho", direction="wide")
est <- IG[is.na(IG$rho) & !is.na(IG$n_genes), c("stratum","study","contrast","programme","direction","FDR")]
names(est)[5:6] <- c("direction.estimated","FDR.estimated")
fry <- IG[is.na(IG$rho) & is.na(IG$n_genes), c("stratum","study","contrast","programme","direction","FDR")]
names(fry)[5:6] <- c("direction.fry","FDR.fry")
M <- Reduce(function(a,b) merge(a,b,by=c("stratum","study","contrast","programme"), all=TRUE), list(w, est, fry))
for (rho in c("0.01","0.05","0.1")) {
  M[[paste0("cat.", rho)]] <- cat_cut(M[[paste0("FDR.", rho)]])
}
M[["cat.estimated"]] <- cat_cut(M[["FDR.estimated"]])
M[["cat.fry"]] <- cat_cut(M[["FDR.fry"]])
M$direction_preserved_0.05 <- M[["direction.0.01"]] == M[["direction.0.05"]]
M$direction_preserved_0.1  <- M[["direction.0.01"]] == M[["direction.0.1"]]
M$direction_preserved_estimated <- M[["direction.0.01"]] == M[["direction.estimated"]]
M$direction_preserved_fry <- M[["direction.0.01"]] == M[["direction.fry"]]
M$category_preserved_0.05 <- M[["cat.0.01"]] == M[["cat.0.05"]]
M$category_preserved_0.1  <- M[["cat.0.01"]] == M[["cat.0.1"]]
M$category_preserved_estimated <- M[["cat.0.01"]] == M[["cat.estimated"]]
M$category_preserved_fry <- M[["cat.0.01"]] == M[["cat.fry"]]
M$is_focal_programme <- M$programme %in% FOCAL
write.csv(M, file.path(SC_OUT, "igc_sensitivity.csv"), row.names=FALSE)
cat("igc_sensitivity.csv:", nrow(M), "rows\n")
cat(sprintf("  direction preserved (0.05/0.1/estimated/fry): %.3f / %.3f / %.3f / %.3f\n",
  mean(M$direction_preserved_0.05), mean(M$direction_preserved_0.1),
  mean(M$direction_preserved_estimated, na.rm=TRUE), mean(M$direction_preserved_fry, na.rm=TRUE)))
cat(sprintf("  category preserved (0.05/0.1/estimated/fry): %.3f / %.3f / %.3f / %.3f\n",
  mean(M$category_preserved_0.05), mean(M$category_preserved_0.1),
  mean(M$category_preserved_estimated, na.rm=TRUE), mean(M$category_preserved_fry, na.rm=TRUE)))
