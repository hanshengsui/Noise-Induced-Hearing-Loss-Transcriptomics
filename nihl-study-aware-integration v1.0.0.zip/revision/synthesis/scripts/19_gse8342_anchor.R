## Independent anchor check: genes the paper states were induced ONLY in the resistant strain
## must carry a POSITIVE interaction coefficient under the analysed contrast coding.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); suppressPackageStartupMessages({library(limma)})
source(file.path(SC_SCR, "utils.R"))
g <- read_geo_series_matrix(file.path(SC_DL, "GSE8342_series_matrix.txt.gz"))
y <- g$expr; if (max(y, na.rm=TRUE) > 100) y <- log2(y + 1)
titles <- g$sample_meta$title[match(colnames(y), g$sample_meta$sample_id)]
grp <- ifelse(grepl("B6\\.CAST", titles) & grepl("_noise_", titles), "susceptible_noise",
       ifelse(grepl("B6\\.CAST", titles), "susceptible_control",
       ifelse(grepl("_noise_", titles), "resistant_noise", "resistant_control")))
grp <- factor(grp, levels = c("resistant_control","resistant_noise","susceptible_control","susceptible_noise"))
des <- model.matrix(~0+grp); colnames(des) <- levels(grp)
C <- cbind(resistant=c(-1,1,0,0), susceptible=c(0,0,-1,1), interaction=c(-1,1,1,-1))
rownames(C) <- colnames(des)
annot <- read_geo_annotation(file.path(SC_DL, "GPL81.annot.gz"))
sy <- toupper(sub("\\s*///.*$", "", annot[["Gene symbol"]][match(rownames(y), annot[["ID"]])]))
fit <- eBayes(contrasts.fit(lmFit(y, des), C), robust=TRUE, trend=FALSE)
tt <- topTable(fit, coef="interaction", number=Inf, sort.by="none")
tt$symbol <- sy[match(rownames(tt), rownames(y))]
## genes the paper states changed only in the resistant (129) mice
anchors <- toupper(c("Hspa1a","Hspa1b","Hspb1","Gadd45b","Gadd45g","Cdkn1a","Ier3","Nfkbia","Fos","Junb","Jun"))
res <- tt[tt$symbol %in% anchors, c("symbol","logFC","t","P.Value","adj.P.Val")]
res <- res[order(-res$t), ]
cat("=== interaction contrast (resistant - susceptible noise effect) for paper anchors ===\n")
print(res, digits=4, row.names=FALSE)
cat("\npositive t = larger noise-induced increase in the RESISTANT (129X1/SvJ) strain\n")
cat("paper: 'a significant induction of genes involved in cell-survival pathways such as the HSP70",
    "and HSP40, GADD45b and p21 was detected only in the resistant mice'\n")
## Group means for Hspa1a to show the raw pattern
for (s in toupper(c("Hspa1a","Gadd45b","Cdkn1a"))) {
  ii <- which(tt$symbol == s)
  if (!length(ii)) next
  v <- y[ii[which.max(rowMeans(y[ii,,drop=FALSE]))], ]
  cat(sprintf("\n%s group means: %s\n", s,
      paste(sprintf("%s=%.2f", names(tapply(v, grp, mean)), tapply(v, grp, mean)), collapse="  ")))
}
write.csv(res, file.path(SC_OUT, "gse8342_anchor_genes.csv"), row.names=FALSE)
