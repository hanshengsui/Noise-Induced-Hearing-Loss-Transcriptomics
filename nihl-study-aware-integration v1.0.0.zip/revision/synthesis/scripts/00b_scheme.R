## Scale ruling (2026-10-29): the deposited GSE196870 matrix is ALREADY log2 (median 3.20, max 16.03,
## back-transformed per-sample sums ~5.5e5).  D1 is withdrawn.  The submitted scheme S0 - using the
## deposited values directly - is the primary analysis; S1 = log2(FPKM+1) is a sensitivity analysis
## (an ADDITIONAL log transform on top of values that are already logged).
PRIMARY_SCHEME <- "S0"
ALT_SCHEME     <- "S1"
SCHEME_LABEL <- c(S0 = "deposited log2 values (primary)",
                  S1 = "extra log2(x+1) applied to already-log2 values (sensitivity)")
