## (a) measured-rho range and (b) null-SD range for the five tested study-contrasts, under both
## schemes, plus (c) a drop-in English sentence.  All values computed from the two CSVs.
## Usage: Rscript 32_null_sd_summary.R <S0 csv> <S1 csv> <out txt>
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) == 3L)
S0 <- read.csv(A[1], stringsAsFactors = FALSE); S1 <- read.csv(A[2], stringsAsFactors = FALSE)
f5 <- function(z) z[z$in_original_five, ]
N0 <- f5(S0); N1 <- f5(S1)
stopifnot(nrow(N0) == 5L, nrow(N1) == 5L)
rr <- function(z) sprintf("%.4f-%.4f", min(z$measured_rho), max(z$measured_rho))
sr <- function(z, col) sprintf("%.2f-%.2f", min(z[[col]]), max(z[[col]]))
L <- c("NULL-SD DIAGNOSIS -- the five tested study-contrasts, S0 and S1",
  "",
  "The five tested study-contrasts are acute GSE160639, acute GSE312476, acute GSE100365,",
  "h24 GSE100365 and later GSE100365.  None of them is GSE196870, so their measured",
  "correlation and their permutation null are scheme-independent by construction; the two",
  "GSE196870 contrasts are carried as extra rows for completeness.",
  "",
  sprintf("(a) measured correlation, five tested contrasts   S0: %s   S1: %s", rr(N0), rr(N1)),
  sprintf("(b) null SD at the measured correlation          S0: %s   S1: %s",
          sr(N0, "null_sd_at_measured"), sr(N1, "null_sd_at_measured")),
  sprintf("    null SD at inter.gene.cor = 0.01             S0: %s   S1: %s",
          sr(N0, "null_sd_at_0.01"), sr(N1, "null_sd_at_0.01")),
  sprintf("    maximum cell-wise difference between the two schemes on those five: %.2e",
          max(abs(c(N0$null_sd_at_0.01, N0$null_sd_at_measured, N0$measured_rho) -
                  c(N1$null_sd_at_0.01, N1$null_sd_at_measured, N1$measured_rho)))),
  "",
  "GSE196870 contrasts (extra rows, scheme-dependent):",
  sprintf("  %-6s %-24s rho %.4f -> %.4f ; null SD %.4f -> %.4f (at 0.01: %.4f -> %.4f)",
          S0$stratum[!S0$in_original_five], S0$contrast[!S0$in_original_five],
          S0$measured_rho[!S0$in_original_five], S1$measured_rho[!S1$in_original_five],
          S0$null_sd_at_measured[!S0$in_original_five], S1$null_sd_at_measured[!S1$in_original_five],
          S0$null_sd_at_0.01[!S0$in_original_five], S1$null_sd_at_0.01[!S1$in_original_five]),
  "",
  "(c) Replacement sentence for the Methods paragraph (numbers from row (a) and (b), S0):",
  "",
  sprintf(paste0("At the inter-gene correlation actually measured in the tested study-contrasts ",
    "(median %.3f-%.3f), the permutation null standard deviation of the study-level z falls from ",
    "%.2f-%.2f at the fixed inter-gene correlation of 0.01 to %.2f-%.2f, so the inflation of the ",
    "study-level z is the known CAMERA-PR behaviour of under-specifying inter-gene correlation ",
    "rather than a property of the permutation scheme."),
    min(N0$measured_rho), max(N0$measured_rho),
    min(N0$null_sd_at_0.01), max(N0$null_sd_at_0.01),
    min(N0$null_sd_at_measured), max(N0$null_sd_at_measured)))
cat(paste(L, collapse="\n"), "\n"); writeLines(L, A[3])
