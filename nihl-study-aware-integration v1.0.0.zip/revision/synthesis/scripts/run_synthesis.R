#!/usr/bin/env Rscript
# run_synthesis.R -- regenerate the synthesis-line tables in revision/synthesis/results from the public inputs.
#   Rscript run_synthesis.R             # all R steps
#   Rscript run_synthesis.R --compare   # additionally the S0-versus-S1 comparison reports (comparison/)
#   Rscript run_synthesis.R --network   # additionally the GEO accession-independence ledger (needs internet)
# Can be started from any directory, e.g. from the repository root:
#   Rscript revision/synthesis/scripts/run_synthesis.R
# or from this directory. Requires data/raw to be filled by scripts/00_download.R.
# Optional: NIHL_VALIDATION_LIB = library directory holding limma 3.62.2 / edgeR 4.4.2 (01_build_expr.R asserts both).
args <- commandArgs(trailingOnly = TRUE)
repo_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
here <- normalizePath(
  if (length(repo_arg) == 1L) dirname(sub("^--file=", "", repo_arg[1])) else ".",
  winslash = "/", mustWork = TRUE)
stopifnot(file.exists(file.path(here, "00_common.R")))
root <- normalizePath(file.path(here, "..", "..", ".."), mustWork = TRUE)
Sys.setenv(SC_SCR = here, SC_ROOT = root)
cache <- file.path(root, "revision", "synthesis", "cache"); out <- file.path(root, "revision", "synthesis", "results")
cache1 <- file.path(root, "revision", "synthesis", "cache_S1"); out1 <- file.path(root, "revision", "synthesis", "results_S1")
for (d in c(cache, out, cache1, out1)) dir.create(d, recursive = TRUE, showWarnings = FALSE)
rscript <- file.path(R.home("bin"), "Rscript"); python <- Sys.getenv("PYTHON", "python3")
t_all <- Sys.time()
run <- function(script, ..., env = character(), cmd = rscript) {
  t0 <- Sys.time(); cat(sprintf("[%s] %s %s\n", format(Sys.time(), "%H:%M:%S"), script, paste(c(...), collapse = " ")))
  st <- system2(cmd, c(shQuote(file.path(here, script)), ...), env = c(env), stdout = "", stderr = "")
  if (!identical(st, 0L)) stop("step failed: ", script, call. = FALSE)
  cat(sprintf("    %.0f s\n", as.numeric(difftime(Sys.time(), t0, units = "secs"))))
}
S1 <- c(paste0("SC_CACHE=", shQuote(cache1)), paste0("SC_OUT=", shQuote(out1)))
run("00_stage_inputs.R")
run("01_build_expr.R")
file.copy(file.path(cache, c("expr.rds", "hallmark.rds")), cache1, overwrite = TRUE)
run("03_syn_repro.R"); run("05_duplicate_check.R")
# inter.gene.cor / fry sensitivity: primary scheme (GSE196870 = deposited log2 values, S0) ...
run("11_igc.R"); run("12_igc_summary.R"); run("13_igc_synthesis.R")
run("14_igc_wide.R", shQuote(file.path(out, "igc_sensitivity_long.csv")), shQuote(file.path(out, "igc_sensitivity.csv")))
# ... and the S1 replica (extra log2(x+1)); 16_focal15.R compares the two at the synthesis level
file.copy(file.path(cache, c("expr.rds", "hallmark.rds")), cache1, overwrite = TRUE)
run("11_igc_S1replica.R", env = S1); run("12_igc_summary.R", env = S1); run("13_igc_synthesis.R", env = S1)
run("14_igc_wide.R", shQuote(file.path(out1, "igc_sensitivity_long.csv")), shQuote(file.path(out1, "igc_sensitivity.csv")), env = S1)
run("16_focal15.R", shQuote(file.path(cache, "igc.rds")), shQuote(file.path(cache1, "igc.rds")),
    shQuote(file.path(out, "igc_synthesis_focal15.csv")), shQuote(file.path(out, "igc_conf_to_ns_estimated.csv")))
file.copy(file.path(out, "igc_conf_to_ns_estimated.csv"), out1, overwrite = TRUE)
# permutation engine: self-tests, then the calibration itself (about 5-10 min)
run("07a_selftest.R"); run("07b_selftest_uniform.R"); run("07c_obs_agreement.R")
run("08_perm_calibration.R"); run("09_perm_synthesis.R"); run("08_stouffer_weights.R"); run("10_signtest.R")
run("24_calibrated.R"); run("21_temporal.R"); run("22_k17_bh_families.R")
run("23_consolidate.R"); run("33_d9_grades.R")
# forest effects, null-SD diagnosis, GSE8342 / GSE107086 interaction checks, E-MTAB source audit
run("14_forest.R"); run("28_competitive_vs_selfcontained.R"); run("25_null_sd_diagnosis.R")
run("16_interactions.R"); run("17_gse8342.R"); run("18_interaction_sign_test.R"); run("19_gse8342_anchor.R")
run("20_interaction_checks.py", cmd = python)
run("31_emtrab_audit.R")
if ("--compare" %in% args) {        # S0-versus-S1 comparison reports (text), written to revision/synthesis/comparison/
  cmp_dir <- file.path(root, "revision", "synthesis", "comparison"); dir.create(cmp_dir, showWarnings = FALSE)
  run("17_corr_summary.R", shQuote(file.path(out, "camera_estimated_correlation.csv")), shQuote(file.path(cmp_dir, "estimated_correlation_S0.txt")), "S0")
  run("21_paired_counts.R", shQuote(out), shQuote(out1), shQuote(file.path(cmp_dir, "paired_counts_S0_vs_S1.txt")))
  run("20_combo_detail.R", shQuote(out), shQuote(out1), shQuote(cmp_dir))
  run("19_scheme_delta.R", shQuote(out), shQuote(out1), shQuote(file.path(cmp_dir, "scheme_delta_S0_vs_S1.txt")))
}
if ("--network" %in% args) {
  run("03a_fetch_gsm_lists.py", cmd = python); run("04_independence.py", cmd = python); run("06_independence_table.py", cmd = python)
}
cat(sprintf("\nsynthesis tables regenerated in %.1f min\n", as.numeric(difftime(Sys.time(), t_all, units = "mins"))))
