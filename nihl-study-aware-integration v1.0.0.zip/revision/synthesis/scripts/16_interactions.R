## B2.7 -- GSE8342 interaction direction verification + GSE107086 interaction CI and MDE.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds")); H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))

## ---------------- GSE8342: read the analysed design straight from the legacy output ----------
g842 <- readRDS(file.path(SC_CACHE, "expr.rds"))   # not included; GSE8342 is analysed separately
## The GSE8342 reference levels and the interaction column are documented in the legacy code;
## reproduce them from the series matrix so the check is code-derived, not transcribed.
gsm <- read.delim(gzfile(file.path(SC_DL, "GSE8342_series_matrix.txt.gz")), comment.char = "!",
                  check.names = FALSE, header = TRUE, skip = 0, nrows = 1)
## sample titles
lines <- readLines(gzfile(file.path(SC_DL, "GSE8342_series_matrix.txt.gz")), warn = FALSE)
tline <- grep("^!Sample_title", lines, value = TRUE)
titles <- strsplit(tline, "\t")[[1]][-1]; titles <- gsub('"', "", titles)
grp <- ifelse(grepl("B6\\.CAST", titles) & grepl("_noise_", titles), "susceptible_noise",
       ifelse(grepl("B6\\.CAST", titles), "susceptible_control",
       ifelse(grepl("_noise_", titles), "resistant_noise", "resistant_control")))
grp <- factor(grp, levels = c("resistant_control","resistant_noise","susceptible_control","susceptible_noise"))
cat("GSE8342 sample titles and derived groups:\n"); print(data.frame(title=titles, group=grp), row.names=FALSE)
cat("\nfactor levels:", paste(levels(grp), collapse=" | "), "\n")
des <- model.matrix(~0 + grp); colnames(des) <- levels(grp)
C <- cbind(resistant_noise_vs_control = c(-1,1,0,0),
           susceptible_noise_vs_control = c(0,0,-1,1),
           strain_by_noise_interaction = c(-1,1,1,-1))
rownames(C) <- colnames(des)
cat("\ndesign columns:", paste(colnames(des), collapse=" | "), "\n")
cat("interaction column 'strain_by_noise_interaction' = (", paste(C[,3], collapse=", "), ")\n")
cat("=> -1*(resistant_control) +1*(resistant_noise) +1*(susceptible_control) -1*(susceptible_noise)\n")
cat("=> = (resistant_noise - resistant_control) - (susceptible_noise - susceptible_control)\n")
cat("=> = RESISTANT strain noise effect MINUS SUSCEPTIBLE strain noise effect\n")
cat("=> a POSITIVE interaction means the larger noise-induced increase is in the RESISTANT strain\n")
## label / phenotype mapping, as stated by GEO and by the paper
g842_series <- readLines(gzfile(file.path(SC_DL, "GSE8342_series_matrix.txt.gz")), warn = FALSE)
summ <- grep("^!Series_summary", g842_series, value = TRUE)
cat("\nGEO series summary sentence naming the susceptible strain:\n")
cat(substr(summ[1], 1, 1200), "\n\n")
cat("counts per group:\n"); print(table(grp))

## ---------------- GSE107086: sample-level score interaction -----------------------------------
obj <- O$GSE107086
STR <- syn_strata(); LP <- syn_levelpairs()
score_study <- function(obj, genes) {
  E <- obj$E; rownames(E) <- toupper(obj$symbols)
  if (any(duplicated(rownames(E)))) { avg <- rowMeans(E, na.rm=TRUE)
    o <- order(rownames(E), -avg); E <- E[o,,drop=FALSE][!duplicated(rownames(E)[o]),,drop=FALSE] }
  g <- intersect(rownames(E), genes)
  if (length(g) < 2) return(rep(NA_real_, ncol(E)))
  Z <- t(scale(t(E[g,,drop=FALSE]))); Z[!is.finite(Z)] <- NA
  colMeans(Z, na.rm=TRUE)
}
## The original interaction definition in the legacy code is a set of linear contrasts on the
## 8-cell group factor; we report the two that carry an explicit noise x adrenalectomy interaction
## (GC_dependency_day / GC_dependency_night) and the pooled average.
int_contrasts <- list(
  GC_dependency_day   = c(DNADX=-1, DNShADX=1, NNADX=0, NNShADX=0, ShDNADX=1, ShDNShADX=-1, ShNNADX=0, ShNNShADX=0),
  GC_dependency_night = c(DNADX=0, DNShADX=0, NNADX=-1, NNShADX=1, ShDNADX=0, ShDNShADX=0, ShNNADX=1, ShNNShADX=-1),
  GC_dependency_average = c(DNADX=-0.5, DNShADX=0.5, NNADX=-0.5, NNShADX=0.5,
                            ShDNADX=0.5, ShDNShADX=-0.5, ShNNADX=0.5, ShNNShADX=-0.5))
rows <- list()
for (p in names(FOCAL)) {
  sc <- score_study(obj, H$hallmark[[FOCAL[[p]]]])
  grp <- factor(as.character(obj$meta$group), levels = obj$lvls)
  d <- data.frame(sc = sc, grp = grp)
  fit <- lm(sc ~ 0 + grp, data = d)
  b <- coef(fit); V <- vcov(fit); dfe <- df.residual(fit)
  for (cn in names(int_contrasts)) {
    cv <- int_contrasts[[cn]]; names(cv) <- paste0("grp", names(cv))
    est <- sum(cv * b[names(cv)])
    se <- sqrt(as.numeric(t(cv) %*% V[names(cv), names(cv)] %*% cv))
    crit <- qt(0.975, dfe)
    rows[[length(rows)+1]] <- data.frame(dataset="GSE107086", program=p, contrast=cn,
      n_samples=sum(is.finite(sc)), n_cells=8, df=dfe, estimate=est, se=se,
      ci_low=est-crit*se, ci_high=est+crit*se, p=2*pt(-abs(est/se), dfe),
      mde_80=(qt(0.975,dfe)+qt(0.80,dfe))*se,
      ci_excludes_zero=abs(est) > crit*se)
  }
}
G <- do.call(rbind, rows); rownames(G) <- NULL
G$fdr_within_dataset_5programmes <- ave(G$p, G$contrast, FUN=function(x) p.adjust(x,"BH"))
write.csv(G, file.path(SC_OUT, "gse107086_interaction_mde.csv"), row.names=FALSE)
print(G[, c("program","contrast","estimate","ci_low","ci_high","p","fdr_within_dataset_5programmes","mde_80")],
      digits=4, row.names=FALSE)

## the same MDE calculation on the gene-level interaction for reference (legacy formal_summary)
legacy <- read.csv(file.path(SC_PKG, "GSE107086_formal_summary.csv"))
print(legacy)
saveRDS(list(G=G, legacy=legacy), file.path(SC_CACHE, "interactions.rds"))
