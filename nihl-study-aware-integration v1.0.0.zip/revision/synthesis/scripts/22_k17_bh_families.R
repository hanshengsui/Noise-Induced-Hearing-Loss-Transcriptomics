## K17 -- do the focal programmes carry the same FDR category in the two BH families?
## family A: BH across the 5 focal programmes within a stratum (>= 5 Hallmarks reaching FDR<0.05)
## family B: BH across all 50 Hallmarks within a stratum
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds")); H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))
STR <- syn_strata(); LP <- syn_levelpairs()
src <- function(k) switch(k, GSE160639="GSE160639", GSE196870="GSE196870_S0", GSE312476="GSE312476",
                          GSE100365="GSE100365", EMTAB="EMTAB")
cat_cut <- function(p) as.character(cut(p, c(-Inf,.05,.10,Inf), labels=c("conf","expl","ns")))
rows <- list(); full50 <- list()
for (s in names(STR)) {
  d <- names(STR[[s]])
  ## per-study signed z on the 50-hallmark vector
  Zmat <- sapply(d, function(k) z_of(O[[src(k)]], STR[[s]][[k]], H$order50))
  if (is.null(dim(Zmat))) Zmat <- matrix(Zmat, nrow = 50)
  rownames(Zmat) <- H$order50
  Z <- rowSums(Zmat)/sqrt(length(d)); names(Z) <- rownames(Zmat)   # rowSums drops names
  stopifnot(all(FOCAL %in% names(Z)))
  p <- 2*pnorm(-abs(Z))
  fdr50 <- p.adjust(p, "BH"); p50 <- p
  full50[[s]] <- data.frame(stratum=s, ph=p, fdr50=fdr50)
  p5 <- p[FOCAL]; fdr5 <- p.adjust(p5, "BH")
  rows[[s]] <- data.frame(stratum=s, program=names(FOCAL), ph50=as.numeric(p50[FOCAL]), hallmarks_reaching_fdr005=sum(fdr50 < 0.05),
    Z=as.numeric(Z[FOCAL]), p=as.numeric(p5),
    fdr_family_5_programmes=as.numeric(fdr5), fdr_family_50_hallmark=as.numeric(fdr50[FOCAL]))
}
K <- do.call(rbind, rows); rownames(K) <- NULL
F50 <- do.call(rbind, full50); rownames(F50) <- NULL
F50$program_hallmark <- F50$ph
F50 <- F50[F50$ph %in% K$ph50 | TRUE, ]
K$pf50 <- F50$ph[match(paste(K$stratum, K$ph50), paste(F50$stratum, F50$ph))]
K$fdr50_full <- F50$fdr50[match(paste(K$stratum, K$ph50), paste(F50$stratum, F50$ph))]
stopifnot(!any(is.na(K$pf50)))
K$cat_5 <- cat_cut(K$fdr_family_5_programmes); K$cat_50 <- cat_cut(K$fdr_family_50_hallmark)
K$same_category <- K$cat_5 == K$cat_50
K$abs_pct_diff <- abs(K$fdr_family_5_programmes - K$fdr_family_50_hallmark)/pmax(K$fdr_family_50_hallmark, 1e-300)
write.csv(K, file.path(SC_OUT, "k17_bh_families.csv"), row.names=FALSE)
write.csv(F50, file.path(SC_OUT, "k17_all50_hallmark_fdr.csv"), row.names=FALSE)
print(K[, c("stratum","program","hallmarks_reaching_fdr005","Z","fdr_family_5_programmes",
            "fdr_family_50_hallmark","cat_5","cat_50","same_category")], digits=4, row.names=FALSE)
cat(sprintf("\nSame FDR category in both families: %d / %d\n", sum(K$same_category), nrow(K)))
cat("Closest to the 0.05 boundary:\n")
i <- order(abs(log(K$fdr_family_50_hallmark) - log(0.05)))
print(K[i[1:3], c("stratum","program","fdr_family_5_programmes","fdr_family_50_hallmark","cat_5","cat_50")], digits=4, row.names=FALSE)
## also verify the p.adjust monotonicity against statsmodels-equivalent (scipy) via an independent implementation
bh_ref <- function(p) { n <- length(p); o <- order(p); q <- p[o]*n/seq_len(n)
  q <- rev(cummin(rev(q))); out <- numeric(n); out[o] <- pmin(q,1); out }
## the family is within-stratum, so the check must be done per stratum
chk <- sapply(unique(K$stratum), function(s) { i <- K$stratum==s
  max(abs(bh_ref(K$p[i]) - K$fdr_family_5_programmes[i])) })
cat(sprintf("\np.adjust(BH) vs independent monotone implementation: max |diff| = %.3e (pass: %s)\n",
            max(chk), max(chk) < 1e-12))
## and the 50-Hallmark family, checked on the full stored 50-row vector
chk50 <- sapply(unique(F50$stratum), function(s) { i <- F50$stratum==s
  max(abs(bh_ref(F50$ph[i]) - F50$fdr50[i])) })
cat(sprintf("50-Hallmark family: max |diff| = %.3e (pass: %s)\n", max(chk50), max(chk50) < 1e-12))
saveRDS(K, file.path(SC_CACHE, "k17.rds"))
