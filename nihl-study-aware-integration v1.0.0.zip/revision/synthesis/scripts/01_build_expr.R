## Rebuild exactly the expression objects / designs used by the main analysis.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R"))
suppressPackageStartupMessages({library(limma); library(edgeR); library(statmod); library(readxl)})
stopifnot(as.character(packageVersion("limma"))=="3.62.2",
          as.character(packageVersion("edgeR"))=="4.4.2")
DL <- SC_DL
OUT <- SC_CACHE
human_hallmark <- read_gmt(file.path(DL,"h.all.v2024.1.Hs.symbols.gmt"))
ORDER50 <- names(human_hallmark)
saveRDS(list(hallmark=human_hallmark, order50=ORDER50), file.path(SC_CACHE, "hallmark.rds"))

extract_contrasts_local <- function(fit, feature, dataset, store_E) {
  pr <- list(); zz <- list()
  for (cn in colnames(fit$coefficients)) {
    tt <- topTable(fit, coef=cn, number=Inf, sort.by="none")
    stat <- tt$t; names(stat) <- feature$gene_symbol
    cam <- camera_pr_signed(stat, human_hallmark)
    cam$dataset <- dataset; cam$contrast <- cn
    pr[[cn]] <- cam
    zz[[cn]] <- stat
  }
  list(camera=do.call(rbind, pr), tstat=zz)
}

## ---------------- GSE160639 (raw counts, TMM-voom) ----------------
g160 <- read.delim(gzfile(file.path(DL,"GSE160639_RawReadCount.txt.gz")), check.names=FALSE)
gm <- read.csv(file.path(DL,"mouse_gene_map.csv")); gm$stable_id <- sub("\\..*$","",gm$gene_id)
sym <- gm$gene_symbol[match(sub("\\..*$","",g160$gene_id), gm$stable_id)]
cnt <- as.matrix(g160[,-1,drop=FALSE]); storage.mode(cnt) <- "numeric"; rownames(cnt) <- g160$gene_id
ok <- !is.na(sym) & nzchar(sym) & sym != "N/A"
cnt <- rowsum(cnt[ok,,drop=FALSE], toupper(sym[ok]), reorder=FALSE)
grp <- factor(sub(".*_","",colnames(cnt)), levels=c("70dB","94dB","105dB"))
des <- model.matrix(~0+grp); colnames(des) <- paste0("g", levels(grp))
keep <- filterByExpr(cnt, design=des, min.count=10)
dge <- calcNormFactors(DGEList(cnt[keep,,drop=FALSE]), method="TMM")
v <- voom(dge, des, plot=FALSE)
cm <- makeContrasts(dB94_vs_70=g94dB-g70dB, dB105_vs_70=g105dB-g70dB, levels=des)
fit <- eBayes(contrasts.fit(lmFit(v,des), cm), robust=TRUE, trend=FALSE)
e1 <- extract_contrasts_local(fit, data.frame(gene_symbol=rownames(fit$coefficients)), "GSE160639")
obj_GSE160639 <- list(lvls=c("70dB","94dB","105dB"), covar_frame=NULL, E=v$E, w=1/v$sd^2, counts=cnt[keep,,drop=FALSE], norm_factors=dge$samples$norm.factors, meta=data.frame(sample_id=colnames(v$E), group=as.character(grp)),
                      design=des, contrasts=cm, fit=fit, group_var="group",
                      camera=e1$camera, tstat=e1$tstat, scale="voom", df_total=fit$df.total, trend=FALSE,
                      symbols=rownames(v$E))
cat("GSE160639 dim", dim(v$E), "\n")

## ---------------- GSE196870 (FPKM; S0 = no log, S1 = log2(x+1)) ----------------
g196 <- read.csv(gzfile(file.path(DL,"GSE196870_Raw_gene_FPKM_matrix.txt.csv.gz")), check.names=FALSE)
cols <- c(paste0("MUS_",1:4), paste0("PN_1h_",1:4), paste0("PN_24h_",1:4))
E0 <- as.matrix(g196[,cols,drop=FALSE]); storage.mode(E0) <- "numeric"; rownames(E0) <- g196$id
representative_by_mean <- function(expr, symbols, feature_ids=rownames(expr)) {
  symbols <- toupper(symbols)
  ok <- !is.na(symbols) & nzchar(symbols) & symbols!="N/A" & !grepl("///", symbols, fixed=TRUE)
  expr <- expr[ok,,drop=FALSE]; symbols <- symbols[ok]; feature_ids <- feature_ids[ok]
  avg <- rowMeans(expr, na.rm=TRUE)
  ord <- order(symbols, -avg, feature_ids)
  expr <- expr[ord,,drop=FALSE]; symbols <- symbols[ord]; feature_ids <- feature_ids[ord]
  k <- !duplicated(symbols)
  list(expression=expr[k,,drop=FALSE], symbols=symbols[k], feature_ids=feature_ids[k])
}
rep196 <- representative_by_mean(E0, g196$gene, g196$id)
Ex <- rep196$expression
keep <- rowMeans(Ex, na.rm=TRUE) > 0.5 & apply(Ex,1,sd,na.rm=TRUE) > 0
Ex <- Ex[keep,,drop=FALSE]; sy <- rep196$symbols[keep]
grp196 <- factor(c(rep("control",4),rep("noise_1h",4),rep("noise_24h",4)),
                 levels=c("control","noise_1h","noise_24h"))
des196 <- model.matrix(~0+grp196); colnames(des196) <- levels(grp196)
cm196 <- makeContrasts(noise_1h_vs_control=noise_1h-control,
                       noise_24h_vs_control=noise_24h-control, levels=des196)
build196 <- function(Emat, tag) {
  fit <- eBayes(contrasts.fit(lmFit(Emat,des196), cm196), robust=TRUE, trend=TRUE)
  ex <- extract_contrasts_local(fit, data.frame(gene_symbol=sy), "GSE196870")
  list(E=Emat, meta=data.frame(sample_id=colnames(Emat), group=as.character(grp196)),
       design=des196, contrasts=cm196, fit=fit, group_var="group",
       camera=ex$camera, tstat=ex$tstat, scale=tag, df_total=fit$df.total, symbols=sy, trend=TRUE)
}
obj_GSE196870_S0 <- build196(Ex, "FPKM (no log)")
obj_GSE196870_S0$lvls <- c("control","noise_1h","noise_24h"); obj_GSE196870_S0$covar_frame <- NULL
obj_GSE196870_S1 <- build196(log2(Ex+1), "log2(FPKM+1)")
obj_GSE196870_S1$lvls <- c("control","noise_1h","noise_24h"); obj_GSE196870_S1$covar_frame <- NULL
obj_GSE196870_S0$symbols <- sy; obj_GSE196870_S1$symbols <- sy
obj_GSE196870_S0$trend <- TRUE; obj_GSE196870_S1$trend <- TRUE
cat("GSE196870 dim", dim(Ex), "\n")

## ---------------- GSE312476 (non-integer processed abundance) ----------------
g312 <- as.data.frame(read_excel(file.path(DL,"GSE312476_Table_S1.xlsx"), sheet="Bulk_RNA_seq_data", skip=2))
c312 <- c(paste0("Ctrl_",1:3), paste0("PN0h_",1:3), paste0("PN4h_",1:3), paste0("PN8h_",1:3))
X <- as.matrix(g312[,c312,drop=FALSE]); storage.mode(X) <- "numeric"
ok <- !is.na(g312$gene_symbol) & nzchar(g312$gene_symbol) & g312$gene_symbol!="N/A"
X <- rowsum(X[ok,,drop=FALSE], toupper(g312$gene_symbol[ok]), reorder=FALSE)
k312 <- rowSums(X > 1, na.rm=TRUE) >= 3
E312 <- log2(X[k312,,drop=FALSE] + 0.5)
grp312 <- factor(c(rep("control",3),rep("post_0h",3),rep("post_4h",3),rep("post_8h",3)),
                 levels=c("control","post_0h","post_4h","post_8h"))
d312 <- model.matrix(~0+grp312); colnames(d312) <- levels(grp312)
c312m <- makeContrasts(post_0h_vs_control=post_0h-control, post_4h_vs_control=post_4h-control,
                       post_8h_vs_control=post_8h-control, levels=d312)
f312 <- eBayes(contrasts.fit(lmFit(E312,d312), c312m), robust=TRUE, trend=TRUE)
e312 <- extract_contrasts_local(f312, data.frame(gene_symbol=rownames(f312$coefficients)), "GSE312476")
obj_GSE312476 <- list(lvls=c("control","post_0h","post_4h","post_8h"), covar_frame=NULL, E=E312, meta=data.frame(sample_id=colnames(E312), group=as.character(grp312)),
                      design=d312, contrasts=c312m, fit=f312, group_var="group",
                      camera=e312$camera, tstat=e312$tstat, scale="log2(x+0.5)", df_total=f312$df.total, trend=TRUE,
                      symbols=rownames(E312))
cat("GSE312476 dim", dim(E312), "\n")

## ---------------- GSE100365 (Affy series matrix, representative probe) ----------------
source(file.path(SC_SCR, "utils.R"))
g100 <- read_geo_series_matrix(file.path(DL,"GSE100365_series_matrix.txt.gz"))
an <- read_geo_annotation(file.path(DL,"GPL1261.annot.gz"))
sy100 <- an$`Gene symbol`[match(g100$feature_id, an$ID)]
r100 <- representative_by_mean(g100$expr, sy100, g100$feature_id)
E100 <- r100$expression; fe100 <- data.frame(feature_id=r100$feature_ids, gene_symbol=r100$symbols)
ti <- g100$sample_meta$title
grp100 <- ifelse(grepl("_control_",ti),"control",
          ifelse(grepl("_Immediate_",ti),"immediate",
          ifelse(grepl("_1Day_",ti),"day1",
          ifelse(grepl("_7Day_",ti),"day7","day14"))))
grp100 <- factor(grp100, levels=c("control","immediate","day1","day7","day14"))
gcol <- grep("^characteristics_ch1_[0-9]+$", names(g100$sample_meta), value=TRUE)
gcol <- gcol[vapply(g100$sample_meta[gcol], function(x) any(grepl("^gender:",x,ignore.case=TRUE)), logical(1))]
sx100 <- factor(sub("^gender:\\s*","", g100$sample_meta[[gcol]], ignore.case=TRUE))
d100 <- model.matrix(~0+grp100+sx100)
colnames(d100) <- sub("^grp100","",colnames(d100)); colnames(d100) <- sub("^sx100","sex_",colnames(d100))
cat("GSE100365 design rank", qr(d100)$rank, "of", ncol(d100), "\n")
c100 <- makeContrasts(immediate_vs_control=immediate-control, day1_vs_control=day1-control,
                      day7_vs_control=day7-control, day14_vs_control=day14-control,
                      day1_vs_immediate=day1-immediate, day7_vs_day1=day7-day1,
                      day14_vs_day7=day14-day7, levels=d100)
f100 <- eBayes(contrasts.fit(lmFit(E100,d100), c100), robust=TRUE, trend=TRUE)
e100 <- extract_contrasts_local(f100, fe100, "GSE100365")
obj_GSE100365 <- list(lvls=c("control","immediate","day1","day7","day14"), covar_frame=model.matrix(~0+sx100)[,-1,drop=FALSE], E=E100, meta=data.frame(sample_id=g100$sample_meta$sample_id, group=as.character(grp100),
                                              sex=as.character(sx100)),
                      design=d100, contrasts=c100, fit=f100, group_var="group", block="sex",
                      camera=e100$camera, tstat=e100$tstat, scale="log2 (series matrix)", df_total=f100$df.total, trend=TRUE,
                      symbols=r100$symbols)
cat("GSE100365 dim", dim(E100), "\n")

## ---------------- E-MTAB-16125 (featureCounts, TMM-voom, sex-adjusted) ----------------
sdrf <- read.delim(file.path(SC_DL, "E-MTAB-16125", "E-MTAB-16125.sdrf.txt"), check.names=TRUE, stringsAsFactors=FALSE)
meta <- unique(sdrf[,c("Source.Name","Characteristics.sex.","Derived.Array.Data.File","Factor.Value.time.","Factor.Value.injury.")])
names(meta) <- c("sample_id","sex","count_file","time_label","injury")
meta$group <- ifelse(meta$time_label=="control","control",
              ifelse(grepl("^24h",meta$time_label),"h24",
              ifelse(grepl("^72h",meta$time_label),"h72","week1")))
meta <- meta[order(match(meta$group,c("control","h24","h72","week1")), meta$sample_id),]
cdir <- file.path(SC_DL, "E-MTAB-16125", "featureCounts")
lst <- list(); genes <- NULL
for (i in seq_len(nrow(meta))) {
  x <- read.delim(file.path(cdir, meta$count_file[i]), header=FALSE, col.names=c("gene_id","count"))
  if (is.null(genes)) genes <- x$gene_id
  if (!identical(genes, x$gene_id)) stop("E-MTAB gene order mismatch")
  lst[[meta$sample_id[i]]] <- x$count
}
cm_counts <- do.call(cbind, lst); rownames(cm_counts) <- genes
gm2 <- read.csv(file.path(DL,"mouse_gene_map.csv")); gm2$stable_id <- sub("\\..*$","",gm2$gene_id)
sym2 <- gm2$gene_symbol[match(sub("\\..*$","",rownames(cm_counts)), gm2$stable_id)]
okk <- !is.na(sym2) & nzchar(sym2)
cmp <- rowsum(cm_counts[okk,,drop=FALSE], toupper(sym2[okk]), reorder=FALSE)
grpE <- factor(meta$group, levels=c("control","h24","h72","week1")); sxE <- factor(meta$sex)
dE <- model.matrix(~0+grpE+sxE)
colnames(dE) <- sub("^grpE","",colnames(dE)); colnames(dE) <- sub("^sxE","sex_",colnames(dE))
cE <- makeContrasts(h24_vs_control=h24-control, h72_vs_control=h72-control, week1_vs_control=week1-control,
                    h72_vs_h24=h72-h24, week1_vs_h72=week1-h72, week1_vs_h24=week1-h24, levels=dE)
kE <- filterByExpr(cmp, design=dE, min.count=10, min.total.count=15)
dgeE <- calcNormFactors(DGEList(cmp[kE,,drop=FALSE]), method="TMM")
vE <- voom(dgeE, dE, plot=FALSE)
fE <- eBayes(contrasts.fit(lmFit(vE,dE), cE), robust=TRUE, trend=FALSE)
eE <- extract_contrasts_local(fE, data.frame(gene_symbol=rownames(fE$coefficients)), "E-MTAB-16125")
obj_EMTAB <- list(lvls=c("control","h24","h72","week1"), covar_frame=model.matrix(~0+sxE)[,-1,drop=FALSE], E=vE$E, w=1/vE$sd^2, counts=cmp[kE,,drop=FALSE], norm_factors=dgeE$samples$norm.factors, meta=data.frame(sample_id=meta$sample_id, group=as.character(grpE), sex=as.character(sxE)),
                  design=dE, contrasts=cE, fit=fE, group_var="group", block="sex",
                  camera=eE$camera, tstat=eE$tstat, scale="voom", df_total=fE$df.total, trend=FALSE,
                  symbols=rownames(vE$E))
cat("E-MTAB dim", dim(vE$E), "\n")

## ---------------- GSE107086 (factorial, TMM-voom) ----------------
x107 <- read.csv(gzfile(file.path(SC_DL, "GSE107086_raw_counts.csv.gz")), check.names=FALSE)
gn <- as.character(x107$geneName); c107 <- as.matrix(x107[,-1,drop=FALSE])
storage.mode(c107) <- "numeric"; rownames(c107) <- gn
s107 <- colnames(c107); g107 <- sub("[abc]$","",s107)
lev107 <- c("DNADX","DNShADX","NNADX","NNShADX","ShDNADX","ShDNShADX","ShNNADX","ShNNShADX")
gf107 <- factor(g107, levels=lev107)
d107 <- model.matrix(~0+gf107); colnames(d107) <- lev107
c107m <- cbind(noise_day_ADX=c(1,0,0,0,-1,0,0,0), noise_day_shamADX=c(0,1,0,0,0,-1,0,0),
               noise_night_ADX=c(0,0,1,0,0,0,-1,0), noise_night_shamADX=c(0,0,0,1,0,0,0,-1),
               GC_dependency_day=c(-1,1,0,0,1,-1,0,0), GC_dependency_night=c(0,0,-1,1,0,0,1,-1),
               noise_average_shamADX=c(0,0.5,0,0.5,0,-0.5,0,-0.5),
               noise_average_ADX=c(0.5,0,0.5,0,-0.5,0,-0.5,0),
               GC_dependency_average=c(-0.5,0.5,-0.5,0.5,0.5,-0.5,0.5,-0.5))
rownames(c107m) <- lev107
k107 <- filterByExpr(c107, design=d107, min.count=10, min.total.count=15)
dge107 <- calcNormFactors(DGEList(c107[k107,,drop=FALSE]), method="TMM")
v107 <- voom(dge107, d107, plot=FALSE)
f107 <- eBayes(contrasts.fit(lmFit(v107,d107), c107m), robust=TRUE, trend=FALSE)
e107 <- extract_contrasts_local(f107, data.frame(gene_symbol=rownames(f107$coefficients)), "GSE107086")
obj_GSE107086 <- list(lvls=lev107, covar_frame=NULL, E=v107$E, w=1/v107$sd^2, counts=c107[k107,,drop=FALSE], norm_factors=dge107$samples$norm.factors,
  meta=data.frame(sample_id=s107, group=g107,
                  noise=ifelse(grepl("^Sh",g107),"sham","noise"),
                  phase=ifelse(grepl("^(Sh)?D",g107),"day","night"),
                  adrenal=ifelse(grepl("ShADX$",g107),"sham_ADX","ADX"),
                  sex=NA_character_),
  design=d107, contrasts=c107m, fit=f107, group_var="group",
  camera=e107$camera, tstat=e107$tstat, scale="voom", df_total=f107$df.total, trend=FALSE,
  symbols=rownames(v107$E))
cat("GSE107086 dim", dim(v107$E), "\n")

saveRDS(list(GSE160639=obj_GSE160639, GSE196870_S0=obj_GSE196870_S0, GSE196870_S1=obj_GSE196870_S1,
             GSE312476=obj_GSE312476, GSE100365=obj_GSE100365, EMTAB=obj_EMTAB, GSE107086=obj_GSE107086),
        file.path(SC_CACHE, "expr.rds"))
cat("saved\n")
