## Rebuild perm_calibration.csv on its own, with the logic of 23_consolidate.R lines 8-33
## (that block also depends on self-test outputs this rerun does not regenerate, so the
##  sheet is rebuilt here rather than by running 23_consolidate.R whole).
## Usage: Rscript 30_perm_calibration_sheet.R <out.csv>
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) == 1L)
STR <- syn_strata()
LED <- read.csv(file.path(SC_OUT, "perm_calibration_ledger.csv"))
SS  <- read.csv(file.path(SC_OUT, "stouffer_sensitivity.csv"))
SS  <- SS[SS$scheme_GSE196870 == PRIMARY_SCHEME, ]
rows <- list()
for (s in names(STR)) {
  ## 23_consolidate.R selected the ledger rows by scheme == "S1"; that label denoted
  ## "the scheme the ledger was run for" at a time when S1 was primary.  It is kept
  ## verbatim here as PRIMARY_SCHEME so the sheet keeps its intended meaning.
  L <- LED[LED$stratum == s & LED$scheme == PRIMARY_SCHEME, ]
  for (w in c("w_equal","w_sqrtn","w_df")) {
    Z <- SS[SS$stratum == s & SS$weighting == w, ]
    nst <- nrow(L)
    prod_n <- prod(L$n_perms)
    rows[[length(rows)+1]] <- data.frame(stratum=s, program="(all)",
      weighting=w, per_study_n_perms=paste(sprintf("%s=%d", L$study, L$n_perms), collapse="; "),
      n_studies=nst, perm_product=prod_n,
      resolution_floor_theoretical=length(Z)/prod_n, B_draws=1e5,
      empirical_floor=1e-5, Z_obs=NA_real_, p_theory=NA_real_, p_emp=NA_real_,
      n_draws_exceeding=NA_integer_, null_sd_of_synthesis_Z=NA_real_,
      resolution_insufficient=any(L$resolution_insufficient),
      block_used=paste(sprintf("%s=%s", L$study, ifelse(is.na(L$block), "none", L$block)), collapse="; "))
  }
}
PC <- do.call(rbind, rows)
## the per-programme rows carry the Z and p values, and are what AF21 actually tabulates;
## rebuild them the same way 23_consolidate.R does when its self-test inputs are present.
rows2 <- list()
for (s in names(STR)) {
  L <- LED[LED$stratum == s & LED$scheme == PRIMARY_SCHEME, ]
  for (w in c("w_equal","w_sqrtn","w_df")) {
    Z <- SS[SS$stratum == s & SS$weighting == w, ]
    for (i in seq_len(nrow(Z))) rows2[[length(rows2)+1]] <- data.frame(
      stratum=s, program=Z$program[i], weighting=w,
      per_study_n_perms=paste(sprintf("%s=%d", L$study, L$n_perms), collapse="; "),
      n_studies=nrow(L), perm_product=prod(L$n_perms),
      resolution_floor_theoretical=length(Z)/prod(L$n_perms), B_draws=1e5,
      empirical_floor=1e-5, Z_obs=Z$Z[i], p_theory=Z$p_theory[i], p_emp=Z$p_emp[i],
      n_draws_exceeding=Z$n_draws_if_hit[i], null_sd_of_synthesis_Z=Z$null_sd[i],
      resolution_insufficient=any(L$resolution_insufficient),
      block_used=paste(sprintf("%s=%s", L$study, ifelse(is.na(L$block), "none", L$block)), collapse="; "))
  }
}
PC <- do.call(rbind, rows2)
write.csv(PC, A[1], row.names = FALSE)
cat("perm_calibration.csv rows:", nrow(PC), "\n")
