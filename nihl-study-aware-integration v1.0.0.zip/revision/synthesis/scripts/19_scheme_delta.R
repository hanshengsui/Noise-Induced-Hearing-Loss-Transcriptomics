## Step 10b -- how much does the primary-scheme switch move each reported quantity?
## Everything is computed from the two runs' saved tables; nothing is read off a printout.
## Usage: Rscript 19_scheme_delta.R <S0 dir> <S1 dir> <out.txt>
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R"))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) == 3L)
rd <- function(f) read.csv(file.path(A[1], f), stringsAsFactors=FALSE)
rs <- function(f) read.csv(file.path(A[2], f), stringsAsFactors=FALSE)

L <- c("SCHEME DELTA -- S0 (primary) versus S1 (sensitivity, = the archived/submitted numbers)", "")

## ---- 1. the 15 focal synthesis cells
f0 <- rd("igc_synthesis.csv"); f1 <- rs("igc_synthesis.csv")
KEY <- c("setting","stratum","program")
stopifnot(nrow(f0)==75L, nrow(f1)==75L)
k0 <- paste(f0$setting,f0$stratum,f0$program,sep="|"); k1 <- paste(f1$setting,f1$stratum,f1$program,sep="|")
stopifnot(setequal(k0,k1))
i0 <- match(k1, k0)
dZ <- f0$Z[i0]-f1$Z
cat_cell <- f0$cat5[i0] != f1$cat5
cat_dir  <- sign(f0$Z[i0]) != sign(f1$Z)
L <- c(L, sprintf("A. synthesis-level, 15 focal stratum x programme x 5 settings = 75 cells"),
  sprintf("   max |dZ| = %.4f  (median |dZ| = %.4f)", max(abs(dZ)), median(abs(dZ))),
  sprintf("   cells with |dZ| > 0.005: %d of 75", sum(abs(dZ) > 0.005)),
  sprintf("   cells with |dZ| > 0.05 : %d of 75", sum(abs(dZ) > 0.05)),
  sprintf("   FDR-category changes: %d of 75; sign changes: %d of 75", sum(cat_cell), sum(cat_dir)),
  sprintf("   largest |dZ| cell: %s", {
    w <- which.max(abs(dZ)); sprintf("%s %s %s: S0 %.4f vs S1 %.4f",
      f0$setting[i0][w], f1$stratum[w], f1$program[w], f0$Z[i0][w], f1$Z[w]) }))

## which of the five settings actually moved
L <- c(L, "   by setting:")
for (st in c("rho0.01","rho0.05","rho0.1","estimated","fry")) {
  ii <- f1$setting == st
  L <- c(L, sprintf("     %-10s max|dZ| = %8.4f   category changes = %d/15   sign changes = %d/15",
    st, max(abs(dZ[ii])), sum(cat_cell[ii]), sum(cat_dir[ii])))
}

## ---- 2. the 450-row retention summary
s0 <- rd("igc_retention_summary.csv"); s1 <- rs("igc_retention_summary.csv")
m <- match(s1$setting, s0$setting)
L <- c(L, "", "B. study-contrast level retention (450 combinations per setting)",
  sprintf("   %-10s %10s %10s %8s %10s %10s %8s", "setting","dir_S1","dir_S0","ddir","cat_S1","cat_S0","dcat"),
  sprintf("   %-10s %10.4f %10.4f %8.4f %10.4f %10.4f %8.4f", s1$setting,
    s1$direction_preserved, s0$direction_preserved[m],
    s0$direction_preserved[m]-s1$direction_preserved,
    s1$fdr_category_preserved, s0$fdr_category_preserved[m],
    s0$fdr_category_preserved[m]-s1$fdr_category_preserved),
  sprintf("   => the count of preserved combinations changes by at most %d of 450 in any setting",
    max(abs(round((s0$fdr_category_preserved[m]-s1$fdr_category_preserved)*450))) ))

## ---- 3. the 15-cell retention table (synthesis level)
r0 <- rd("igc_synthesis_retention.csv"); r1 <- rs("igc_synthesis_retention.csv")
m <- match(r1$setting, r0$setting)
L <- c(L, "", "C. synthesis-level retention (the numbers quoted in the manuscript)",
  sprintf("   %-10s %11s %11s %11s %11s", "setting","direction","category","to_ns","from_ns"),
  sprintf("   %-10s %11d %11d %11d %11d   <- S1 (submitted)", r1$setting,
    r1$direction_kept, r1$category_kept, r1$changed_to_ns, r1$changed_from_ns),
  sprintf("   %-10s %11d %11d %11d %11d   <- S0 (primary)", r0$setting[m],
    r0$direction_kept[m], r0$category_kept[m], r0$changed_to_ns[m], r0$changed_from_ns[m]),
  sprintf("   identical in every column: %s",
    ifelse(all(r0[m, -1] == r1[, -1]), "yes -- no number in this table changes", "NO")))

## ---- 4. the conf -> ns lists
c0 <- rd("igc_conf_to_ns_estimated.csv"); c1 <- rs("igc_conf_to_ns_estimated.csv")
c0 <- c0[c0$scheme == "S0_primary", ]; c1 <- c1[c1$scheme == "S1_sensitivity", ]
L <- c(L, "", "D. combinations whose synthesis FDR category moves conf -> ns under the",
  "   data-estimated correlation setting",
  sprintf("   S0: %d of 15 -> %s", nrow(c0), paste(paste(c0$stratum, c0$program, sep=":"), collapse=", ")),
  sprintf("   S1: %d of 15 -> %s", nrow(c1), paste(paste(c1$stratum, c1$program, sep=":"), collapse=", ")),
  sprintf("   same set of combinations: %s",
    ifelse(setequal(paste(c0$stratum,c0$program), paste(c1$stratum,c1$program)), "yes", "NO")))

## ---- 5. the 450-row wide table
w0 <- rd("igc_sensitivity.csv"); w1 <- rs("igc_sensitivity.csv")
stopifnot(identical(names(w0), names(w1)), nrow(w0)==450L)
num <- names(w0)[vapply(w0, is.numeric, logical(1))]
mx <- max(sapply(num, function(j) max(abs(w0[[j]]-w1[[j]]), na.rm=TRUE)))
catc <- grep("^cat[.]", names(w0), value=TRUE)
ncat <- sum(sapply(catc, function(j) sum(w0[[j]] != w1[[j]])))
dirc <- grep("^direction[.]", names(w0), value=TRUE)
ndir <- sum(sapply(dirc, function(j) sum(as.character(w0[[j]]) != as.character(w1[[j]]))))
L <- c(L, "", "E. the 450 x 28 wide table",
  sprintf("   max |dFDR| between the two schemes = %.4f", mx),
  sprintf("   category cells differing: %d of 2250 (%s)", ncat, paste(catc, collapse=", ")),
  sprintf("   direction cells differing: %d of 2250 (%s)", ndir, paste(dirc, collapse=", ")))
cat(paste(L, collapse="\n"), "\n")
writeLines(L, A[3])
