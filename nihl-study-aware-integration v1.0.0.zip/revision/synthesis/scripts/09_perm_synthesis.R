## Synthesis-null by independent row draws from each study's enumerated null (B2.3).
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R")); source(file.path(SC_SCR, "00b_scheme.R"))
O <- readRDS(file.path(SC_CACHE, "expr.rds")); H <- readRDS(file.path(SC_CACHE, "hallmark.rds"))
STR <- syn_strata(); NU <- syn_nunits(); LP <- syn_levelpairs()
B <- 100000L
src_of <- function(study, scheme) switch(study, GSE160639="GSE160639",
  GSE196870=if (scheme==PRIMARY_SCHEME) "GSE196870_S0" else "GSE196870_S1",
  GSE312476="GSE312476", GSE100365="GSE100365", EMTAB="EMTAB")

synth_null <- function(nulls, s, w_list, B, seed) {
  set.seed(seed)
  d <- names(nulls[[s]])
  ## independent draws: one row per study per replicate
  draws <- lapply(d, function(k) {
    M <- nulls[[s]][[k]]
    M[sample.int(nrow(M), B, replace=TRUE), , drop=FALSE]
  })
  names(draws) <- d
  out <- list()
  for (wn in names(w_list)) {
    w <- w_list[[wn]]
    Z0 <- matrix(0, B, length(H$order50))
    for (i in seq_along(d)) Z0 <- Z0 + w[i] * draws[[i]]
    Z0 <- Z0 / sqrt(sum(w^2))
    out[[wn]] <- Z0
  }
  out
}

rows <- list()
for (scheme in c(PRIMARY_SCHEME, ALT_SCHEME)) {
  P <- readRDS(file.path(SC_CACHE, sprintf("perm_null_%s.rds", scheme)))
  nulls <- list()
  for (k in names(P$nulls)) { sp <- strsplit(k, "|", fixed=TRUE)[[1]]; 
    nulls[[sp[1]]] <- nulls[[sp[1]]] %||% list()
    nulls[[sp[1]]][[sp[2]]] <- P$nulls[[k]] }
  `%||%` <- function(a,b) if (is.null(a)) b else a
  for (s in names(STR)) {
    d <- names(STR[[s]]); n12 <- NU[[s]][d]
    w_list <- list(w_equal = rep(1, length(d)),
                   w_sqrtn = sqrt(2*n12),
                   w_df    = sqrt(sapply(d, function(k) {
                     obj <- O[[src_of(k, scheme)]]
                     df_total_median(obj, STR[[s]][[k]]) })))
    Z0 <- tryCatch(synth_null(nulls, s, w_list, B, SEED_GLOBAL + which(names(STR)==s)),
                   error=function(e) { cat("null build failed for", s, ": ", conditionMessage(e), "\n"); NULL })
    for (p in names(FOCAL)) {
      zs <- sapply(d, function(k) {
        obj <- O[[src_of(k, scheme)]]
        cn <- STR[[s]][[k]]; lp <- LP[[k]][[cn]]
        ## observed study-level z from the PERMUTATION-consistent refit path is asserted equal
        ## to the main-analysis z (07c); here we reuse the main-analysis value
        z_of(obj, cn, FOCAL[[p]])
      })
      for (wn in names(w_list)) {
        w <- w_list[[wn]]
        Zobs <- sum(w*zs)/sqrt(sum(w^2))
        Z0w <- if (!is.null(Z0)) Z0[[wn]][, FOCAL[[p]]] else NULL
        pemp <- if (is.null(Z0w)) NA_real_ else (1 + sum(abs(Z0w) >= abs(Zobs) - 1e-10 * max(1, abs(Zobs))))/(B+1)
        nperm <- prod(sapply(d, function(k) nrow(nulls[[s]][[k]])))
        rows[[length(rows)+1]] <- data.frame(scheme_GSE196870=scheme, stratum=s, program=p,
          weighting=wn, k=length(d), n_up=sum(zs>0), Z=Zobs,
          p_theory=2*pnorm(-abs(Zobs)), p_emp=pemp,
          n_draws_if_hit=if (is.null(Z0w)) NA_integer_ else sum(abs(Z0w) >= abs(Zobs) - 1e-10 * max(1, abs(Zobs))),
          null_sd=if (is.null(Z0w)) NA_real_ else sd(Z0w),
          z_over_null_sd=if (is.null(Z0w)) NA_real_ else Zobs/sd(Z0w),
          perm_product=nperm, resolution_floor=1/nperm,
          empirical_floor=1/(B+1), B=B, seed=SEED_GLOBAL)
      }
    }
  }
}
R <- do.call(rbind, rows); rownames(R) <- NULL
## FDR within stratum for each weighting, on the permutation p (and reported alongside theory p)
for (w in c("w_equal","w_sqrtn","w_df")) for (sc in c(PRIMARY_SCHEME, ALT_SCHEME)) {
  idx <- R$weighting==w & R$scheme_GSE196870==sc
  R$fdr_emp[idx] <- ave(R$p_emp[idx], R$stratum[idx], FUN=function(x) p.adjust(x,"BH"))
  R$fdr_theory[idx] <- ave(R$p_theory[idx], R$stratum[idx], FUN=function(x) p.adjust(x,"BH"))
}
write.csv(R, file.path(SC_OUT, "stouffer_sensitivity.csv"), row.names=FALSE)
cat("\n=== S1, equal weights ===\n")
print(R[R$scheme_GSE196870==PRIMARY_SCHEME & R$weighting=="w_equal",
   c("stratum","program","k","n_up","Z","p_theory","p_emp","resolution_floor","fdr_emp")],
   digits=5, row.names=FALSE)
cat("\n=== S1, sqrt(n) weights ===\n")
print(R[R$scheme_GSE196870==PRIMARY_SCHEME & R$weighting=="w_sqrtn",
   c("stratum","program","Z","p_theory","p_emp","fdr_emp")], digits=5, row.names=FALSE)
cat("\n=== S1, df weights ===\n")
print(R[R$scheme_GSE196870==PRIMARY_SCHEME & R$weighting=="w_df",
   c("stratum","program","Z","p_theory","p_emp","fdr_emp")], digits=5, row.names=FALSE)
saveRDS(R, file.path(SC_CACHE, "stouffer_final.rds"))
