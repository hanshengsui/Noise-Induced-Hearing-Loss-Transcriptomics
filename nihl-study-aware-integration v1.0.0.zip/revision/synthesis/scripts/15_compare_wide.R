## Step 7 -- cell-by-cell comparison of the S0 wide igc table against the archived copy.
## Usage: Rscript 15_compare_wide.R <existing.csv> <s0.csv> <out_diff.csv> <out_summary.txt>
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R"))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) == 4L)
EX <- read.csv(A[1], check.names = FALSE, stringsAsFactors = FALSE)
S0 <- read.csv(A[2], check.names = FALSE, stringsAsFactors = FALSE)
KEY <- c("stratum","study","contrast","programme")
stopifnot(identical(names(EX), names(S0)))
stopifnot(nrow(EX) == 450L, nrow(S0) == 450L)
stopifnot(setequal(do.call(paste, c(EX[KEY], sep="|")), do.call(paste, c(S0[KEY], sep="|"))))
EX <- EX[do.call(order, EX[KEY]), ]; S0 <- S0[do.call(order, S0[KEY]), ]
stopifnot(identical(do.call(paste, c(EX[KEY], sep="|")), do.call(paste, c(S0[KEY], sep="|"))))

## numeric tolerance: FDR to 1e-6 (as specified); directions/categories/logicals exact
num_cols <- names(EX)[vapply(EX, is.numeric, logical(1))]
## FALSE/TRUE are logical in this file; keep them as exact comparisons
rows <- list()
for (j in names(EX)) {
  a <- EX[[j]]; b <- S0[[j]]
  if (j %in% KEY) next
  if (is.numeric(a)) {
    diff <- !(mapply(function(x,y) {
      if (is.na(x) && is.na(y)) TRUE else if (is.na(x) || is.na(y)) FALSE
      else abs(x-y) <= 1e-6
    }, a, b))
  } else {
    diff <- !((is.na(a) & is.na(b)) | (!is.na(a) & !is.na(b) & as.character(a) == as.character(b)))
  }
  if (any(diff)) {
    ii <- which(diff)
    rows[[length(rows)+1]] <- data.frame(
      stratum = S0$stratum[ii], study = S0$study[ii], contrast = S0$contrast[ii],
      programme = S0$programme[ii], setting = sub("^[a-zA-Z_.]+[.]", "", j), field = j,
      existing = as.character(a[ii]), S0_new = as.character(b[ii]),
      is_focal_programme = S0$programme[ii] %in% FOCAL,
      stringsAsFactors = FALSE)
  }
}
D <- if (length(rows)) do.call(rbind, rows) else
  data.frame(stratum=character(), study=character(), contrast=character(), programme=character(),
             setting=character(), field=character(), existing=character(), S0_new=character(),
             is_focal_programme=logical(), stringsAsFactors=FALSE)
## the schema in the task lists setting before field; keep exactly: stratum, study, contrast,
## programme, setting, field, existing, S0_new
D <- D[, c("stratum","study","contrast","programme","setting","field","existing","S0_new",
           "is_focal_programme")]
write.csv(D, A[3], row.names = FALSE)

## --- summary counts (all computed from the full 450-row tables, never from print output)
n_changed_cells <- nrow(D)
n_changed_design_cells <- length(unique(paste(D$stratum, D$study, D$contrast, D$programme,
                                               D$field, sep="|")))
n_focal_cells <- sum(D$is_focal_programme)
cat_cols <- grep("^cat[.]", names(EX), value=TRUE)
dir_cols <- grep("^direction[.]", names(EX), value=TRUE)
cat_changed <- sum(sapply(cat_cols, function(j) sum(EX[[j]] != S0[[j]])))
dir_changed <- sum(sapply(dir_cols, function(j) sum(as.character(EX[[j]]) != as.character(S0[[j]]))))
n_rows_any_change <- sum(apply(D[, c("stratum","study","contrast","programme")], 1, paste, collapse="|") %in%
                          apply(data.frame(stratum=EX$stratum, study=EX$study, contrast=EX$contrast,
                                            programme=EX$programme), 1, paste, collapse="|"))
## how many distinct comparison rows differ at all
rowkey_changed <- length(unique(paste(D$stratum, D$study, D$contrast, D$programme, sep="|")))
## restriction to the 9 study-contrasts that involve GSE196870
gse196 <- unique(paste(S0$stratum, S0$study, S0$contrast, sep="|")[S0$study == "GSE196870"])
chg_gse196 <- D[paste(D$stratum, D$study, D$contrast, sep="|") %in% gse196, ]
## FDR.columns only, >1e-6
fdr_cols <- grep("^FDR[.]", names(EX), value=TRUE)
fdr_bigger <- sum(sapply(fdr_cols, function(j) sum(abs(EX[[j]] - S0[[j]]) > 1e-6, na.rm=TRUE)))

L <- c(
  sprintf("existing file: %s", A[1]),
  sprintf("S0 file      : %s", A[2]),
  sprintf("rows compared: %d (keys matched 1:1)", nrow(EX)),
  "",
  sprintf("changed cells (field-level, >1e-6 for FDR; exact for direction/category): %d", n_changed_cells),
  sprintf("  of which in focal programmes: %d", n_focal_cells),
  sprintf("  of which in the 9 GSE196870 study-contrasts: %d", nrow(chg_gse196)),
  sprintf("  of which in focal programmes AND GSE196870 contrasts: %d", sum(chg_gse196$is_focal_programme)),
  sprintf("changed comparison rows (>=1 changed cell): %d of 450", rowkey_changed),
  "",
  sprintf("direction cells changed (exact): %d across %d direction columns", dir_changed, length(dir_cols)),
  sprintf("category cells changed (exact): %d across %d cat columns", cat_changed, length(cat_cols)),
  sprintf("FDR cells changed by >1e-6: %d", fdr_bigger),
  "",
  "changed cells by field:"
)
tb <- table(D$field)
L <- c(L, sprintf("  %-32s %d", names(tb), as.integer(tb)))
L <- c(L, "", "changed cells by setting x field:")
tb2 <- table(paste(D$setting, D$field, sep=" | "))
L <- c(L, sprintf("  %-40s %d", names(tb2), as.integer(tb2)))
cat(paste(L, collapse="\n"), "\n")
writeLines(L, A[4])
saveRDS(list(D=D, n_changed=n_changed_cells, n_focal=n_focal_cells,
             cat_changed=cat_changed, dir_changed=dir_changed, fdr_bigger=fdr_bigger,
             rowkey_changed=rowkey_changed, n_gse196=sum(paste(D$stratum,D$study,D$contrast,sep="|") %in% gse196),
             n_gse196_focal=sum(chg_gse196$is_focal_programme)), file.path(SC_CACHE, "compare.rds"))
