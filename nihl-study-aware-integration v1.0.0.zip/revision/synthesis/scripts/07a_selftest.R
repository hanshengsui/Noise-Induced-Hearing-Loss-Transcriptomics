## Appendix B2.3 self-tests.  Both must pass before the real calibration is run.
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R"))
suppressPackageStartupMessages({library(limma)})

## ---------- A. the enumerator itself ----------
mkcase <- function(lab, blk, expect, name) {
  p <- enumerate_relabelings(lab, blk)
  data.frame(design=name, n_relabelings=length(p), closed_form=expect,
             observed_first=all(p[[1]] == lab),
             within_block_multiset_ok=if (is.null(blk)) NA else
               all(vapply(p, function(v) all(vapply(split(seq_along(v), blk), function(ii)
                 identical(sort(v[ii]), sort(lab[ii])), logical(1))), logical(1))))
}
A <- rbind(
  mkcase(c(rep("A",4),rep("B",4)), NULL, choose(8,4), "4 vs 4 unblocked"),
  mkcase(c(rep("A",3),rep("B",3)), NULL, choose(6,3), "3 vs 3 unblocked"),
  mkcase(c(rep("A",2),rep("B",2)), NULL, choose(4,2), "2 vs 2 unblocked"),
  mkcase(c(rep("A",5),rep("B",9)), NULL, choose(14,5), "5 vs 9 unblocked"),
  mkcase(rep(c("A","B"),4), rep(1:4, each=2), 2^4, "4 blocks x (1 A + 1 B)"),
  mkcase(c(rep("A",3),rep("B",2),"B"), c(rep("f",5),"m"), 10, "5f(3A2B)+1m(B)"))
A$matches_closed_form <- A$n_relabelings == A$closed_form
print(A, row.names=FALSE)

## ---------- B(i). simulated null data -> empirical p approximately uniform ----------
sim_pvalues <- function(nrep=120, n1=4, n2=4, ngenes=1200, nsets=20, set_size=40, seed=SEED_GLOBAL) {
  set.seed(seed); allp <- numeric(0)
  for (r in seq_len(nrep)) {
    E <- matrix(rnorm(ngenes*(n1+n2)), ngenes)
    grp <- factor(rep(c("c","t"), c(n1,n2))); d <- model.matrix(~0+grp); colnames(d) <- c("c","t")
    cmv <- matrix(c(-1,1),2,1,dimnames=list(c("c","t"),"diff"))
    fitstat <- function(E, d) { f <- eBayes(contrasts.fit(lmFit(E,d), cmv), robust=TRUE, trend=FALSE)
                                t <- f$t[,1]; names(t) <- paste0("G", seq_len(nrow(E))); t }
    sets <- replicate(nsets, sample(paste0("G", seq_len(ngenes)), set_size), simplify=FALSE)
    names(sets) <- paste0("S", seq_len(nsets))
    zobs <- { cam <- camera_pr_signed(fitstat(E,d), sets); signed_z_of(cam$PValue, cam$direction) }
    perms <- enumerate_relabelings(as.character(grp))
    Z0 <- matrix(NA_real_, length(perms), nsets)
    for (b in seq_along(perms)) {
      gg <- factor(perms[[b]], levels=c("c","t")); dd <- model.matrix(~0+gg); colnames(dd) <- c("c","t")
      cam2 <- camera_pr_signed(fitstat(E,dd), sets)
      Z0[b,] <- signed_z_of(cam2$PValue, cam2$direction)
    }
    allp <- c(allp, vapply(seq_along(zobs), function(k)
      (1 + sum(abs(Z0[,k]) >= abs(zobs[k]))) / (nrow(Z0)+1), numeric(1)))
  }
  allp
}
pv <- sim_pvalues()
ks <- suppressWarnings(ks.test(pv, "punif", exact=FALSE))
cat(sprintf("\nB(i) null uniformity: n_p=%d  KS D=%.4f  p=%.3g  mean=%.3f  frac<0.05=%.3f  frac<0.10=%.3f\n",
            length(pv), ks$statistic, ks$p.value, mean(pv), mean(pv<0.05), mean(pv<0.10)))
## proportion of p below nominal level should track the nominal level (calibration check)
bin <- data.frame(nominal=c(0.01,0.05,0.10,0.25,0.50),
                  observed=vapply(c(0.01,0.05,0.10,0.25,0.50), function(a) mean(pv <= a), numeric(1)))
bin$abs_dev <- abs(bin$observed - bin$nominal)
print(bin, row.names=FALSE)
## binomial test that the fraction below 0.05 is consistent with 0.05
bt <- binom.test(sum(pv <= 0.05), length(pv), 0.05)
cat(sprintf("B(i) binomial check frac(p<=0.05): %d/%d = %.4f, p=%.3f\n",
            sum(pv <= 0.05), length(pv), mean(pv <= 0.05), bt$p.value))

## ---------- B(ii). real block structure: labels change, only within blocks ----------
O <- readRDS(file.path(SC_CACHE, "expr.rds"))
blockreport <- function(lab, blk, name) {
  p <- enumerate_relabelings(lab, blk)
  changed <- mean(!vapply(p, function(v) all(v == lab), logical(1)))
  if (is.null(blk)) {
    within <- NA
  } else {
    within <- all(vapply(p, function(v) {
      ok <- TRUE
      for (u in unique(blk)) { ii <- which(blk == u)
        ok <- ok && identical(sort(v[ii]), sort(lab[ii])) }
      ok }, logical(1)))
  }
  ## how many relabelings move at least one label across a block boundary (must be 0)
  if (is.null(blk)) crossmoves <- NA else
    crossmoves <- sum(vapply(p, function(v) {
      any(vapply(unique(blk), function(u) { ii <- which(blk == u)
        sum(v[ii] == lab[1]) != sum(lab[ii] == lab[1]) }, logical(1))) }, logical(1)))
  data.frame(design=name, n_perms=length(p), frac_label_vectors_changed=round(changed,3),
             within_block_multiset_preserved=within, n_perms_with_cross_block_moves=crossmoves)
}
B <- rbind(
  blockreport(as.character(O$GSE196870_S0$meta$group)[O$GSE196870_S0$meta$group %in% c("noise_1h","control")],
              NULL, "GSE196870 acute (no block)"),
  blockreport(as.character(O$GSE100365$meta$group)[O$GSE100365$meta$group %in% c("immediate","control")],
              as.character(O$GSE100365$meta$sex)[O$GSE100365$meta$group %in% c("immediate","control")],
              "GSE100365 acute (sex-blocked)"),
  blockreport(as.character(O$EMTAB$meta$group)[O$EMTAB$meta$group %in% c("h24","control")],
              as.character(O$EMTAB$meta$sex)[O$EMTAB$meta$group %in% c("h24","control")],
              "E-MTAB-16125 h24 (sex-blocked)"))
print(B, row.names=FALSE)

write.csv(A, file.path(SC_OUT, "perm_selftest_enumeration.csv"), row.names=FALSE)
write.csv(B, file.path(SC_OUT, "perm_selftest_blocking.csv"), row.names=FALSE)
write.csv(bin, file.path(SC_OUT, "perm_selftest_uniformity_bins.csv"), row.names=FALSE)
cat("\nSELFTEST SUMMARY: enumeration ", ifelse(all(A$matches_closed_form), "PASS", "FAIL"),
    "; blocking ", ifelse(all(B$n_perms_with_cross_block_moves %in% c(0L, NA)), "PASS", "FAIL"),
    "; pooled-set KS p=", format.pval(ks$p.value),
    " (descriptive: sets within a simulated dataset are correlated; see independent-dataset test 07b)\n")
saveRDS(list(pv=pv, ks=ks, bin=bin), file.path(SC_CACHE, "selftest_uniform.rds"))
