## Final AF21 update plan: every candidate sheet compared cell by cell, S0 against the
## archived revision results.  A sheet that is already S0 shows 0 changed cells; one that is
## still S1 shows the cell count that regeneration would move.
##
## Usage: Rscript 31_af21_plan_final.R <repo_dir> <S0_dir> <out_csv> <out_txt>
# Paths. SC_SCR = this script directory, SC_ROOT = repository root, SC_CACHE = cache,
# SC_OUT = output directory, SC_DL = staged public inputs (see 00_stage_inputs.R),
# SC_PKG = frozen result files of the original analysis package (revision/synthesis/inputs/frozen_package_results).
SC_SCR   <- Sys.getenv("SC_SCR",  normalizePath(".", mustWork = FALSE))
SC_ROOT  <- Sys.getenv("SC_ROOT", normalizePath("../../..", mustWork = FALSE))
SC_CACHE <- Sys.getenv("SC_CACHE", file.path(SC_ROOT, "revision", "synthesis", "cache"))
SC_OUT   <- Sys.getenv("SC_OUT",  file.path(SC_ROOT, "revision", "synthesis", "results"))
SC_DL    <- Sys.getenv("SC_DL",   file.path(SC_ROOT, "revision", "synthesis", "inputs", "downloads"))
SC_PKG   <- Sys.getenv("SC_PKG",  file.path(SC_ROOT, "revision", "synthesis", "inputs", "frozen_package_results"))
dir.create(SC_CACHE, showWarnings = FALSE, recursive = TRUE)
dir.create(SC_OUT, showWarnings = FALSE, recursive = TRUE)
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB"))) .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB"), winslash="/"), .libPaths())))
source(file.path(SC_SCR, "00_common.R")); source(file.path(SC_SCR, "03_syn_def.R"))
A <- commandArgs(trailingOnly = TRUE); stopifnot(length(A) == 4L)
REPO <- A[1]; D0 <- A[2]
rd <- function(d,f) read.csv(file.path(d,f), stringsAsFactors = FALSE, check.names = FALSE, na.strings = c("NA",""))
rp <- function(f) rd(REPO, f)

## align two tables on a key before comparing, so that a different row ORDER is not counted
## as a changed cell
align_on <- function(old, new, key) {
  if (is.null(key) || !all(key %in% names(old)) || !all(key %in% names(new))) return(list(old, new))
  ko <- do.call(paste, c(old[key], sep = "|")); kn <- do.call(paste, c(new[key], sep = "|"))
  if (!setequal(ko, kn)) return(list(old, new))
  list(old[match(ko, ko), , drop = FALSE], new[match(ko, kn), , drop = FALSE])
}

cmp <- function(old, new, tol = 1e-6, key = NULL) {
  if (is.null(old) || is.null(new)) return(list(n=NA_integer_, mx=NA_real_, cols="", rows_ok=NA))
  al <- align_on(old, new, key); old <- al[[1]]; new <- al[[2]]
  cols <- intersect(names(old), names(new))
  n <- 0L; mx <- 0; bad <- character(0)
  rownames_ok <- nrow(old) == nrow(new)
  if (!rownames_ok) return(list(n=NA_integer_, mx=NA_real_, cols="ROW COUNT DIFFERS", rows_ok=FALSE))
  for (j in cols) {
    a <- old[[j]]; b <- new[[j]]
    if (is.numeric(a) && is.numeric(b)) {
      d <- abs(a - b); hit <- is.finite(d) & d > tol
      nahit <- (is.na(a) != is.na(b))
      if (any(hit)) { n <- n + sum(hit); mx <- max(mx, max(d[hit])); bad <- c(bad, j) }
      if (any(nahit)) { n <- n + sum(nahit); bad <- c(bad, j) }
    } else {
      hit <- as.character(a) != as.character(b) & !(is.na(a) & is.na(b))
      if (any(hit)) { n <- n + sum(hit); bad <- c(bad, j) }
    }
  }
  list(n = n, mx = if (n == 0L) 0 else mx, cols = paste(unique(bad), collapse = ";"), rows_ok = TRUE)
}

rows <- list()
add <- function(sheet, src, old, new, note, key = NULL) {
  cc <- cmp(old, new, key = key)
  rows[[length(rows)+1]] <<- data.frame(
    sheet = sheet, source_file_S0 = src,
    rows_old = if (is.null(old)) NA_integer_ else nrow(old),
    rows_new = if (is.null(new)) NA_integer_ else nrow(new),
    n_cells_changed = cc$n, max_abs_diff = cc$mx, changed_columns = cc$cols,
    note = note, stringsAsFactors = FALSE)
}
add("igc_sensitivity", "igc_sensitivity.csv", rp("igc_sensitivity.csv"), rd(D0,"igc_sensitivity.csv"),
    "24 FDR-category and 4 direction cells change; all in the two GSE196870 contrasts",
    key = c("stratum","study","contrast","programme"))
add("igc_estimated_correlation", "camera_estimated_correlation.csv",
    rp("camera_estimated_correlation.csv"), rd(D0,"camera_estimated_correlation.csv"),
    "only the 100 GSE196870 rows move; the other 350 are identical",
    key = c("stratum","study","contrast","programme"))
add("fry_p_values", "fry_pvalue_mixed.csv", rp("fry_pvalue_mixed.csv"), rd(D0,"fry_pvalue_mixed.csv"),
    "the sheet holds the later/EMTAB programme only (no GSE196870 contrast in that stratum)",
    key = c("stratum","study","contrast","programme"))
add("stouffer_calibrated", "stouffer_calibrated.csv", rp("stouffer_calibrated.csv"), rd(D0,"stouffer_calibrated.csv"),
    "S0-only sheet (45 rows, scheme column = S0)", key = c("scheme_GSE196870","stratum","program","weighting"))
add("weighting_sensitivity", "stouffer_sensitivity.csv", rp("stouffer_sensitivity.csv"), rd(D0,"stouffer_sensitivity.csv"),
    "carries both scheme_GSE196870 rows; compared within scheme",
    key = c("scheme_GSE196870","stratum","program","weighting"))
add("permutation_calibration", "perm_calibration.csv", rp("perm_calibration.csv"), rd(D0,"perm_calibration.csv"),
    "per-study enumeration ledger + resolution floors; rebuilt under S0 by 30_perm_calibration_sheet.R",
    key = c("stratum","program","weighting"))
add("perm_null_dispersion", "perm_null_dispersion.csv", rp("perm_null_dispersion.csv"), rd(D0,"perm_null_dispersion.csv"),
    "per study-contrast null SD; the two GSE196870 contrasts are the only ones that can move",
    key = c("study_contrast"))
add("sign_tests", "sign_test_results.csv", rp("sign_test_results.csv"), rd(D0,"sign_test_results.csv"),
    "sign test on the w_equal synthesis Z, S0", key = c("stratum","program"))
add("bh_families", "k17_bh_families.csv", rp("k17_bh_families.csv"), rd(D0,"k17_bh_families.csv"),
    "5-programme and 50-Hallmark BH families, S0", key = c("stratum","program"))
add("k17_all50_hallmark_fdr", "k17_all50_hallmark_fdr.csv", rp("k17_all50_hallmark_fdr.csv"), rd(D0,"k17_all50_hallmark_fdr.csv"),
    "150 rows, per-stratum per-Hallmark FDR", key = c("stratum","program_hallmark"))
add("temporal", "temporal_evidence.csv", rp("temporal_evidence.csv"), rd(D0,"temporal_evidence.csv"),
    "5 programmes x 3 strata with the IUT columns", key = c("program"))
add("forest_effects", "forest_effects.csv", rp("forest_effects.csv"), rd(D0,"forest_effects.csv"),
    "per study-contrast gene-set score effects; GSE196870 rows are the only ones that can move",
    key = c("stratum","study","contrast","program"))
add("competitive_vs_selfcontained", "competitive_vs_selfcontained.csv",
    rp("competitive_vs_selfcontained.csv"), rd(D0,"competitive_vs_selfcontained.csv"),
    "camera_t vs the self-contained score; GSE196870 rows only",
    key = c("stratum","study","program"))

## null-SD sheet: the five tested contrasts, none of which is GSE196870
NS0 <- rd(D0,"null_sd_diagnosis_S0.csv"); NS0 <- NS0[NS0$in_original_five, ]
old_ns <- rp("perm_null_sd_diagnosis.csv")
like <- do.call(rbind, lapply(seq_len(nrow(NS0)), function(i) data.frame(
  stratum = NS0$stratum[i], study = NS0$study[i],
  inter_gene_cor_used = c(0.01, NS0$rho_assumed[i]), n_perms = NS0$n_perms[i],
  median_z_null_sd = c(NS0$null_sd_at_0.01[i], NS0$null_sd_at_measured[i]),
  measured_correlation_median = NS0$measured_rho[i], stringsAsFactors = FALSE)))
like <- like[order(match(paste(like$stratum, like$study), paste(old_ns$stratum, old_ns$study)),
                   like$inter_gene_cor_used), ]
add("null_sd_diagnosis", "null_sd_diagnosis_S0.csv (in_original_five rows)", old_ns, like,
    "the five tested contrasts contain no GSE196870, so this sheet is scheme-independent",
    key = c("stratum","study","inter_gene_cor_used"))

P <- do.call(rbind, rows)
write.csv(P, A[3], row.names = FALSE)
L <- c("AF21 UPDATE PLAN", "",
  sprintf("%-32s %6s %6s %10s %12s  %s", "sheet","rows","rows","cells","max|diff|","verdict"),
  sprintf("%-32s %6d %6d %10s %12s  %s", P$sheet, P$rows_old, P$rows_new,
    ifelse(is.na(P$n_cells_changed), "n/a", as.character(P$n_cells_changed)),
    ifelse(is.na(P$max_abs_diff), "n/a", sprintf("%.3e", P$max_abs_diff)),
    ifelse(is.na(P$n_cells_changed), "NOT COMPARABLE",
      ifelse(P$n_cells_changed == 0, "identical -- no change needed", "MUST BE REGENERATED"))), "",
  "Changed columns per sheet:",
  sprintf("  %-32s %s", P$sheet[P$n_cells_changed > 0 | is.na(P$n_cells_changed)],
          ifelse(is.na(P$changed_columns[P$n_cells_changed > 0 | is.na(P$n_cells_changed)]), "",
                 P$changed_columns[P$n_cells_changed > 0 | is.na(P$n_cells_changed)])), "",
  "Sheets needing regeneration:", sprintf("  %s", P$sheet[!is.na(P$n_cells_changed) & P$n_cells_changed > 0]),
  "Sheets already correct under S0:", sprintf("  %s", P$sheet[!is.na(P$n_cells_changed) & P$n_cells_changed == 0]))
cat(paste(L, collapse="\n"), "\n"); writeLines(L, A[4])
