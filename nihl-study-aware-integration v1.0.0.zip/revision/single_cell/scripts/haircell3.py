import os
import pickle, numpy as np, pandas as pd, json
W=os.environ.get("SC_W","work")
pd.set_option("display.width",200)
libs=pickle.load(open(f"{W}/sc_out/libs.pkl","rb")); obs=pickle.load(open(f"{W}/sc_out/obs_raw.pkl","rb"))
Mats,Feats,meta=libs["Mats"],libs["Feats"],libs["meta"]
HC=["Myo7a","Pou4f3","Slc26a5","Otof","Ocm"]
rec=[]
for i,sm in meta.iterrows():
    M,feat=Mats[i],Feats[i]; gi={g:np.where(feat==g)[0][0] for g in HC}
    keep=obs.loc[obs.sample_id==sm.sample_id,"qc_pass"].values
    sub=M[[gi[g] for g in HC],:][:,keep]
    pos=(sub>0).toarray()
    d=obs[(obs.sample_id==sm.sample_id)&obs.qc_pass].copy()
    for k,g in enumerate(HC): d["pos_"+g]=pos[k]
    d["n_hc"]=pos.sum(axis=0)
    rec.append(d)
d=pd.concat(rec,ignore_index=True)
d["cell_key"] = d.sample_id.astype(str) + "_" + d.barcode.astype(str)
# Hair-cell definitions stated in the supplementary methods.
d["ihc_like"] = d.pos_Otof & d.pos_Myo7a & d.pos_Pou4f3
d["ohc_like"] = d.pos_Slc26a5 & d.pos_Ocm & d.pos_Myo7a
print("Marginal detection rate per gene (post-QC, n=%d):"%len(d))
marg={g: d["pos_"+g].mean() for g in HC}
print({k:round(v,5) for k,v in marg.items()})
print("\nExpected vs observed co-expression counts (independence):")
for k in range(2,6):
    exp=None
    print(f"  n_hc>={k}: {int((d.n_hc>=k).sum())}")
# expected number of cells with >=2 by independence, per-cell binomial from marginals
from itertools import combinations
p=np.array([marg[g] for g in HC])
exp2 = ((p[None,:]*(1-p)[None,:])*0)
# exact independence: prob a cell has >=2 positives, product over cells approximates with equal marginals
P2 = sum(np.prod([p[j] if j in c else 1-p[j] for j in range(5)]) for c in combinations(range(5),2))
P2 += sum(np.prod([p[j] if j in c else 1-p[j] for j in range(5)]) for c in combinations(range(5),3))
P2 += sum(np.prod([p[j] if j in c else 1-p[j] for j in range(5)]) for c in combinations(range(5),4))
P2 += np.prod(p)
print(f"  expected cells with n_hc>=2 under independence = {P2*len(d):.1f}; observed = {int((d.n_hc>=2).sum())}")
print("\nSlc26a5 (prestin) positive cells:", int(d.pos_Slc26a5.sum()))
print("  breakdown:", d[d.pos_Slc26a5].groupby("tissue_cohort").size().to_dict())
print("  of which n_hc>=2:", int(((d.n_hc>=2)&d.pos_Slc26a5).sum()))
print("\nn_hc>=3 by cohort:", d[d.n_hc>=3].groupby("tissue_cohort").size().to_dict())
print("n_hc==5:", int((d.n_hc==5).sum()), " ==4:", int((d.n_hc==4).sum()))
print("\nTop hc_like cells by n_hc then top_marker_score:")
print(d[d.n_hc>=2].sort_values(["n_hc","top_marker_score"],ascending=False).head(10)[["sample_id","tissue_cohort","cell_type","n_hc","n_count","n_feature","top_marker_score"]].to_string())
# ambient check: do the hc_like cells have high library/feature counts (ambient signature)?
print("\nn_count quartiles: hc_like", d[d.n_hc>=2].n_count.describe()[["25%","50%","75%"]].to_dict(),
      " others", d[d.n_hc<2].n_count.describe()[["25%","50%","75%"]].to_dict())
d.to_pickle(f"{W}/sc_out/obs_qc_genes.pkl")
json.dump({"marginal":{k:float(v) for k,v in marg.items()},
           "n_hc_ge2":int((d.n_hc>=2).sum()), "n_hc_ge3":int((d.n_hc>=3).sum()),
           "expected_ge2_indep":float(P2*len(d)),
           "slc26a5_pos":int(d.pos_Slc26a5.sum()),
           "n_cells":int(len(d))}, open(f"{W}/sc_out/hair_cell_stats.json","w"), indent=1)
