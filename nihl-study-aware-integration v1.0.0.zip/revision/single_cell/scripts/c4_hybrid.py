"""A4/C4 stage 2b: label-preserving reassignment.

Five of nine classes retain fewer than two markers after the stable-panel filter (fibrocyte,
pericyte_smooth_muscle, marginal_cell, intermediate_melanocyte, basal_cell:
fewer than two stable markers each), so a like-for-like reclassification across all nine
classes is impossible under the pre-specified rule. Two readings are computed:

  PRIMARY  (label-preserving): cells originally assigned to a VERIFIABLE class
           (>=2 stable markers: SGN, Schwann, endothelial, immune) are re-scored
           against those four classes only; every other cell keeps its original
           label.  Units downstream are therefore comparable with the original
           run for all 13 contrasts.
  SECONDARY (pure restriction): the scorer only ever sees the four verifiable
           classes, so everything else collapses to unassigned -- reported as a
           sensitivity, not as the concordance denominator.
"""
import pickle, json, numpy as np, pandas as pd, scipy.sparse as sp
import os
W=os.environ.get("SC_W","work")
W=os.environ.get("SC_W","work")
libs=pickle.load(open(f"{W}/sc_out/libs.pkl","rb")); obs=pickle.load(open(f"{W}/sc_out/obs_raw.pkl","rb"))
Mats,Feats,meta=libs["Mats"],libs["Feats"],libs["meta"]
mk=pd.read_csv(os.environ.get("SC_MARKERS", "resources/annotations/cell_type_markers.csv"))
stable=[l.strip() for l in open(f"{W}/sc_out/stable_list.txt") if l.strip()]
st=pd.read_pickle(f"{W}/sc_out/obs_stable.pkl")
VER=["spiral_ganglion_neuron","schwann_glial","endothelial","immune"]
st["hybrid_cell_type"]=st.cell_type.copy()

for i,sm in meta.iterrows():
    M,feat=Mats[i],Feats[i]
    cm=mk[mk.cohort_scope.isin(["both",sm.tissue_cohort])]
    types=[c for c in dict.fromkeys(cm.cell_type) if c in VER and c in set(
        mk.cell_type[mk.cohort_scope.isin(["both",sm.tissue_cohort])])]
    if not types: continue
    keep=obs.loc[obs.sample_id==sm.sample_id,"qc_pass"].values
    gi={ct:[int(np.where(feat==x)[0][0]) for x in cm.loc[cm.cell_type==ct,"marker_gene"]
            if x in stable and (feat==x).any()] for ct in types}
    rows_=np.array(sorted({k for v in gi.values() for k in v}))
    pos={g:k for k,g in enumerate(rows_)}
    sub=M[rows_,:][:,keep].tocsc().astype(np.float64)
    lib=np.asarray(M.sum(axis=0)).ravel()[keep]
    sub=sp.csr_matrix(sp.diags(1e4/np.maximum(lib,1))@sub.T); sub.data=np.log1p(sub.data)
    score=np.zeros((sub.shape[0],len(types)))
    for j,ct in enumerate(types):
        if gi[ct]: score[:,j]=np.asarray(sub[:,[pos[k] for k in gi[ct]]].mean(axis=1)).ravel()
    top_i=score.argmax(axis=1); top=score[np.arange(len(top_i)),top_i]
    srt=np.sort(score,axis=1); second=srt[:,-2] if len(types)>1 else np.zeros(len(top))
    margin=top-second
    assigned=np.array(types,dtype=object)[top_i]
    assigned[(top<0.05)|(margin<0.01)]="unassigned"

    idx=np.where((st.sample_id==sm.sample_id).values)[0]
    orig=st.cell_type.values[idx]
    new=st.hybrid_cell_type.values[idx].copy()
    ev=np.isin(orig,VER)
    new[ev]=assigned[ev]
    st.loc[idx,"hybrid_cell_type"]=new

st.to_pickle(f"{W}/sc_out/obs_stable_hybrid.pkl")
ORDER=["spiral_ganglion_neuron","schwann_glial","fibrocyte","endothelial","pericyte_smooth_muscle",
       "immune","marginal_cell","intermediate_melanocyte","basal_cell","unassigned"]

def report(col, tag, rows_filter=None):
    sub=st if rows_filter is None else st[rows_filter]
    rows=[]
    for c in ORDER:
        A=set(np.where(sub.cell_type==c)[0]); B=set(np.where(sub[col]==c)[0])
        inter=len(A&B); un=len(A|B)
        rows.append(dict(definition=tag, cell_type=c, n_original=len(A), n_reassigned=len(B),
                         n_intersection=inter, n_union=un, jaccard=inter/un if un else np.nan,
                         retained_fraction=inter/len(A) if A else np.nan,
                         verifiable=c in VER))
    return pd.DataFrame(rows)

prim=report("hybrid_cell_type","label_preserving", st.cell_type.isin(VER) | (st.cell_type=="unassigned"))
sec =report("stable_cell_type","pure_restriction")
pd.set_option("display.width",250)
print("=== PRIMARY: label-preserving (Jaccard limited to verifiable classes' own rows) ===")
print(prim.to_string(index=False))
print("\nconcordance, verifiable-class cells:",
      float((st.loc[st.cell_type.isin(VER),"cell_type"]==st.loc[st.cell_type.isin(VER),"hybrid_cell_type"]).mean()))
print("concordance, all cells:", float((st.cell_type==st.hybrid_cell_type).mean()))
print("\n=== SECONDARY: pure restriction ===")
print(sec.to_string(index=False))
cmh=pd.crosstab(pd.Categorical(st.loc[st.cell_type.isin(VER),"cell_type"],categories=VER,ordered=True),
                pd.Categorical(st.loc[st.cell_type.isin(VER),"hybrid_cell_type"],categories=ORDER,ordered=True))
print("\nhybrid confusion (verifiable-class rows only):"); print(cmh.to_string())
prim.to_csv(f"{W}/sc_out/stable_marker_reassignment_primary.csv",index=False)
sec.to_csv(f"{W}/sc_out/stable_marker_reassignment_pure.csv",index=False)
cmh.to_csv(f"{W}/sc_out/stable_marker_confusion_hybrid.csv")
json.dump({"n_verifiable_classes":4,"n_unverifiable_classes":5,
           "concordance_verifiable":float((st.loc[st.cell_type.isin(VER),"cell_type"]==st.loc[st.cell_type.isin(VER),"hybrid_cell_type"]).mean()),
           "concordance_all":float((st.cell_type==st.hybrid_cell_type).mean()),
           "n_cells_verifiable_class_rows":int(st.cell_type.isin(VER).sum()),
           "n_cells_unverifiable_class_rows":int((~st.cell_type.isin(VER+["unassigned"])).sum())},
          open(f"{W}/sc_out/c4_concordance.json","w"),indent=1)
