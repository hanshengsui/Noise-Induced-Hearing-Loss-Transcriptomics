import os
"""A4/C1 rev: what defines the Leiden cluster that holds the hair-cell-like cells?"""
import numpy as np, pandas as pd, scipy.sparse as sp, pickle
W=os.environ.get("SC_W","work")
for cls in (sp.csr_array, sp.csc_array, sp.coo_array, sp.csr_matrix, sp.csc_matrix, sp.coo_matrix):
    if not hasattr(cls, "getnnz"):
        cls.getnnz = lambda self, axis=None: self._getnnz(axis=axis)
import scanpy as sc
sc.settings.verbosity = 0
O=f"{W}/sc_out"
A = sc.read_h5ad(f"{O}/ad_qc.h5ad"); A.var_names_make_unique()
d = pd.read_pickle(f"{O}/obs_qc_genes.pkl").set_index("cell_key")
A.obs["leiden"] = d["leiden"].reindex(A.obs_names).astype(str).values
A.obs["n_hc"] = d["n_hc"].reindex(A.obs_names).values
A.obs["ihc"] = d["ihc_like"].reindex(A.obs_names).values
a = A[A.obs.tissue_cohort=="neuronal_focused"].copy()
sc.pp.normalize_total(a, target_sum=1e4); sc.pp.log1p(a)
target = "29"
a.obs["grp"] = np.where(a.obs.leiden==target, "cluster29", "rest")
sc.tl.rank_genes_groups(a, "grp", groups=["cluster29"], reference="rest", method="wilcoxon")
res = sc.get.rank_genes_groups_df(a, group="cluster29")
res["ishc"] = res.names.str.upper().isin(["MYO7A","POU4F3","SLC26A5","OTOF","OCM"])
print("top 25 genes of cluster 29 (n=%d vs rest):" % int((a.obs.leiden==target).sum()))
print(res.head(25)[["names","logfoldchanges","pvals_adj"]].to_string(index=False))
print("\nhair-cell genes in rank list:")
print(res[res.ishc][["names","logfoldchanges","pvals_adj","scores"]].to_string(index=False))
res.to_csv(f"{O}/leiden_cluster29_markers.csv", index=False)
# fibroblast/structural genes as a sanity check on contamination
for g in ["Col1a1","Dcn","Mpz","Plp1","Nefh","Snap25","Ptprc","Pecam1","Kcnq1","Dct"]:
    r = res[res.names.str.upper()==g]
    if len(r): print(f"  {g}: lfc={r.logfoldchanges.iloc[0]:.2f} padj={r.pvals_adj.iloc[0]:.2e}")
