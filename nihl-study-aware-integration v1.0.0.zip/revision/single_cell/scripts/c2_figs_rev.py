"""A4/C2 rev: UMAP with a well-separated palette + hair-cell-like cluster annotation."""
import os, sys, numpy as np, pandas as pd, pickle
W=os.environ.get("SC_W","work")
sys.path.insert(0, "work/sc_scripts")
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from palette import CLASS_ORDER, PAL, LAB
from palette import apply_figure_style
apply_figure_style(frame="open", sizes=(8,7,6))
O=f"{W}/sc_out"; FIG=f"{O}/figs"; os.makedirs(FIG, exist_ok=True)
lean = pickle.load(open(f"{O}/leiden_lean.pkl","rb"))
d = pd.read_pickle(f"{O}/obs_qc_genes.pkl")

def draw(ax, tag, label, show_cl29=False):
    z = lean[tag]; emb = z["umap"]; obs = z["obs"]
    ct = obs.cell_type.astype(str).values
    for c in [x for x in CLASS_ORDER if x in set(ct)]:
        m = ct == c
        ax.scatter(emb[m,0], emb[m,1], s=0.5, lw=0, c=PAL[c],
                   alpha=0.5 if c=="unassigned" else 0.68, rasterized=True)
    if show_cl29:
        m = (obs.leiden.astype(str) == "29").values
        ax.scatter(emb[m,0], emb[m,1], s=1.6, lw=0, c="#111111", rasterized=True, zorder=3)
        cx, cy = emb[m,0].mean(), emb[m,1].mean()
        xr = emb[:,0].max()-emb[:,0].min(); yr = emb[:,1].max()-emb[:,1].min()
        ax.annotate("hair-cell-like\ncluster (Leiden 29)", xy=(cx, cy),
                    xytext=(cx + 0.22*xr, cy + 0.10*yr),
                    fontsize=6.2, ha="left", va="center",
                    arrowprops=dict(arrowstyle="-", lw=0.6, color="0.25",
                                    shrinkA=2, shrinkB=3))
    ax.set_xticks([]); ax.set_yticks([]); ax.set_xlabel("UMAP 1"); ax.set_ylabel("UMAP 2")
    ax.set_title(f"{label} (n={obs.shape[0]:,} cells)", loc="left", fontsize=8)
    for s in ax.spines.values(): s.set_visible(False)

fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.7))
draw(axes[0], "neuronal", "Neuronal-cohort dissection", show_cl29=True)
draw(axes[1], "lateral_wall", "Lateral-wall-cohort dissection")
handles = [Line2D([0],[0], marker="o", ls="", ms=5, mfc=PAL[c], mec="none", label=LAB[c]) for c in CLASS_ORDER]
fig.legend(handles=handles, loc="lower center", ncol=5, frameon=False, fontsize=6.4,
           bbox_to_anchor=(0.5, -0.07), handletextpad=0.35, columnspacing=1.1)
fig.savefig(f"{FIG}/umap_both_cohorts.pdf", bbox_inches="tight")
fig.savefig(f"{FIG}/umap_both_cohorts.png", dpi=300, bbox_inches="tight")
plt.close(fig)

# individual panels, with per-class n in the legend
for tag, lab in [("neuronal","Neuronal-cohort dissection"), ("lateral_wall","Lateral-wall-cohort dissection")]:
    fig, ax = plt.subplots(figsize=(6.4, 4.7))
    draw(ax, tag, lab, show_cl29=(tag=="neuronal"))
    ct = lean[tag]["obs"].cell_type.astype(str).values
    hs=[Line2D([0],[0], marker="o", ls="", ms=5, mfc=PAL[c], mec="none",
               label=f"{LAB[c]} (n={int((ct==c).sum()):,})") for c in CLASS_ORDER if c in set(ct)]
    ax.legend(handles=hs, loc="center left", bbox_to_anchor=(1.01, 0.5), frameon=False,
              fontsize=6.4, handletextpad=0.4, labelspacing=0.42)
    fig.savefig(f"{FIG}/umap_{tag}.pdf", bbox_inches="tight")
    fig.savefig(f"{FIG}/umap_{tag}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
print("figures written")
