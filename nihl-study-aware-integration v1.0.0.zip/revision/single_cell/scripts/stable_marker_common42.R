#!/usr/bin/env Rscript
# Unified multiple-testing family for the stable-identity-marker re-annotation comparison.
#
# In stable_marker_direction_comparison.csv, fdr_orig is a Benjamini-Hochberg (BH) FDR over the 50 Hallmark
# sets within one cohort-by-cell-class contrast, whereas fdr_stable is a BH FDR over the 7 focal programmes
# within the same contrast. The two columns therefore belong to different families and are not directly
# comparable. This script re-adjusts both P-value columns over one common family -- the 42 tests that are
# evaluable under both annotations (assessed == TRUE) -- and writes the four *_common42 columns.
#
# Usage (from the repository root):
#   Rscript revision/single_cell/scripts/stable_marker_common42.R [--check]
# Without --check the CSV is rewritten with the four columns added (or replaced); with --check the columns are
# recomputed and compared with the stored values, and the script stops if any value differs.

args <- commandArgs(trailingOnly = TRUE)
check_only <- "--check" %in% args
root <- Sys.getenv("NIHL_REPO_ROOT", ".")
path <- Sys.getenv("SC_STABLE_TABLE", file.path(root, "revision", "single_cell", "results", "stable_marker_direction_comparison.csv"))
d <- read.csv(path, stringsAsFactors = FALSE, na.strings = c("", "NA"))

cls <- function(q) ifelse(is.na(q), NA_character_, ifelse(q < 0.05, "conf", ifelse(q < 0.10, "expl", "ns")))
ev <- as.logical(d$assessed)
stopifnot(sum(ev) == 42L)

new <- data.frame(fdr_orig_common42 = rep(NA_real_, nrow(d)), fdr_stable_common42 = NA_real_)
new$fdr_orig_common42[ev]   <- p.adjust(d$p_orig[ev],   method = "BH")
new$fdr_stable_common42[ev] <- p.adjust(d$p_stable[ev], method = "BH")
new$class_orig_common42   <- cls(new$fdr_orig_common42)
new$class_stable_common42 <- cls(new$fdr_stable_common42)

if (check_only) {
  for (v in names(new)) {
    old <- d[[v]]
    ok <- if (is.numeric(new[[v]])) isTRUE(all.equal(as.numeric(old), new[[v]], tolerance = 1e-5))
          else identical(as.character(old), as.character(new[[v]]))
    cat(sprintf("%-24s %s\n", v, if (ok) "identical" else "DIFFERENT"))
    if (!ok) quit(status = 1)
  }
} else {
  d[names(new)] <- new
  write.csv(d, path, row.names = FALSE, na = "")
}
n_ev <- sum(ev)
cat("evaluable tests:", n_ev, "\n")
cat("class changes between original-annotation and stable-annotation (common-42 family):",
    sum(new$class_orig_common42[ev] != new$class_stable_common42[ev]), "of", n_ev, "\n")
