import pickle, os, numpy as np, pandas as pd
W=os.environ.get("SC_W","work")
OUT=os.environ.get("SC_OUT", f"{W}/sc_out")
obs = pickle.load(open(f"{OUT}/obs_raw.pkl","rb"))
# Written by scripts/03_singlecell_pseudobulk.R to work/stage1/source_data/.
LEG = os.environ.get("SC_LEGACY_CELLTABLE",
                     os.path.join(os.environ.get("NIHL_ANALYSIS_ROOT", os.path.join(W, "stage1")),
                                  "source_data/GSE168041_celltype/cell_metadata_marker_guided.csv.gz"))
leg = pd.read_csv(LEG)
print("legacy rows", len(leg), "cols", leg.columns.tolist())
mine = obs[obs.qc_pass].copy()
key = ["sample_id","barcode"]
if mine.duplicated(key).any() or leg.duplicated(key).any():
    raise ValueError("Duplicate sample/barcode keys prevent a one-to-one comparison")
m = mine.merge(leg, on=key, how="outer", suffixes=("_mine","_leg"), indicator=True, validate="one_to_one")
print("merge indicator:\n", m._merge.value_counts().to_string())
both = m[m._merge=="both"]
print("n both", len(both))
agree = (both.cell_type_mine == both.cell_type_leg)
print("cell_type agreement: %d/%d = %.6f%%" % (agree.sum(), len(both), 100*agree.mean()))
# numeric checks
numeric_ok = True
max_diffs = {}
for c in ["top_marker_score","marker_score_margin","n_count","n_feature","percent_mito"]:
    d = np.abs(both[c+"_mine"].values - both[c+"_leg"].values)
    max_diffs[c] = float(np.nanmax(d)) if len(d) else None
    numeric_ok &= len(d) > 0 and bool(np.isfinite(d).all() and (d <= 1e-10).all())
    print(f"  {c}: max abs diff = {max_diffs[c]}")
print("\ncell_type counts mine vs legacy:")
print(pd.crosstab(both.cell_type_mine, both.cell_type_leg))
res = {"n_legacy": int(len(leg)), "n_matched": int(len(both)),
       "n_agree": int(agree.sum()), "agreement": float(agree.mean()),
       "max_abs_differences": max_diffs,
       "passed": bool(len(both) > 0 and (m._merge == "both").all() and agree.all() and numeric_ok)}
import json; json.dump(res, open(f"{OUT}/repro_agreement.json","w"), indent=1)
print(json.dumps(res))

if not res["passed"]:
    raise SystemExit("Annotation comparison failed; see repro_agreement.json")
