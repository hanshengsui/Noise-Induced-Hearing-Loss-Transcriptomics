# A4/C3 part 2 + C5 leading genes: re-run the primary pseudobulk limma model on the 13
# eligible cohort x class units, then screen the 58-gene marker panel for noise response.
suppressPackageStartupMessages({library(limma); library(edgeR); library(Matrix); library(data.table)})
# Run from the repository root after the main pipeline (see README_run_order.txt).
W <- Sys.getenv("SC_W", normalizePath("work", mustWork = FALSE))
set.seed(20261029)
LEG <- Sys.getenv("NIHL_ANALYSIS_ROOT", file.path(W, "stage1"))
pb <- fread(file.path(LEG, "source_data/GSE168041_celltype/mouse_celltype_pseudobulk_counts.csv.gz"))
gene_id <- pb$gene_id; gene_symbol <- pb$gene_symbol
P <- as.matrix(pb[, -(1:2), with = FALSE]); storage.mode(P) <- "numeric"; rownames(P) <- gene_id
cc <- fread(file.path(LEG, "source_data/GSE168041_celltype/cell_counts_and_library_sizes.csv"))
meta <- fread(Sys.getenv("SC_METADATA", "config/samples/GSE168041_libraries.csv"))
mk <- fread(Sys.getenv("SC_MARKERS", "resources/annotations/cell_type_markers.csv"))
panel <- unique(mk$marker_gene)

# eligible units for the primary threshold (>=20 cells, >=5000 UMI, >=3 per condition)
units <- list()
for (coh in unique(meta$tissue_cohort)) for (ct in setdiff(unique(cc[tissue_cohort == coh, cell_type]), "unassigned")) {
  z <- merge(meta[tissue_cohort == coh, .(sample_id, condition)],
             cc[tissue_cohort == coh & cell_type == ct, .(sample_id, condition, n_cells, library_size)],
             by = c("sample_id", "condition"), all.x = TRUE)
  z[is.na(n_cells), n_cells := 0][is.na(library_size), library_size := 0]
  z <- z[n_cells >= 20 & library_size >= 5000]
  if (sum(z$condition == "naive") < 3 || sum(z$condition == "noise") < 3) next
  units[[length(units) + 1]] <- list(cohort = coh, cell_type = ct, samples = z)
}
cat("eligible units:", length(units), "\n")

fit_unit <- function(u) {
  z <- u$samples[order(condition, sample_id)]
  keys <- paste(z$sample_id, u$cell_type, sep = "__")
  stopifnot(all(keys %in% colnames(P)))
  counts <- P[, keys, drop = FALSE]; colnames(counts) <- z$sample_id
  condition <- factor(z$condition, levels = c("naive", "noise"))
  design <- model.matrix(~0 + condition); colnames(design) <- c("naive", "noise")
  C <- matrix(c(-1, 1), ncol = 1, dimnames = list(colnames(design), "noise_vs_naive"))
  keep <- filterByExpr(counts, design = design, min.count = 10, min.total.count = 15)
  cf <- counts[keep, , drop = FALSE]
  nf <- calcNormFactors(cf, method = "TMM")
  v <- voom(cf, design = design, lib.size = colSums(cf) * nf, normalize.method = "none", plot = FALSE)
  fit <- contrasts.fit(lmFit(v, design), C); fit <- eBayes(fit, robust = TRUE, trend = FALSE)
  tt <- topTable(fit, coef = 1, number = Inf, sort.by = "none")
  data.table(gene_id = rownames(cf), gene_symbol = gene_symbol[match(rownames(cf), gene_id)],
             tissue_cohort = u$cohort, cell_type = u$cell_type, contrast = "noise_vs_naive",
             logFC = tt$logFC, moderated_t = tt$t, PValue = tt$P.Value, FDR = tt$adj.P.Val,
             n_naive = sum(condition == "naive"), n_noise = sum(condition == "noise"))
}
all_de <- rbindlist(lapply(units, fit_unit))
fwrite(all_de, file.path(W, "sc_out/c3_all_units_DE_recomputed.csv.gz"))

# verify against the legacy per-unit tables
leg <- rbindlist(lapply(unique(paste(all_de$tissue_cohort, all_de$cell_type)), function(k) {
  f <- file.path(LEG, "results/GSE168041_celltype",
                 paste0(gsub("[^A-Za-z0-9]+", "_", gsub(" ", "__", k)), "__noise_vs_naive.csv.gz"))
  if (!file.exists(f)) return(NULL)
  d <- fread(f); d[, unit := k]; d }))
m <- merge(all_de, leg, by = c("gene_id", "tissue_cohort", "cell_type"),
           suffixes = c("_new", "_leg"))
cat(sprintf("legacy cross-check: n=%d genes x units, max|dt| = %.3e, max|dlogFC| = %.3e\n",
            nrow(m), max(abs(m$moderated_t_new - m$moderated_t_leg)),
            max(abs(m$logFC_new - m$logFC_leg))))

# ---- marker panel screen (pre-specified: FDR<0.10 and |log2FC|>0.5) ----
mkq <- all_de[gene_symbol %in% panel]
mkq[, responsive := FDR < 0.10 & abs(logFC) > 0.5]
mkq[, direction := ifelse(logFC > 0, "up", "down")]
fwrite(mkq, file.path(W, "sc_out/responsive_markers_by_unit.csv"))
cat("panel genes tested per unit:", mkq[, .N, by = .(tissue_cohort, cell_type)][, range(N)], "\n")
cat("panel gene x unit tests:", nrow(mkq), "\n")
cat("responsive marker x unit:", sum(mkq$responsive), "\n")
resp <- unique(mkq[responsive == TRUE, gene_symbol])
cat("distinct responsive markers:", length(resp), "of", length(panel), "\n")
print(mkq[responsive == TRUE][order(gene_symbol), .(gene_symbol, tissue_cohort, cell_type, logFC=round(logFC,3), FDR=signif(FDR,3))])

# ---- C5: INFL leading negative genes in the two immune units ----
hm <- strsplit(readLines(Sys.getenv("SC_HALLMARK", "resources/gene_sets/h.all.v2024.1.Hs.symbols.gmt"), warn = FALSE), "\t")
hm <- hm[lengths(hm) >= 3]
names(hm) <- vapply(hm, `[[`, character(1), 1)
infl <- unique(toupper(hm[["HALLMARK_INFLAMMATORY_RESPONSE"]][-c(1, 2)]))
lead <- list()
for (coh in c("lateral_wall_focused", "neuronal_focused")) {
  d <- all_de[tissue_cohort == coh & cell_type == "immune"]
  d[, key := toupper(gene_symbol)]
  d <- d[key %in% infl]
  d <- d[order(moderated_t)]
  lead[[coh]] <- head(d[, .(tissue_cohort, cell_type, gene_symbol, logFC, moderated_t, PValue, FDR)], 15)
}
lead <- rbindlist(lead)
fwrite(lead, file.path(W, "sc_out/immune_leading_genes.csv"))
print(lead[, .(tissue_cohort, gene_symbol, logFC=round(logFC,3), moderated_t=round(moderated_t,2), FDR=signif(FDR,3))])
cat("\nINFL set size:", length(infl), "; tested in LW immune:", all_de[tissue_cohort == "lateral_wall_focused" & cell_type == "immune" & toupper(gene_symbol) %in% infl, .N],
    "; in N immune:", all_de[tissue_cohort == "neuronal_focused" & cell_type == "immune" & toupper(gene_symbol) %in% infl, .N], "\n")
saveRDS(list(all_de = all_de, mkq = mkq, resp = resp), file.path(W, "sc_out/c3_c5.rds"))

# Stable-identity panel used by c4_reassign.py and c4_hybrid.py.
# Exclude both condition-responsive markers and markers overlapping tested sets.
ov <- fread(file.path(W, "sc_out/marker_hallmark_overlap.csv"))
stable <- setdiff(panel, union(resp, panel[toupper(panel) %in% ov[in_n_hallmark > 0, marker_gene_up]]))
writeLines(stable, file.path(W, "sc_out/stable_list.txt"))
