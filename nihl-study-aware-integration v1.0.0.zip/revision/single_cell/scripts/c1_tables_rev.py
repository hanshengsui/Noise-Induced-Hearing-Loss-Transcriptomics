import os
"""A4/C1 rev: assemble hair_cell_profiles.csv and refresh hair_cell_check.csv."""
import pandas as pd, numpy as np, json
W=os.environ.get("SC_W","work")
O=f"{W}/sc_out"
d = pd.read_pickle(f"{O}/obs_qc_genes.pkl")
meta = pd.read_csv(os.environ.get("SC_METADATA", "config/samples/GSE168041_libraries.csv"))
coh = meta.set_index("sample_id").tissue_cohort; cond = meta.set_index("sample_id").condition
G = ["Myo7a","Pou4f3","Slc26a5","Otof","Ocm"]

rows=[]
# (1) marginal detection per gene, post-QC
for g in G:
    rows.append(dict(measure="detection_rate_post_qc", stratum="all_cohorts", cell_class="",
                     metric=g, n_cells=int(len(d)), n_value=int(d["pos_"+g].sum()),
                     fraction=float(d["pos_"+g].mean()), note=""))
# (2) profiles
for name, m in [("ihc_like_Otof_Myo7a_Pou4f3", d.ihc_like),
                ("ohc_like_Slc26a5_Ocm_Myo7a", d.ohc_like),
                ("any_hc_marker_ge2", d.n_hc>=2),
                ("any_hc_marker_ge3", d.n_hc>=3),
                ("any_hc_marker_ge4", d.n_hc>=4)]:
    sub=d[m.values]
    rows.append(dict(measure="profile_count", stratum="all_cohorts", cell_class="", metric=name,
                     n_cells=int(len(d)), n_value=int(len(sub)), fraction=float(len(sub)/len(d)),
                     note=f"naive={int((sub.sample_id.map(cond)=='naive').sum())}, noise={int((sub.sample_id.map(cond)=='noise').sum())}"))
    for c in ["neuronal_focused","lateral_wall_focused"]:
        s2=sub[sub.tissue_cohort==c]
        rows.append(dict(measure="profile_count", stratum=c, cell_class="", metric=name,
                         n_cells=int(len(d[d.tissue_cohort==c])), n_value=int(len(s2)),
                         fraction=float(len(s2)/max(len(d[d.tissue_cohort==c]),1)), note=""))
# (3) annotation of each profile
for name, m in [("ihc_like_Otof_Myo7a_Pou4f3", d.ihc_like), ("any_hc_marker_ge3", d.n_hc>=3),
                ("any_hc_marker_ge4", d.n_hc>=4),
                ("leiden29_neuronal", (d.cohort=="neuronal_focused")&(d.leiden=="29"))]:
    for ct, n in d[m.values].cell_type.value_counts().items():
        rows.append(dict(measure="annotation_of_profile", stratum="all_cohorts", cell_class=ct,
                         metric=name, n_cells=int(m.sum()), n_value=int(n),
                         fraction=float(n/m.sum()), note=""))
# (4) Leiden occupancy
for name, m in [("ihc_like_Otof_Myo7a_Pou4f3", d.ihc_like), ("any_hc_marker_ge3", d.n_hc>=3)]:
    for (c,cl), n in d[m.values].groupby(["cohort","leiden"]).size().items():
        rows.append(dict(measure="leiden_occupancy", stratum=c, cell_class=str(cl), metric=name,
                         n_cells=int(m.sum()), n_value=int(n), fraction=float(n/m.sum()), note=""))
# (5) eligibility per definition
el = pd.read_csv(f"{O}/hair_cell_eligibility.csv")
for r in el.itertuples():
    rows.append(dict(measure="pseudobulk_eligibility", stratum="all_cohorts", cell_class="",
                     metric=r.definition, n_cells=r.n_cells, n_value=r.max_cells_per_library,
                     fraction=np.nan,
                     note=f"libraries>=20 cells {r.libraries_with_ge20}; eligible={r.eligible} (rule: >=3 naive and >=3 noise)"))
out = pd.DataFrame(rows)
out.to_csv(f"{O}/hair_cell_profiles.csv", index=False)
print(out.groupby("measure").size().to_string())
print("\nprofiles:\n", out[(out.measure=="profile_count")&(out.stratum=="all_cohorts")][["metric","n_value","fraction","note"]].to_string(index=False))
