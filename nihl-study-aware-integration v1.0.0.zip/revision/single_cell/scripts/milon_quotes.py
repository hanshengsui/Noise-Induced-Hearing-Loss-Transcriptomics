import os
import re, json
W=os.environ.get("SC_W","work")
t=open('articles/10.1016_j.celrep.2021.109758.txt',errors='replace').read()
Q=[("neuronal_focused","Cell dissociation of spiral ganglion neurons (METHOD DETAILS)",
    "the overlying bone and lateral wall were extracted leaving just the modiolus"),
   ("neuronal_focused","Cell dissociation of spiral ganglion neurons (METHOD DETAILS)",
    "with the spiral ganglion, the spiral limbus, inner sulcus, and portions of the organ of Corti and outer sulcus remaining"),
   ("lateral_wall_focused","Cell dissociation of the lateral wall (METHOD DETAILS)",
    "The lateral wall with attached stria vascularis was extracted from apex to base and separated from the modiolus and other cochlear tissue"),
   ("both","LIMITATIONS (Discussion)",
    "the single-cell analysis suffers from the disadvantage of dissociation, which may alter gene expression"),
   ("both","STAR Methods, SGN scRNA-seq dataset",
    "count matrices from all samples were merged into one matrix of 34,776 cells and 22,292 genes"),
]
out=[]
for cohort,loc,q in Q:
    i=t.find(q)
    assert i>=0, q
    out.append(dict(cohort=cohort, location=loc, quote=q, n_words=len(q.split()), char_offset=i,
                    verified_in_pmc_fulltext=True))
for o in out: print(o["n_words"], o["cohort"], "|", o["quote"][:95])
json.dump(out, open(f"{W}/sc_out/milon_quote_ledger.json","w"), indent=1)
