"""A4/C2 deliverable figures: per-cohort UMAP (9 classes + Unassigned) and marker dot plots."""
import os, numpy as np, pandas as pd, scipy.sparse as sp
W=os.environ.get("SC_W","work")
for cls in (sp.csr_array, sp.csc_array, sp.coo_array, sp.csr_matrix, sp.csc_matrix, sp.coo_matrix):
    if not hasattr(cls, "getnnz"):
        cls.getnnz = lambda self, axis=None: self._getnnz(axis=axis)
import scanpy as sc, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import to_hex

from palette import apply_figure_style
apply_figure_style(frame="open", sizes=(8, 7, 6))
sc.settings.verbosity = 0
SEED = 20261029
W = "work"; FIG = f"{W}/sc_out/figs"
os.makedirs(FIG, exist_ok=True)
mk = pd.read_csv(os.environ.get("SC_MARKERS", "resources/annotations/cell_type_markers.csv"))

CLASS_ORDER = ["spiral_ganglion_neuron","schwann_glial","fibrocyte","endothelial",
               "pericyte_smooth_muscle","immune","marginal_cell","intermediate_melanocyte",
               "basal_cell","unassigned"]
# CVD-safe qualitative palette (Okabe-Ito derived + greys for unassigned)
PAL = {"spiral_ganglion_neuron":"#0072B2","schwann_glial":"#56B4E9","fibrocyte":"#009E73",
       "endothelial":"#F0E442","pericyte_smooth_muscle":"#E69F00","immune":"#D55E00",
       "marginal_cell":"#CC79A7","intermediate_melanocyte":"#8B5E3C","basal_cell":"#A6761D",
       "unassigned":"#BBBBBB"}
LAB = {"spiral_ganglion_neuron":"Spiral ganglion neuron","schwann_glial":"Schwann/glial",
       "fibrocyte":"Fibrocyte","endothelial":"Endothelial","pericyte_smooth_muscle":"Pericyte/smooth muscle",
       "immune":"Immune","marginal_cell":"Marginal cell","intermediate_melanocyte":"Intermediate/melanocyte",
       "basal_cell":"Basal cell","unassigned":"Unassigned"}

def umap_panel(a, cohort_label, tag):
    emb = a.obsm["X_umap"]
    ct = a.obs.cell_type.astype(str).values
    present = [c for c in CLASS_ORDER if c in set(ct)]
    fig, ax = plt.subplots(figsize=(6.3, 4.6))
    for c in present:
        m = ct == c
        ax.scatter(emb[m,0], emb[m,1], s=0.7, lw=0, c=PAL[c], alpha=0.55 if c=="unassigned" else 0.7,
                   rasterized=True, zorder=1 if c=="unassigned" else 2)
    # direct labels at class centroids, with leader lines into whitespace
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_xlabel("UMAP 1"); ax.set_ylabel("UMAP 2")
    counts = {c:int((ct==c).sum()) for c in present}
    handles = [Line2D([0],[0], marker="o", ls="", ms=5, mfc=PAL[c], mec="none",
                      label=f"{LAB[c]} (n={counts[c]:,})") for c in present]
    ax.legend(handles=handles, loc="center left", bbox_to_anchor=(1.01, 0.5), frameon=False,
              fontsize=6.5, handletextpad=0.4, labelspacing=0.45, title=None)
    ax.set_title(f"{cohort_label} (n={a.n_obs:,} cells)", loc="left", fontsize=8)
    fig.savefig(f"{FIG}/umap_{tag}.pdf", bbox_inches="tight")
    fig.savefig(f"{FIG}/umap_{tag}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    return counts

counts_all = {}
for cohort, tag, lab in [("neuronal_focused","neuronal","Neuronal-cohort dissection"),
                         ("lateral_wall_focused","lateral_wall","Lateral-wall-cohort dissection")]:
    a = sc.read_h5ad(f"{W}/sc_out/ad_{tag}_umap.h5ad")
    counts_all[cohort] = umap_panel(a, lab, tag)

# combined two-panel UMAP figure
fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.6))
for ax, (cohort, tag, lab) in zip(axes, [("neuronal_focused","neuronal","Neuronal-cohort dissection"),
                                         ("lateral_wall_focused","lateral_wall","Lateral-wall-cohort dissection")]):
    a = sc.read_h5ad(f"{W}/sc_out/ad_{tag}_umap.h5ad")
    emb = a.obsm["X_umap"]; ct = a.obs.cell_type.astype(str).values
    for c in [x for x in CLASS_ORDER if x in set(ct)]:
        m = ct == c
        ax.scatter(emb[m,0], emb[m,1], s=0.5, lw=0, c=PAL[c],
                   alpha=0.5 if c=="unassigned" else 0.68, rasterized=True)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_xlabel("UMAP 1"); ax.set_ylabel("UMAP 2")
    ax.set_title(lab, loc="left", fontsize=8)
    for s in ax.spines.values(): s.set_visible(False)
handles = [Line2D([0],[0], marker="o", ls="", ms=5, mfc=PAL[c], mec="none", label=LAB[c])
           for c in CLASS_ORDER]
fig.legend(handles=handles, loc="lower center", ncol=5, frameon=False, fontsize=6.5,
           bbox_to_anchor=(0.5, -0.06), handletextpad=0.35, columnspacing=1.2)
fig.savefig(f"{FIG}/umap_both_cohorts.pdf", bbox_inches="tight")
fig.savefig(f"{FIG}/umap_both_cohorts.png", dpi=300, bbox_inches="tight")
plt.close(fig)
print({k:v for k,v in counts_all.items()})
