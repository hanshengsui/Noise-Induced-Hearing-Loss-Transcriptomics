"""A4/C2 (rev): Leiden clustering per cohort, label purity, ARI, purity<0.6 list.
Annotation is NOT changed; Leiden is only used to test whether the marker classes are
transcriptionally coherent inside each dissection cohort."""
import os, numpy as np, pandas as pd, scipy.sparse as sp
W=os.environ.get("SC_W","work")
for cls in (sp.csr_array, sp.csc_array, sp.coo_array, sp.csr_matrix, sp.csc_matrix, sp.coo_matrix):
    if not hasattr(cls, "getnnz"):
        cls.getnnz = lambda self, axis=None: self._getnnz(axis=axis)
import scanpy as sc, anndata as ad
from sklearn.metrics import adjusted_rand_score
sc.settings.verbosity = 0
SEED = 20261029; RES = 1.0
W = "work"; O = f"{W}/sc_out"
A = sc.read_h5ad(f"{O}/ad_qc.h5ad")
A.var_names_make_unique()
ihc = pd.read_pickle(f"{O}/obs_qc_genes.pkl").set_index("cell_key")
A.obs["key"] = A.obs_names
A.obs["ihc_like"] = ihc["ihc_like"].reindex(A.obs_names).values.astype(bool)
A.obs["ohc_like"] = ihc["ohc_like"].reindex(A.obs_names).values.astype(bool)
A.obs["n_hc"] = ihc["n_hc"].reindex(A.obs_names).values
print("IHC-like in object:", int(A.obs.ihc_like.sum()), "OHC-like:", int(A.obs.ohc_like.sum()))

rows, purity_rows, ihc_rows = [], [], []
lean = {}
for cohort, tag in [("neuronal_focused","neuronal"), ("lateral_wall_focused","lateral_wall")]:
    cached=f"{O}/ad_{tag}_umap.h5ad"
    if os.path.exists(cached):
        # c2_umap uses the same HVG/PCA/neighbour/UMAP settings as this step.
        a=sc.read_h5ad(cached)
        expected=A.obs_names[A.obs.tissue_cohort == cohort]
        assert a.obs_names.equals(expected), "Cached cells differ from the QC input"
        assert a.uns["neighbors"]["params"]["n_neighbors"] == 15
        assert a.uns["neighbors"]["params"]["n_pcs"] == 30
        assert a.uns["neighbors"]["params"]["random_state"] == SEED
        for field in ["ihc_like","ohc_like","n_hc"]:
            a.obs[field]=ihc[field].reindex(a.obs_names).values
    else:
        a = A[A.obs.tissue_cohort == cohort].copy()
        sc.pp.highly_variable_genes(a, n_top_genes=2000, flavor="seurat_v3", batch_key="sample_id")
        sc.pp.normalize_total(a, target_sum=1e4); sc.pp.log1p(a)
        a.raw = a
        sc.pp.scale(a, max_value=10)
        sc.tl.pca(a, n_comps=30, random_state=SEED)
        sc.pp.neighbors(a, n_neighbors=15, n_pcs=30, random_state=SEED)
        sc.tl.umap(a, random_state=SEED)
    sc.tl.leiden(a, resolution=RES, random_state=SEED, key_added="leiden", flavor="igraph", n_iterations=2,
                 directed=False)
    ct = a.obs.cell_type.astype(str)
    ari = adjusted_rand_score(a.obs.leiden.astype(str), ct)
    rows.append(dict(cohort=cohort, n_cells=a.n_obs, n_leiden=a.obs.leiden.nunique(),
                     n_classes=ct.nunique(), ari=ari))
    for cl in sorted(a.obs.leiden.unique(), key=int):
        m = (a.obs.leiden == cl).values
        comp = ct[m].value_counts()
        purity_rows.append(dict(cohort=cohort, leiden_cluster=cl, n_cells=int(m.sum()),
                                modal_class=comp.index[0],
                                modal_share=float(comp.iloc[0]/m.sum()),
                                second_class=comp.index[1] if len(comp) > 1 else "",
                                second_share=float(comp.iloc[1]/m.sum()) if len(comp) > 1 else 0.0,
                                composition=";".join(f"{k}:{v}" for k, v in comp.items())))
    z = a.obs[["sample_id","condition","cell_type","leiden","ihc_like","ohc_like","n_hc"]].copy()
    z["cohort"] = cohort
    z.to_pickle(f"{O}/leiden_{tag}.pkl")
    lean[tag] = dict(umap=a.obsm["X_umap"].astype(np.float32),
                     obs=z.assign(cell=a.obs_names).reset_index(drop=True))
    print(cohort, "leiden", a.obs.leiden.nunique(), "ARI", round(ari,4), flush=True)

pd.DataFrame(rows).to_csv(f"{O}/leiden_summary.csv", index=False)
pur = pd.DataFrame(purity_rows)
pur.to_csv(f"{O}/leiden_cluster_purity.csv", index=False)
pur[pur.modal_share < 0.60].to_csv(f"{O}/leiden_purity_below_0.60.csv", index=False)
import pickle; pickle.dump(lean, open(f"{O}/leiden_lean.pkl","wb"))
print(pd.DataFrame(rows).to_string(index=False))
print("\nclusters with purity < 0.60:", len(pur[pur.modal_share<0.60]), "of", len(pur))
print(pur[pur.modal_share<0.60][["cohort","leiden_cluster","n_cells","modal_class","modal_share"]].to_string(index=False))
