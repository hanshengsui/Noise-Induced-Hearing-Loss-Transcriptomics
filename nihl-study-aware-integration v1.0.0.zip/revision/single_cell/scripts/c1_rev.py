import os
"""A4/C1 revision: IHC-like / OHC-like profiles, per-library counts, annotation, eligibility,
and whether hair-cell-like cells form their own Leiden cluster."""
import numpy as np, pandas as pd, pickle, json
W=os.environ.get("SC_W","work")
pd.set_option("display.width", 220)
O = f"{W}/sc_out"
d = pd.read_pickle(f"{O}/obs_qc_genes.pkl")
lean = pickle.load(open(f"{O}/leiden_lean.pkl","rb"))
for tag,z in lean.items():
    z["obs"]["cell_key"] = z["obs"]["cell"]
lk = pd.concat([z["obs"] for z in lean.values()], ignore_index=True)[["cell_key","leiden","cohort"]]
d = d.drop(columns=["leiden","cohort"],errors="ignore").merge(lk, on="cell_key", how="left", validate="one_to_one")
d.to_pickle(f"{O}/obs_qc_genes.pkl")
meta = pd.read_csv(os.environ.get("SC_METADATA", "config/samples/GSE168041_libraries.csv"))

out = {}
# (a) IHC-like and OHC-like
out["n_ihc_like"] = int(d.ihc_like.sum()); out["n_ohc_like"] = int(d.ohc_like.sum())
print("IHC-like", out["n_ihc_like"], " OHC-like", out["n_ohc_like"])
print("\nIHC-like by cohort:", d[d.ihc_like].groupby("tissue_cohort").size().to_dict())
print("OHC-like by cohort:", d[d.ohc_like].groupby("tissue_cohort").size().to_dict())
print("\nIHC-like original annotation:", d[d.ihc_like].cell_type.value_counts().to_dict())
print("IHC-like n_hc distribution:", d[d.ihc_like].n_hc.value_counts().sort_index().to_dict())
print("IHC-like median UMI:", d[d.ihc_like].n_count.median(), " outside:", d[~d.ihc_like].n_count.median())

# (b) n_hc>=3, >=4 by library x condition
rows=[]
for k in [3,4]:
    s = d[d.n_hc>=k]
    for sid, ct_g in meta.assign().groupby("sample_id"):
        pass
    w = (s.groupby(["sample_id","condition","tissue_cohort"]).size()
           .rename("n").reset_index())
    w["threshold"]=k
    # include libraries with zero
    full = meta[["sample_id","tissue_cohort","condition"]].merge(w, on=["sample_id","tissue_cohort","condition"], how="left")
    full["n"] = full.n.fillna(0).astype(int); full["threshold"]=k
    rows.append(full)
b = pd.concat(rows, ignore_index=True)
b.to_csv(f"{O}/hair_cell_threshold_by_library.csv", index=False)
print("\nthreshold x library (n_hc>=3):")
print(b[b.threshold==3][["sample_id","tissue_cohort","condition","n"]].to_string(index=False))

# (c) annotation of each threshold group
ann = {}
for k in [2,3,4]:
    ann[k] = d[d.n_hc>=k].cell_type.value_counts().to_dict()
out["annotation_by_threshold"] = {str(k):v for k,v in ann.items()}
print("\nannotation by threshold:", ann)

# (d) eligibility if treated as its own class: >=20 cells AND >=5000 UMI per library
elig = {}
for k in [2,3,4]:
    for label, mask in [("ihc_like", d.ihc_like), ("n_hc_ge"+str(k), d.n_hc>=k)]:
        s = d[mask]
        ok = s[s.n_count>=5000]
        per = ok.groupby(["sample_id","condition"]).size()
        libs = meta.set_index("sample_id").condition
        n_n = sum(1 for s_,c in per.items() if libs.get(s_[0]) == "naive")
        n_no = sum(1 for s_,c in per.items() if libs.get(s_[0]) == "noise")
        # rule: >=20 cells in a library AND >=5000 UMI. Count libraries that reach 20 cells with >=5000 UMI
        ok20 = s[s.n_count>=5000].groupby("sample_id").size()
        na = int(sum(1 for sid,v_ in ok20.items() if v_>=20 and libs.get(sid)=="naive"))
        no = int(sum(1 for sid,v_ in ok20.items() if v_>=20 and libs.get(sid)=="noise"))
        elig[label] = dict(n_cells=int(len(s)), n_cells_umi5000=int(len(ok)),
                           libraries_with_at_least_20=dict(naive=na, noise=no),
                           eligible=bool(na>=3 and no>=3))
out["eligibility"] = elig
print("\neligibility:", json.dumps(elig, indent=1))

# (e) Leiden cluster membership
for name, mask in [("ihc_like", d.ihc_like), ("n_hc>=3", d.n_hc>=3), ("n_hc>=4", d.n_hc>=4)]:
    s = d[mask & d.leiden.notna()]
    if not len(s): continue
    tab = s.groupby(["cohort","leiden"]).size().sort_values(ascending=False)
    n_clu = s.groupby("cohort").leiden.nunique()
    mx = s.groupby("cohort").leiden.apply(lambda x: x.value_counts().iloc[0]/len(x))
    print(f"\n{name}: n={len(s)} clusters occupied={n_clu.to_dict()} max single-cluster share={mx.round(3).to_dict()}")
    print(tab.head(6).to_dict())
    out[f"leiden_{name}"] = {"n": int(len(s)), "clusters_occupied": {k:int(v) for k,v in n_clu.items()},
                             "max_cluster_share": {k:float(v) for k,v in mx.items()}}
json.dump(out, open(f"{O}/hair_cell_revision.json","w"), indent=1, default=str)
