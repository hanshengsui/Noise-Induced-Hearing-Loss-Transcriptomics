import os
"""Control: is the hc co-expression excess panel-specific? Use 5 rate-matched control genes."""
import pickle, numpy as np, pandas as pd, json
W=os.environ.get("SC_W","work")
libs=pickle.load(open(f"{W}/sc_out/libs.pkl","rb")); obs=pickle.load(open(f"{W}/sc_out/obs_raw.pkl","rb"))
Mats,Feats,meta=libs["Mats"],libs["Feats"],libs["meta"]
HC=["Myo7a","Pou4f3","Slc26a5","Otof","Ocm"]
# Build post-QC detection matrix for a candidate pool of genes with similar marginal rates
rates={}; keep_by=[]
for i,sm in meta.iterrows():
    M,feat=Mats[i],Feats[i]; keep=obs.loc[obs.sample_id==sm.sample_id,"qc_pass"].values; keep_by.append((i,keep))
    tot=M[:,keep].sum(axis=0).A1 if hasattr(M[:,keep].sum(axis=0),'A1') else np.asarray(M[:,keep].sum(axis=0)).ravel()
    pos=np.asarray((M[:,keep]>0).sum(axis=1)).ravel(); npos=max(keep.sum(),1)
    for k,s in enumerate(feat): rates.setdefault(s,[]).append(pos[k]/npos)
r=pd.Series({k:np.mean(v) for k,v in rates.items()})
targets={g:r.get(g,np.nan) for g in HC}
print("target rates:", {k:round(v,5) for k,v in targets.items()})
# candidate control genes: individually rare (rate 1e-3..5e-3), not hair-cell / not cochlear-structural
excl=set(HC)|{"Slc26a4","Gjb2","Gjb6","Kcne1","Kcnq1","Dct","Mitf","Tyr","Pmel","Col1a1","Col1a2","Ptprc","Pecam1"}
cand=r[(r>2e-3)&(r<9e-3)&(~r.index.isin(excl))].sort_values(ascending=False)
print("n candidates", len(cand))
# pick 5 by deterministic nearest-rate matching to targets (seeded tie-break by seed 20261029)
rng=np.random.default_rng(20261029)
chosen=[]
for g,t in targets.items():
    pool=cand[~cand.index.isin(chosen)]
    if not len(pool): break
    d=(pool-t).abs()
    best=pool[d==d.min()].index.tolist()
    chosen.append(sorted(best)[0])
print("control genes:", chosen, [round(r[g],5) for g in chosen])
def coexp(genes):
    out=[]
    for i,sm in meta.iterrows():
        M,feat=Mats[i],Feats[i]; keep=dict(keep_by)[i]
        gi=[np.where(feat==g)[0][0] for g in genes if (feat==g).any()]
        if len(gi)<2: continue
        pos=(M[gi,:][:,keep]>0).toarray(); out.append((pos.sum(axis=0)>=2).sum())
    return int(np.sum(out))
print("observed cells with >=2 HC markers:", coexp(HC))
print("observed cells with >=2 control markers:", coexp(chosen))
res={"hc_ge2":coexp(HC),"control_genes":chosen,"control_ge2":coexp(chosen),
     "control_rates":[float(r[g]) for g in chosen]}
json.dump(res,open(f"{W}/sc_out/hair_cell_control.json","w"),indent=1)
