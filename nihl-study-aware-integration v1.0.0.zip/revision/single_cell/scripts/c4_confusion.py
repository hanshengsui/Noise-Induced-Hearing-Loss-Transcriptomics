"""A4/C4 stage 2: confusion matrix, per-class Jaccard, and stability of the reassignment."""
import json, numpy as np, pandas as pd
import os
W=os.environ.get("SC_W","work")
W=os.environ.get("SC_W","work")
d=pd.read_pickle(f"{W}/sc_out/obs_stable.pkl")
meta=json.load(open(f"{W}/sc_out/stable_panel_meta.json"))
ORDER=["spiral_ganglion_neuron","schwann_glial","fibrocyte","endothelial","pericyte_smooth_muscle",
       "immune","marginal_cell","intermediate_melanocyte","basal_cell","unassigned"]
cm=pd.crosstab(pd.Categorical(d.cell_type,categories=ORDER,ordered=True),
               pd.Categorical(d.stable_cell_type,categories=ORDER,ordered=True),
               dropna=False)
cm.index.name="original"; cm.columns.name="stable_panel"; cm.to_csv(f"{W}/sc_out/stable_marker_confusion.csv")

rows=[]
for c in ORDER:
    A=set(np.where(d.cell_type==c)[0]); B=set(np.where(d.stable_cell_type==c)[0])
    inter=len(A&B); un=len(A|B)
    rows.append(dict(cell_type=c, n_original=len(A), n_stable=len(B), n_intersection=inter,
                     n_union=un, jaccard=inter/un if un else np.nan,
                     retained_fraction=inter/len(A) if A else np.nan,
                     verifiable= c in ["spiral_ganglion_neuron","schwann_glial","endothelial","immune"],
                     note=("fewer than 2 stable markers" if c in meta["unverifiable"] else "")))
jac=pd.DataFrame(rows)
jac.to_csv(f"{W}/sc_out/stable_marker_reassignment.csv", index=False)
pd.set_option("display.width",250)
print(jac.to_string(index=False))
print("\noverall concordance (all cells):", float((d.cell_type==d.stable_cell_type).mean()))
print("concordance on cells whose original class is verifiable:",
      float((d.loc[d.cell_type.isin(["spiral_ganglion_neuron","schwann_glial","endothelial","immune"]),
                   "cell_type"]==d.loc[d.cell_type.isin(["spiral_ganglion_neuron","schwann_glial","endothelial","immune"]),
                   "stable_cell_type"]).mean()))
print("\nconfusion (counts):"); print(cm.to_string())
print("\ncells moving TO unassigned:", int(((d.cell_type!="unassigned")&(d.stable_cell_type=="unassigned")).sum()))
print("cells moving BETWEEN assigned classes:", int(((d.cell_type!="unassigned")&(d.stable_cell_type!="unassigned")&(d.cell_type!=d.stable_cell_type)).sum()))
