"""A4/C2: per-cohort UMAP + marker dot plot (display only, no batch integration)."""
import os, numpy as np, pandas as pd, scipy.sparse as sp
W=os.environ.get("SC_W","work")
# --- compat shim: scipy >=1.14 sparse arrays lack getnnz(), used by scanpy's knn helper
for cls in (sp.csr_array, sp.csc_array, sp.coo_array, sp.csr_matrix, sp.csc_matrix, sp.coo_matrix):
    if not hasattr(cls, "getnnz"):
        cls.getnnz = lambda self, axis=None: self._getnnz(axis=axis)
import scanpy as sc
sc.settings.verbosity = 1
SEED = 20261029
W = "work"
A = sc.read_h5ad(f"{W}/sc_out/ad_qc.h5ad")
A.var_names_make_unique()
mk = pd.read_csv(os.environ.get("SC_MARKERS", "resources/annotations/cell_type_markers.csv"))
os.makedirs(f"{W}/sc_out/figs", exist_ok=True)

summary = []
for cohort, tag in [("neuronal_focused","neuronal"), ("lateral_wall_focused","lateral_wall")]:
    a = A[A.obs.tissue_cohort == cohort].copy()
    a.layers["counts"] = a.X.copy()
    sc.pp.highly_variable_genes(a, n_top_genes=2000, flavor="seurat_v3", batch_key="sample_id")
    sc.pp.normalize_total(a, target_sum=1e4)
    sc.pp.log1p(a)
    a.raw = a
    sc.pp.scale(a, max_value=10)
    sc.tl.pca(a, n_comps=30, random_state=SEED)
    sc.pp.neighbors(a, n_neighbors=15, n_pcs=30, random_state=SEED)
    sc.tl.umap(a, random_state=SEED)
    a.write(f"{W}/sc_out/ad_{tag}_umap.h5ad")
    summary.append(dict(cohort=cohort, n_cells=a.n_obs,
                        n_hvg=int(a.var.highly_variable.sum()),
                        pca_var_pc1=float(a.uns["pca"]["variance_ratio"][0]),
                        pca_var_30=float(a.uns["pca"]["variance_ratio"].sum())))
    print(cohort, a.n_obs, "HVG", int(a.var.highly_variable.sum()), flush=True)
print(pd.DataFrame(summary).to_string(index=False))
pd.DataFrame(summary).to_csv(f"{W}/sc_out/umap_run_summary.csv", index=False)
