"""A4 rev: (a) concordance figure with not-assessed rows greyed; (b) composition faceted by cohort."""
import os, sys, numpy as np, pandas as pd, matplotlib
W=os.environ.get("SC_W","work")
matplotlib.use("Agg"); sys.path.insert(0,"work/sc_scripts")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from palette import PAL, LAB
from palette import apply_figure_style
apply_figure_style(frame="open", sizes=(8,7,6))
O=f"{W}/sc_out"; FIG=f"{O}/figs"
PROG=["HALLMARK_TNFA_SIGNALING_VIA_NFKB","HALLMARK_INFLAMMATORY_RESPONSE",
      "HALLMARK_UNFOLDED_PROTEIN_RESPONSE","HALLMARK_OXIDATIVE_PHOSPHORYLATION",
      "HALLMARK_E2F_TARGETS","HALLMARK_INTERFERON_GAMMA_RESPONSE",
      "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION"]
SHORT=["TNFα/NFκB","Inflammation","UPR","OxPhos","E2F","IFNγ","EMT"]
VER={"spiral_ganglion_neuron","schwann_glial","endothelial","immune"}

cmp=pd.read_csv(f"{O}/stable_marker_direction_comparison.csv")
cmp["assessed"]=cmp.cell_type.isin(VER)
units=sorted(cmp.cell_unit.unique(), key=lambda u:(u.startswith("neuronal"), u))
SHORTU={"lateral_wall_focused":"LW","neuronal_focused":"N"}
M=np.full((len(units),len(PROG)),np.nan)
for i,u in enumerate(units):
    for j,p in enumerate(PROG):
        r=cmp[(cmp.cell_unit==u)&(cmp.pathway==p)]
        if len(r): M[i,j]=1.0 if r.concordant.iloc[0] else 0.0
assessed=[bool(cmp[cmp.cell_unit==u].assessed.iloc[0]) for u in units]
n_ev=int(np.nansum(M[[i for i,a in enumerate(assessed) if a]]))
n_ev_tot=len(PROG)*sum(assessed)

fig,ax=plt.subplots(figsize=(4.9,4.6))
cols=np.array([["#009E73" if M[i,j]==1 else "#D55E00" for j in range(len(PROG))] for i in range(len(units))],dtype=object)
for i in range(len(units)):
    for j in range(len(PROG)):
        if not assessed[i]: cols[i,j]="#CFCFCF"
    if not assessed[i]:
        ax.add_patch(plt.Rectangle((-0.5,i-0.5),len(PROG),1,facecolor="#CFCFCF",edgecolor="none",zorder=0))
for i in range(len(units)):
    if not assessed[i]: continue
    for j in range(len(PROG)):
        ax.add_patch(plt.Rectangle((j-0.5,i-0.5),1,1,facecolor=cols[i,j],edgecolor="white",lw=0.4,zorder=1))
        if M[i,j]==0: ax.text(j,i,"×",ha="center",va="center",fontsize=7.5,color="white",zorder=2)
ax.set_xlim(-0.5,len(PROG)-0.5); ax.set_ylim(len(units)-0.5,-0.5)
ax.set_xticks(range(len(PROG))); ax.set_xticklabels(SHORT,rotation=45,ha="right",fontsize=6.4)
ax.set_yticks(range(len(units)))
ax.set_yticklabels([f"{SHORTU[u.split('__')[0]]} {LAB[u.split('__')[1]].lower()}" for u in units],fontsize=6.2)
for i,u in enumerate(units):
    if not assessed[i]:
        ax.text(len(PROG)-0.42,i,"not assessed",va="center",ha="right",fontsize=5.4,color="0.35",style="italic")
for s in ax.spines.values(): s.set_visible(False)
ax.set_title(f"{n_ev}/{n_ev_tot} evaluable directions",loc="left",fontsize=8)
ax.legend(handles=[Patch(facecolor="#009E73",label="direction concordant"),
                   Patch(facecolor="#D55E00",label="direction discordant"),
                   Patch(facecolor="#CFCFCF",label="not assessed (<2 stable markers)")],
          loc="upper center",bbox_to_anchor=(0.42,-0.30),frameon=False,fontsize=5.8,ncol=1,
          handlelength=1.0,handleheight=0.8)
fig.savefig(f"{FIG}/stable_direction_concordance.pdf",bbox_inches="tight")
fig.savefig(f"{FIG}/stable_direction_concordance.png",dpi=400,bbox_inches="tight")
plt.close(fig)
print("concordance figure:", n_ev, "/", n_ev_tot)

# ---- composition faceted by cohort ----
comp=pd.read_csv(f"{O}/composition_per_mouse.csv")
order=["immune","fibrocyte","endothelial","pericyte_smooth_muscle","schwann_glial","basal_cell",
       "marginal_cell","intermediate_melanocyte","spiral_ganglion_neuron"]
present=[c for c in order if c in set(comp.cell_class)]
fig,axes=plt.subplots(1,2,figsize=(10.4,3.9),sharey=True)
COL={"naive":"#56B4E9","noise":"#D55E00"}
for ax,coh,title in zip(axes,["neuronal_focused","lateral_wall_focused"],
                        ["Neuronal-cohort dissection","Lateral-wall-cohort dissection"]):
    z=comp[comp.cohort==coh]
    cs=[c for c in present if c in set(z.cell_class)]
    off={"naive":-0.17,"noise":0.17}
    for k,ct in enumerate(cs):
        s=z[z.cell_class==ct]
        for cond in ["naive","noise"]:
            v=s[s.condition==cond].frac.values*100
            jit=(np.arange(len(v))-(len(v)-1)/2)*0.045
            ax.scatter(k+off[cond]+jit, v, s=17, c=COL[cond], lw=0, alpha=0.95, zorder=3)
        m=s.groupby("condition").frac.median()*100
        ax.plot([k-0.27,k-0.07],[m["naive"]]*2,color=COL["naive"],lw=1.8,zorder=4)
        ax.plot([k+0.07,k+0.27],[m["noise"]]*2,color=COL["noise"],lw=1.8,zorder=4)
    ax.set_yscale("log"); ax.set_yticks([0.1,0.3,1,3,10,30,60])
    ax.set_yticklabels(["0.1","0.3","1","3","10","30","60"])
    ax.set_xticks(range(len(cs))); ax.set_xticklabels([LAB[c] for c in cs],rotation=30,ha="right",fontsize=6.0)
    ax.set_xlim(-0.6,len(cs)-0.4)
    ax.set_title(title,loc="left",fontsize=8)
    ax.set_ylabel("Share of assigned cells (%)" if coh=="neuronal_focused" else "")
    ax.margins(0.06)
    for sp in ["top","right"]: ax.spines[sp].set_visible(False)
axes[0].legend(handles=[Line2D([0],[0],marker="o",ls="",ms=4,mfc=COL["naive"],mec="none",label="Naive"),
                        Line2D([0],[0],marker="o",ls="",ms=4,mfc=COL["noise"],mec="none",label="Noise")],
               frameon=False,fontsize=6.4,loc="lower left")
fig.savefig(f"{FIG}/composition_by_cohort.pdf",bbox_inches="tight")
fig.savefig(f"{FIG}/composition_by_cohort.png",dpi=400,bbox_inches="tight")
plt.close(fig)
print("composition facet written; classes:", present)
