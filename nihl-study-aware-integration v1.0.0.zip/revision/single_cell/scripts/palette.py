import os
"""Shared class palette; verified for pairwise CIELAB separation."""
import numpy as np
W=os.environ.get("SC_W","work")
CLASS_ORDER = ["spiral_ganglion_neuron","schwann_glial","fibrocyte","endothelial",
               "pericyte_smooth_muscle","immune","marginal_cell","intermediate_melanocyte",
               "basal_cell","unassigned"]
PAL = {"spiral_ganglion_neuron":"#2255A4","schwann_glial":"#E8871E","fibrocyte":"#1B9E77",
       "endothelial":"#5BC0DE","pericyte_smooth_muscle":"#C0392B","immune":"#D01C8B",
       "marginal_cell":"#7B3294","intermediate_melanocyte":"#8C564B","basal_cell":"#C7A600",
       "unassigned":"#BDBDBD"}
LAB = {"spiral_ganglion_neuron":"Spiral ganglion neuron","schwann_glial":"Schwann/glial",
       "fibrocyte":"Fibrocyte","endothelial":"Endothelial","pericyte_smooth_muscle":"Pericyte/smooth muscle",
       "immune":"Immune","marginal_cell":"Marginal cell","intermediate_melanocyte":"Intermediate/melanocyte",
       "basal_cell":"Basal cell","unassigned":"Unassigned"}

def lab_dists():
    from matplotlib.colors import to_rgb
    def f(c):
        r,g,b=to_rgb(c)
        f_=lambda u: u/12.92 if u<=0.04045 else ((u+0.055)/1.055)**2.4
        r,g,b=f_(r),f_(g),f_(b)
        X=r*.4124+g*.3576+b*.1805; Y=r*.2126+g*.7152+b*.0722; Z=r*.0193+g*.1192+b*.9505
        X/=0.95047; Z/=1.08883
        g_=lambda t: t**(1/3) if t>0.008856 else 7.787*t+16/116
        return np.array([116*g_(Y)-16, 500*(g_(X)-g_(Y)), 200*(g_(Y)-g_(Z))])
    ks=[k for k in CLASS_ORDER if k!="unassigned"]
    worst=(1e9,None)
    for i,a in enumerate(ks):
        for b in ks[i+1:]:
            d=float(np.linalg.norm(f(PAL[a])-f(PAL[b])))
            if d<worst[0]: worst=(d,(a,b))
    return worst
if __name__=="__main__":
    d,p=lab_dists(); print(f"min pairwise dE76 = {d:.1f} between {p}")
    for i,a in enumerate(CLASS_ORDER[:-1]):
        for b in CLASS_ORDER[i+1:-1]:
            pass


def apply_figure_style(frame="open", sizes=(8,7,6)):
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size":sizes[0], "axes.titlesize":sizes[0],
        "axes.labelsize":sizes[1], "xtick.labelsize":sizes[2],
        "ytick.labelsize":sizes[2], "legend.fontsize":sizes[2],
        "pdf.fonttype":42, "ps.fonttype":42})
    if frame == "open":
        plt.rcParams.update({"axes.spines.top":False,"axes.spines.right":False})
