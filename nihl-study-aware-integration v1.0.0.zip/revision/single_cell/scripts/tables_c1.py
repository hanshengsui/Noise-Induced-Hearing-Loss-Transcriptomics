import os
"""Assemble sc_reproduction.csv and hair_cell_check.csv from the computed JSON/CSV."""
import json, numpy as np, pandas as pd
W=os.environ.get("SC_W","work")
pd.set_option("display.width",200)

rep = json.load(open(f"{W}/sc_out/repro_summary.json"))
agr = json.load(open(f"{W}/sc_out/repro_agreement.json"))
rows = [
 dict(item="cells_deposited_raw", manuscript_value=71743, reproduced_value=rep["cells_deposited"], abs_diff=abs(71743-rep["cells_deposited"]), status="match" if rep["cells_deposited"]==71743 else "mismatch"),
 dict(item="cells_passing_QC", manuscript_value=64208, reproduced_value=rep["cells_passing_QC"], abs_diff=abs(64208-rep["cells_passing_QC"]), status="match" if rep["cells_passing_QC"]==64208 else "mismatch"),
 dict(item="cells_assigned", manuscript_value=63280, reproduced_value=rep["cells_assigned"], abs_diff=abs(63280-rep["cells_assigned"]), status="match" if rep["cells_assigned"]==63280 else "mismatch"),
 dict(item="cells_unassigned", manuscript_value=928, reproduced_value=rep["cells_unassigned"], abs_diff=abs(928-rep["cells_unassigned"]), status="match" if rep["cells_unassigned"]==928 else "mismatch"),
 dict(item="cell_type_agreement_vs_legacy", manuscript_value=0.999, reproduced_value=round(agr["agreement"],6), abs_diff=None,
      status="match" if agr["agreement"]>=0.999 else "mismatch"),
]
rep_df = pd.DataFrame(rows)
rep_df["note"] = ["QC: total_counts>=1000 & 500<=n_genes<=7500 & pct_mt<=20, all 16 libraries",
                  "identical predicate to Script 03","top score>=0.05 & margin>=0.01 applied to QC-passing cells",
                  "64208 - 63280","per-cell comparison with cell_metadata_marker_guided.csv.gz (n=64208 pairs)"]
rep_df.to_csv(f"{W}/sc_out/sc_reproduction.csv", index=False)
print(rep_df[["item","manuscript_value","reproduced_value","status"]].to_string(index=False))

# hair cell check table
lib = pd.read_csv(f"{W}/sc_out/hair_cell_check_by_library.csv")
st = lib.groupby("stage", as_index=False).agg(n_cells=("n_cells","sum"), n_hc_like=("n_hc_like","sum"),
                                              n_marker_any=("marker_any_pos","sum"))
order = ["raw_all","post_qc","assigned"]
st["stage"] = pd.Categorical(st["stage"], order, ordered=True); st = st.sort_values("stage")
print("\n", st.to_string(index=False))
# per-cohort breakdown also written
coh = lib.groupby(["stage","tissue_cohort"], as_index=False).agg(n_cells=("n_cells","sum"), n_hc_like=("n_hc_like","sum"))
st.to_csv(f"{W}/sc_out/hair_cell_check_stage_totals.csv", index=False)
coh.to_csv(f"{W}/sc_out/hair_cell_check_by_cohort.csv", index=False)
print("\n", coh.to_string(index=False))
