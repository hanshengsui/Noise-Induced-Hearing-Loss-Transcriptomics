# A4/C5: cell-type composition per mouse, logit-proportion + limma (B3.6 fallback; speckle not
# available for this R build - confirmed by install attempt on 2026-10-29).
suppressPackageStartupMessages({library(limma); library(data.table)})
# Run from the repository root after the main pipeline (see README_run_order.txt).
W <- Sys.getenv("SC_W", normalizePath("work", mustWork = FALSE))
LEG <- Sys.getenv("NIHL_ANALYSIS_ROOT", file.path(W, "stage1")); OUT <- file.path(W, "sc_out")
cm <- fread(cmd = sprintf("gunzip -c '%s'", file.path(LEG, "source_data/GSE168041_celltype/cell_metadata_marker_guided.csv.gz")))
meta <- fread(Sys.getenv("SC_METADATA", "config/samples/GSE168041_libraries.csv"))
cm <- merge(cm, meta[, .(sample_id, tissue_cohort, condition)], by = c("sample_id", "tissue_cohort", "condition"))

comp <- cm[, .(n = .N), by = .(sample_id, tissue_cohort, condition, cell_type)]
tot  <- cm[, .(N = .N), by = .(sample_id)]                       # denominator = assigned+unassigned? use assigned
totA <- cm[cell_type != "unassigned", .(N_assigned = .N), by = .(sample_id)]
cat("denominator check: total cells", nrow(cm), " assigned", sum(cm$cell_type != "unassigned"), "\n")

res <- list(); raw <- list()
for (coh in unique(meta$tissue_cohort)) {
  keep_libs <- meta[tissue_cohort == coh, sample_id]
  for (ct in setdiff(unique(cm[tissue_cohort == coh, cell_type]), "unassigned")) {
    z <- merge(meta[tissue_cohort == coh, .(sample_id, condition)],
               comp[cell_type == ct, .(sample_id, n)], by = "sample_id", all.x = TRUE)
    z[is.na(n), n := 0]
    z <- merge(z, totA, by = "sample_id")
    z[, frac := n / N_assigned]
    z[, logit := qlogis((n + 0.5) / (N_assigned + 1))]
    z[, condition := factor(condition, levels = c("naive", "noise"))]
    fit <- eBayes(lmFit(z$logit, model.matrix(~0 + condition, z)))
    co <- makeContrasts(conditionnoise - conditionnaive, levels = colnames(fit$design))
    fit2 <- eBayes(contrasts.fit(fit, co))
    tt <- topTable(fit2, number = 1)
    res[[paste(coh, ct, sep = "__")]] <- data.table(
      cohort = coh, cell_class = ct, n_naive = sum(z$condition == "naive"),
      n_noise = sum(z$condition == "noise"),
      frac_naive_mean = mean(z$frac[z$condition == "naive"]),
      frac_noise_mean = mean(z$frac[z$condition == "noise"]),
      logit_diff = tt$logFC, moderated_t = tt$t, p_value = tt$P.Value)
    raw[[paste(coh, ct, sep = "__")]] <- z[, .(cohort = coh, cell_class = ct, sample_id, condition, n, N_assigned, frac, logit)]
  }
}
res <- rbindlist(res)
res[, fdr := p.adjust(p_value, "BH")]                     # family: all cohort x class tests
res[, fdr_within_cohort := p.adjust(p_value, "BH"), by = cohort]
res[, direction := ifelse(logit_diff > 0, "higher_in_noise", "lower_in_noise")]
setorder(res, cohort, p_value)
fwrite(res, file.path(OUT, "composition_limma_logit.csv"))
fwrite(rbindlist(raw), file.path(OUT, "composition_per_mouse.csv"))
print(res[, .(cohort, cell_class, n_naive, n_noise, frac_naive = round(frac_naive_mean, 4),
              frac_noise = round(frac_noise_mean, 4), logit_diff = round(logit_diff, 3),
              t = round(moderated_t, 2), fdr = signif(fdr, 3))], nrows = 100)

# Wilcoxon on per-mouse fractions, as a distribution-free check (same unit = mouse)
wil <- rbindlist(lapply(unique(res$cohort), function(coh) rbindlist(lapply(
  setdiff(unique(cm[tissue_cohort == coh, cell_type]), "unassigned"), function(ct) {
  z <- rbindlist(raw)[cohort == coh & cell_class == ct]
  w <- wilcox.test(frac ~ condition, data = z, exact = FALSE)
  data.table(cohort = coh, cell_class = ct, wilcox_p = w$p.value,
             median_naive = median(z$frac[z$condition == "naive"]),
             median_noise = median(z$frac[z$condition == "noise"]))
}))))
wil[, wilcox_fdr := p.adjust(wilcox_p, "BH")]
fwrite(wil, file.path(OUT, "composition_wilcoxon.csv"))
cat("\nWilcoxon:\n"); print(wil[order(wilcox_p)])
