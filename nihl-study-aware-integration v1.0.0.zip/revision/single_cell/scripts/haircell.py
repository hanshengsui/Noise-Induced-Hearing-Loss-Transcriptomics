import os
"""A4/C1: hair-cell marker co-expression at raw / post-QC / assigned stages."""
import pickle, json, numpy as np, pandas as pd
W=os.environ.get("SC_W","work")
libs = pickle.load(open(f"{W}/sc_out/libs.pkl","rb"))
obs = pickle.load(open(f"{W}/sc_out/obs_raw.pkl","rb"))
Mats, Feats, Bcs, meta = libs["Mats"], libs["Feats"], libs["Bcs"], libs["meta"]
HC = ["Myo7a","Pou4f3","Slc26a5","Otof","Ocm"]
present_all = {g: [g in set(f) for f in Feats] for g in HC}
print("gene presence per library:", {g: sum(v) for g,v in present_all.items()}, "of 16")

def counts_for_mask(mask_by_lib):
    rows=[]
    for i, sm in meta.iterrows():
        M, feat = Mats[i], Feats[i]
        gi = {g: (np.where(feat==g)[0][0] if (feat==g).any() else None) for g in HC}
        avail = [g for g in HC if gi[g] is not None]
        mask = mask_by_lib[i]
        sub = M[[gi[g] for g in avail], :][:, mask]
        npos = np.asarray((sub > 0).sum(axis=0)).ravel()
        hc_like = npos >= 2
        rows.append(dict(sample_id=sm.sample_id, tissue_cohort=sm.tissue_cohort,
                         condition=sm.condition, stage=mask_by_lib["stage"],
                         n_cells=int(mask.sum()), n_hc_like=int(hc_like.sum()),
                         n_marker_genes_present=len(avail),
                         marker_any_pos=int((npos>=1).sum())))
    return rows

# stage 1: all deposited
allm = {i: np.ones(Mats[i].shape[1], bool) for i in range(len(meta))}; allm["stage"]="raw_all"
# stage 2: QC pass
qcm = {}
for i, sm in meta.iterrows():
    qcm[i] = (obs.loc[obs.sample_id==sm.sample_id,"qc_pass"].values)
qcm["stage"]="post_qc"
# stage 3: assigned (non-unassigned) cells
asm = {}
for i, sm in meta.iterrows():
    d = obs[obs.sample_id==sm.sample_id]
    asm[i] = (d.qc_pass & (d.cell_type!="unassigned")).values
asm["stage"]="assigned"
# stage 4: cells assigned to non-hair-cell classes and kept in eligible pseudobulk is a subset of 3.

rows = counts_for_mask(allm) + counts_for_mask(qcm) + counts_for_mask(asm)
hc = pd.DataFrame(rows)
hc.to_csv(f"{W}/sc_out/hair_cell_check_by_library.csv", index=False)
agg = hc.groupby("stage")[["n_cells","n_hc_like","marker_any_pos"]].sum()
print(agg.to_string())
agg2 = hc.groupby(["stage","tissue_cohort"])[["n_cells","n_hc_like"]].sum()
print(agg2.to_string())

# where do hc_like cells sit in the annotation, and which genes are positive
det = []
for i, sm in meta.iterrows():
    M, feat = Mats[i], Feats[i]
    gi = {g: (np.where(feat==g)[0][0] if (feat==g).any() else None) for g in HC}
    avail=[g for g in HC if gi[g] is not None]
    mask = qcm[i]
    sub = M[[gi[g] for g in avail], :][:, mask]
    npos = np.asarray((sub>0).sum(axis=0)).ravel()
    hl = npos >= 2
    if hl.sum()==0: continue
    d = obs[obs.sample_id==sm.sample_id][mask].iloc[np.where(hl)[0]]
    for _,r in d.iterrows():
        det.append(dict(sample_id=sm.sample_id, tissue_cohort=sm.tissue_cohort,
                        condition=sm.condition, barcode=r.barcode,
                        n_hc_markers=int(npos[np.where(hl)[0][list(d.index).index(r.name)]]) if False else None,
                        cell_type=r.cell_type, top=r.top_marker_score))
detdf = pd.DataFrame(det)
if len(detdf):
    detdf = detdf.drop(columns=["n_hc_markers"])
    print("\nannotation of hc_like cells:")
    print(pd.crosstab(detdf.tissue_cohort, detdf.cell_type))
    detdf.to_csv(f"{W}/sc_out/hair_cell_candidates.csv", index=False)

# per-gene detection rates, all stages, to show absence is not a threshold artefact
grows=[]
for i, sm in meta.iterrows():
    M, feat = Mats[i], Feats[i]
    for g in HC:
        if (feat==g).any():
            gi = np.where(feat==g)[0][0]
            v = M[gi,:]
            grows.append(dict(sample_id=sm.sample_id, tissue_cohort=sm.tissue_cohort,
                              condition=sm.condition, gene=g,
                              n_raw=int(v.shape[1]), n_raw_pos=int((v>0).sum()),
                              n_qc=int(qcm[i].sum()), n_qc_pos=int((v[:, qcm[i]]>0).sum())))
gdf = pd.DataFrame(grows)
gdf.to_csv(f"{W}/sc_out/hair_cell_gene_detection.csv", index=False)
print("\nper-gene detection, summed over libraries:")
print(gdf.groupby(["gene","tissue_cohort"])[["n_raw_pos","n_qc_pos"]].sum().to_string())
