"""Load GSE168041 raw matrices, reproduce QC + marker-guided annotation (script 03 rules)."""
import gzip, os, sys
import numpy as np, pandas as pd, scipy.io, scipy.sparse as sp

BASE = os.environ.get("NIHL_GSE168041_MATRIX_DIR", "data/raw/GSE168041/extracted")
META = os.environ.get("NIHL_GSE168041_METADATA", "config/samples/GSE168041_libraries.csv")
MARK = os.environ.get("NIHL_CELL_TYPE_MARKERS", "resources/annotations/cell_type_markers.csv")

meta = pd.read_csv(META)
markers = pd.read_csv(MARK)

def load_lib(label):
    with gzip.open(os.path.join(BASE, label + "_matrix.mtx.gz"), "rb") as f:
        M = scipy.io.mmread(f).tocsr()
    feat = pd.read_csv(os.path.join(BASE, label + "_genes.tsv.gz"), sep="\t", header=None,
                       names=["gene_id", "gene_symbol"], dtype=str)
    with gzip.open(os.path.join(BASE, label + "_barcodes.tsv.gz"), "rt") as f:
        bc = [l.strip() for l in f if l.strip()]
    assert M.shape == (len(feat), len(bc)), (M.shape, len(feat), len(bc))
    return M.astype(np.int32), feat, np.array(bc)

def qc_pass(M, feat):
    n_count = np.asarray(M.sum(axis=0)).ravel()
    n_feature = np.diff(M.tocsc().indptr)  # one count per cell (matrix columns)
    mt = feat["gene_symbol"].str.match(r"^mt-", case=False).values
    percent_mito = np.asarray(M[mt, :].sum(axis=0)).ravel() / np.maximum(n_count, 1) * 100
    keep = (n_count >= 1000) & (n_feature >= 500) & (n_feature <= 7500) & (percent_mito <= 20)
    return dict(n_count=n_count, n_feature=n_feature, percent_mito=percent_mito, keep=keep)

def score_pass(M, feat, cohort, keep):
    cm = markers[markers["cohort_scope"].isin(["both", cohort])]
    genes = list(dict.fromkeys(cm["marker_gene"]))
    idx = np.array([feat.index[feat["gene_symbol"] == g][0] if (feat["gene_symbol"] == g).any() else -1
                    for g in genes])
    present = idx >= 0
    genes = [g for g, p in zip(genes, present) if p]; idx = idx[present]
    sub = M[idx[:, None], np.where(keep)[0][None, :]]
    lib = np.asarray(M.sum(axis=0)).ravel()[keep]
    sub = sub.astype(np.float64).tocsr()
    sub = sp.diags(1e4 / np.maximum(lib, 1)) @ sub.T   # cells x genes
    sub = sp.csr_matrix(sub); sub.data = np.log1p(sub.data)
    types = list(dict.fromkeys(cm["cell_type"]))
    score = np.zeros((sub.shape[0], len(types)))
    for j, ct in enumerate(types):
        g = cm.loc[cm["cell_type"] == ct, "marker_gene"]
        ci = [genes.index(x) for x in g if x in genes]
        if ci:
            score[:, j] = np.asarray(sub[:, ci].mean(axis=1)).ravel()
    top_i = score.argmax(axis=1)
    top = score[np.arange(score.shape[0]), top_i]
    srt = np.sort(score, axis=1)
    second = srt[:, -2] if score.shape[1] > 1 else np.zeros(score.shape[0])
    margin = top - second
    assigned = np.array(types, dtype=object)[top_i]
    assigned[(top < 0.05) | (margin < 0.01)] = "unassigned"
    return assigned, top, margin, genes, types
