"""A4 step 0: load GSE168041, reproduce QC (71,743 -> 64,208) and marker-guided annotation (63,280)."""
import gzip, os, sys, json, time
W=os.environ.get("SC_W","work")
import numpy as np, pandas as pd, scipy.io, scipy.sparse as sp

os.environ.setdefault("NUMBA_CACHE_DIR", "/tmp/nbcache")
# Repository-layout defaults (same files that scripts/00_download.R and
# scripts/00_setup.R produce): matrices under data/raw/GSE168041/extracted,
# library metadata in config/samples/, marker panel in resources/annotations/.
BASE = os.environ.get("SC_MATRIX_DIR", "data/raw/GSE168041/extracted")
META = os.environ.get("SC_METADATA", "config/samples/GSE168041_libraries.csv")
MARK = os.environ.get("SC_MARKERS", "resources/annotations/cell_type_markers.csv")
OUT = os.environ.get("SC_OUT", f"{W}/sc_out")
os.makedirs(OUT, exist_ok=True)

meta = pd.read_csv(META)
markers = pd.read_csv(MARK)

def load_lib(label):
    with gzip.open(os.path.join(BASE, label + "_matrix.mtx.gz"), "rb") as f:
        M = scipy.io.mmread(f).tocsc()
    feat = pd.read_csv(os.path.join(BASE, label + "_genes.tsv.gz"), sep="\t", header=None,
                       names=["gene_id", "gene_symbol"], dtype=str)
    with gzip.open(os.path.join(BASE, label + "_barcodes.tsv.gz"), "rt") as f:
        bc = [l.strip() for l in f if l.strip()]
    assert M.shape == (len(feat), len(bc))
    return sp.csr_matrix(M.astype(np.int32)), feat, np.array(bc)

rows = []
Mats, Feats, GeneIds, Bcs = [], [], [], []
t0 = time.time()
for i, sm in meta.iterrows():
    M, feat, bc = load_lib(sm.sample_label)
    n_count = np.asarray(M.sum(axis=0)).ravel()
    n_feature = np.diff(M.tocsc().indptr)   # per cell (R: diff(m@p) on CsparseMatrix)
    mt = feat["gene_symbol"].str.match(r"^mt-", case=False).values
    pct_mito = np.asarray(M[mt, :].sum(axis=0)).ravel() / np.maximum(n_count, 1) * 100
    keep = (n_count >= 1000) & (n_feature >= 500) & (n_feature <= 7500) & (pct_mito <= 20)

    # marker scoring on QC-passing cells, exactly as 03_...R
    cm = markers[markers["cohort_scope"].isin(["both", sm.tissue_cohort])]
    genes = list(dict.fromkeys(cm["marker_gene"]))
    sym2idx = {}
    for k, s in enumerate(feat["gene_symbol"].values):
        sym2idx.setdefault(s, k)
    gi = [sym2idx.get(g, -1) for g in genes]
    present = np.array([g >= 0 for g in gi])
    genes = [g for g, p in zip(genes, present) if p]
    gi = np.array([g for g in gi if g >= 0])
    sub = M[gi, :][:, keep].astype(np.float64).tocsr()
    lib = n_count[keep]
    sc_ = sub.T.multiply(1e4 / np.maximum(lib, 1)[:, None]).tocsr()
    sc_.data = np.log1p(sc_.data)
    types = list(dict.fromkeys(cm["cell_type"]))
    score = np.zeros((sc_.shape[0], len(types)))
    for j, ct in enumerate(types):
        g = [x for x in cm.loc[cm["cell_type"] == ct, "marker_gene"] if x in genes]
        ci = [genes.index(x) for x in g]
        if ci:
            score[:, j] = np.asarray(sc_[:, ci].mean(axis=1)).ravel()
    top_i = score.argmax(axis=1)
    top = score[np.arange(score.shape[0]), top_i]
    srt = np.sort(score, axis=1)
    second = srt[:, -2] if score.shape[1] > 1 else np.zeros(score.shape[0])
    margin = top - second
    assigned = np.array(types, dtype=object)[top_i]
    assigned[(top < 0.05) | (margin < 0.01)] = "unassigned"

    df = pd.DataFrame({
        "barcode": bc, "sample_id": sm.sample_id, "sample_label": sm.sample_label,
        "tissue_cohort": sm.tissue_cohort, "condition": sm.condition,
        "n_count": n_count, "n_feature": n_feature, "percent_mito": pct_mito,
        "qc_pass": keep, "cell_type": "not_evaluated", "top_marker_score": np.nan,
        "marker_score_margin": np.nan})
    df.loc[keep, "cell_type"] = assigned
    df.loc[keep, "top_marker_score"] = top
    df.loc[keep, "marker_score_margin"] = margin
    rows.append(df)
    Mats.append(M); Feats.append(feat["gene_symbol"].values); GeneIds.append(feat["gene_id"].values); Bcs.append(bc)
    print(f"{i+1}/16 {sm.sample_id} cells={M.shape[1]} keep={keep.sum()} [{time.time()-t0:.0f}s]", flush=True)

obs = pd.concat(rows, ignore_index=True)
# union gene set (identical across libraries? check)
allsym = [set(f) for f in Feats]
print("identical gene sets:", all(s == allsym[0] for s in allsym), "n_union:", len(set().union(*allsym)))

np.save(f"{OUT}/obs_raw.npy", obs.to_dict("list"), allow_pickle=True)
import pickle
with open(f"{OUT}/obs_raw.pkl", "wb") as f:
    pickle.dump(obs, f)
with open(f"{OUT}/libs.pkl", "wb") as f:
    pickle.dump({"Mats": Mats, "Feats": Feats, "GeneIds": GeneIds, "Bcs": Bcs, "meta": meta}, f)

summary = {"cells_deposited": int(len(obs)),
           "cells_passing_QC": int(obs.qc_pass.sum()),
           "cells_assigned": int((obs.loc[obs.qc_pass, "cell_type"] != "unassigned").sum()),
           "cells_unassigned": int((obs.loc[obs.qc_pass, "cell_type"] == "unassigned").sum())}
print(json.dumps(summary))
json.dump(summary, open(f"{OUT}/repro_summary.json", "w"), indent=1)
