"""Build a single AnnData of QC-passing cells for UMAP / dotplot (display only)."""
import os
import pickle, numpy as np, pandas as pd, scipy.sparse as sp, anndata as ad
W=os.environ.get("SC_W","work")
libs=pickle.load(open(f"{W}/sc_out/libs.pkl","rb")); obs=pickle.load(open(f"{W}/sc_out/obs_raw.pkl","rb"))
Mats,Feats,meta=libs["Mats"],libs["Feats"],libs["meta"]
genes=list(Feats[0])
blocks=[]; obsl=[]
for i,sm in meta.iterrows():
    keep=obs.loc[obs.sample_id==sm.sample_id,"qc_pass"].values
    blocks.append(Mats[i][:,keep].T.tocsr())
    d=obs[(obs.sample_id==sm.sample_id)&obs.qc_pass].reset_index(drop=True)
    obsl.append(d)
X=sp.vstack(blocks).tocsr().astype(np.float32)
o=pd.concat(obsl,ignore_index=True)
assert X.shape[0]==len(o), (X.shape, len(o))
A=ad.AnnData(X=X)
A.obs=o.set_index(pd.Index([f"{r.sample_id}_{r.barcode}" for r in o.itertuples()]))
A.var_names=genes
A.var["mt"]=pd.Series(genes).str.match(r"^mt-",case=False).values
A.raw=None
A.write(f"{W}/sc_out/ad_qc.h5ad")
print(A)
print(A.obs.cell_type.value_counts().to_dict())
print("X max", X.max(), "nnz", X.nnz)
