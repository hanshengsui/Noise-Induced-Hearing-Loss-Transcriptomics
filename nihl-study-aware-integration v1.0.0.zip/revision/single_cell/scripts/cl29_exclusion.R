# Remove hair-cell-like Leiden 29 cells from the N SGN and N Schwann/glial pseudobulks
# Root of the run tree (see README_run_order.txt).
W <- Sys.getenv("SC_W", normalizePath("work", mustWork = FALSE))
.libPaths(c(file.path(W, "Rlib"), .libPaths()))
suppressPackageStartupMessages({library(limma); library(edgeR); library(data.table)})
args <- commandArgs(TRUE)
OUTD <- if (length(args)) args[1] else file.path(W, "sc_out")
dir.create(OUTD, recursive = TRUE, showWarnings = FALSE); LEG <- Sys.getenv("NIHL_ANALYSIS_ROOT", file.path(W, "stage1"))
pb <- fread(file.path(LEG, "source_data/GSE168041_celltype/mouse_celltype_pseudobulk_counts.csv.gz"))
gid <- pb$gene_id; gsym <- pb$gene_symbol
P0 <- as.matrix(pb[, -(1:2), with = FALSE]); storage.mode(P0) <- "numeric"; rownames(P0) <- gid
cl <- fread(file.path(OUTD, "cl29_counts_by_sample_celltype.csv.gz")); stopifnot(all(cl$gene_id == gid))
cc0 <- fread(file.path(LEG, "source_data/GSE168041_celltype/cell_counts_and_library_sizes.csv"))
meta <- fread(Sys.getenv("SC_METADATA", "config/samples/GSE168041_libraries.csv"))
cells <- fread(file.path(OUTD, "cl29_cells_by_sample_celltype.csv"))
TARGET <- c("spiral_ganglion_neuron", "schwann_glial")
P1 <- P0; cc1 <- copy(cc0)
for (k in setdiff(names(cl), c("gene_id","gene_symbol"))) {
  ct <- sub(".*__", "", k); s <- sub("__.*", "", k)
  if (!(ct %in% TARGET)) next
  stopifnot(k %in% colnames(P1)); P1[, k] <- P1[, k] - cl[[k]]; stopifnot(all(P1[, k] >= 0))
  n <- cells[sample_id == s & cell_type == ct, n]
  cc1[sample_id == s & cell_type == ct, `:=`(n_cells = n_cells - n, library_size = library_size - sum(cl[[k]]))]
}
hm <- strsplit(readLines(Sys.getenv("SC_HALLMARK", "resources/gene_sets/h.all.v2024.1.Hs.symbols.gmt"), warn = FALSE), "\t")
hm <- hm[lengths(hm) >= 3]; hallmark <- lapply(hm, function(x) unique(toupper(x[-c(1, 2)]))); names(hallmark) <- vapply(hm, `[[`, "", 1)
get_units <- function(cc) { units <- list()
  for (coh in unique(meta$tissue_cohort)) for (ct in setdiff(unique(cc[tissue_cohort == coh, cell_type]), "unassigned")) {
    z <- merge(meta[tissue_cohort == coh, .(sample_id, condition)], cc[tissue_cohort == coh & cell_type == ct, .(sample_id, condition, n_cells, library_size)], by = c("sample_id","condition"), all.x = TRUE)
    z[is.na(n_cells), n_cells := 0][is.na(library_size), library_size := 0]; z <- z[n_cells >= 20 & library_size >= 5000]
    if (sum(z$condition == "naive") < 3 || sum(z$condition == "noise") < 3) next
    units[[length(units)+1]] <- list(cohort = coh, cell_type = ct, samples = z) }; units }
run <- function(P, cc, label) { units <- get_units(cc)
  rbindlist(lapply(units, function(u) {
    z <- u$samples[order(condition, sample_id)]; counts <- P[, paste(z$sample_id, u$cell_type, sep = "__"), drop = FALSE]
    condition <- factor(z$condition, levels = c("naive","noise")); design <- model.matrix(~0 + condition); colnames(design) <- c("naive","noise")
    C <- matrix(c(-1, 1), ncol = 1, dimnames = list(colnames(design), "nvn"))
    keep <- filterByExpr(counts, design = design, min.count = 10, min.total.count = 15); cf <- counts[keep, , drop = FALSE]
    nf <- calcNormFactors(cf, method = "TMM"); v <- voom(cf, design = design, lib.size = colSums(cf) * nf, normalize.method = "none", plot = FALSE)
    fit <- eBayes(contrasts.fit(lmFit(v, design), C), robust = TRUE, trend = FALSE)
    st <- fit$t[,1]; names(st) <- toupper(gsym[match(rownames(cf), gid)]); st <- st[is.finite(st)]; st <- st[!duplicated(names(st))]
    idx <- lapply(hallmark, function(s) which(names(st) %in% s)); ok <- lengths(idx) >= 5 & lengths(idx) < length(st) - 2
    tab <- cameraPR(st, index = idx[ok], inter.gene.cor = 0.01, sort = FALSE)
    data.table(run = label, tissue_cohort = u$cohort, cell_type = u$cell_type, pathway = rownames(tab), NGenes = tab$NGenes, Direction = tab$Direction, PValue = tab$PValue,
               n_naive = sum(condition == "naive"), n_noise = sum(condition == "noise"), cells = sum(z$n_cells)) })) }
r0 <- run(P0, cc0, "original"); r1 <- run(P1, cc1, "cl29_excluded")
for (r in list(r0, r1)) stopifnot(nrow(r) == 650)
r0[, global_FDR := p.adjust(PValue, "BH")]; r1[, global_FDR := p.adjust(PValue, "BH")]
fwrite(rbind(r0, r1), file.path(OUTD, "cl29_exclusion_all650.csv"))
cat("units original/excluded:", uniqueN(r0[, paste(tissue_cohort, cell_type)]), uniqueN(r1[, paste(tissue_cohort, cell_type)]), "\n")
# Focused comparison in the two neuronal-cohort classes affected by exclusion.
map <- c(HALLMARK_TNFA_SIGNALING_VIA_NFKB="TNFA",HALLMARK_INFLAMMATORY_RESPONSE="INFL",HALLMARK_UNFOLDED_PROTEIN_RESPONSE="UPR",HALLMARK_OXIDATIVE_PHOSPHORYLATION="OXPHOS",HALLMARK_E2F_TARGETS="E2F",HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION="EMT",HALLMARK_INTERFERON_GAMMA_RESPONSE="IFNG")
x <- rbind(r0,r1)[tissue_cohort=="neuronal_focused" & cell_type %in% TARGET & pathway %in% names(map)]
x[, cat := ifelse(global_FDR < 0.10,Direction,"ns")]
z <- dcast(x,tissue_cohort+cell_type+pathway~run,value.var=c("Direction","cat","cells","global_FDR"))
z[, `:=`(program=unname(map[pathway]),dir_same=Direction_cl29_excluded==Direction_original,cat_same=cat_cl29_excluded==cat_original,cl29_cell_fraction=(cells_original-cells_cl29_excluded)/cells_original)]
fwrite(z,file.path(OUTD,"cl29_exclusion_sensitivity.csv"))
