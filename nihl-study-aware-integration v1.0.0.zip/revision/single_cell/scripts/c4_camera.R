# A4/C4 stage 3: 13 main contrasts x 7 programs CAMERA under the stable-marker annotation.
suppressPackageStartupMessages({library(limma); library(edgeR); library(data.table)})
set.seed(20261029)
# Root of the run tree (see README_run_order.txt). Inputs are produced by build_raw.py,
# c4_hybrid.py and c4_pseudobulk_build.py.
W <- Sys.getenv("SC_W", normalizePath("work", mustWork = FALSE))
LEG <- Sys.getenv("NIHL_ANALYSIS_ROOT", file.path(W, "stage1"))
OUT <- file.path(W, "sc_out")

pb <- fread(file.path(OUT, "hybrid_pseudobulk_counts.csv.gz"))
gid <- pb$gene_id; gsym <- pb$gene_symbol
P <- as.matrix(pb[, -(1:2), with = FALSE]); storage.mode(P) <- "numeric"; rownames(P) <- gid
cc <- fread(file.path(OUT, "hybrid_cell_counts.csv"))
meta <- fread(Sys.getenv("SC_METADATA", "config/samples/GSE168041_libraries.csv"))

hm <- strsplit(readLines(Sys.getenv("SC_HALLMARK", "resources/gene_sets/h.all.v2024.1.Hs.symbols.gmt"), warn = FALSE), "\t")
hm <- hm[lengths(hm) >= 3]
hallmark <- lapply(hm, function(x) unique(toupper(x[-c(1, 2)])))
names(hallmark) <- vapply(hm, `[[`, character(1), 1)
PROG <- c(TNFA = "HALLMARK_TNFA_SIGNALING_VIA_NFKB", INFL = "HALLMARK_INFLAMMATORY_RESPONSE",
          UPR = "HALLMARK_UNFOLDED_PROTEIN_RESPONSE", OXPHOS = "HALLMARK_OXIDATIVE_PHOSPHORYLATION",
          E2F = "HALLMARK_E2F_TARGETS", IFNG = "HALLMARK_INTERFERON_GAMMA_RESPONSE",
          EMT = "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION")

camera_pr_exact <- function(statistic, pathways, inter_gene_cor = 0.01) {
  statistic <- statistic[is.finite(statistic)]
  names(statistic) <- toupper(names(statistic))
  statistic <- statistic[!duplicated(names(statistic))]
  G <- length(statistic)
  index <- lapply(pathways, function(set) which(names(statistic) %in% set))
  valid <- lengths(index) >= 5L & lengths(index) < G - 2L
  tab <- limma::cameraPR(statistic, index = index[valid], inter.gene.cor = inter_gene_cor, sort = FALSE)
  data.table(pathway = rownames(tab), NGenes = tab$NGenes, Direction = tab$Direction,
             PValue = tab$PValue, within_class_FDR = tab$FDR)
}

units <- list()
ccm <- merge(cc, meta[, .(sample_id, tissue_cohort, condition)], by = "sample_id")
ccm[, n_cells := n_cells]
for (coh in unique(meta$tissue_cohort)) for (ct in setdiff(unique(ccm[tissue_cohort == coh, cell_type]), "unassigned")) {
  z <- merge(meta[tissue_cohort == coh, .(sample_id, condition)],
             ccm[tissue_cohort == coh & cell_type == ct, .(sample_id, condition, n_cells, library_size)],
             by = c("sample_id", "condition"), all.x = TRUE)
  z[is.na(n_cells), n_cells := 0][is.na(library_size), library_size := 0]
  z <- z[n_cells >= 20 & library_size >= 5000]
  if (sum(z$condition == "naive") < 3 || sum(z$condition == "noise") < 3) next
  units[[length(units) + 1]] <- list(cohort = coh, cell_type = ct, samples = z)
}
cat("eligible units under stable annotation:", length(units), "\n")

fit_unit <- function(u) {
  z <- u$samples[order(condition, sample_id)]
  keys <- paste(z$sample_id, u$cell_type, sep = "__")
  stopifnot(all(keys %in% colnames(P)))
  counts <- P[, keys, drop = FALSE]; colnames(counts) <- z$sample_id
  condition <- factor(z$condition, levels = c("naive", "noise"))
  design <- model.matrix(~0 + condition); colnames(design) <- c("naive", "noise")
  C <- matrix(c(-1, 1), ncol = 1, dimnames = list(colnames(design), "noise_vs_naive"))
  keep <- filterByExpr(counts, design = design, min.count = 10, min.total.count = 15)
  cf <- counts[keep, , drop = FALSE]
  nf <- calcNormFactors(cf, method = "TMM")
  v <- voom(cf, design = design, lib.size = colSums(cf) * nf, normalize.method = "none", plot = FALSE)
  fit <- contrasts.fit(lmFit(v, design), C); fit <- eBayes(fit, robust = TRUE, trend = FALSE)
  stat <- fit$t[, 1]; names(stat) <- gsym[match(rownames(cf), gid)]
  ans <- camera_pr_exact(stat, hallmark[PROG])
  ans[, `:=`(tissue_cohort = u$cohort, cell_type = u$cell_type,
             n_naive = sum(condition == "naive"), n_noise = sum(condition == "noise"),
             n_genes = nrow(cf))]
  ans
}
new <- rbindlist(lapply(units, fit_unit))
new[, definition := "stable_label_preserving"]
fwrite(new, file.path(OUT, "camera_stable_annotation.csv"))

# original (primary) annotation from the legacy run, restricted to the same 7 programs
orig <- fread(file.path(LEG, "results/cell_annotation_sensitivity/CAMERA_PR_annotation_and_cell_threshold_sensitivity.csv"))
orig <- orig[grepl("^primary__20__", analysis)]
orig[, definition := "original"]
parts <- strsplit(orig$analysis, "__", fixed = TRUE)
orig[, `:=`(tissue_cohort = vapply(parts, `[[`, character(1), 3),
            cell_type = vapply(parts, function(x) paste(x[4:length(x)], collapse = "__"), character(1)))]
orig <- orig[pathway %in% PROG]

cmp <- merge(
  new[, .(pathway, tissue_cohort, cell_type, dir_stable = Direction, p_stable = PValue,
          fdr_stable = within_class_FDR, n_naive, n_noise)],
  orig[, .(pathway, tissue_cohort, cell_type, dir_orig = Direction, p_orig = PValue,
           fdr_orig = within_class_FDR)],
  by = c("pathway", "tissue_cohort", "cell_type"))
cmp[, cell_unit := paste(tissue_cohort, cell_type, sep = "__")]
cmp[, concordant := dir_stable == dir_orig]
panel_meta <- jsonlite::fromJSON(file.path(OUT, "stable_panel_meta.json"))
cmp[, assessed := !(cell_type %in% panel_meta$unverifiable)]
cmp[, contrast := cell_unit]
fwrite(cmp, file.path(OUT, "stable_marker_direction_comparison.csv"))
cat("units compared:", uniqueN(cmp$cell_unit), "\n")
cat("program x unit rows:", nrow(cmp), "\n")
cat(sprintf("CONCORDANT %d / %d = %.4f\n", sum(cmp$concordant), nrow(cmp), mean(cmp$concordant)))
print(cmp[, .(concordant = sum(concordant), n = .N), by = cell_unit][order(cell_unit)])
print(cmp[, .(concordant = sum(concordant), n = .N), by = pathway][order(pathway)])
saveRDS(list(cmp = cmp, new = new, orig = orig), file.path(OUT, "c4_camera.rds"))
