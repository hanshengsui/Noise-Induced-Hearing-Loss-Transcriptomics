"""Supporting figures for C4 (stable-marker concordance) and C5 (composition)."""
import numpy as np, pandas as pd, matplotlib
import os
W=os.environ.get("SC_W","work")
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from palette import apply_figure_style
apply_figure_style(frame="open", sizes=(8, 7, 6))
W=os.environ.get("SC_W","work"); FIG=f"{W}/sc_out/figs"

LAB = {"spiral_ganglion_neuron":"Spiral ganglion neuron","schwann_glial":"Schwann/glial",
       "fibrocyte":"Fibrocyte","endothelial":"Endothelial","pericyte_smooth_muscle":"Pericyte/smooth muscle",
       "immune":"Immune","marginal_cell":"Marginal cell","intermediate_melanocyte":"Intermediate/melanocyte",
       "basal_cell":"Basal cell"}
VER = {"spiral_ganglion_neuron","schwann_glial","endothelial","immune"}

# --- panel A: per-class retained fraction under the stable panel
prim = pd.read_csv(f"{W}/sc_out/stable_marker_reassignment_primary.csv")
prim = prim[prim.cell_type!="unassigned"].dropna(subset=["retained_fraction"])
prim = prim.sort_values("retained_fraction")
fig, axes = plt.subplots(1, 2, figsize=(9.4, 3.5), gridspec_kw=dict(width_ratios=[1,1.15]))

ax = axes[0]
y = np.arange(len(prim))
ax.barh(y, prim.retained_fraction, height=0.62, color="#0072B2", alpha=0.85, lw=0)
for i,(v,n0) in enumerate(zip(prim.retained_fraction, prim.n_original)):
    ax.text(v-0.03, i, f"{v:.2f}", va="center", ha="right", fontsize=6.2, color="white")
    ax.text(1.03, i, f"n = {n0:,}", va="center", ha="left", fontsize=6, color="0.25")
ax.set_yticks(y); ax.set_yticklabels([LAB[c] for c in prim.cell_type])
ax.set_xlim(0, 1.42); ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
ax.set_xlabel("Fraction of original cells re-assigned to the same class")
ax.set_title("Only four classes keep \u22652 stable markers", loc="left")
ax.axvline(1.0, color="0.6", lw=0.6, ls=(0,(3,2)), zorder=0)

# --- panel B: composition per mouse (naive vs noise), immune emphasised
comp = pd.read_csv(f"{W}/sc_out/composition_per_mouse.csv")
ax = axes[1]
classes = ["immune","fibrocyte","endothelial","pericyte_smooth_muscle","schwann_glial"]
lw_naive, lw_noise = "#56B4E9", "#D55E00"
off = {"naive": -0.17, "noise": 0.17}
for k, ct in enumerate(classes):
    z = comp[comp.cell_class==ct]
    for cond, col in [("naive", lw_naive), ("noise", lw_noise)]:
        v = z[z.condition==cond].frac.values*100
        jit = (np.arange(len(v)) - (len(v)-1)/2)*0.045
        ax.scatter(k + off[cond] + jit, v, s=17, c=col, lw=0, alpha=0.95, zorder=3)
    m = z.groupby("condition").frac.median()*100
    ax.plot([k-0.27, k-0.07], [m["naive"]]*2, color=lw_naive, lw=1.8, zorder=4)
    ax.plot([k+0.07, k+0.27], [m["noise"]]*2, color=lw_noise, lw=1.8, zorder=4)
ax.set_yscale("log")
ax.set_yticks([0.3,1,3,10,30])
ax.set_yticklabels(["0.3","1","3","10","30"])
ax.set_xticks(range(len(classes))); ax.set_xlim(-0.55, len(classes)+0.05)
ax.set_xticklabels([LAB[c] for c in classes], rotation=25, ha="right")
ax.set_ylabel("Share of assigned cells (%)")
ax.set_title("No class shifts significantly (n = 4 mice per group)", loc="left")
ax.legend(handles=[Line2D([0],[0], marker="o", ls="", ms=4, mfc=lw_naive, mec="none", label="Naive"),
                   Line2D([0],[0], marker="o", ls="", ms=4, mfc=lw_noise, mec="none", label="Noise")],
          frameon=False, loc="lower left", fontsize=6.5, bbox_to_anchor=(0.0, 0.0))
for a in (axes[0], axes[1]):
    for s in ["top","right"]: a.spines[s].set_visible(False)
fig.savefig(f"{FIG}/stable_annotation_and_composition.pdf", bbox_inches="tight")
fig.savefig(f"{FIG}/stable_annotation_and_composition.png", dpi=400, bbox_inches="tight")
plt.close(fig)

# --- panel: 91-cell direction concordance heat block
cmp = pd.read_csv(f"{W}/sc_out/stable_marker_direction_comparison.csv")
PROG = ["HALLMARK_TNFA_SIGNALING_VIA_NFKB","HALLMARK_INFLAMMATORY_RESPONSE",
        "HALLMARK_UNFOLDED_PROTEIN_RESPONSE","HALLMARK_OXIDATIVE_PHOSPHORYLATION",
        "HALLMARK_E2F_TARGETS","HALLMARK_INTERFERON_GAMMA_RESPONSE",
        "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION"]
SHORT = ["TNF\u03b1/NF\u03baB","Inflammation","UPR","OxPhos","E2F","IFN\u03b3","EMT"]
units = sorted(cmp.cell_unit.unique(), key=lambda u: (u.startswith("neuronal"), u))
M = np.full((len(units), len(PROG)), np.nan)
for i,u in enumerate(units):
    for j,p in enumerate(PROG):
        r = cmp[(cmp.cell_unit==u)&(cmp.pathway==p)]
        if len(r): M[i,j] = 1.0 if r.concordant.iloc[0] else 0.0
fig, ax = plt.subplots(figsize=(4.6, 4.3))
cmap = matplotlib.colors.ListedColormap(["#D55E00","#009E73"])
ax.imshow(M, cmap=cmap, vmin=0, vmax=1, aspect="auto")
ax.set_xticks(range(len(PROG))); ax.set_xticklabels(SHORT, rotation=45, ha="right")
ax.set_yticks(range(len(units)))
ax.set_yticklabels([u.replace("lateral_wall_focused","LW").replace("neuronal_focused","N")
                    .replace("_"," ") for u in units], fontsize=6)
for i in range(len(units)):
    for j in range(len(PROG)):
        if M[i,j]==0: ax.text(j, i, "\u00d7", ha="center", va="center", fontsize=7, color="white")
ax.set_title(f"Direction agreement {int(np.nansum(M))}/{M.size} cells", loc="left")
ax.set_xlabel(""); 
for s in ax.spines.values(): s.set_visible(False)
fig.savefig(f"{FIG}/stable_direction_concordance.pdf", bbox_inches="tight")
fig.savefig(f"{FIG}/stable_direction_concordance.png", dpi=400, bbox_inches="tight")
plt.close(fig)
print("concordance sum:", int(np.nansum(M)), "/", M.size)
