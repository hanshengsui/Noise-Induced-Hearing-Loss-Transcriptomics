import os
import pickle, numpy as np, pandas as pd
W=os.environ.get("SC_W","work")
pd.set_option("display.width", 200)
libs = pickle.load(open(f"{W}/sc_out/libs.pkl","rb")); obs = pickle.load(open(f"{W}/sc_out/obs_raw.pkl","rb"))
Mats, Feats, meta = libs["Mats"], libs["Feats"], libs["meta"]
HC = ["Myo7a","Pou4f3","Slc26a5","Otof","Ocm"]
rec=[]
for i, sm in meta.iterrows():
    M, feat = Mats[i], Feats[i]
    gi={g:np.where(feat==g)[0][0] for g in HC}
    sub = M[[gi[g] for g in HC],:][:, obs.loc[obs.sample_id==sm.sample_id,"qc_pass"].values]
    npos=np.asarray((sub>0).sum(axis=0)).ravel()
    d=obs[(obs.sample_id==sm.sample_id)&obs.qc_pass].copy(); d["n_hc"]=npos
    rec.append(d)
d=pd.concat(rec)
hl=d[d.n_hc>=2]
print("hc_like cells (post-QC):", len(hl), "of", len(d), f"= {100*len(hl)/len(d):.3f}%")
print(pd.crosstab(hl.tissue_cohort, hl.cell_type, margins=True).to_string())
print("\nn_hc distribution:", hl.n_hc.value_counts().sort_index().to_dict())
print("\nQC metrics of hc_like vs other:")
print(pd.DataFrame({"hc_like_median":[hl.n_count.median(), hl.n_feature.median(), hl.percent_mito.median(), hl.top_marker_score.median()],
                    "other_median":[d[d.n_hc<2].n_count.median(), d[d.n_hc<2].n_feature.median(), d[d.n_hc<2].percent_mito.median(), d[d.n_hc<2].top_marker_score.median()]},
                   index=["n_count","n_feature","percent_mito","top_marker_score"]).to_string())
print("\nper-mouse hc_like counts (max):", hl.groupby("sample_id").size().describe().to_dict())
print("per-mouse counts:", hl.groupby(["tissue_cohort","sample_id"]).size().to_dict())
print("\nper-cell marker positivity among hc_like:")
gi={g:0 for g in HC}
rows=[]
for i, sm in meta.iterrows():
    M, feat = Mats[i], Feats[i]
    gi={g:np.where(feat==g)[0][0] for g in HC}
    sub=M[[gi[g] for g in HC],:][:, obs.loc[obs.sample_id==sm.sample_id,"qc_pass"].values]
    npos=np.asarray((sub>0).sum(axis=0)).ravel()
    sel=np.where(npos>=2)[0]
    if len(sel)==0: continue
    for k,g in enumerate(HC):
        rows.append(dict(sample_id=sm.sample_id,tissue=sm.tissue_cohort,gene=g,n_pos=int((sub[k,sel].toarray().ravel()>0).sum())))
r=pd.DataFrame(rows)
print(r.groupby(["tissue","gene"]).n_pos.sum().to_string())
print("\ntotal hc_like by cohort:", hl.tissue_cohort.value_counts().to_dict())
print("cohort totals:", d.tissue_cohort.value_counts().to_dict())
hl[["sample_id","tissue_cohort","condition","barcode","cell_type","n_hc","n_count","n_feature","percent_mito","top_marker_score"]].to_csv(f"{W}/sc_out/hair_cell_candidates.csv",index=False)
