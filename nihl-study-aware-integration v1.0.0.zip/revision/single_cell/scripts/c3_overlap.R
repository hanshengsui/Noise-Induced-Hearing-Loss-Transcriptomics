# A4/C3 part 1: marker panel x 50 Hallmark overlap; and the tested-set bookkeeping.
suppressPackageStartupMessages({library(data.table)})
# Run from the repository root after the main pipeline (see README_run_order.txt).
W <- Sys.getenv("SC_W", normalizePath("work", mustWork = FALSE))
hm <- strsplit(readLines(Sys.getenv("SC_HALLMARK", "resources/gene_sets/h.all.v2024.1.Hs.symbols.gmt"), warn=FALSE), "\t")
hm <- hm[lengths(hm) >= 3]
hallmark <- lapply(hm, function(x) unique(toupper(x[-c(1,2)])))
names(hallmark) <- vapply(hm, `[[`, character(1), 1)
stopifnot(length(hallmark)==50)

mk <- fread(Sys.getenv("SC_MARKERS", "resources/annotations/cell_type_markers.csv"))
mk[, gene_up := toupper(marker_gene)]
rows <- list()
for (g in unique(mk$gene_up)) {
  in_sets <- names(hallmark)[vapply(hallmark, function(s) g %in% s, logical(1))]
  src <- mk[gene_up==g, .(cell_types=paste(sort(unique(cell_type)),collapse=";"),
                          cohort_scopes=paste(sort(unique(cohort_scope)),collapse=";"),
                          n_classes=uniqueN(cell_type))]
  rows[[g]] <- data.table(marker_gene_up=g, in_n_hallmark=length(in_sets),
    hallmark_sets=paste(in_sets, collapse=";"),
    cell_types=src$cell_types, cohort_scopes=src$cohort_scopes, n_classes=src$n_classes)
}
ov <- rbindlist(rows)
setorder(ov, -in_n_hallmark, marker_gene_up)
fwrite(ov, file.path(W,"sc_out/marker_hallmark_overlap.csv"))
cat("panel genes (upper):", nrow(ov), "\n")
cat("genes in >=1 Hallmark:", sum(ov$in_n_hallmark>0), "\n")
cat("gene-set pairs:", sum(ov$in_n_hallmark), "\n")
print(ov[in_n_hallmark>0, .(marker_gene_up, in_n_hallmark, hallmark_sets, cell_types)])
