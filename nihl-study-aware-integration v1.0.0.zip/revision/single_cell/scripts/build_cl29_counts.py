"""Aggregate neuronal-cohort cluster-29 counts for the exclusion sensitivity."""
import os,pickle
from pathlib import Path
import numpy as np,pandas as pd
w=Path(os.environ.get('SC_W','work'));out=w/'sc_out'
libs=pickle.load(open(out/'libs.pkl','rb'));obs=pd.read_pickle(out/'obs_qc_genes.pkl')
legacy=Path(os.environ.get('NIHL_ANALYSIS_ROOT',str(w/'stage1')))
ids=pd.read_csv(legacy/'source_data/GSE168041_celltype/mouse_celltype_pseudobulk_counts.csv.gz',usecols=['gene_id','gene_symbol'])
master=pd.Index(ids.gene_id);columns={};cells=[]
for i,sm in libs['meta'].iterrows():
 sub=obs[(obs.sample_id==sm.sample_id)&(obs.cohort=='neuronal_focused')&(obs.leiden.astype(str)=='29')]
 bmap=pd.Series(np.arange(len(libs['Bcs'][i])),index=libs['Bcs'][i]);rowmap=master.get_indexer(libs['GeneIds'][i]);assert (rowmap>=0).all()
 for ct,d in sub.groupby('cell_type'):
  cols=bmap.loc[d.barcode].to_numpy();v=np.asarray(libs['Mats'][i][:,cols].sum(axis=1)).ravel();a=np.zeros(len(master));np.add.at(a,rowmap,v)
  columns[f'{sm.sample_id}__{ct}']=a;cells.append({'sample_id':sm.sample_id,'cell_type':ct,'n':len(d)})
r=pd.concat([ids,pd.DataFrame(columns)],axis=1)
r.to_csv(out/'cl29_counts_by_sample_celltype.csv.gz',index=False)
pd.DataFrame(cells).sort_values(['sample_id','cell_type']).to_csv(out/'cl29_cells_by_sample_celltype.csv',index=False)
print('cluster-29 annotated cells:',sum(c['n'] for c in cells))
