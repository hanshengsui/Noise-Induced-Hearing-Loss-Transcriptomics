import os
"""A4/C1 rev (d): would a hair-cell-like class meet the pseudobulk inclusion rule?"""
import numpy as np, pandas as pd, json
W=os.environ.get("SC_W","work")
O=f"{W}/sc_out"
d = pd.read_pickle(f"{O}/obs_qc_genes.pkl")
meta = pd.read_csv(os.environ.get("SC_METADATA", "config/samples/GSE168041_libraries.csv"))
cohort_of = meta.set_index("sample_id").tissue_cohort
cond_of = meta.set_index("sample_id").condition
res=[]
defs = {
 "ihc_like_3markers": d.ihc_like,
 "n_hc_ge2": d.n_hc>=2,
 "n_hc_ge3": d.n_hc>=3,
 "leiden29_neuronal": (d.cohort=="neuronal_focused")&(d.leiden=="29"),
 "leiden29_and_nhc2": (d.cohort=="neuronal_focused")&(d.leiden=="29")&(d.n_hc>=2),
}
for name, m in defs.items():
    s = d[m.values].copy()
    s["cond"] = s.sample_id.map(cond_of)
    # eligibility is evaluated per library: >=20 cells AND >=5000 UMI for that unit in that library
    g = s.groupby(["sample_id","cond"]).agg(n_cells=("n_count","size"),
                                            median_umi=("n_count","median"),
                                            min_umi=("n_count","min"), library_umi=("n_count","sum")).reset_index()
    # a library passes if it has >=20 cells of that unit with >=5000 UMI each? B3 uses unit library_size>=5000
    passed = g[(g.n_cells>=20) & (g.library_umi>=5000)]
    na = int((passed.cond=="naive").sum()); no = int((passed.cond=="noise").sum())
    res.append(dict(definition=name, n_cells=int(len(s)), n_libraries=int(len(g)),
                    max_cells_per_library=int(g.n_cells.max()) if len(g) else 0,
                    libraries_with_ge20=dict(naive=na, noise=no),
                    eligible=bool(na>=3 and no>=3)))
r = pd.DataFrame(res)
r["libraries_with_ge20"] = r.libraries_with_ge20.astype(str)
r.to_csv(f"{O}/hair_cell_eligibility.csv", index=False)
print(r.to_string(index=False))
print()
# detail for the winning definition
s = d[((d.cohort=="neuronal_focused")&(d.leiden=="29")).values].copy()
s["cond"]=s.sample_id.map(cond_of)
g=s.groupby(["sample_id","cond"]).agg(n=("n_count","size"), med_umi=("n_count","median"),
                                      lib_umi=("n_count","sum")).reset_index()
print("leiden29 per library:"); print(g.to_string(index=False))
print("\ntotal library size (sum UMI) per library for cl29:", g.lib_umi.tolist())
json.dump(res, open(f"{O}/hair_cell_eligibility.json","w"), indent=1)
