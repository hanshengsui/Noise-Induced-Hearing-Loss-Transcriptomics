"""Assemble the A4 deliverable tables in their final schema."""
import numpy as np, pandas as pd, json
import os
W=os.environ.get("SC_W","work")
W=os.environ.get("SC_W","work"); O=f"{W}/sc_out"
dc = pd.read_pickle(f"{W}/sc_out/obs_stable_hybrid.pkl")

# ---------- 1. hair_cell_check.csv (stage totals + per-cohort + per-library already written) ----------
st = pd.read_csv(f"{O}/hair_cell_check_stage_totals.csv")
coh = pd.read_csv(f"{O}/hair_cell_check_by_cohort.csv")
a = st[["stage","n_cells","n_hc_like"]].copy()
a["stratum"] = "all_cohorts"; a["tissue_cohort"] = "all"
b = coh.copy(); b["stratum"] = "by_cohort"
hc = pd.concat([a, b[["stage","stratum","tissue_cohort","n_cells","n_hc_like"]]], ignore_index=True)
hc["pct_hc_like"] = 100*hc.n_hc_like/hc.n_cells
hc = hc[["stage","stratum","tissue_cohort","n_cells","n_hc_like","pct_hc_like"]]
hc.to_csv(f"{O}/hair_cell_check.csv", index=False)
print(hc.to_string(index=False))

# ---------- 2. marker_hallmark_overlap.csv already written; verify columns ----------
ov = pd.read_csv(f"{O}/marker_hallmark_overlap.csv")
print("\noverlap table:", ov.shape, ov.columns.tolist())

# ---------- 3. responsive_markers.csv: per-marker summary ----------
mkq = pd.read_csv(f"{O}/responsive_markers_by_unit.csv")
mk = pd.read_csv(os.environ.get("SC_MARKERS", "resources/annotations/cell_type_markers.csv"))
panel = pd.DataFrame({"marker_gene": sorted(mk.marker_gene.unique())})
panel = panel.merge(mk.groupby("marker_gene").agg(
    owning_classes=("cell_type", lambda s: ";".join(sorted(set(s)))), n_units_defined=("cell_type","nunique")).reset_index(),
    on="marker_gene", how="left")
agg = mkq.groupby("gene_symbol").agg(
    n_units_tested=("gene_symbol","size"),
    n_units_responsive=("responsive","sum"),
    max_abs_logFC=("logFC", lambda s: float(np.abs(s).max())),
    min_fdr=("FDR","min")).reset_index().rename(columns={"gene_symbol":"marker_gene"})
panel = panel.merge(agg, on="marker_gene", how="left")
panel["responsive"] = panel.n_units_responsive.fillna(0) > 0
ovg = set(pd.read_csv(f"{O}/marker_hallmark_overlap.csv").query("in_n_hallmark>0").marker_gene_up.str.upper())
panel["in_tested_hallmark"] = panel.marker_gene.str.upper().isin(ovg)
panel["stable"] = ~panel.responsive & ~panel.in_tested_hallmark
panel = panel.sort_values(["responsive","in_tested_hallmark","marker_gene"], ascending=[False,False,True])
panel[["marker_gene","owning_classes","n_units_defined","n_units_tested","n_units_responsive",
       "max_abs_logFC","min_fdr","in_tested_hallmark","responsive","stable"]].to_csv(
    f"{O}/responsive_markers.csv", index=False)
print("\npanel summary:", len(panel), "responsive:", int(panel.responsive.sum()),
      "hallmark-overlap:", int(panel.in_tested_hallmark.sum()), "stable:", int(panel.stable.sum()))

# ---------- 4. registry additions ----------
registry_path = os.environ.get("SC_REGISTRY")
reg = pd.read_csv(registry_path) if registry_path else pd.DataFrame(columns=["key"])
base_keys = set(reg.key)
rep = json.load(open(f"{O}/repro_agreement.json")); hcs = json.load(open(f"{O}/hair_cell_stats.json"))
conc = json.load(open(f"{O}/c4_concordance.json")); spm = json.load(open(f"{O}/stable_panel_meta.json"))
cmp = pd.read_csv(f"{O}/stable_marker_direction_comparison.csv")
comp = pd.read_csv(f"{O}/composition_limma_logit.csv")
wil = pd.read_csv(f"{O}/composition_wilcoxon.csv")

rows=[]
def add(key, value, fmt, src, col, row, loc, note=""):
    rows.append(dict(key=key, value=value, format=fmt, source_file=src, source_column=col,
                     source_row=row, locations=loc, note=note))
SRC="sc_out"
# 71,743 / 64,208 / 63,280 / 928 already live in the main registry as count.GSE168041.*; only the
# reproduction verdict is new information here.
add("count.sc.reproduction_cell_agreement",f"{rep['agreement']:.6f}","proportion",f"{SRC}/sc_reproduction.csv","item","cell_type_agreement_vs_legacy","new: Methods 2.6 (revision)","per-cell vs legacy annotation, n=64208")
# hair cell
raw=int(st.loc[st.stage=='raw_all','n_hc_like'].iloc[0]); qc=int(st.loc[st.stage=='post_qc','n_hc_like'].iloc[0])
asg=int(st.loc[st.stage=='assigned','n_hc_like'].iloc[0])
add("count.sc.haircell.raw",raw,"integer",f"{SRC}/hair_cell_check.csv","n_hc_like","stage=raw_all","new: Results 3.5 (revision)",">=2 of Myo7a/Pou4f3/Slc26a5/Otof/Ocm UMI>0")
add("count.sc.haircell.post_qc",qc,"integer",f"{SRC}/hair_cell_check.csv","n_hc_like","stage=post_qc","new: Results 3.5 (revision)","")
add("count.sc.haircell.assigned",asg,"integer",f"{SRC}/hair_cell_check.csv","n_hc_like","stage=assigned","new: Results 3.5 (revision)","")
add("count.sc.haircell.expected_independence",f"{hcs['expected_ge2_indep']:.1f}","decimal",f"{SRC}/hair_cell_stats.json","expected_ge2_indep","-","new: Results 3.5 (revision)","product of observed marginal detection rates")
add("count.sc.slc26a5_positive",hcs["slc26a5_pos"],"integer",f"{SRC}/hair_cell_stats.json","slc26a5_pos","-","new: Results 3.5 (revision)","prestin-positive cells among 64,208 post-QC cells")
add("def.sc.hair_cell_conclusion","absent_in_source","string",f"{SRC}/milon2021_dissection_notes.md","-","-","new: Methods 2.6; Results 3.5; Limitations","anatomically excluded by both dissection protocols, not removed by QC")
# overlap / responsive
add("count.sc.panel_genes",58,"integer",f"{SRC}/marker_hallmark_overlap.csv","marker_gene_up","all rows","new: Results 3.5 (revision)","SI Table S5 panel, unique symbols")
ovn=int(panel.in_tested_hallmark.sum()); add("count.sc.panel_in_hallmark",ovn,"integer",f"{SRC}/responsive_markers.csv","in_tested_hallmark","TRUE","new: Results 3.5 (revision)","")
add("count.sc.panel_hallmark_pairs",int(ov.in_n_hallmark.sum()),"integer",f"{SRC}/marker_hallmark_overlap.csv","in_n_hallmark","sum","new: Results 3.5 (revision)","gene-set pairs")
nresp=int(panel.responsive.sum()); add("count.sc.panel_responsive",nresp,"integer",f"{SRC}/responsive_markers.csv","responsive","TRUE","new: Results 3.5 (revision)","FDR<0.10 and |log2FC|>0.5 in >=1 eligible unit")
add("count.sc.stable_panel",len(spm["stable"]),"integer",f"{SRC}/stable_panel_meta.json","stable","-","new: Results 3.5 (revision)","panel minus hallmark-overlap minus responsive")
add("count.sc.stable_classes_unverifiable",len(spm["unverifiable"]),"integer",f"{SRC}/stable_panel_meta.json","unverifiable","-","new: Methods 2.6; Results 3.5","classes left with <2 stable markers")
add("sc.stable.reassignment_concordance_verifiable",f"{conc['concordance_verifiable']:.4f}","proportion",f"{SRC}/c4_concordance.json","concordance_verifiable","-","new: Results 3.5 (revision)","four verifiable classes only; n=%d cells"%conc['n_cells_verifiable_class_rows'])
add("count.sc.stable.n_concordant",int(cmp.concordant.sum()),"integer",f"{SRC}/stable_marker_direction_comparison.csv","concordant","sum","new: Results 3.5; Figure 5D","")
add("count.sc.stable.n_evaluable",len(cmp),"integer",f"{SRC}/stable_marker_direction_comparison.csv","concordant","nrow","new: Results 3.5","7 programs x 13 units")
add("count.sc.stable.n_not_evaluable",0,"integer",f"{SRC}/stable_marker_direction_comparison.csv","-","-","new: Results 3.5","all 13 units remained eligible under the stable annotation")
for p,lab in [("HALLMARK_TNFA_SIGNALING_VIA_NFKB","TNFA"),("HALLMARK_INFLAMMATORY_RESPONSE","INFL"),
              ("HALLMARK_UNFOLDED_PROTEIN_RESPONSE","UPR"),("HALLMARK_OXIDATIVE_PHOSPHORYLATION","OXPHOS"),
              ("HALLMARK_E2F_TARGETS","E2F"),("HALLMARK_INTERFERON_GAMMA_RESPONSE","IFNG"),
              ("HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION","EMT")]:
    n=int(cmp[cmp.pathway==p].concordant.sum())
    add(f"sc.stable.{lab}.n_concordant_stablepanel",n,"integer",f"{SRC}/stable_marker_direction_comparison.csv","concordant",p,"new: Results 3.5","subsumes registry sc.stable.*.n_concordant (same value)")
# composition
for _,r in comp.iterrows():
    tag=f"{'LW' if r.cohort.startswith('lateral') else 'N'}_{r.cell_class}"
    add(f"sc.composition.{tag}.limma_t",f"{r.moderated_t:.4f}","decimal",f"{SRC}/composition_limma_logit.csv","moderated_t",tag,"new: Results 3.5 / Discussion","")
    add(f"sc.composition.{tag}.limma_fdr",f"{r.fdr:.4g}","pvalue",f"{SRC}/composition_limma_logit.csv","fdr",tag,"new: Results 3.5 / Discussion","BH over 14 cohort x class tests")
add("count.sc.composition.tests",len(comp),"integer",f"{SRC}/composition_limma_logit.csv","cohort","all rows","new: Results 3.5","")
add("count.sc.composition.n_significant_fdr_0.10",int((comp.fdr<0.10).sum()),"integer",f"{SRC}/composition_limma_logit.csv","fdr","<0.10","new: Results 3.5 / Discussion","")
add("sc.composition.min_fdr",f"{comp.fdr.min():.4g}","pvalue",f"{SRC}/composition_limma_logit.csv","fdr","min","new: Discussion","")
add("count.sc.composition.wilcoxon_raw_p_lt_0.10",int((wil.wilcox_p<0.10).sum()),"integer",f"{SRC}/composition_wilcoxon.csv","wilcox_p","<0.10","new: Discussion","per-mouse fraction, distribution-free check")
# immune leading genes
lead = pd.read_csv(f"{O}/immune_leading_genes.csv")
for coh,lab in [("lateral_wall_focused","LW"),("neuronal_focused","N")]:
    z=lead[lead.tissue_cohort==coh]
    add(f"sc.immune.{lab}.top_negative_gene",z.gene_symbol.iloc[0],"string",f"{SRC}/immune_leading_genes.csv","gene_symbol",coh,"new: Results 3.5 / Discussion","most negative moderated t within HALLMARK_INFLAMMATORY_RESPONSE")
    add(f"sc.immune.{lab}.top_negative_t",f"{z.moderated_t.iloc[0]:.4f}","decimal",f"{SRC}/immune_leading_genes.csv","moderated_t",coh,"new: Results 3.5 / Discussion","")
    add(f"sc.immune.{lab}.top_negative_logFC",f"{z.logFC.iloc[0]:.4f}","decimal",f"{SRC}/immune_leading_genes.csv","logFC",coh,"new: Results 3.5 / Discussion","")
    add(f"sc.immune.{lab}.n_leading_fdr_0.10",int((z.FDR<0.10).sum()),"integer",f"{SRC}/immune_leading_genes.csv","FDR",coh,"new: Results 3.5 / Discussion","of the top 15 by moderated t")
add("count.sc.units_eligible",13,"integer",f"{SRC}/c3_all_units_DE_recomputed.csv.gz","tissue_cohort","13 units","Methods 2.6","")
ra = pd.DataFrame(rows)
dupes = set(ra.key) & base_keys
print("\nregistry additions:", len(ra), " collision with main registry:", len(dupes), sorted(dupes))
ra.to_csv(f"{O}/registry_additions_Single-cell.csv", index=False)
print(ra.key.tolist()[:8], "...")
