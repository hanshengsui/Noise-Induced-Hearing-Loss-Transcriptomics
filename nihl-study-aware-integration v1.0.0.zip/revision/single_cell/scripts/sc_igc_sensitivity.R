# Pseudobulk inter.gene.cor sensitivity for Table 4
# Root of the run tree (see README_run_order.txt).
W <- Sys.getenv("SC_W", normalizePath("work", mustWork = FALSE))
.libPaths(c(file.path(W, "Rlib"), .libPaths()))
suppressPackageStartupMessages({library(limma); library(edgeR); library(data.table)})
set.seed(20261029)
args <- commandArgs(TRUE)
OUTD <- if (length(args)) args[1] else file.path(W, "sc_out")
dir.create(OUTD, recursive = TRUE, showWarnings = FALSE)
LEG <- Sys.getenv("NIHL_ANALYSIS_ROOT", file.path(W, "stage1"))
pb <- fread(file.path(LEG, "source_data/GSE168041_celltype/mouse_celltype_pseudobulk_counts.csv.gz"))
gid <- pb$gene_id; gsym <- pb$gene_symbol
P <- as.matrix(pb[, -(1:2), with = FALSE]); storage.mode(P) <- "numeric"; rownames(P) <- gid
cc <- fread(file.path(LEG, "source_data/GSE168041_celltype/cell_counts_and_library_sizes.csv"))
meta <- fread(Sys.getenv("SC_METADATA", "config/samples/GSE168041_libraries.csv"))
hm <- strsplit(readLines(Sys.getenv("SC_HALLMARK", "resources/gene_sets/h.all.v2024.1.Hs.symbols.gmt"), warn = FALSE), "\t")
hm <- hm[lengths(hm) >= 3]; hallmark <- lapply(hm, function(x) unique(toupper(x[-c(1, 2)]))); names(hallmark) <- vapply(hm, `[[`, "", 1)
units <- list()
for (coh in unique(meta$tissue_cohort)) for (ct in setdiff(unique(cc[tissue_cohort == coh, cell_type]), "unassigned")) {
  z <- merge(meta[tissue_cohort == coh, .(sample_id, condition)], cc[tissue_cohort == coh & cell_type == ct, .(sample_id, condition, n_cells, library_size)], by = c("sample_id","condition"), all.x = TRUE)
  z[is.na(n_cells), n_cells := 0][is.na(library_size), library_size := 0]
  z <- z[n_cells >= 20 & library_size >= 5000]
  if (sum(z$condition == "naive") < 3 || sum(z$condition == "noise") < 3) next
  units[[length(units)+1]] <- list(cohort = coh, cell_type = ct, samples = z)
}
stopifnot(length(units) == 13)
run_unit <- function(u) {
  z <- u$samples[order(condition, sample_id)]
  counts <- P[, paste(z$sample_id, u$cell_type, sep = "__"), drop = FALSE]
  condition <- factor(z$condition, levels = c("naive","noise"))
  design <- model.matrix(~0 + condition); colnames(design) <- c("naive","noise")
  C <- matrix(c(-1, 1), ncol = 1, dimnames = list(colnames(design), "noise_vs_naive"))
  keep <- filterByExpr(counts, design = design, min.count = 10, min.total.count = 15)
  cf <- counts[keep, , drop = FALSE]; nf <- calcNormFactors(cf, method = "TMM")
  v <- voom(cf, design = design, lib.size = colSums(cf) * nf, normalize.method = "none", plot = FALSE)
  fit <- eBayes(contrasts.fit(lmFit(v, design), C), robust = TRUE, trend = FALSE)
  sym <- toupper(gsym[match(rownames(cf), gid)])
  ok <- is.finite(fit$t[,1]) & !is.na(sym) & !duplicated(sym)
  stat <- fit$t[ok, 1]; names(stat) <- sym[ok]
  G <- length(stat)
  index <- lapply(hallmark, function(s) which(names(stat) %in% s))
  valid <- lengths(index) >= 5L & lengths(index) < G - 2L
  res <- list()
  for (rho in c(0.01, 0.05, 0.1)) {
    tab <- cameraPR(stat, index = index[valid], inter.gene.cor = rho, sort = FALSE)
    res[[length(res)+1]] <- data.table(setting = sprintf("rho%g", rho), pathway = rownames(tab), NGenes = tab$NGenes, Direction = tab$Direction, PValue = tab$PValue, est_cor = NA_real_)
  }
  vv <- v[ok, ]
  tab <- camera(vv, index = index[valid], design = design, contrast = c(-1, 1), inter.gene.cor = NA, sort = FALSE)
  res[[length(res)+1]] <- data.table(setting = "estimated", pathway = rownames(tab), NGenes = tab$NGenes, Direction = tab$Direction, PValue = tab$PValue, est_cor = tab$Correlation)
  out <- rbindlist(res); out[, `:=`(tissue_cohort = u$cohort, cell_type = u$cell_type)]; out
}
all <- rbindlist(lapply(units, run_unit))
all[, global_FDR := p.adjust(PValue, "BH"), by = setting]
stopifnot(all[, .N, by = setting]$N == 650)
# reproduce published 0.01 global FDR (rar Table S11A)
s11 <- fread(Sys.getenv("SC_PRIMARY_TABLE", "results/tables/Table_S11A_complete_650_primary_pseudobulk_results.csv"))
s11[, key := paste(celltype_analysis, pathway)]
a1 <- all[setting == "rho0.01"]; a1[, key := paste(paste(tissue_cohort, cell_type, sep = "_"), pathway)]
m <- merge(a1, s11, by = "key")
cat(sprintf("repro vs S11A: n=%d max|dP|=%.2e max|dFDR|=%.2e dir_mismatch=%d\n", nrow(m), max(abs(m$PValue.x - m$PValue.y)), max(abs(m$global_FDR.x - m$global_FDR.y)), sum(m$Direction.x != m$Direction.y)))
fwrite(all, file.path(OUTD, "sc_igc_all650.csv"))
