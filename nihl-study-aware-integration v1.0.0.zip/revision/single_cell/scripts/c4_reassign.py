"""A4/C4 stage 1: re-annotate with the stable marker panel (same scoring rule, same thresholds)."""
import os
import pickle, json, numpy as np, pandas as pd, scipy.sparse as sp
W=os.environ.get("SC_W","work")
libs=pickle.load(open(f"{W}/sc_out/libs.pkl","rb")); obs=pickle.load(open(f"{W}/sc_out/obs_raw.pkl","rb"))
Mats,Feats,meta=libs["Mats"],libs["Feats"],libs["meta"]
mk=pd.read_csv(os.environ.get("SC_MARKERS", "resources/annotations/cell_type_markers.csv"))
st=pd.read_pickle(f"{W}/sc_out/stable_panel.rds") if False else None
import subprocess
stable=[l.strip() for l in open(f"{W}/sc_out/stable_list.txt") if l.strip()]
panel=set(mk.marker_gene)
missing=[g for g in stable if g not in set(Feats[0])]
print("stable panel:",len(stable),stable); print("absent from matrix:",missing)
stable=[g for g in stable if g in set(Feats[0])]

# classes with <2 stable markers cannot be re-verified
cls_counts={ct: len([g for g in mk.marker_gene[mk.cell_type==ct] if g in stable]) for ct in mk.cell_type.unique()}
print("stable markers per class:", cls_counts)
unverifiable=[c for c,n in cls_counts.items() if n<2]
print("unverifiable classes:", unverifiable)

rec=[]
for i,sm in meta.iterrows():
    M,feat=Mats[i],Feats[i]
    cm=mk[mk.cohort_scope.isin(["both",sm.tissue_cohort])]
    types=[c for c in dict.fromkeys(cm.cell_type) if c not in unverifiable]
    keep=obs.loc[obs.sample_id==sm.sample_id,"qc_pass"].values
    gi={}
    for ct in types:
        g=[x for x in cm.loc[cm.cell_type==ct,"marker_gene"] if x in stable]
        gi[ct]=[int(np.where(feat==x)[0][0]) for x in g]
    rows_=np.array(sorted({k for v in gi.values() for k in v}))
    sub=M[rows_,:][:,keep].tocsc().astype(np.float64)
    lib=np.asarray(M.sum(axis=0)).ravel()[keep]
    sub=sp.diags(1e4/np.maximum(lib,1))@sub.T   # cells x rows_
    sub=sp.csr_matrix(sub); sub.data=np.log1p(sub.data)
    pos={g:k for k,g in enumerate(rows_)}
    score=np.zeros((sub.shape[0],len(types)))
    for j,ct in enumerate(types):
        if gi[ct]: score[:,j]=np.asarray(sub[:,[pos[k] for k in gi[ct]]].mean(axis=1)).ravel()
    top_i=score.argmax(axis=1); top=score[np.arange(len(top_i)),top_i]
    srt=np.sort(score,axis=1); second=srt[:,-2] if len(types)>1 else np.zeros(len(top))
    margin=top-second
    assigned=np.array(types,dtype=object)[top_i]
    assigned[(top<0.05)|(margin<0.01)]="unassigned"
    d=obs[(obs.sample_id==sm.sample_id)&obs.qc_pass].copy()
    d["stable_cell_type"]=assigned; d["stable_top"]=top; d["stable_margin"]=margin
    rec.append(d)
new=pd.concat(rec,ignore_index=True)
new.to_pickle(f"{W}/sc_out/obs_stable.pkl")
json.dump({"stable":stable,"unverifiable":unverifiable,"per_class":cls_counts},
          open(f"{W}/sc_out/stable_panel_meta.json","w"),indent=1)
print("\nnew annotation counts:", new.stable_cell_type.value_counts().to_dict())
print("cells from unverifiable original classes:",
      int(new.cell_type.isin(unverifiable).sum()))
