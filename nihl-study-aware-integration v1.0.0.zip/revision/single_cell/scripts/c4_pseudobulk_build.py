"""A4/C4 stage 3a: export the stable-marker (hybrid) cell annotation and rebuild per-sample
pseudobulk counts (rows = gene_id, one column per sample x cell class).

Reads   work/sc_out/obs_stable_hybrid.pkl   (written by c4_hybrid.py)
        work/sc_out/libs.pkl                (written by build_raw.py)
        resources/annotations/GSE168041_gene_map.csv
Writes  work/sc_out/obs_stable_hybrid.csv.gz
        work/sc_out/hybrid_pseudobulk_counts.csv.gz   -> read by c4_camera.R
        work/sc_out/hybrid_cell_counts.csv

Run with SC_W pointing at the run root (default ./work).
"""
import os, pickle, numpy as np, pandas as pd, scipy.sparse as sp, gzip
W = os.environ.get("SC_W", "work")
d=pd.read_pickle(f"{W}/sc_out/obs_stable_hybrid.pkl")
d[["sample_id","barcode","tissue_cohort","condition","cell_type","hybrid_cell_type","stable_cell_type",
   "n_count","top_marker_score","stable_top","stable_margin"]].to_csv(
   f"{W}/sc_out/obs_stable_hybrid.csv.gz", index=False, compression="gzip")

libs=pickle.load(open(f"{W}/sc_out/libs.pkl","rb"))
Mats,Feats,meta=libs["Mats"],libs["Feats"],libs["meta"]
master=pd.read_csv(os.environ.get("SC_GENE_MAP", "resources/annotations/GSE168041_gene_map.csv"))
gid=master.gene_id.values; gsym=master.gene_symbol.values
if "GeneIds" not in libs:
    raise ValueError("libs.pkl has no GeneIds; rerun build_raw.py with the current script before this step")
if master.gene_id.duplicated().any():
    raise ValueError("Gene map contains duplicate gene_id values")
cols={}; counts=[]
for i,sm in meta.iterrows():
    M,feat=Mats[i],Feats[i]
    sub=d[d.sample_id==sm.sample_id].reset_index(drop=True)
    # map library barcode -> column
    bmap=pd.Series(np.arange(M.shape[1]), index=None)
    libidx={b:k for k,b in enumerate(libs["Bcs"][i])}
    mi=np.asarray(libs["GeneIds"][i])
    if len(mi) != M.shape[0]:
        raise ValueError("Gene IDs do not align with library matrix rows")
    mp=pd.Series(np.arange(len(gid)), index=gid)
    rowmap=mp.reindex(mi).values
    ok=~pd.isna(rowmap)
    if not ok.all():
        raise ValueError("Library gene IDs are missing from the master gene map")
    rowmap=rowmap[ok].astype(int)
    for ct in sorted(sub.hybrid_cell_type.unique()):
        if ct=="unassigned": continue
        cells=sub.index[sub.hybrid_cell_type==ct].values
        colidx=np.array([libidx[sub.barcode[j]] for j in cells])
        agg=np.asarray(M[:,colidx].sum(axis=1)).ravel()
        v=np.zeros(len(gid)); np.add.at(v, rowmap, agg[ok])
        key=f"{sm.sample_id}__{ct}"
        cols[key]=len(counts); counts.append(v)
C=np.column_stack(counts); C=pd.DataFrame(C, columns=list(cols)); C.insert(0,"gene_symbol",gsym); C.insert(0,"gene_id",gid)
C.to_csv(f"{W}/sc_out/hybrid_pseudobulk_counts.csv.gz", index=False, compression="gzip")
print("pseudobulk:", C.shape, "units:", len(cols))
cc=[]
for key in cols:
    sid,ct=key.split("__")
    tot=C[key].sum()
    cc.append(dict(sample_id=sid, cell_type=ct, n_cells=int(((d.sample_id==sid)&(d.hybrid_cell_type==ct)).sum()),
                   library_size=int(tot), detected_genes=int((C[key]>0).sum())))
pd.DataFrame(cc).to_csv(f"{W}/sc_out/hybrid_cell_counts.csv", index=False)
print(pd.DataFrame(cc).groupby("cell_type").agg(n=("sample_id","size"), median_cells=("n_cells","median")).to_string())
