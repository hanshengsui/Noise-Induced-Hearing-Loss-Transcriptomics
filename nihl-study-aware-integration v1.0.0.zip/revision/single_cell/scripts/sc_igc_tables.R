#!/usr/bin/env Rscript
# Pivot and summarise sc_igc_all650.csv into the two published inter.gene.cor tables.
#
# sc_igc_all650.csv (written by sc_igc_sensitivity.R) is long: one row per setting x cell unit x Hallmark,
# settings = rho0.01 (reference), rho0.05, rho0.1, estimated.
#   sc_igc_sensitivity.csv  wide: the 13 eligible units x the four focused programs (52 rows), four settings
#                           side by side plus direction/FDR-category retention flags
#   sc_igc_summary.csv      per scope and setting: n, directions kept, FDR categories kept, significant counts
#                           scope Table4_52cells = the 52 focused cells; all_650 = all 13 units x 50 Hallmarks
#
# "sig_at_0.01" = cells with global FDR < 0.10 under inter.gene.cor = 0.01; "sig_kept" = of those, still < 0.10.
# Usage: Rscript sc_igc_tables.R [<sc_igc_all650.csv>] [<out dir>]
# Outputs are written to the shipped library-revision results directory by default.

suppressPackageStartupMessages(library(data.table))
args <- commandArgs(trailingOnly = TRUE)
inp  <- if (length(args) >= 1) args[1] else file.path(Sys.getenv("SC_W", "work"), "sc_out", "sc_igc_all650.csv")
outd <- if (length(args) >= 2) args[2] else dirname(inp)

all <- fread(inp)
# Category used in the published tables: the direction if global FDR < 0.10, otherwise "ns".
all[, cat := ifelse(global_FDR < 0.10, Direction, "ns")]
setnames(all, c("Direction", "global_FDR"), c("direction", "fdr"))

focal <- c(HALLMARK_TNFA_SIGNALING_VIA_NFKB = "TNFA", HALLMARK_INFLAMMATORY_RESPONSE = "INFL",
           HALLMARK_UNFOLDED_PROTEIN_RESPONSE = "UPR", HALLMARK_OXIDATIVE_PHOSPHORYLATION = "OXPHOS")

## ---- published wide table: the 52 focused cells ----
f <- all[pathway %in% names(focal)]
w <- dcast(f, tissue_cohort + cell_type + pathway ~ setting,
           value.var = c("direction", "cat", "fdr"), sep = "_")
setcolorder(w, c("tissue_cohort", "cell_type", "pathway",
                 paste0(rep(c("direction", "cat", "fdr"), each = 4), "_",
                        rep(c("estimated", "rho0.01", "rho0.05", "rho0.1"), times = 3))))
for (s in c("rho0.05", "rho0.1", "estimated")) {
  w[, paste0("dir_kept_", s) := get(paste0("direction_", s)) == direction_rho0.01]
  w[, paste0("cat_kept_", s) := get(paste0("cat_", s)) == cat_rho0.01]
}
setnames(w, c("cat_estimated", "cat_rho0.01", "cat_rho0.05", "cat_rho0.1",
              "fdr_estimated", "fdr_rho0.01", "fdr_rho0.05", "fdr_rho0.1"),
         c("cat_estimated", "cat_rho0.01", "cat_rho0.05", "cat_rho0.1",
           "global_FDR_estimated", "global_FDR_rho0.01", "global_FDR_rho0.05", "global_FDR_rho0.1"))
setnames(w, gsub("^direction_", "Direction_", names(w)))
w[, program := focal[pathway]]
fwrite(w, file.path(outd, "sc_igc_sensitivity.csv"))

## ---- published summary: 52 focused cells and all 650 ----
scope_of <- function(d) d
summ <- rbindlist(lapply(c("Table4_52cells", "all_650"), function(sc) {
  d <- if (sc == "Table4_52cells") f else all
  rbindlist(lapply(c("rho0.05", "rho0.1", "estimated"), function(s) {
    b <- d[setting == "rho0.01"]; a <- d[setting == s]
    m <- merge(b, a, by = c("tissue_cohort", "cell_type", "pathway"), suffixes = c("_b", "_a"))
    tab <- function(cut) {
      b <- m$fdr_b < cut; a <- m$fdr_a < cut
      c(n_sig = sum(b), n_kept = sum(b & a))
    }
    t10 <- tab(0.10)
    data.table(scope = sc, setting = s, n = nrow(m),
               dir_kept = sum(m$direction_b == m$direction_a),
               cat_kept = sum(m$cat_b == m$cat_a),
               sig_at_0.01 = t10[["n_sig"]], sig_kept = t10[["n_kept"]])
  }))
}))
fwrite(summ, file.path(outd, "sc_igc_summary.csv"))
cat("sc_igc_sensitivity.csv:", nrow(w), "rows; sc_igc_summary.csv:", nrow(summ), "rows\n")
