## Shared helpers for the Preprocessing line (A2).
## All parameters follow Appendix B1.1-B1.5; nothing here deviates from it.

## the side library must come FIRST so limma 3.62.2 / edgeR 4.4.2 are used
if (nzchar(Sys.getenv("NIHL_VALIDATION_LIB")) &&
    dir.exists(Sys.getenv("NIHL_VALIDATION_LIB"))) {
  .libPaths(unique(c(normalizePath(Sys.getenv("NIHL_VALIDATION_LIB")), .libPaths())))
}

suppressPackageStartupMessages({
  library(limma)
  library(edgeR)
  library(ggplot2)
})

set.seed(20261029)

W <- Sys.getenv("A2_W", normalizePath("work"))
DATA <- file.path(W, "prj/Expanded_Validation/downloads")
EXP_RES <- file.path(W, "prj/Expanded_Validation/results/expanded_validation")
LEGACY <- file.path(W, "out/legacy")
REV <- file.path(W, "rev")
FIGS <- file.path(W, "figs")
dir.create(REV, showWarnings = FALSE, recursive = TRUE)
dir.create(FIGS, showWarnings = FALSE, recursive = TRUE)

read_gmt <- function(path) {
  z <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  z <- z[lengths(z) >= 3]
  ans <- lapply(z, function(x) unique(toupper(x[-c(1, 2)])))
  names(ans) <- vapply(z, `[[`, character(1), 1)
  ans
}

hallmark50 <- read_gmt(file.path(DATA, "h.all.v2024.1.Hs.symbols.gmt"))
stopifnot(length(hallmark50) == 50L)

FOCAL <- c(
  TNFA = "HALLMARK_TNFA_SIGNALING_VIA_NFKB",
  INFL = "HALLMARK_INFLAMMATORY_RESPONSE",
  UPR = "HALLMARK_UNFOLDED_PROTEIN_RESPONSE",
  OXPHOS = "HALLMARK_OXIDATIVE_PHOSPHORYLATION",
  E2F = "HALLMARK_E2F_TARGETS"
)

## The single gene-set -> index mapping used EVERYWHERE (cameraPR and coverage).
## Whitespace-insensitivity is not added: the original code uppercases symbols and
## matches directly, so we do exactly the same.
make_index <- function(statistic, pathways = hallmark50) {
  statistic <- statistic[is.finite(statistic)]
  names(statistic) <- toupper(names(statistic))
  statistic <- statistic[!duplicated(names(statistic))]
  G <- length(statistic)
  index <- lapply(pathways, function(set) which(names(statistic) %in% set))
  valid <- lengths(index) >= 5L & lengths(index) < G - 2L
  list(index = index[valid], valid = valid, G = G, statistic = statistic)
}

## cameraPR with the original signed-t back-conversion and BH over the
## tested Hallmark family (the family is what limma returns from cameraPR,
## i.e. BH within the valid sets of this contrast = 50_hallmark_within_contrast).
camera_pr <- function(statistic, pathways = hallmark50, dataset, contrast,
                      scheme, collection = "human_hallmark_direct_symbol",
                      df = NULL) {
  mi <- make_index(statistic, pathways)
  if (!length(mi$index)) return(NULL)
  tab <- limma::cameraPR(mi$statistic, index = mi$index,
                         inter.gene.cor = 0.01, use.ranks = FALSE, sort = FALSE)
  dff <- if (is.null(df)) mi$G - 2 else df
  signed_t <- ifelse(tab$Direction == "Up",
                     qt(tab$PValue / 2, df = dff, lower.tail = FALSE),
                     qt(tab$PValue / 2, df = dff))
  data.frame(
    dataset = dataset, contrast = contrast, scheme = scheme,
    collection = collection, program = rownames(tab),
    n_genes_in_set = tab$NGenes, statistic = signed_t,
    direction = tab$Direction, p_value = tab$PValue, fdr = tab$FDR,
    fdr_family = "50_hallmark_within_contrast",
    ranked_universe = mi$G,
    stringsAsFactors = FALSE, row.names = NULL
  )
}

fdr_category <- function(fdr) {
  ifelse(fdr < 0.05, "conf", ifelse(fdr < 0.10, "expl", "ns"))
}

program_code <- function(msig_name) {
  rev <- setNames(names(FOCAL), unname(FOCAL))
  out <- rev[msig_name]
  out[is.na(out)] <- msig_name[is.na(out)]
  unname(out)
}

## Human-readable scheme labels. G1 (2026-10-30) ruled that the deposited
## GSE196870 matrix is ALREADY log2 scaled, so S0 (use the values as deposited)
## is the main analysis and S1/S3 apply a SECOND log on top of it.
SCHEME_LABEL <- c(
  S0 = "S0: deposited values used as-is (log2 scale) - main analysis",
  S1 = "S1: additional log2(x+1) on deposited log-scale values",
  S2 = "S2: stricter gene filter + additional log2(x+1) on deposited log-scale values",
  S3 = "S3: additional log2(x+0.1) on deposited log-scale values"
)

## Signed z from a cameraPR p and direction (Appendix B1.3).
signed_z <- function(p, dir) ifelse(dir == "Up", 1, -1) * qnorm(p / 2, lower.tail = FALSE)

stouffer <- function(z, w = rep(1, length(z))) sum(w * z) / sqrt(sum(w^2))
