#!/usr/bin/env Rscript
## A2 step 4a: gene retention per data set / scheme / analysis unit (B1.4).
source(file.path(Sys.getenv("A2_SCR"), "common.R"))
suppressPackageStartupMessages({library(edgeR); library(readxl)})

obj196 <- readRDS(file.path(REV, "GSE196870_objects.rds"))
obj312 <- readRDS(file.path(REV, "GSE312476_objects.rds"))

## raw feature counts, read from the deposited files (not from memory)
n196_raw <- nrow(read.csv(gzfile(file.path(DATA, "GSE196870_Raw_gene_FPKM_matrix.txt.csv.gz")),
                          check.names = FALSE, colClasses = "character"))
xl <- file.path(DATA, "GSE312476_Table_S1.xlsx")
n312_raw <- nrow(as.data.frame(read_excel(xl, sheet = "Bulk_RNA_seq_data", skip = 2)))

gk <- read.csv(file.path(REV, "GSE312476_grid_gene_counts.csv"), stringsAsFactors = FALSE)

bulk <- rbind(
  data.frame(dataset = "GSE196870", analysis_unit = "whole cochlea; 1h & 24h vs control",
             scheme = c("S0 (main)", "S1 (double log)", "S2 (stricter filter + double log)", "S3 (double log)"),
             n_features_raw = n196_raw,
             n_symbols = nrow(obj196$rep196$expression),
             n_after_filter = c(nrow(obj196$E$S0), nrow(obj196$E$S1),
                                nrow(obj196$E$S2), nrow(obj196$E$S3)),
             n_tested = c(nrow(obj196$E$S0), nrow(obj196$E$S1),
                          nrow(obj196$E$S2), nrow(obj196$E$S3)),
             stringsAsFactors = FALSE),
  data.frame(dataset = "GSE312476", analysis_unit = "whole cochlea; exposure-end/4h/8h",
             scheme = c("S0 (published)", setdiff(gk$scheme, "S0")),
             n_features_raw = n312_raw,
             n_symbols = nrow(obj312$cnt),
             n_after_filter = c(gk$n_after_filter[gk$scheme == "S0"],
                                gk$n_after_filter[gk$scheme != "S0"]),
             n_tested = c(gk$n_after_filter[gk$scheme == "S0"],
                          gk$n_after_filter[gk$scheme != "S0"]),
             stringsAsFactors = FALSE))

## the four data sets Baseline already quantified (kept verbatim, marked as S0)
bulk_base <- read.csv(file.path(REV, "gene_retention_baseline_bulk.csv"), stringsAsFactors = FALSE)
bulk_base <- bulk_base[bulk_base$dataset %in% c("GSE160639", "GSE100365", "GSE8342",
                                                "E-MTAB-16125"), ]
bulk_base$scheme <- "S0 (published)"

## ---- single cell: cohort x class -------------------------------------
pb <- read.csv(gzfile(file.path(LEGACY,
        "source_data/GSE168041_celltype/mouse_celltype_pseudobulk_counts.csv.gz")),
        check.names = FALSE)
pb_keys <- names(pb)[-(1:2)]
cc <- read.csv(file.path(LEGACY,
  "source_data/GSE168041_celltype/cell_counts_and_library_sizes.csv"), stringsAsFactors = FALSE)
cat("cell_counts columns:", names(cc), "\n")

sc <- list()
for (i in seq_len(nrow(cc))) {
  cohort <- cc$tissue_cohort[i]; ct <- cc$cell_type[i]
  if (identical(ct, "unassigned")) next
  z <- cc[cc$tissue_cohort == cohort & cc$cell_type == ct &
            cc$n_cells >= 20 & cc$library_size >= 5000, ]
  n_naive <- sum(z$condition == "naive"); n_noise <- sum(z$condition == "noise")
  eligible <- n_naive >= 3 && n_noise >= 3
  n_after <- NA_integer_
  if (eligible) {
    cols <- pb_keys[match(paste(z$sample_id, ct, sep = "__"), pb_keys)]
    cols <- cols[!is.na(cols)]
    if (length(cols) >= 2) {
      cnt <- as.matrix(pb[, cols, drop = FALSE]); storage.mode(cnt) <- "numeric"
      rownames(cnt) <- pb$gene_id
      cond <- factor(z$condition[match(sub("__.*$", "", cols), z$sample_id)],
                     levels = c("naive", "noise"))
      if (length(unique(cond)) == 2) {
        dsn <- model.matrix(~0 + cond)
        n_after <- sum(filterByExpr(cnt, design = dsn, min.count = 10, min.total.count = 15))
      }
    }
  }
  id <- paste(cohort, ct, sep = " / ")
  if (id %in% names(sc)) next          # each cohort x class appears once
  sc[[id]] <- data.frame(
    dataset = "GSE168041", analysis_unit = id,
    scheme = if (eligible) "S0 (published pseudobulk)" else "not eligible",
    n_features_raw = nrow(pb), n_symbols = nrow(pb),
    n_after_filter = n_after, n_tested = n_after,
    tissue_cohort = cohort, cell_type = ct,
    n_naive_libraries = n_naive, n_noise_libraries = n_noise,
    inferentially_eligible = eligible, stringsAsFactors = FALSE)
}
sc_tab <- do.call(rbind, sc); rownames(sc_tab) <- NULL

out <- rbind(
  data.frame(bulk[, c("dataset", "analysis_unit", "scheme", "n_features_raw",
                      "n_symbols", "n_after_filter", "n_tested")],
             tissue_cohort = NA_character_, cell_type = NA_character_,
             n_naive_libraries = NA_integer_, n_noise_libraries = NA_integer_,
             inferentially_eligible = NA),
  data.frame(bulk_base[, c("dataset", "analysis_unit", "scheme", "n_features_raw",
                           "n_symbols", "n_after_filter", "n_tested")],
             tissue_cohort = NA_character_, cell_type = NA_character_,
             n_naive_libraries = NA_integer_, n_noise_libraries = NA_integer_,
             inferentially_eligible = NA),
  sc_tab)
write.csv(out, file.path(REV, "gene_retention.csv"), row.names = FALSE)
cat("rows:", nrow(out), " eligible sc units:", sum(sc_tab$inferentially_eligible), "\n")
