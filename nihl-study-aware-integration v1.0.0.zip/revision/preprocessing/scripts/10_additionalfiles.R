#!/usr/bin/env Rscript
## A2: turn the retention and coverage tables into publication-shaped
## Additional-file tables (sheet-ready, English headers, first two rows free
## for the title and legend that the Writing line will add).
source(file.path(Sys.getenv("A2_SCR"), "common.R"))

gr <- read.csv(file.path(REV, "gene_retention.csv"), stringsAsFactors = FALSE)
cv <- read.csv(file.path(REV, "hallmark_coverage.csv"), stringsAsFactors = FALSE)

## ---- Additional file: gene retention ---------------------------------
gr_out <- data.frame(
  Dataset = gr$dataset,
  `Analysis unit` = gr$analysis_unit,
  `Preprocessing scheme` = gr$scheme,
  `Features in deposited matrix` = gr$n_features_raw,
  `Genes after symbol mapping and collapsing` = gr$n_symbols,
  `Genes after filtering` = gr$n_after_filter,
  `Genes tested (universe used by CAMERA-PR)` = gr$n_tested,
  `Single-cell libraries, naive` = gr$n_naive_libraries,
  `Single-cell libraries, noise` = gr$n_noise_libraries,
  `Eligible for inference` = gr$inferentially_eligible,
  check.names = FALSE, stringsAsFactors = FALSE)
write.csv(gr_out, file.path(REV, "Additional_file_gene_retention.csv"), row.names = FALSE)

## ---- Additional file: Hallmark coverage ------------------------------
## one row per analysis unit and programme, wide by the five focal programmes
## would lose the other 45, so the full long table is the deliverable and a
## separate compact summary gives the median mapped fraction per unit.
cv_out <- data.frame(
  Dataset = cv$dataset,
  `Analysis unit` = cv$analysis_unit,
  `Hallmark programme` = sub("^HALLMARK_", "", cv$program),
  `Genes in MSigDB set` = cv$set_size,
  `Genes mapped in this unit` = cv$n_mapped,
  `Mapped fraction` = round(cv$frac, 4),
  `Genes in test universe` = cv$n_tested_genes,
  `Included by CAMERA-PR` = cv$camera_valid,
  `Gene-set source` = cv$collection,
  check.names = FALSE, stringsAsFactors = FALSE)
write.csv(cv_out, file.path(REV, "Additional_file_hallmark_coverage.csv"), row.names = FALSE)

## compact per-unit summary: median / min mapped fraction over the 50 sets,
## and the five focal programmes side by side
## FOCAL is a NAMED character vector: index it by name (unname() would make
## focal_names["TNFA"] NA and silently recycle rows to the full table length)
focal_frac <- function(z, code) {
  v <- z$frac[z$program == FOCAL[[code]]]
  if (!length(v)) NA_real_ else round(v, 4)
}
summ <- do.call(rbind, lapply(split(cv, cv$analysis_unit), function(z) {
  data.frame(
    Dataset = z$dataset[1],
    `Analysis unit` = z$analysis_unit[1],
    `Median mapped fraction, 50 Hallmark sets` = round(median(z$frac), 4),
    `Minimum mapped fraction, 50 Hallmark sets` = round(min(z$frac), 4),
    `TNFA mapped fraction` = focal_frac(z, "TNFA"),
    `INFL mapped fraction` = focal_frac(z, "INFL"),
    `UPR mapped fraction` = focal_frac(z, "UPR"),
    `OXPHOS mapped fraction` = focal_frac(z, "OXPHOS"),
    `E2F mapped fraction` = focal_frac(z, "E2F"),
    `Sets included by CAMERA-PR` = sum(z$camera_valid),
    check.names = FALSE, stringsAsFactors = FALSE)
}))
rownames(summ) <- NULL
stopifnot(nrow(summ) == length(unique(cv$analysis_unit)),
          !any(duplicated(summ$`Analysis unit`)))
write.csv(summ, file.path(REV, "hallmark_coverage_unit_summary.csv"), row.names = FALSE)

cat("retention rows:", nrow(gr_out), " coverage rows:", nrow(cv_out),
    " units:", nrow(summ), "\n")
