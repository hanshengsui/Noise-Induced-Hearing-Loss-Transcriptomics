#!/usr/bin/env Rscript
## A2 step 4b: Hallmark coverage per analysis unit, computed from the very
## index object cameraPR used (Appendix B1.4 requirement).
source(file.path(Sys.getenv("A2_SCR"), "common.R"))
suppressPackageStartupMessages({library(edgeR); library(readxl)})

## Build the statistic (gene -> moderated t) for every analysis unit exactly as
## the analysis scripts did; the coverage then comes from make_index() on that
## vector, so the counted genes are the genes actually tested.

units <- list()   # each entry: name, dataset, contrast, stat (named by SYMBOL), collection

## ---- expanded-validation studies (published gene-level tables) --------
ev <- file.path(EXP_RES)
add_from_table <- function(ds, contrast, path) {
  z <- read.csv(gzfile(path), stringsAsFactors = FALSE)
  s <- setNames(z$moderated_t, z$gene_symbol)
  units[[paste(ds, contrast)]] <<- list(dataset = ds, contrast = contrast, stat = s,
                                        source = "expanded_validation")
}
for (ds in c("GSE160639", "GSE196870", "GSE312476", "GSE100365")) {
  fs <- list.files(file.path(ev, ds), pattern = "__complete_results[.]csv[.]gz$")
  for (f in fs) {
    contrast <- sub("^.*__", "", sub("__complete_results.csv.gz$", "", f))
    add_from_table(ds, contrast, file.path(ev, ds, f))
  }
}

## ---- E-MTAB-16125 (legacy gene-level tables) -------------------------
for (f in list.files(file.path(LEGACY, "results/E-MTAB-16125"), pattern = "^E-MTAB.*[.]csv[.]gz$")) {
  z <- read.csv(gzfile(file.path(LEGACY, "results/E-MTAB-16125", f)), stringsAsFactors = FALSE)
  contrast <- sub("^E-MTAB-16125__", "", sub("[.]csv[.]gz$", "", f))
  contrast <- sub("__complete_results$", "", contrast)
  units[[paste("E-MTAB-16125", contrast)]] <- list(
    dataset = "E-MTAB-16125", contrast = contrast,
    stat = setNames(z$moderated_t, z$gene_symbol), source = "legacy")
}

## ---- GSE8342 (legacy representative-probe tables) --------------------
g8342 <- list.files(file.path(LEGACY, "results/GSE8342"),
                    pattern = "^representative_probe__.*[.]csv[.]gz$")
for (f in g8342) {
  z <- read.csv(gzfile(file.path(LEGACY, "results/GSE8342", f)), stringsAsFactors = FALSE)
  contrast <- sub("^representative_probe__", "", sub("[.]csv[.]gz$", "", f))
  z$symbol_key <- toupper(z$gene_symbol)
  z <- z[order(z$symbol_key, -abs(z$moderated_t)), ]
  z <- z[!duplicated(z$symbol_key), ]
  units[[paste("GSE8342", contrast)]] <- list(
    dataset = "GSE8342", contrast = contrast,
    stat = setNames(z$moderated_t, z$symbol_key), source = "legacy")
}

## ---- GSE107086 (legacy) ----------------------------------------------
for (f in list.files(file.path(LEGACY, "results/GSE107086"), pattern = "^GSE107086__.*[.]csv[.]gz$")) {
  z <- read.csv(gzfile(file.path(LEGACY, "results/GSE107086", f)), stringsAsFactors = FALSE)
  if (!"moderated_t" %in% names(z) || !"gene_symbol" %in% names(z)) next
  z$symbol_key <- toupper(z$gene_symbol)
  z <- z[order(z$symbol_key, -abs(z$moderated_t)), ]
  z <- z[!duplicated(z$symbol_key), ]
  contrast <- sub("^GSE107086__", "", sub("[.]csv[.]gz$", "", f))
  units[[paste("GSE107086", contrast)]] <- list(
    dataset = "GSE107086", contrast = contrast,
    stat = setNames(z$moderated_t, z$symbol_key), source = "legacy")
}

## ---- GSE168041 pseudobulk cell classes -------------------------------
sc_files <- list.files(file.path(LEGACY, "results/GSE168041_celltype"),
                       pattern = "__noise_vs_naive[.]csv[.]gz$")
for (f in sc_files) {
  z <- read.csv(gzfile(file.path(LEGACY, "results/GSE168041_celltype", f)), stringsAsFactors = FALSE)
  if (!"moderated_t" %in% names(z) || !"gene_symbol" %in% names(z)) next
  z$symbol_key <- toupper(z$gene_symbol)
  z <- z[order(z$symbol_key, -abs(z$moderated_t)), ]
  z <- z[!duplicated(z$symbol_key), ]
  unit <- sub("__noise_vs_naive[.]csv[.]gz$", "", f)
  units[[paste("GSE168041", unit)]] <- list(
    dataset = "GSE168041", contrast = "noise_vs_naive", analysis_unit = unit,
    stat = setNames(z$moderated_t, z$symbol_key), source = "legacy_pseudobulk")
}

## ---- coverage rows ---------------------------------------------------
rows <- list()
for (nm in names(units)) {
  u <- units[[nm]]
  ## the SAME function cameraPR uses -> the same idx
  mi <- make_index(u$stat, hallmark50)
  set_names <- names(hallmark50)
  for (p in set_names) {
    has <- p %in% names(mi$index)
    n_mapped <- if (has) length(mi$index[[p]]) else sum(mi$statistic %in% hallmark50[[p]])
    rows[[paste(nm, p)]] <- data.frame(
      dataset = u$dataset,
      contrast = if (is.null(u$analysis_unit)) u$contrast else u$analysis_unit,
      analysis_unit = paste(u$dataset, if (is.null(u$analysis_unit)) u$contrast else u$analysis_unit),
      program = p,
      set_size = length(hallmark50[[p]]),
      n_mapped = n_mapped,
      frac = n_mapped / length(hallmark50[[p]]),
      n_tested_genes = mi$G,
      passes_camera_minimum = has,
      collection = u$source,
      stringsAsFactors = FALSE)
  }
}
cov <- do.call(rbind, rows); rownames(cov) <- NULL
## a program is usable only when it has >=5 mapped genes and is not the universe
cov$camera_valid <- cov$passes_camera_minimum & cov$n_mapped >= 5
write.csv(cov, file.path(REV, "hallmark_coverage.csv"), row.names = FALSE)

summ <- aggregate(cbind(n_mapped, set_size) ~ analysis_unit,
                  data = cov, FUN = function(x) mean(x))
print(dim(cov))
print(head(summ, 5))
cat("units:", length(unique(cov$analysis_unit)), " programs:", length(unique(cov$program)), "\n")
