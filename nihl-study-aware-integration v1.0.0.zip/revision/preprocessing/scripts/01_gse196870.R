#!/usr/bin/env Rscript
## A2 step 1: GSE196870 scale diagnostics + S0-S3 sensitivity (Appendix B1.1).
source(file.path(Sys.getenv("A2_SCR"), "common.R"))

## ---- data (identical read and collapse as 01_expanded_bulk_validation.R) ----
g196 <- read.csv(gzfile(file.path(DATA, "GSE196870_Raw_gene_FPKM_matrix.txt.csv.gz")),
                 check.names = FALSE)
g196_cols <- c(paste0("MUS_", 1:4), paste0("PN_1h_", 1:4), paste0("PN_24h_", 1:4))
expr0 <- as.matrix(g196[, g196_cols, drop = FALSE])
storage.mode(expr0) <- "numeric"
rownames(expr0) <- g196$id
n_features_raw <- nrow(expr0)

## collapse = representative feature by mean (def.GSE196870.collapse)
representative_by_mean <- function(expr, symbols, feature_ids = rownames(expr)) {
  symbols <- toupper(symbols)
  ok <- !is.na(symbols) & nzchar(symbols) & symbols != "N/A" & !grepl("///", symbols, fixed = TRUE)
  expr <- expr[ok, , drop = FALSE]; symbols <- symbols[ok]; feature_ids <- feature_ids[ok]
  avg <- rowMeans(expr, na.rm = TRUE)
  ord <- order(symbols, -avg, feature_ids)
  expr <- expr[ord, , drop = FALSE]; symbols <- symbols[ord]; feature_ids <- feature_ids[ord]
  keep <- !duplicated(symbols)
  list(expression = expr[keep, , drop = FALSE], symbols = symbols[keep],
       feature_ids = feature_ids[keep])
}
rep196 <- representative_by_mean(expr0, g196$gene, g196$id)
fpkm <- rep196$expression
n_symbols <- nrow(fpkm)

sym196 <- rep196$symbols          # cameraPR statistics are named by SYMBOL (original code)
keep0 <- rowMeans(fpkm) > 0.5 & apply(fpkm, 1, sd) > 0
keep2 <- rowSums(fpkm > 1) >= 4
sym0 <- sym196[keep0]
sym2 <- sym196[keep2]

## G1 裁决 (2026-10-30)：存放矩阵本身已是 log2 尺度（每样本中位数 3.2、
## 99.9% 分位约 11、99.6% 非整数，反变换后总和 5.4-6.3e5），因此 S0 = 直接
## 使用存放值，是修回版的主分析；S1 与 S3 是在 log 尺度上再取一次 log（双重
## 变换），S2 是更严格过滤加额外 log 的联合方案。三者都是敏感性分析。
E <- list(
  S0 = fpkm[keep0, , drop = FALSE],
  S1 = log2(fpkm[keep0, , drop = FALSE] + 1),
  S2 = log2(fpkm[keep2, , drop = FALSE] + 1),
  S3 = log2(fpkm[keep0, , drop = FALSE] + 0.1)
)
names(E) <- names(SCHEME_LABEL)
SYM <- list(S0 = sym0, S1 = sym0, S2 = sym2, S3 = sym0)

group <- factor(c(rep("control", 4), rep("noise_1h", 4), rep("noise_24h", 4)),
                levels = c("control", "noise_1h", "noise_24h"))
design <- model.matrix(~0 + group)
colnames(design) <- levels(group)
cm <- makeContrasts(h1 = noise_1h - control, h24 = noise_24h - control, levels = design)

## ---- diagnostics -------------------------------------------------------
diag_rows <- list()
for (s in names(E)) {
  mat <- E[[s]]
  diag_rows[[s]] <- data.frame(
    scheme = s, n_after_filter = nrow(mat),
    min = min(mat), q25 = quantile(mat, .25), median = median(mat),
    q75 = quantile(mat, .75), max = max(mat),
    mean_sd_ratio_max = max(apply(mat, 1, sd) / pmax(rowMeans(mat), 1e-12)),
    stringsAsFactors = FALSE)
}
diag_tab <- do.call(rbind, diag_rows)
rownames(diag_tab) <- NULL
write.csv(diag_tab, file.path(REV, "GSE196870_scale_diagnostics.csv"), row.names = FALSE)

## per-sample library size (sum of FPKM) and detected genes (FPKM > 1)
qc_samp <- data.frame(
  sample_id = colnames(fpkm),
  group = as.character(group),
  fpkm_sum = colSums(fpkm),
  n_detected_fpkm_gt1 = colSums(fpkm > 1),
  stringsAsFactors = FALSE)
write.csv(qc_samp, file.path(REV, "GSE196870_sample_qc.csv"), row.names = FALSE)

## ---- fits & cameraPR --------------------------------------------------
res_all <- list()
fit_list <- list()
gtab <- list()
for (s in names(E)) {
  fit <- lmFit(E[[s]], design)
  fit2 <- eBayes(contrasts.fit(fit, cm), trend = TRUE, robust = TRUE)
  fit_list[[s]] <- fit2
  for (k in colnames(cm)) {
    tt <- fit2$t[, k]
    names(tt) <- SYM[[s]]
    ttg <- topTable(fit2, coef = k, number = Inf, sort.by = "none")
    gtab[[paste(s, k)]] <- data.frame(
      dataset = "GSE196870", scheme = s,
      contrast = setNames(c("noise_1h_vs_control", "noise_24h_vs_control"),
                          c("h1", "h24"))[[k]],
      gene_symbol = SYM[[s]], logFC = ttg$logFC, AveExpr = ttg$AveExpr,
      moderated_t = ttg$t, PValue = ttg$P.Value, FDR = ttg$adj.P.Val,
      stringsAsFactors = FALSE)
    res_all[[paste(s, k)]] <- camera_pr(tt, hallmark50, "GSE196870",
                                        setNames(c("noise_1h_vs_control", "noise_24h_vs_control"),
                                                 c("h1", "h24"))[[k]],
                                        s)   # df = G-2, the published convention
  }
}
sens <- do.call(rbind, res_all)
rownames(sens) <- NULL
sens$fdr_category <- fdr_category(sens$fdr)
write.csv(sens, file.path(REV, "GSE196870_preproc_sensitivity.csv"), row.names = FALSE)

## ---- check: S0 reproduces the published values ------------------------
pub <- read.csv(file.path(EXP_RES, "expanded_programme_results_complete.csv"))
pub <- pub[pub$dataset == "GSE196870" &
             pub$collection == "Human Hallmark v2024.1 direct-symbol match", ]
names(pub)[names(pub) == "programme"] <- "program"
chk <- merge(sens[sens$scheme == "S0", c("contrast", "program", "statistic", "p_value", "fdr")],
             pub[, c("contrast", "program", "camera_t", "PValue", "FDR")],
             by = c("contrast", "program"), suffixes = c("_new", "_pub"))
chk$abs_diff_t <- abs(chk$statistic - chk$camera_t)
chk$abs_diff_p <- abs(chk$p_value - chk$PValue)
write.csv(chk, file.path(REV, "GSE196870_S0_reproduction_check.csv"), row.names = FALSE)

## full 50-Hallmark agreement vs S0
agree <- list()
for (s in c("S1", "S2", "S3")) {
  for (k in c("noise_1h_vs_control", "noise_24h_vs_control")) {
    a <- sens[sens$scheme == s & sens$contrast == k, ]
    b <- sens[sens$scheme == "S0" & sens$contrast == k, ]
    m <- merge(a[, c("program", "direction", "fdr_category")],
               b[, c("program", "direction", "fdr_category")],
               by = "program", suffixes = c("_new", "_S0"))
    agree[[paste(s, k)]] <- data.frame(
      scheme = s, contrast = k, n_programs = nrow(m),
      n_same_direction = sum(m$direction_new == m$direction_S0),
      agree_frac = mean(m$direction_new == m$direction_S0),
      n_same_fdr_category = sum(m$fdr_category_new == m$fdr_category_S0),
      stringsAsFactors = FALSE)
  }
}
agree_tab <- do.call(rbind, agree)
rownames(agree_tab) <- NULL
write.csv(agree_tab, file.path(REV, "GSE196870_agree_frac.csv"), row.names = FALSE)

## ---- focal 5 programme summary ---------------------------------------
focal_tab <- sens[sens$program %in% unname(FOCAL), ]
focal_tab$program_code <- program_code(focal_tab$program)
focal_wide <- reshape(focal_tab[, c("contrast", "program_code", "scheme", "statistic", "fdr", "fdr_category")],
                      idvar = c("contrast", "program_code"), timevar = "scheme", direction = "wide")
write.csv(focal_wide, file.path(REV, "GSE196870_focal_by_scheme.csv"), row.names = FALSE)

## gene-level tables under every scheme (step 5 needs them)
gene_tab <- do.call(rbind, gtab); rownames(gene_tab) <- NULL
## the main analysis is S0, so the gene-level table used downstream is S0
write.csv(gene_tab[gene_tab$scheme == "S0",
                   c("dataset", "contrast", "scheme", "gene_symbol", "logFC",
                     "AveExpr", "moderated_t", "PValue", "FDR")],
          file.path(REV, "GSE196870_gene_level_S0.csv"), row.names = FALSE)
saveRDS(gene_tab, file.path(REV, "GSE196870_gene_level_all_schemes.rds"))

saveRDS(list(fit_list = fit_list, E = E, design = design, cm = cm, group = group,
             sens = sens, fpkm = fpkm, rep196 = rep196, keep0 = keep0, keep2 = keep2,
             sym0 = sym0, sym2 = sym2),
        file.path(REV, "GSE196870_objects.rds"))

## the published values correspond to S0 (deposited scale), which is also the
## revised main analysis under the G1 ruling
cat("GSE196870 done. rows:", nrow(sens), "\n")
cat("S0 vs published max |dt| =", max(chk$abs_diff_t, na.rm = TRUE),
    " max |dp| =", max(chk$abs_diff_p, na.rm = TRUE), "\n")
print(agree_tab, row.names = FALSE)
