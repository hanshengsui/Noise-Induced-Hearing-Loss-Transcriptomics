#!/usr/bin/env Rscript
## A2 supplementary (G1 request): identify the scale of each deposited matrix.
## Compares GSE196870 (claimed FPKM) and GSE312476 (claimed raw counts) against
## GSE160639, which is a genuine raw read-count matrix, on the same metrics.
source(file.path(Sys.getenv("A2_SCR"), "common.R"))
suppressPackageStartupMessages(library(readxl))

metric_row <- function(dataset, file, sample_id, values, claimed_scale) {
  v <- values[is.finite(values)]
  nonzero <- v[v != 0]
  ## back-transform assuming the values are log2(x + 1); only meaningful if the
  ## matrix really is log scaled, so it is reported as a diagnostic, not a proof.
  ## Guard: a value above 30 cannot be log2-scaled expression (2^30 > 1e9), and
  ## exponentiating it would overflow to Inf, so it is reported as NA instead.
  back <- if (all(v >= 0) && max(v) <= 30) sum(2^v - 1) else NA_real_
  data.frame(
    dataset = dataset, file = file, sample_id = sample_id,
    claimed_scale = claimed_scale,
    min = min(v), q50 = median(v), q999 = as.numeric(quantile(v, 0.999)),
    max = max(v),
    min_nonzero = if (length(nonzero)) min(nonzero) else NA_real_,
    frac_zero = mean(v == 0),
    frac_non_integer = mean(v != round(v)),
    frac_integer = mean(v == round(v)),
    column_sum = sum(v),
    backtransformed_sum_2x_minus_1 = back,
    stringsAsFactors = FALSE)
}

rows <- list()

## --- GSE196870: deposited matrix, 12 libraries -------------------------
g196 <- read.csv(gzfile(file.path(DATA, "GSE196870_Raw_gene_FPKM_matrix.txt.csv.gz")),
                 check.names = FALSE)
cols196 <- c(paste0("MUS_", 1:4), paste0("PN_1h_", 1:4), paste0("PN_24h_", 1:4))
m196 <- as.matrix(g196[, cols196]); storage.mode(m196) <- "numeric"
for (j in seq_along(cols196)) {
  rows[[length(rows) + 1]] <- metric_row(
    "GSE196870", "GSE196870_Raw_gene_FPKM_matrix.txt.csv.gz", cols196[j],
    m196[, j], "GEO text says FPKM")
}

## --- GSE312476: deposited matrix, 12 libraries -------------------------
xl <- file.path(DATA, "GSE312476_Table_S1.xlsx")
r312 <- as.data.frame(read_excel(xl, sheet = "Bulk_RNA_seq_data", skip = 2))
cols312 <- c(paste0("Ctrl_", 1:3), paste0("PN0h_", 1:3),
             paste0("PN4h_", 1:3), paste0("PN8h_", 1:3))
m312 <- as.matrix(r312[, cols312]); storage.mode(m312) <- "numeric"
for (j in seq_along(cols312)) {
  rows[[length(rows) + 1]] <- metric_row(
    "GSE312476", "GSE312476_Table_S1.xlsx (Bulk_RNA_seq_data)", cols312[j],
    m312[, j], "GEO text says raw counts")
}

## --- GSE160639: genuine raw read counts, 12 libraries ------------------
g160 <- read.delim(gzfile(file.path(DATA, "GSE160639_RawReadCount.txt.gz")),
                   check.names = FALSE)
m160 <- as.matrix(g160[, -1, drop = FALSE]); storage.mode(m160) <- "numeric"
for (j in seq_len(ncol(m160))) {
  rows[[length(rows) + 1]] <- metric_row(
    "GSE160639", "GSE160639_RawReadCount.txt.gz", colnames(m160)[j],
    m160[, j], "raw read counts")
}

sf <- do.call(rbind, rows); rownames(sf) <- NULL
write.csv(sf, file.path(REV, "GSE196870_scale_identification.csv"), row.names = FALSE)

## ---- one-line verdict per dataset, computed from the metrics -----------
per <- do.call(rbind, lapply(split(sf, sf$dataset), function(z) {
  data.frame(
    dataset = z$dataset[1], claimed_scale = z$claimed_scale[1],
    median_of_q50 = median(z$q50), max_max = max(z$max),
    median_frac_non_integer = median(z$frac_non_integer),
    median_frac_integer = median(z$frac_integer),
    min_nonzero = min(z$min_nonzero),
    backtransformed_sum_range = if (all(is.na(z$backtransformed_sum_2x_minus_1))) {
      "not applicable (values exceed any log2 range)"
    } else {
      paste(signif(range(z$backtransformed_sum_2x_minus_1, na.rm = TRUE), 3), collapse = " - ")
    },
    column_sum_range = paste(signif(range(z$column_sum), 3), collapse = " – "),
    stringsAsFactors = FALSE)
}))
rownames(per) <- NULL
write.csv(per, file.path(REV, "GSE196870_scale_identification_summary.csv"), row.names = FALSE)
print(per, row.names = FALSE)
