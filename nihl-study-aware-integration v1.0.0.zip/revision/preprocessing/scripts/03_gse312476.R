#!/usr/bin/env Rscript
## A2 step 2: GSE312476 value-type diagnosis + 18-cell filter/offset grid (Appendix B1.2, G0 D2).
source(file.path(Sys.getenv("A2_SCR"), "common.R"))
suppressPackageStartupMessages(library(readxl))

## ---- 1. what is actually deposited? ----------------------------------
xl <- file.path(DATA, "GSE312476_Table_S1.xlsx")
raw <- as.data.frame(read_excel(xl, sheet = "Bulk_RNA_seq_data", skip = 2))
g312_cols <- c(paste0("Ctrl_", 1:3), paste0("PN0h_", 1:3),
               paste0("PN4h_", 1:3), paste0("PN8h_", 1:3))
xx <- as.matrix(raw[, g312_cols]); storage.mode(xx) <- "numeric"

## Per-column diagnostics used to decide the value type (B1.2 first block).
vdiag <- data.frame(
  sample_id = g312_cols,
  column_sum = colSums(xx),
  frac_non_integer = colMeans(xx != round(xx)),
  min_nonzero = apply(xx, 2, function(v) min(v[v > 0])),
  max_value = apply(xx, 2, max),
  n_zeros = colMeans(xx == 0),
  stringsAsFactors = FALSE)
write.csv(vdiag, file.path(REV, "GSE312476_value_diagnostics.csv"), row.names = FALSE)

med_sum <- median(colSums(xx))
frac_ni <- mean(vdiag$frac_non_integer)
min_nz <- min(vdiag$min_nonzero)
value_type <- if (med_sum > 9e5 && med_sum < 1.1e6 && frac_ni < 0.01) {
  "TPM_or_CPM_like_sum_1e6_counts_integer"
} else if (frac_ni > 0.05) {
  "normalised_non_integer_abundance (not raw counts; column sums ~3.1e5, ~47% non-integer)"
} else {
  "integer_counts"
}
cat("VALUE TYPE:", value_type, "\n")
writeLines(c(
  paste0("value_type: ", value_type),
  sprintf("median column sum: %.1f", med_sum),
  sprintf("mean fraction of non-integer values: %.4f", frac_ni),
  sprintf("minimum non-zero value: %.6g", min_nz),
  sprintf("columns: %d samples (%s)", ncol(xx), paste(g312_cols, collapse = ", "))),
  file.path(REV, "GSE312476_value_type.txt"))

## NOTE: the deposited matrix is not raw counts, so the RC scheme
## (filterByExpr + TMM + voom) is not applicable (decision D2).

## ---- 2. the 18-cell grid --------------------------------------------
sym <- toupper(raw$gene_symbol)
ok <- !is.na(sym) & nzchar(sym) & sym != "N/A"
## collapse duplicates on the deposited (normalised) scale, by SUM, as the
## published code does (aggregate_counts_by_symbol)
cnt <- rowsum(xx[ok, , drop = FALSE], group = sym[ok], reorder = FALSE)

grid <- expand.grid(thr = c(0.5, 1, 2), minlib = c(2, 3, 4), off = c(0.5, 1),
                    KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE)
## the published scheme (thr = 1, minlib = 3, off = 0.5) is S0
grid$scheme <- sprintf("T%g_L%d_O%g", grid$thr, grid$minlib, grid$off)
## the published scheme is thr = 1, minlib = 3, off = 0.5 -> labelled S0
grid$scheme[grid$thr == 1 & grid$minlib == 3 & grid$off == 0.5] <- "S0"
stopifnot(sum(grid$scheme == "S0") == 1L, !any(duplicated(grid$scheme)))
grid <- grid[order(grid$scheme != "S0", grid$scheme), ]

grp <- factor(c(rep("control", 3), rep("post_0h", 3), rep("post_4h", 3), rep("post_8h", 3)),
              levels = c("control", "post_0h", "post_4h", "post_8h"))
design <- model.matrix(~0 + grp); colnames(design) <- levels(grp)
cm <- makeContrasts(ac = post_0h - control, h4 = post_4h - control, h8 = post_8h - control,
                    levels = design)
cmap <- c(ac = "post_0h_vs_control", h4 = "post_4h_vs_control", h8 = "post_8h_vs_control")

res_all <- list(); nkeep <- data.frame(scheme = character(), n_after_filter = integer())
for (i in seq_len(nrow(grid))) {
  g <- grid[i, ]
  keep <- rowSums(cnt > g$thr) >= g$minlib
  y <- log2(cnt[keep, , drop = FALSE] + g$off)
  sy <- rownames(y)
  fit <- lmFit(y, design)
  fit2 <- eBayes(contrasts.fit(fit, cm), trend = TRUE, robust = TRUE)
  nkeep <- rbind(nkeep, data.frame(scheme = g$scheme, thr = g$thr, minlib = g$minlib,
                                   off = g$off, n_after_filter = sum(keep)))
  for (k in colnames(cm)) {
    tt <- fit2$t[, k]; names(tt) <- sy
    res_all[[paste(g$scheme, k)]] <- camera_pr(tt, hallmark50, "GSE312476", cmap[[k]], g$scheme)
  }
}
sens <- do.call(rbind, res_all)
rownames(sens) <- NULL
sens$fdr_category <- fdr_category(sens$fdr)
write.csv(sens, file.path(REV, "GSE312476_preproc_sensitivity.csv"), row.names = FALSE)
write.csv(nkeep, file.path(REV, "GSE312476_grid_gene_counts.csv"), row.names = FALSE)

## ---- 3. S0 reproduction check against the published table -----------
pub <- read.csv(file.path(EXP_RES, "expanded_programme_results_complete.csv"))
pub <- pub[pub$dataset == "GSE312476" &
             pub$collection == "Human Hallmark v2024.1 direct-symbol match", ]
names(pub)[names(pub) == "programme"] <- "program"
chk <- merge(sens[sens$scheme == "S0", c("contrast", "program", "statistic", "p_value", "fdr")],
             pub[, c("contrast", "program", "camera_t", "PValue", "FDR")],
             by = c("contrast", "program"), suffixes = c("_new", "_pub"))
chk$abs_diff_t <- abs(chk$statistic - chk$camera_t)
write.csv(chk, file.path(REV, "GSE312476_S0_reproduction_check.csv"), row.names = FALSE)
cat("S0 rows compared:", nrow(chk), " max |dt| =", max(chk$abs_diff_t), "\n")

## ---- 4. agreement vs S0 ---------------------------------------------
agree <- list()
for (s in setdiff(grid$scheme, "S0")) {
  for (k in names(cmap)) {
    a <- sens[sens$scheme == s & sens$contrast == cmap[[k]], ]
    b <- sens[sens$scheme == "S0" & sens$contrast == cmap[[k]], ]
    if (!nrow(a) || !nrow(b)) next
    m <- merge(a[, c("program", "direction", "fdr_category")],
               b[, c("program", "direction", "fdr_category")],
               by = "program", suffixes = c("_new", "_S0"))
    agree[[paste(s, k)]] <- data.frame(
      scheme = s, contrast = cmap[[k]], n_programs = nrow(m),
      n_same_direction = sum(m$direction_new == m$direction_S0),
      agree_frac = mean(m$direction_new == m$direction_S0),
      n_same_fdr_category = sum(m$fdr_category_new == m$fdr_category_S0),
      stringsAsFactors = FALSE)
  }
}
agree_tab <- do.call(rbind, agree); rownames(agree_tab) <- NULL
write.csv(agree_tab, file.path(REV, "GSE312476_agree_frac.csv"), row.names = FALSE)

## focal programs by scheme
focal_tab <- sens[sens$program %in% unname(FOCAL), ]
focal_tab$program_code <- program_code(focal_tab$program)
write.csv(focal_tab[, c("contrast", "program_code", "scheme", "statistic", "direction",
                        "fdr", "fdr_category", "n_genes_in_set")],
          file.path(REV, "GSE312476_focal_by_scheme.csv"), row.names = FALSE)

saveRDS(list(sens = sens, grid = grid, cnt = cnt, design = design, cm = cm, grp = grp),
        file.path(REV, "GSE312476_objects.rds"))
cat("grid cells:", nrow(grid), " result rows:", nrow(sens), "\n")
