#!/usr/bin/env Rscript
## A2 step 1 (figures): GSE196870 scale diagnostics. Appendix B1.1 items 1-3.
source(file.path(Sys.getenv("A2_SCR"), "common.R"))

obj <- readRDS(file.path(REV, "GSE196870_objects.rds"))
E <- obj$E; fit_list <- obj$fit_list; group <- obj$group

save2 <- function(p, stem, w, h) {
  ggsave(filename = file.path(FIGS, paste0(stem, ".pdf")), plot = p, width = w, height = h,
         units = "in", device = "pdf")
  ggsave(filename = file.path(FIGS, paste0(stem, ".png")), plot = p, width = w, height = h,
         units = "in", dpi = 300, device = "png")
}

## ---- 1. sample density on the original scale and on the log2 scale ----
dens_df <- do.call(rbind, lapply(c("S0", "S1"), function(s) {
  m <- E[[s]]
  data.frame(scheme = s, sample_id = rep(colnames(m), each = nrow(m)),
             value = as.vector(m), stringsAsFactors = FALSE)
}))
dens_df$group <- as.character(group)[match(dens_df$sample_id, colnames(E$S0))]
dens_df$scheme_lab <- ifelse(dens_df$scheme == "S0",
                             "S0: deposited values (log2 scale), used as-is",
                             "S1: additional log2(x+1) on deposited log-scale values")
p1 <- ggplot(dens_df, aes(x = value, colour = sample_id, linetype = group)) +
  geom_density(linewidth = 0.35) +
  facet_wrap(~ scheme_lab, scales = "free") +
  scale_colour_viridis_d(name = "sample", option = "D", end = 0.9) +
  scale_linetype_manual(name = "group", values = c(control = "solid", noise_1h = "22",
                                                   noise_24h = "42")) +
  labs(x = "expression value", y = "density", title = NULL) +
  theme_bw(base_size = 9) +
  theme(legend.position = "right", legend.key.height = unit(0.35, "cm"))
save2(p1, "fig_GSE196870_density_orig_vs_log2", 9.5, 4.2)

## ---- 2. mean-variance and plotSA ----
mv_df <- do.call(rbind, lapply(c("S0", "S1"), function(s) {
  m <- E[[s]]
  data.frame(scheme = s, mean = rowMeans(m), sd = apply(m, 1, sd))
}))
mv_df$scheme_lab <- ifelse(mv_df$scheme == "S0",
                           "S0: deposited values (log2 scale)",
                           "S1: additional log2(x+1) on deposited log-scale values")
p2 <- ggplot(mv_df, aes(x = mean, y = sd)) +
  geom_point(size = 0.25, alpha = 0.35, colour = "grey35") +
  geom_smooth(method = "loess", span = 0.5, se = FALSE, colour = "#B2182B", linewidth = 0.6) +
  facet_wrap(~ scheme_lab, scales = "free") +
  labs(x = "gene mean across 12 samples", y = "gene SD across 12 samples") +
  theme_bw(base_size = 9)
save2(p2, "fig_GSE196870_mean_variance", 9.0, 4.0)

sa_draw <- function() {
  par(mfrow = c(2, 2), mar = c(4.4, 4.4, 3.0, 1.2), mgp = c(2.5, 0.7, 0))
  for (nm in names(fit_list)) {
    plotSA(fit_list[[nm]], main = "", cex.axis = 0.85, cex.lab = 0.9, cex = 0.35)
    title(main = paste0(nm, ": limma-trend, log sqrt(s2) vs AveExpr"),
          cex.main = 0.85, line = 1.4)
  }
}
sa_title <- c(S0 = "S0: deposited values as-is (main)", S1 = "S1: additional log2(x+1)",
              S2 = "S2: stricter filter + additional log2(x+1)", S3 = "S3: additional log2(x+0.1)")
sa_draw <- function() {
  par(mfrow = c(2, 2), mar = c(4.4, 4.4, 3.0, 1.2), mgp = c(2.5, 0.7, 0))
  for (nm in names(fit_list)) {
    plotSA(fit_list[[nm]], main = "", cex.axis = 0.85, cex.lab = 0.9, cex = 0.35)
    title(main = paste0(sa_title[[nm]], ": limma-trend, log sqrt(s2) vs AveExpr"),
          cex.main = 0.78, line = 1.5)
  }
}

## ---- 3. sample QC on the MAIN scheme (S0 = deposited log2 scale) -------
##         PCA on top-500 variable genes, correlation heatmap, library sums
m1 <- E$S0
vk <- head(order(apply(m1, 1, var), decreasing = TRUE), 500)
pv <- prcomp(t(m1[vk, , drop = FALSE]), scale. = FALSE)
ve <- round(100 * summary(pv)$importance[2, 1:2], 1)
pca <- data.frame(PC1 = pv$x[, 1], PC2 = pv$x[, 2], sample_id = colnames(m1),
                  group = as.character(group))
p3 <- ggplot(pca, aes(PC1, PC2, colour = group, label = sample_id)) +
  geom_point(size = 2.6) +
  ggrepel::geom_text_repel(size = 2.3, show.legend = FALSE, min.segment.length = 0,
                           seed = 20261029) +
  scale_colour_manual(values = c(control = "#4D4D4D", noise_1h = "#D95F02",
                                 noise_24h = "#1B7C8C"), name = "group") +
  labs(x = paste0("PC1 (", ve[1], "%)"), y = paste0("PC2 (", ve[2], "%)")) +
  theme_bw(base_size = 9) + coord_cartesian(clip = "off")
save2(p3, "fig_GSE196870_PCA_S0_top500", 5.6, 4.4)

cr <- cor(E$S0, method = "pearson")
ord <- order(group, colnames(E$S0))
cr <- cr[ord, ord]
cr_long <- data.frame(
  s1 = factor(rep(rownames(cr), times = ncol(cr)), levels = rownames(cr)),
  s2 = factor(rep(colnames(cr), each = nrow(cr)), levels = colnames(cr)),
  r = as.vector(cr))
p4 <- ggplot(cr_long, aes(s1, s2, fill = r)) +
  geom_tile() +
  geom_text(aes(label = sprintf("%.3f", r)), size = 1.9,
            colour = ifelse(as.vector(cr) > 0.9, "white", "black")) +
  scale_fill_viridis_c(name = "Pearson r", limits = c(min(cr), 1)) +
  labs(x = NULL, y = NULL) +
  theme_bw(base_size = 9) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5, size = 6),
        axis.text.y = element_text(size = 6), panel.grid = element_blank())
save2(p4, "fig_GSE196870_sample_correlation_S0", 6.6, 5.4)

qc <- read.csv(file.path(REV, "GSE196870_sample_qc.csv"))
qc_long <- rbind(
  data.frame(sample_id = qc$sample_id, group = qc$group,
             metric = "sum of deposited values across genes (x1e3)",
             value = qc$fpkm_sum / 1e3),
  data.frame(sample_id = qc$sample_id, group = qc$group,
             metric = "genes with deposited value > 1",
             value = qc$n_detected_fpkm_gt1))
p5 <- ggplot(qc_long, aes(x = factor(sample_id, levels = qc$sample_id), y = value, fill = group)) +
  geom_col(width = 0.72) +
  facet_wrap(~ metric, scales = "free_y") +
  scale_fill_manual(values = c(control = "#4D4D4D", noise_1h = "#D95F02",
                               noise_24h = "#1B7C8C"), name = "group") +
  labs(x = NULL, y = NULL) +
  theme_bw(base_size = 9) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 7))
save2(p5, "fig_GSE196870_library_and_detection", 8.6, 3.8)

cat("figures written to", FIGS, "\n")
