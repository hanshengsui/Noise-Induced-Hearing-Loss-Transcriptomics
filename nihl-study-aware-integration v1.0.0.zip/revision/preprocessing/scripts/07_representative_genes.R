#!/usr/bin/env Rscript
## A2 step 5: representative genes for TNFA / INFL / UPR under the MAIN scheme
## (GSE196870 = S0, the deposited log2-scale values, per the G1 ruling of
## 2026-10-30; GSE312476 = S0; GSE160639 / GSE100365 as published).
## Rule fixed before looking at results: genes measured in ALL FOUR acute
## studies, ranked by mean moderated t across those four, top 10 per programme;
## the classic-gene group is labelled separately (Appendix B1.5).
source(file.path(Sys.getenv("A2_SCR"), "common.R"))

## ---- gene-level moderated t per acute study, main scheme -------------
ACUTE <- data.frame(
  dataset = c("GSE160639", "GSE196870", "GSE312476", "GSE100365"),
  contrast = c("dB105_vs_70", "noise_1h_vs_control",
               "post_0h_vs_control", "immediate_vs_control"),
  stringsAsFactors = FALSE)

get_genes <- function(ds, contrast) {
  if (ds == "GSE196870") {
    z <- read.csv(file.path(REV, "GSE196870_gene_level_S0.csv"), stringsAsFactors = FALSE)
    z <- z[z$contrast == contrast, c("gene_symbol", "logFC", "moderated_t", "PValue", "FDR")]
  } else {
    f <- file.path(EXP_RES, ds, paste0(ds, "__", contrast, "__complete_results.csv.gz"))
    z <- read.csv(gzfile(f), stringsAsFactors = FALSE)
    z <- z[, c("gene_symbol", "logFC", "moderated_t", "PValue", "FDR")]
  }
  z$gene_symbol <- toupper(z$gene_symbol)
  z <- z[!is.na(z$gene_symbol) & nzchar(z$gene_symbol) & is.finite(z$moderated_t), ]
  z <- z[order(z$gene_symbol, -abs(z$moderated_t)), ]
  z[!duplicated(z$gene_symbol), ]
}

tab <- list(); tmat <- list()
for (i in seq_len(nrow(ACUTE))) {
  ds <- ACUTE$dataset[i]; ct <- ACUTE$contrast[i]
  g <- get_genes(ds, ct)
  tab[[ds]] <- data.frame(dataset = ds, contrast = ct, gene_symbol = g$gene_symbol,
                          logFC = g$logFC, moderated_t = g$moderated_t,
                          PValue = g$PValue, FDR = g$FDR, stringsAsFactors = FALSE)
  tmat[[ds]] <- setNames(g$moderated_t, g$gene_symbol)
}
long_tab <- do.call(rbind, tab); rownames(long_tab) <- NULL

## genes measured (finite t) in every one of the four studies
shared <- Reduce(intersect, lapply(tmat, names))
tm <- sapply(tmat, function(v) v[shared])   # rows = genes, cols = studies
mean_t <- rowMeans(tm)

## ---- top 10 per programme, plus the classic set ----------------------
## The classic set is restricted to genes that ARE members of the programme's
## Hallmark set (membership asserted by code below, as B1.5 requires). DDIT3
## and CXCL1/PTGS2 are not in the UPR / INFL Hallmark sets respectively, so
## they cannot be labelled as members of those programmes.
## IL6 is filtered out of GSE196870 and GSE312476, and DDIT3 is not a member of
## HALLMARK_UNFOLDED_PROTEIN_RESPONSE, so neither can serve as a classic gene
## measured in all four acute studies. The replacements below are the most
## frequently cited members of each set that survive in all four studies.
## G1 裁决 (2026-10-30)：TNFA 与 UPR 的经典组保留；INFL 的经典基因在计划里
## 从未预先指定，因此删除该组，INFL 只用 top-10 规则。DDIT3 经代码核实不是
## HALLMARK_UNFOLDED_PROTEIN_RESPONSE 成员，已从 UPR 组删除。
classic <- list(
  TNFA = c("NFKBIA", "TNFAIP3", "ATF3"),
  INFL = character(0),
  UPR  = c("HSPA5", "ATF4", "XBP1"))

progs <- c("TNFA", "INFL", "UPR")
sel <- list()
for (P in progs) {
  set_genes <- hallmark50[[FOCAL[[P]]]]
  g <- intersect(set_genes, shared)
  ord <- order(-mean_t[g])
  top10 <- g[ord][seq_len(min(10, length(g)))]
  cl <- classic[[P]]
  stopifnot(all(cl %in% set_genes))          # membership confirmed by code
  if (!length(cl)) cl <- character(0)        # INFL has no classic group by design
  allg <- union(top10, cl)
  sel[[P]] <- data.frame(
    program = P,
    gene_symbol = allg,
    in_top10 = allg %in% top10,
    is_classic = allg %in% cl,
    selection = ifelse(allg %in% intersect(top10, cl), "top10_and_classic",
                       ifelse(allg %in% top10, "top10_by_mean_t", "classic_gene")),
    n_classic_defined = length(cl),
    within_program_rank = match(allg, top10),
    mean_moderated_t_across_4_acute = as.numeric(mean_t[allg]),
    measured_in_all_four = allg %in% shared,
    n_hallmark_genes_shared = length(g),
    stringsAsFactors = FALSE)
}
sel <- do.call(rbind, sel); rownames(sel) <- NULL
stopifnot(!any(duplicated(paste(sel$program, sel$gene_symbol))))

## ---- long table: gene x dataset x contrast ---------------------------
rep_long <- merge(sel[, c("program", "gene_symbol", "selection", "in_top10",
                          "is_classic", "mean_moderated_t_across_4_acute",
                          "within_program_rank", "measured_in_all_four",
                          "n_classic_defined")],
                  long_tab, by = "gene_symbol", all.x = TRUE)
rep_long$fdr_category <- fdr_category(rep_long$FDR)
rep_long <- rep_long[order(match(rep_long$program, progs),
                           -rep_long$in_top10, rep_long$within_program_rank,
                           match(rep_long$dataset, ACUTE$dataset)), ]
write.csv(rep_long, file.path(REV, "representative_genes.csv"), row.names = FALSE)
write.csv(sel, file.path(REV, "representative_gene_selection.csv"), row.names = FALSE)

## ---- heatmap: gene x acute study, log2 fold change, faceted by programme --
## R2-m3 asks for log2FC and FDR, so colour and printed value are log2FC and
## FDR < 0.05 cells carry a dot. moderated t stays in the long table only.
hm <- rep_long[!is.na(rep_long$logFC), ]
hm$program <- factor(hm$program, levels = progs)
hm$dataset <- factor(hm$dataset, levels = ACUTE$dataset,
                     labels = c("GSE160639\n(105 vs 70 dB)", "GSE196870\n(1 h)",
                                "GSE312476\n(exposure end)", "GSE100365\n(immediate)"))
## display label: classic genes get a dagger (not an asterisk, which readers
## would take for a significance mark - the point of R1-b)
sel_ord <- sel[order(match(sel$program, progs), -sel$in_top10,
                     sel$within_program_rank), ]
sel_ord$display <- ifelse(sel_ord$is_classic,
                          paste0(sel_ord$gene_symbol, " \u2020"), sel_ord$gene_symbol)
stopifnot(!any(duplicated(paste(sel_ord$program, sel_ord$display))))
hm$display <- sel_ord$display[match(paste(hm$program, hm$gene_symbol),
                                    paste(sel_ord$program, sel_ord$gene_symbol))]
hm$gene_label <- factor(hm$display, levels = rev(unique(sel_ord$display)))
hm$sig <- hm$FDR < 0.05
lim <- max(abs(hm$logFC), na.rm = TRUE)

## With free_y facets each panel keeps only its own gene levels, so categorical
## y positions restart per panel and dots drift out of their tiles. Giving every
## gene a GLOBALLY unique integer y position (programme blocks) lets a single
## scale carry correct per-panel labels while free_y shows only that panel's
## range. x is numeric for the same reason.
sel_ord$display <- factor(sel_ord$display)
ord_levels <- do.call(rbind, lapply(progs, function(P) {
  z <- sel_ord[as.character(sel_ord$program) == P, ]
  z <- z[order(-z$in_top10, z$within_program_rank), ]
  data.frame(program = P, display = as.character(z$display),
             ylocal = seq_len(nrow(z)), stringsAsFactors = FALSE)
}))
ord_levels$ypos <- seq_len(nrow(ord_levels))
hm <- merge(hm, ord_levels[, c("program", "display", "ypos")],
            by = c("program", "display"), all.x = TRUE)
stopifnot(!any(is.na(hm$ypos)))
hm$xpos <- match(as.character(hm$dataset), levels(hm$dataset))
hm_sig <- hm[hm$sig, ]

p <- ggplot(hm, aes(x = xpos, y = ypos, fill = logFC)) +
  geom_tile(colour = "white", linewidth = 0.4) +
  geom_text(aes(label = sprintf("%.2f", logFC)), size = 1.7) +
  geom_point(data = hm_sig, aes(x = xpos + 0.31, y = ypos - 0.31),
             inherit.aes = FALSE, shape = 16, size = 0.7, colour = "black") +
  facet_wrap(~ factor(program, levels = progs), nrow = 1, as.table = TRUE,
             scales = "free_y", space = "free_y",
             labeller = labeller(`factor(program, levels = progs)` = c(
               TNFA = "TNF-\u03b1 signaling via NF-\u03baB",
               INFL = "Inflammatory response",
               UPR = "Unfolded protein response"))) +
  scale_x_continuous(breaks = 1:4, limits = c(0.5, 4.5),
                     labels = c("GSE160639\n(105 vs 70 dB)", "GSE196870\n(1 h)",
                                "GSE312476\n(exposure end)", "GSE100365\n(immediate)"),
                     expand = c(0, 0)) +
  scale_y_continuous(breaks = ord_levels$ypos, labels = ord_levels$display,
                     expand = expansion(add = 0.45)) +

  scale_fill_gradient2(low = "#2166AC", mid = "#F7F7F7", high = "#B2182B",
                       midpoint = 0, limits = c(-lim, lim),
                       name = "log2 fold change") +
  labs(x = NULL, y = NULL,
       caption = paste0(
         "Dot = FDR < 0.05 (BH within each contrast). ",
         "\u2020 = classic gene, labelled separately from the top-ranked set.\n",
         "SERPINE1, NFKBIA, ATF3 and CCL2 belong to more than one of these three gene sets, ",
         "so they can appear in more than one panel.")) +
  theme_bw(base_size = 8) +
  theme(panel.grid = element_blank(),
        axis.text.x = element_text(size = 6, angle = 45, hjust = 1),
        axis.text.y = element_text(size = 6),
        strip.background = element_rect(fill = "grey92", colour = NA),
        strip.text = element_text(size = 7),
        plot.caption = element_text(size = 6, hjust = 0),
        legend.key.height = unit(0.6, "cm"))

ggsave(file.path(FIGS, "fig_representative_genes_heatmap.pdf"), plot = p,
       width = 9.6, height = 5.8, units = "in", device = "pdf")
ggsave(file.path(FIGS, "fig_representative_genes_heatmap.png"), plot = p,
       width = 9.6, height = 5.8, units = "in", dpi = 300, device = "png")

cat("shared genes across 4 acute studies:", length(shared), "\n")
cat("selected genes:", nrow(sel), " long rows:", nrow(rep_long), "\n")
cat("classic genes not measured in all four:",
    paste(sel$gene_symbol[sel$is_classic & !sel$measured_in_all_four], collapse = ", "), "\n")

