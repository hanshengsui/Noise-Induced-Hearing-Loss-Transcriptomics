#!/usr/bin/env Rscript
## A2: build the machine-readable summaries the report and the structured
## output are computed from (no number is typed by hand anywhere below).
source(file.path(Sys.getenv("A2_SCR"), "common.R"))

s196 <- read.csv(file.path(REV, "GSE196870_preproc_sensitivity.csv"), stringsAsFactors = FALSE)
s312 <- read.csv(file.path(REV, "GSE312476_preproc_sensitivity.csv"), stringsAsFactors = FALSE)
cd <- read.csv(file.path(REV, "core_direction_robustness_long.csv"), stringsAsFactors = FALSE)
a196 <- read.csv(file.path(REV, "GSE196870_agree_frac.csv"), stringsAsFactors = FALSE)
a312 <- read.csv(file.path(REV, "GSE312476_agree_frac.csv"), stringsAsFactors = FALSE)

## ---- 1. focal-programme direction/category changes vs S0 -------------
focal_changes <- function(tab, dataset) {
  out <- list()
  for (sm in setdiff(unique(tab$scheme), "S0")) {
    for (ct in unique(tab$contrast)) {
      a <- tab[tab$scheme == sm & tab$contrast == ct & tab$program %in% unname(FOCAL), ]
      b <- tab[tab$scheme == "S0" & tab$contrast == ct & tab$program %in% unname(FOCAL), ]
      if (!nrow(a) || !nrow(b)) next
      m <- merge(a[, c("program", "direction", "fdr_category")],
                 b[, c("program", "direction", "fdr_category")],
                 by = "program", suffixes = c("_new", "_S0"))
      m <- m[m$direction_new != m$direction_S0 | m$fdr_category_new != m$fdr_category_S0, ]
      if (!nrow(m)) next
      out[[paste(sm, ct)]] <- data.frame(
        dataset = dataset, scheme = sm, contrast = ct,
        program = program_code(m$program),
        orig_dir = m$direction_S0, new_dir = m$direction_new,
        orig_cat = m$fdr_category_S0, new_cat = m$fdr_category_new,
        change = ifelse(m$direction_new != m$direction_S0,
                        ifelse(m$fdr_category_new != m$fdr_category_S0,
                               "direction_and_category", "direction_only"),
                        "category_only"),
        stringsAsFactors = FALSE)
    }
  }
  if (!length(out)) return(NULL)
  z <- do.call(rbind, out); rownames(z) <- NULL; z
}
fc <- rbind(focal_changes(s196, "GSE196870"), focal_changes(s312, "GSE312476"))
write.csv(fc, file.path(REV, "focal_direction_changes.csv"), row.names = FALSE)

## ---- 2. per-scheme agreement summary (focal + all 50) ----------------
ag <- rbind(
  data.frame(dataset = "GSE196870", a196[, c("scheme", "contrast", "n_same_direction",
                                             "n_programs", "agree_frac",
                                             "n_same_fdr_category")]),
  data.frame(dataset = "GSE312476", a312[, c("scheme", "contrast", "n_same_direction",
                                             "n_programs", "agree_frac",
                                             "n_same_fdr_category")]))
write.csv(ag, file.path(REV, "preproc_agree_frac_all.csv"), row.names = FALSE)

## ---- 3. core programme robustness across all combinations ------------
rob <- do.call(rbind, lapply(c("acute", "h24"), function(st) {
  do.call(rbind, lapply(c("TNFA", "INFL", "UPR", "OXPHOS", "E2F"), function(p) {
    z <- cd[cd$stratum == st & cd$program_code == p, ]
    main <- z[z$combination == "main_S0_S0", ]
    main_dir <- sign(main$Z)
    main_cat <- main$fdr_category
    ## "holds" = same direction in every combination AND the main category is
    ## reproduced in every combination; "weakened" = same direction but the FDR
    ## category moves at least once; "flipped" = direction changes at least once
    status <- if (any(sign(z$Z) != main_dir)) "flipped" else
      if (any(z$fdr_category != main_cat)) "weakened" else "holds"
    data.frame(stratum = st, program = p,
               main_n_up = main$n_up, main_k = main$k, main_Z = main$Z,
               main_fdr = main$fdr, main_cat = main_cat,
               n_combinations = nrow(z),
               n_same_direction = sum(sign(z$Z) == main_dir),
               n_all_studies_same_dir = sum(z$n_up == z$k),
               Z_min = min(z$Z), Z_max = max(z$Z),
               fdr_max = max(z$fdr),
               cat_counts = paste(sprintf("%s:%d", names(table(z$fdr_category)),
                                          as.integer(table(z$fdr_category))), collapse = "; "),
               loso_all_same_sign_n = sum(z$loso_all_same_sign),
               restricted_n_up_values = paste(sort(unique(z$restricted_n_up)), collapse = "/"),
               restricted_k = z$restricted_k[1],
               classification = status, stringsAsFactors = FALSE)
  }))
}))
write.csv(rob, file.path(REV, "core_programme_robustness_summary.csv"), row.names = FALSE)

## ---- 4. propagation table in the plan's wide format (already written) --
cat("focal changes:", nrow(fc), " agreement rows:", nrow(ag), "\n")
print(rob[, c("stratum", "program", "main_n_up", "main_k", "main_cat",
              "Z_min", "Z_max", "classification")], row.names = FALSE, digits = 3)
