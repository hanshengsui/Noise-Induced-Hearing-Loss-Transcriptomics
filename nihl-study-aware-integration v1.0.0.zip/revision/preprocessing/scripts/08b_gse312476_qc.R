#!/usr/bin/env Rscript
## A2 supplementary (G1 request): quantify the sample structure visible on PC1
## in GSE312476 and check whether it tracks library size, detection, or group.
source(file.path(Sys.getenv("A2_SCR"), "common.R"))
suppressPackageStartupMessages(library(readxl))

obj <- readRDS(file.path(REV, "GSE312476_objects.rds"))
grp <- obj$grp
cols <- c(paste0("Ctrl_", 1:3), paste0("PN0h_", 1:3),
          paste0("PN4h_", 1:3), paste0("PN8h_", 1:3))
raw <- as.data.frame(read_excel(file.path(DATA, "GSE312476_Table_S1.xlsx"),
                                sheet = "Bulk_RNA_seq_data", skip = 2))
dep <- as.matrix(raw[, cols]); storage.mode(dep) <- "numeric"
sym <- toupper(raw$gene_symbol)
ok <- !is.na(sym) & nzchar(sym) & sym != "N/A"
cnt2 <- rowsum(dep[ok, , drop = FALSE], group = sym[ok], reorder = FALSE)
keep <- rowSums(cnt2 > 1) >= 3
E <- log2(cnt2[keep, , drop = FALSE] + 0.5)

vk <- head(order(apply(E, 1, var), decreasing = TRUE), 500)
pv <- prcomp(t(E[vk, ]), scale. = FALSE)
pc1 <- pv$x[, 1]
left <- pc1 < 0

## ---- per-sample QC table with the PC1 coordinate ----------------------
## block membership is computed once, in the ORIGINAL sample order, and then
## carried into the PC1-sorted table (indexing qc after sorting would mix it up)
block_orig <- ifelse(left, "left", "right")
qc <- data.frame(
  sample_id = cols,
  group = as.character(grp),
  PC1 = pc1, PC2 = pv$x[, 2],
  PC1_block = block_orig,
  deposited_sum = colSums(dep),
  features_gt1 = colSums(dep > 1),
  features_detected = colSums(dep > 0),
  frac_zero = colMeans(dep == 0),
  stringsAsFactors = FALSE)
qc <- qc[order(qc$PC1), ]
write.csv(qc, file.path(REV, "GSE312476_sample_qc_PC1.csv"), row.names = FALSE)

## ---- what drives PC1? -------------------------------------------------
diff <- rowMeans(E[vk, left, drop = FALSE]) - rowMeans(E[vk, !left, drop = FALSE])
drivers <- data.frame(
  gene_symbol = names(sort(-abs(diff))),
  mean_left = as.numeric(rowMeans(E[names(sort(-abs(diff))), left, drop = FALSE])),
  mean_right = as.numeric(rowMeans(E[names(sort(-abs(diff))), !left, drop = FALSE])),
  stringsAsFactors = FALSE)
drivers$difference <- drivers$mean_left - drivers$mean_right
drivers <- drivers[order(-abs(drivers$difference)), ]
write.csv(head(drivers, 50), file.path(REV, "GSE312476_PC1_driver_genes.csv"), row.names = FALSE)

## ---- summary: is the split explained by library size / detection? ----
cor_sum <- data.frame(
  metric = c("PC1 vs deposited sum", "PC1 vs features > 1",
             "PC1 vs features detected", "PC1 vs fraction zero"),
  pearson_r = c(cor(pc1, qc$deposited_sum), cor(pc1, qc$features_gt1),
                cor(pc1, qc$features_detected), cor(pc1, qc$frac_zero)),
  stringsAsFactors = FALSE)
cor_sum$abs_r <- abs(cor_sum$pearson_r)
write.csv(cor_sum, file.path(REV, "GSE312476_PC1_correlations.csv"), row.names = FALSE)

tab <- table(qc$group, qc$PC1_block)
write.csv(as.data.frame.matrix(tab), file.path(REV, "GSE312476_PC1_block_by_group.csv"))

cat("left block:", paste(qc$sample_id[qc$PC1_block == "left"], collapse = ", "), "\n")
cat("right block:", paste(qc$sample_id[qc$PC1_block == "right"], collapse = ", "), "\n")
cat("group x block:\n"); print(tab)
cat("drivers switched on in left block:", sum(diff > 1),
    " switched off:", sum(diff < -1), "of 500 top-variable genes\n")
cat("max |r| with library-size metrics:", round(max(cor_sum$abs_r), 3), "\n")
