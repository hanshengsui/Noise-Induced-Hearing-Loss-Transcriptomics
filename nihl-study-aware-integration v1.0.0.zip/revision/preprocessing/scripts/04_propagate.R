#!/usr/bin/env Rscript
## A2 step 3: propagate each preprocessing scheme into the cross-study synthesis
## (Appendix B1.3). Acute layer: 4 studies; h24 layer: 3 studies. LOSO = 4 fits
## on the acute layer; the design-restricted analysis keeps GSE196870 + GSE312476.
source(file.path(Sys.getenv("A2_SCR"), "common.R"))

## ---- unchanged studies take their published cameraPR values -----------
pub <- read.csv(file.path(EXP_RES, "expanded_programme_results_complete.csv"))
pub <- pub[pub$collection == "Human Hallmark v2024.1 direct-symbol match", ]
names(pub)[names(pub) == "programme"] <- "program"
pub$fdr_category <- fdr_category(pub$FDR)

## E-MTAB-16125 comes from the deposited machine-readable phase_transition
## table (the canonical source of the published synthesis), not from the
## legacy precursor file, whose gene universe differs.
emtab <- read.csv(file.path(REV, "pkg/E-MTAB-16125_programme_results_complete.csv"),
                  stringsAsFactors = FALSE)
emtab <- emtab[emtab$collection == "Human Hallmark v2024.1 direct-symbol match", ]
names(emtab)[names(emtab) == "programme"] <- "program"
emtab$fdr_category <- fdr_category(emtab$FDR)

LAYERS <- list(
  acute = list(
    studies = c("GSE160639", "GSE196870", "GSE312476", "GSE100365"),
    key = data.frame(
      dataset = c("GSE160639", "GSE196870", "GSE312476", "GSE100365"),
      contrast = c("dB105_vs_70", "noise_1h_vs_control",
                   "post_0h_vs_control", "immediate_vs_control"),
      stringsAsFactors = FALSE)),
  h24 = list(
    studies = c("GSE196870", "GSE100365", "E-MTAB-16125"),
    key = data.frame(
      dataset = c("GSE196870", "GSE100365", "E-MTAB-16125"),
      contrast = c("noise_24h_vs_control", "day1_vs_control", "h24_vs_control"),
      stringsAsFactors = FALSE)))

## ---- a scheme-independent lookup of the unaffected studies ------------
pub_fixed <- rbind(
  pub[, c("dataset", "contrast", "program", "camera_t", "PValue", "FDR", "fdr_category")],
  emtab[, c("dataset", "contrast", "program", "camera_t", "PValue", "FDR", "fdr_category")])
pub_fixed$scheme <- "published"

to_std <- function(d) data.frame(dataset = d$dataset, contrast = d$contrast,
                                 scheme = d$scheme, program = d$program,
                                 camera_t = d$statistic, PValue = d$p_value,
                                 FDR = d$fdr, fdr_category = d$fdr_category,
                                 stringsAsFactors = FALSE)
s196 <- to_std(readRDS(file.path(REV, "GSE196870_objects.rds"))$sens)
s312 <- to_std(readRDS(file.path(REV, "GSE312476_objects.rds"))$sens)
## G1 (2026-10-30): the deposited GSE196870 matrix is already log2 scaled, so
## S0 (as deposited) is the revised MAIN analysis; S1/S2/S3 are sensitivities.
MAIN196 <- "S0"
MAIN312 <- "S0"
SENS <- rbind(s196[, c("dataset", "contrast", "program", "scheme", "camera_t",
                       "PValue", "FDR", "fdr_category")],
              s312[, c("dataset", "contrast", "program", "scheme", "camera_t",
                       "PValue", "FDR", "fdr_category")])

LAYERS <- list(
  acute = data.frame(
    dataset = c("GSE160639", "GSE196870", "GSE312476", "GSE100365"),
    contrast = c("dB105_vs_70", "noise_1h_vs_control",
                 "post_0h_vs_control", "immediate_vs_control"),
    stringsAsFactors = FALSE),
  h24 = data.frame(
    dataset = c("GSE196870", "GSE100365", "E-MTAB-16125"),
    contrast = c("noise_24h_vs_control", "day1_vs_control", "h24_vs_control"),
    stringsAsFactors = FALSE))

## rows for one (stratum, programme) under one scheme assignment
study_rows <- function(stratum, program, s196_scheme, s312_scheme) {
  key <- LAYERS[[stratum]]
  out <- list()
  for (i in seq_len(nrow(key))) {
    ds <- key$dataset[i]; ct <- key$contrast[i]
    if (ds == "GSE196870") {
      r <- SENS[SENS$dataset == ds & SENS$contrast == ct &
                  SENS$scheme == s196_scheme & SENS$program == program, ]
    } else if (ds == "GSE312476") {
      r <- SENS[SENS$dataset == ds & SENS$contrast == ct &
                  SENS$scheme == s312_scheme & SENS$program == program, ]
    } else {
      r <- pub_fixed[pub_fixed$dataset == ds & pub_fixed$contrast == ct &
                       pub_fixed$program == program, ]
    }
    stopifnot(nrow(r) == 1L)
    out[[ds]] <- r
  }
  do.call(rbind, out)
}

synth <- function(rows) {
  z <- signed_z(rows$PValue, ifelse(rows$camera_t > 0, "Up", "Down"))
  Z <- stouffer(z)
  data.frame(k = nrow(rows), n_up = sum(rows$camera_t > 0), Z = Z,
             p = 2 * pnorm(-abs(Z)), stringsAsFactors = FALSE)
}

## ---- base check: S0/S0 must equal the published synthesis ------------
base <- list()
for (st in names(LAYERS)) for (pg in unname(FOCAL)) {
  rows <- study_rows(st, pg, MAIN196, MAIN312)
  s <- synth(rows); s$stratum <- st; s$program <- pg
  base[[paste(st, pg)]] <- s
}
base <- do.call(rbind, base); rownames(base) <- NULL
base$fdr <- ave(base$p, base$stratum, FUN = function(p) p.adjust(p, "BH"))
base$fdr_category <- fdr_category(base$fdr)

reg <- read.csv(file.path(REV, "registry_baseline.csv"), stringsAsFactors = FALSE)
regz <- reg[grepl("^syn[.](acute|h24)[.]w_equal[.].*[.]Z$", reg$key), ]
regz$stratum <- ifelse(grepl("^syn[.]acute", regz$key), "acute", "h24")
regz$program <- sub("[.]Z$", "", sub("^syn[.][a-z0-9]+[.]w_equal[.]", "", regz$key))
base$program_code <- program_code(base$program)
chk <- merge(base[, c("stratum", "program_code", "Z", "n_up", "k")],
             data.frame(stratum = regz$stratum, program_code = regz$program,
                        Z_pub = as.numeric(regz$value)), by = c("stratum", "program_code"))
chk$abs_diff_Z <- abs(chk$Z - chk$Z_pub)
write.csv(chk, file.path(REV, "core_synthesis_main_reproduction_check.csv"), row.names = FALSE)
## the registry holds 3-decimal values, so agreement is at the published precision
chk$within_rounding <- chk$abs_diff_Z < 5e-4
write.csv(chk, file.path(REV, "core_synthesis_main_reproduction_check.csv"), row.names = FALSE)
cat("main scheme vs registry: max |dZ| =", max(chk$abs_diff_Z),
    " all within 3-dp rounding:", all(chk$within_rounding), "\n")

## ---- 1. the main combination and the alternatives ---------------------
## main_S0_S0 reproduces the published analysis exactly (deposited-scale FPKM
## for GSE196870 and the published filter for GSE312476); every alternative
## changes exactly one data set's scheme so the effect of that change is isolated.
main_combos <- data.frame(
  label = "main_S0_S0", s196 = MAIN196, s312 = MAIN312, stringsAsFactors = FALSE)

## ---- 2. every single-scheme substitution around the main combination --
s196_schemes <- c("S0", "S1", "S2", "S3")
s312_schemes <- c("S0", sort(setdiff(unique(s312$scheme), "S0")))

combos <- rbind(
  main_combos,
  data.frame(label = paste0("GSE196870_", setdiff(s196_schemes, MAIN196), "_GSE312476_S0"),
             s196 = setdiff(s196_schemes, MAIN196), s312 = "S0", stringsAsFactors = FALSE),
  data.frame(label = paste0("GSE196870_S0_GSE312476_", setdiff(s312_schemes, MAIN312)),
             s196 = "S0", s312 = setdiff(s312_schemes, MAIN312), stringsAsFactors = FALSE))
stopifnot(!any(duplicated(combos$label)),
          nrow(combos) == 1 + length(setdiff(s196_schemes, MAIN196)) +
            length(setdiff(s312_schemes, MAIN312)))

out <- list()
for (i in seq_len(nrow(combos))) {
  for (st in names(LAYERS)) for (pg in unname(FOCAL)) {
    rows <- study_rows(st, pg, combos$s196[i], combos$s312[i])
    s <- synth(rows)

    ## LOSO: refit dropping each study in turn
    loso <- vapply(seq_len(nrow(rows)), function(j) {
      stouffer(signed_z(rows$PValue[-j],
                        ifelse(rows$camera_t[-j] > 0, "Up", "Down")))
    }, numeric(1))
    loso_sign <- vapply(seq_len(nrow(rows)), function(j) {
      sgn <- ifelse(rows$camera_t[-j] > 0, 1, -1)
      length(unique(sgn)) == 1L
    }, logical(1))

    ## design-restricted analysis: only GSE196870 + GSE312476
    rr <- rows[rows$dataset %in% c("GSE196870", "GSE312476"), ]
    out[[paste(combos$label[i], st, pg)]] <- data.frame(
      stratum = st, program = pg,
      scheme_GSE196870 = combos$s196[i], scheme_GSE312476 = combos$s312[i],
      combination = combos$label[i],
      k = s$k, n_up = s$n_up, Z = s$Z, p = s$p,
      loso_min_Z = min(loso), loso_max_Z = max(loso),
      loso_all_same_sign = all(loso_sign),
      restricted_k = nrow(rr), restricted_n_up = sum(rr$camera_t > 0),
      stringsAsFactors = FALSE)
  }
}
cd <- do.call(rbind, out); rownames(cd) <- NULL
## BH within stratum x combination over the 5 focal programmes
cd$fdr <- ave(cd$p, interaction(cd$stratum, cd$combination, drop = TRUE),
              FUN = function(p) p.adjust(p, "BH"))
cd$fdr_category <- fdr_category(cd$fdr)
cd$program_code <- program_code(cd$program)
## the "direction count / k, Z, FDR category" cell string used by the plan
cd$cell <- sprintf("%d/%d, Z=%.2f, %s", cd$n_up, cd$k, cd$Z, cd$fdr_category)

write.csv(cd, file.path(REV, "core_direction_robustness_long.csv"), row.names = FALSE)
saveRDS(cd, file.path(REV, "core_direction_robustness.rds"))

## wide form: rows = programme x stratum, columns = scheme combination
wide_cell <- reshape(as.data.frame(cd[, c("stratum", "program_code", "combination", "cell")]),
                     idvar = c("stratum", "program_code"), timevar = "combination",
                     direction = "wide")
names(wide_cell) <- sub("^cell\\.", "", names(wide_cell))
ord <- c("stratum", "program_code",
         "main_S0_S0",
         paste0("GSE196870_", c("S1", "S2", "S3"), "_GSE312476_S0"),
         grep("^GSE196870_S0_GSE312476_T", names(wide_cell), value = TRUE))
wide_cell <- wide_cell[, ord]
program_order <- c("TNFA", "INFL", "UPR", "OXPHOS", "E2F")
wide_cell <- wide_cell[order(match(wide_cell$stratum, c("acute", "h24")),
                             match(wide_cell$program_code, program_order)), ]
write.csv(wide_cell, file.path(REV, "core_direction_robustness.csv"), row.names = FALSE)

cat("combinations:", nrow(combos), " cells:", nrow(cd), "\n")
print(table(cd$combination, cd$stratum))

