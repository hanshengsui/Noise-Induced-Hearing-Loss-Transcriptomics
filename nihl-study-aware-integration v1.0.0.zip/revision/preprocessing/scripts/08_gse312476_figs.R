#!/usr/bin/env Rscript
## A2 step 2 (figures): GSE312476 scale diagnostics, same panel set as GSE196870.
source(file.path(Sys.getenv("A2_SCR"), "common.R"))
suppressPackageStartupMessages(library(readxl))

obj <- readRDS(file.path(REV, "GSE312476_objects.rds"))
cnt <- obj$cnt
grp <- obj$grp

xl <- file.path(DATA, "GSE312476_Table_S1.xlsx")
raw <- as.data.frame(read_excel(xl, sheet = "Bulk_RNA_seq_data", skip = 2))
cols <- c(paste0("Ctrl_", 1:3), paste0("PN0h_", 1:3),
          paste0("PN4h_", 1:3), paste0("PN8h_", 1:3))
dep <- as.matrix(raw[, cols]); storage.mode(dep) <- "numeric"
lg <- log2(dep + 0.5)

save2 <- function(p, stem, w, h) {
  ggsave(file.path(FIGS, paste0(stem, ".pdf")), plot = p, width = w, height = h,
         units = "in", device = "pdf")
  ggsave(file.path(FIGS, paste0(stem, ".png")), plot = p, width = w, height = h,
         units = "in", dpi = 300, device = "png")
}

## 1. density, deposited scale vs log2(x + 0.5)
## the deposited scale is dominated by zeros, so that panel shows only the
## positive values on a log10 axis (the zero fraction is stated in the panel)
dep_pos <- dep[dep > 0]
zero_frac <- mean(dep == 0)
dd <- rbind(
  data.frame(scale_lab = sprintf("deposited abundance, positive values only (log10 axis); %.0f%% of all values are zero",
                                 100 * zero_frac),
             sample_id = rep(cols, each = nrow(dep))[as.vector(dep) > 0],
             value = log10(dep_pos)),
  data.frame(scale_lab = "log2(abundance + 0.5), all values",
             sample_id = rep(cols, each = nrow(lg)),
             value = as.vector(lg)))
dd$group <- as.character(grp)[match(dd$sample_id, cols)]
p1 <- ggplot(dd, aes(value, colour = sample_id, linetype = group)) +
  geom_density(linewidth = 0.35) +
  facet_wrap(~ scale_lab, scales = "free") +
  scale_colour_viridis_d(name = "sample", end = 0.9) +
  scale_linetype_manual(name = "group",
                        values = c(control = "solid", post_0h = "22",
                                   post_4h = "42", post_8h = "13")) +
  labs(x = "expression value (see panel label for the scale)", y = "density") +
  theme_bw(base_size = 9) + theme(legend.key.height = unit(0.3, "cm"))
save2(p1, "fig_GSE312476_density_deposited_vs_log2", 10.4, 4.4)

## 2. mean-variance, both scales (on the filtered S0 gene set)
k0 <- rowSums(cnt > 1) >= 3
mv <- rbind(
  data.frame(scale_lab = "deposited abundance", mean = rowMeans(cnt[k0, , drop = FALSE]),
             sd = apply(cnt[k0, , drop = FALSE], 1, sd)),
  data.frame(scale_lab = "log2(abundance + 0.5)", mean = rowMeans(lg[k0, , drop = FALSE]),
             sd = apply(lg[k0, , drop = FALSE], 1, sd)))
p2 <- ggplot(mv, aes(mean, sd)) +
  geom_point(size = 0.2, alpha = 0.3, colour = "grey35") +
  geom_smooth(method = "loess", span = 0.4, se = FALSE, colour = "#B2182B", linewidth = 0.6) +
  facet_wrap(~ scale_lab, scales = "free") +
  labs(x = "gene mean across 12 libraries", y = "gene SD across 12 libraries") +
  theme_bw(base_size = 9)
save2(p2, "fig_GSE312476_mean_variance", 9.0, 4.0)

## 3. sample QC: PCA, correlation heatmap, detection counts
E <- lg[k0, ]
vk <- head(order(apply(E, 1, var), decreasing = TRUE), 500)
pv <- prcomp(t(E[vk, ]), scale. = FALSE)
ve <- round(100 * summary(pv)$importance[2, 1:2], 1)
pca <- data.frame(PC1 = pv$x[, 1], PC2 = pv$x[, 2], sample_id = colnames(E),
                  group = as.character(grp))
p3 <- ggplot(pca, aes(PC1, PC2, colour = group, label = sample_id)) +
  geom_point(size = 2.6) +
  ggrepel::geom_text_repel(size = 2.2, show.legend = FALSE, min.segment.length = 0,
                           seed = 20261029) +
  scale_colour_manual(values = c(control = "#4D4D4D", post_0h = "#D95F02",
                                 post_4h = "#7570B3", post_8h = "#1B7C8C"), name = "group") +
  labs(x = paste0("PC1 (", ve[1], "%)"), y = paste0("PC2 (", ve[2], "%)")) +
  theme_bw(base_size = 9) + coord_cartesian(clip = "off")
save2(p3, "fig_GSE312476_PCA_top500", 5.8, 4.4)

cr <- cor(E)
ord <- order(grp, colnames(E)); cr <- cr[ord, ord]
cl <- data.frame(s1 = factor(rep(rownames(cr), times = ncol(cr)), levels = rownames(cr)),
                 s2 = factor(rep(colnames(cr), each = nrow(cr)), levels = colnames(cr)),
                 r = as.vector(cr))
p4 <- ggplot(cl, aes(s1, s2, fill = r)) + geom_tile() +
  geom_text(aes(label = sprintf("%.3f", r)), size = 2.0,
            colour = ifelse(as.vector(cr) > 0.95, "white", "black")) +
  scale_fill_viridis_c(name = "Pearson r", limits = c(min(cr), 1)) +
  labs(x = NULL, y = NULL) + theme_bw(base_size = 9) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5, size = 6.5),
        axis.text.y = element_text(size = 6.5), panel.grid = element_blank())
save2(p4, "fig_GSE312476_sample_correlation", 6.6, 5.4)

qc <- data.frame(sample_id = cols, group = as.character(grp),
                 col_sum = colSums(dep), n_gt1 = colSums(dep > 1))
ql <- rbind(
  data.frame(sample_id = qc$sample_id, group = qc$group,
             metric = "deposited abundance sum (x1e3)", value = qc$col_sum / 1e3),
  data.frame(sample_id = qc$sample_id, group = qc$group,
             metric = "features with value > 1", value = qc$n_gt1))
p5 <- ggplot(ql, aes(factor(sample_id, levels = qc$sample_id), value, fill = group)) +
  geom_col(width = 0.72) + facet_wrap(~ metric, scales = "free_y") +
  scale_fill_manual(values = c(control = "#4D4D4D", post_0h = "#D95F02",
                               post_4h = "#7570B3", post_8h = "#1B7C8C"), name = "group") +
  labs(x = NULL, y = NULL) + theme_bw(base_size = 9) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 7))
save2(p5, "fig_GSE312476_library_and_detection", 8.6, 3.8)
cat("GSE312476 figures written\n")
