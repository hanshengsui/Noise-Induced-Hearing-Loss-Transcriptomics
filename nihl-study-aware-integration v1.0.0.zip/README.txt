nihl-study-aware-integration v1.0.0

Study-aware integration of public mouse auditory transcriptomes reveals reproducible inflammatory-proteostasis dynamics after noise exposure.

Public release is pending. Repository URL: [to be inserted]. Zenodo DOI: [to be inserted]. The archive does not assert a published repository or DOI.

The workflow models each dataset separately and combines signed gene-set evidence within temporal strata. It does not concatenate expression matrices across studies. Single-cell inference uses mouse-library-by-broad-class pseudobulk.

Software
R 4.4.3, limma 3.62.2, edgeR 4.4.2 and statmod 1.5.2. Other R dependencies and the Python 3.11 single-cell environment are specified in env/environment.yml and env/single_cell_environment.yml. env/sessionInfo.txt records the R rerun environment. Create the R environment and run Rscript env/install_pinned_bioc.R to install the exact Bioconductor packages into Rlib. Set NIHL_VALIDATION_LIB to an absolute library path if using a different location. A source compiler is required for these packages.

Run from the repository root
1. Rscript run_all.R
2. Rscript scripts/98_smoke_test.R --strict
3. In the single-cell Python environment, run:
   python validation/run_revision_checks.py --line all --rscript /absolute/path/to/Rscript
4. Rscript validation/iut_sensitivity.R
Optional complete later-stratum enumeration: Rscript validation/later_exact.R.

The revision runner accepts --line synthesis, preprocessing or single_cell to run one component. The main pipeline must finish first. Use the Rscript executable belonging to the R environment; use Python from the single-cell environment. Public input downloads require network access. All 31 manifest input files were obtained and MD5-verified for the rerun. Large source inputs, installed runtimes and working intermediates are not distributed in this archive.

The main run writes work/, results/tables/ and results/figures/. The revision runner writes its 28 synthesis, 25 preprocessing and 24 single-cell tables under revision/. revision/TABLE_TO_SCRIPT.csv maps these 77 tables to their generators. revision/synthesis/scripts/run_synthesis.R --network additionally refreshes the GEO sample-overlap ledger. Small frozen inputs and their checksums are retained under revision/*/inputs/frozen_package_results/.

Verification on 2026-11-02
The main pipeline completed all 16 stages and regenerated 18 main result tables. All 48 strict checks passed, including the pinned-version check. All revision components were executed. The 25 preprocessing and 24 single-cell supplemental tables agreed with their prior corrected counterparts within rtol=1e-8 and atol=1e-10. Of 28 synthesis tables, 22 agreed and six changed in permutation quantities after numerical equality was handled consistently. Of 18 main tables, 17 agreed; Table 3 contains four corresponding FDR updates. The 15 synthesis evidence classes were unchanged. The independent single-cell annotation reconstruction matched all 64,208 post-QC assignments; numeric trait differences were below 6e-14.

Permutation exceedance comparisons include numeric ties with tolerance 1e-10 * max(1, abs(observed statistic)). The seed is config/seed.txt (20261029). The primary CAMERA-PR inter-gene correlation is 0.01. validation/iut_sensitivity.csv contains all 50 Hallmarks under the primary, 0.05, 0.1, estimated-correlation and fry settings. The temporal IUT interpretation is conditional on the primary correlation setting; these theoretical IUT P values are not permutation calibrated. Primary IUT tiers use FDR <0.05 for support and 0.05–0.10 for suggestive evidence. Cross-study synthesis uses its separately stated permutation-calibrated evidence classes.

Data and reporting
config/input_manifest.csv identifies the public inputs and checksums. config/samples/ and config/contrasts.yaml define biological units and contrasts. resources/ contains marker panels, gene mappings and gene-set files. MSigDB files remain subject to the MSigDB license terms: https://www.gsea-msigdb.org/gsea/msigdb_license_terms.jsp . GSE196870 deposited values are already log2-scaled and are used directly in the primary analysis; an additional transform is a sensitivity analysis. GSE312476 contains non-integer normalized abundances and is modeled with limma-trend after the stated filter and log transform.

The main figure stage first draws the original-design figures and S1–S7, then redraws Figures 1–6 in the revised layout. Revision figure helpers generate the additional S8–S10 panels. docs/numbering.csv maps manuscript numbering. Figures are visual summaries; the machine-readable tables and the stated inferential families define the numerical results.

License: MIT for the analysis code (LICENSE). See CITATION.cff for manuscript attribution; no archival DOI has yet been assigned.
